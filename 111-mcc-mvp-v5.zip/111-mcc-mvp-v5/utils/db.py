"""
SQLite 데이터 계층 (v5) — Oracle 11테이블에서 벡터/NFS 전용을 제거한 9테이블.

설계(설계참고.html · 핵심 로직)의 Oracle 스키마를 SQLite로 옮긴 단일 마스터 모듈.
- init_db(): 9테이블 CREATE IF NOT EXISTS
- PARSE_JOBS / EQP_PROMPTS / MEA / MOTION_EVENTS / REACT_LOOPS
  / CHAT_SESSIONS / CHAT_MESSAGES / audit_log / LOG_FILES 의 CRUD
- eqp_prompt_load / propose / confirm (장비로드 프롬프트 read/write/lock)
- aggregate_summary (STEP 5 결과 리포트 집계)

NOTE: STEP 4가 생성하는 파서 패키지는 본 모듈에 의존하지 않는다(독립 실행).
      파서는 표준 sqlite3 로 동일 스키마에 직접 INSERT 한다.
"""
from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

OUTPUT_DIR = Path("output")
DB_PATH = OUTPUT_DIR / "events.db"
SANDBOX_DB_PATH = OUTPUT_DIR / "_verify_sandbox.db"

# PARSE_JOBS.STATUS 라이프사이클
STATUS_ORDER = [
    "INIT", "STEP1_DONE", "STEP2_DONE", "STEP3_DONE", "STEP4_DONE", "STEP5_DONE",
]


def now() -> str:
    """밀리초 단위 타임스탬프 문자열."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def new_id() -> str:
    return str(uuid.uuid4())


# ─────────────────────────────────────────────
# 연결 / 스키마
# ─────────────────────────────────────────────
def connect(db_path: str | Path = DB_PATH) -> sqlite3.Connection:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


# 9개 테이블 DDL (CREATE TABLE IF NOT EXISTS) — 샌드박스 DB 에도 동일 적용.
# 타입은 설계 ERD(Oracle) 표기를 그대로 사용. SQLite 는 타입 어피니티 규칙으로
#   VARCHAR2/CHAR/CLOB→TEXT, NUMBER(p,s)→NUMERIC, TIMESTAMP→NUMERIC(문자열은 보존)
# 으로 처리한다. 단, 자동 시퀀스 PK 는 SQLite 규칙상 'INTEGER PRIMARY KEY AUTOINCREMENT'
# 여야 하므로 NUMBER 가 아닌 INTEGER 로 선언한다(= Oracle '자동 시퀀스' 등가).
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS PARSE_JOBS (
    JOB_ID         VARCHAR2(36) PRIMARY KEY,
    USER_ID        VARCHAR2(50),
    EQP_ID         VARCHAR2(50),
    STATUS         VARCHAR2(20) DEFAULT 'INIT',   -- INIT~STEP5_DONE
    CURRENT_STEP   NUMBER(1) DEFAULT 1,           -- 1~5
    EQP_PROMPT_ID  VARCHAR2(36),
    PARSER_PATH    VARCHAR2(500),
    REPORT_PATH    VARCHAR2(500),
    TOTAL_ITER     NUMBER DEFAULT 0,
    CREATED_AT     TIMESTAMP,
    UPDATED_AT     TIMESTAMP,
    ENDED_AT       TIMESTAMP
);

CREATE TABLE IF NOT EXISTS EQP_PROMPTS (
    PROMPT_ID          VARCHAR2(36) PRIMARY KEY,
    EQP_TYPE           VARCHAR2(50),         -- photo/etch/cvd
    EQP_ID             VARCHAR2(50),
    EQP_MODEL          VARCHAR2(100),
    FIRMWARE_VERSION   VARCHAR2(30),
    SCHEMA_VERSION     VARCHAR2(10) DEFAULT '1.0',
    PAIRING_STRATEGY   VARCHAR2(1),          -- A/B/C/D/NULL
    ANALYSIS_STRATEGY  CLOB,                 -- JSON: pair_matrix·instance_regex·noise_codes·pending_pairs·discovery_log
    REGEX_PATTERN      CLOB,                 -- legacy 보조
    LOCKED             CHAR(1) DEFAULT 'N',  -- Y=사람 확정 freeze
    FIRST_RUN_FLAG     CHAR(1) DEFAULT 'Y',
    ENGINEER_SIGNOFF   VARCHAR2(50),
    STRATEGY_LOCKED_AT TIMESTAMP,
    STRATEGY_LOCKED_BY VARCHAR2(50),
    INTERVIEW_MD_PATH  VARCHAR2(500),
    INTERVIEW_SESSION_ID VARCHAR2(36),
    INTERVIEW_TURNS    NUMBER DEFAULT 0,
    INTERVIEW_LLM_CALLS NUMBER DEFAULT 0,
    UPDATED_AT         TIMESTAMP
);

CREATE TABLE IF NOT EXISTS MEA (
    MEA_ID                  INTEGER PRIMARY KEY AUTOINCREMENT,  -- NUMBER 자동 시퀀스
    JOB_ID                  VARCHAR2(36),    -- ② PARSE_JOBS 참조
    DATETIME                TIMESTAMP,       -- ② regex 추출 타임스탬프
    EVENT_CODE              VARCHAR2(50),    -- ② 원시 이벤트 코드 (LO-XXXX)
    ORIGIN_MESSAGE          VARCHAR2(2000),  -- ② 원본 로그 라인
    EVENT_NAME              VARCHAR2(200),   -- ③ LLM 추론 이벤트 명칭
    SIGNAL                  VARCHAR2(10),    -- ③ START/END/MID
    START_CODE              VARCHAR2(50),    -- ③ 모션 시작 코드
    END_CODE                VARCHAR2(50),    -- ③ 모션 종료 코드
    LLM_INTERPRETATION      CLOB,            -- ③ HCP LLM 해석 전문
    IS_MOTION_RELATED       CHAR(1),         -- ③④ 모션 관련 여부 (최종) Y/N
    ENGINEER_INTERPRETATION CLOB,            -- ④ 엔지니어 직접 해석
    REMARK                  VARCHAR2(500),   -- ②③④ 비고 (task/wafer/lot/field prepend)
    PROCESS_TIME_MS         NUMBER(12,3),    -- Step4 파서 실행 후 계산
    CODE_GEN_OK             CHAR(1),         -- Step4 코드생성 검증 완료 Y/N
    CREATED_AT              TIMESTAMP,       -- ② 레코드 생성
    UPDATED_AT              TIMESTAMP        -- 전체 최종 수정
);

CREATE TABLE IF NOT EXISTS MOTION_EVENTS (
    EVENT_ID       INTEGER PRIMARY KEY AUTOINCREMENT,  -- NUMBER 자동 시퀀스
    JOB_ID         VARCHAR2(36),
    EQP_ID         VARCHAR2(50),
    MOTION_TYPE    VARCHAR2(50),
    START_TS       TIMESTAMP,
    END_TS         TIMESTAMP,
    DURATION_MS    NUMBER,
    ENTITY_KEYS    CLOB,                     -- JSON: task/wafer/lot/field
    PARSER_VERSION VARCHAR2(10),
    TS             TIMESTAMP
);

CREATE TABLE IF NOT EXISTS REACT_LOOPS (
    LOOP_ID      INTEGER PRIMARY KEY AUTOINCREMENT,  -- NUMBER 자동 시퀀스
    JOB_ID       VARCHAR2(36),
    ITER_N       NUMBER(2),                  -- 1~10
    STATUS       VARCHAR2(15),               -- MISMATCH/PASS/TIMEOUT
    DIFF_JSON    CLOB,                       -- 모듈별 start/end/time diff
    STDERR       CLOB,
    PARSER_PATH  VARCHAR2(500),
    DURATION_S   NUMBER(8,2),
    TS           TIMESTAMP
);

CREATE TABLE IF NOT EXISTS CHAT_SESSIONS (
    SESSION_ID             VARCHAR2(36) PRIMARY KEY,
    JOB_ID                 VARCHAR2(36),
    EQP_ID                 VARCHAR2(50),
    ENGINEER_ID            VARCHAR2(50),
    SESSION_PHASE          VARCHAR2(30),     -- interview/preflight_review/labeling_review
    STATE                  VARCHAR2(15) DEFAULT 'ACTIVE',
    TURN_COUNT             NUMBER DEFAULT 0,
    LLM_CALL_COUNT         NUMBER DEFAULT 0,
    CURRENT_SUMMARY        CLOB,             -- rolling 요약
    STRUCTURED_STATE_MIRROR CLOB,            -- EQP_PROMPTS.draft 미러
    STARTED_AT             TIMESTAMP,
    ENDED_AT               TIMESTAMP
);

CREATE TABLE IF NOT EXISTS CHAT_MESSAGES (
    MSG_ID       INTEGER PRIMARY KEY AUTOINCREMENT,  -- NUMBER 자동 시퀀스
    SESSION_ID   VARCHAR2(36),
    TURN_N       NUMBER,
    ROLE         VARCHAR2(10),               -- user/assistant/system
    CONTENT      CLOB,
    TS           TIMESTAMP,
    LLM_MODEL    VARCHAR2(50),
    TOKEN_COUNT  NUMBER
);

CREATE TABLE IF NOT EXISTS audit_log (
    AUDIT_ID              VARCHAR2(36) PRIMARY KEY,
    JOB_ID                VARCHAR2(36),
    ENGINEER_ID           VARCHAR2(50),
    ACTION                VARCHAR2(50),      -- interview/preflight/confirm
    ROW_ID                VARCHAR2(100),
    BEFORE_AFTER_SNAPSHOT CLOB,
    TS                    TIMESTAMP
);

CREATE TABLE IF NOT EXISTS LOG_FILES (
    FILE_SEQ     INTEGER PRIMARY KEY AUTOINCREMENT,  -- NUMBER 자동 시퀀스
    JOB_ID       VARCHAR2(36),
    FILE_NAME    VARCHAR2(200),
    FILE_PATH    VARCHAR2(500),
    FILE_SIZE_MB NUMBER(10,2),
    TOTAL_LINES  NUMBER,
    ENCODING     VARCHAR2(20),
    SELECTED     CHAR(1) DEFAULT 'N'
);
"""


def init_db(db_path: str | Path = DB_PATH) -> None:
    """9테이블을 생성한다(이미 있으면 무시). 샌드박스 DB 초기화에도 사용."""
    conn = connect(db_path)
    try:
        conn.executescript(SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()


def reset_sandbox() -> Path:
    """VERIFY용 샌드박스 DB를 새로 만든다(기존 삭제 후 스키마 생성)."""
    if SANDBOX_DB_PATH.exists():
        SANDBOX_DB_PATH.unlink()
    init_db(SANDBOX_DB_PATH)
    return SANDBOX_DB_PATH


def _row_to_dict(row: sqlite3.Row | None) -> dict | None:
    return dict(row) if row is not None else None


# ─────────────────────────────────────────────
# PARSE_JOBS
# ─────────────────────────────────────────────
def create_job(user_id: str, eqp_id: str) -> str:
    job_id = new_id()
    ts = now()
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO PARSE_JOBS (JOB_ID, USER_ID, EQP_ID, STATUS, CURRENT_STEP, CREATED_AT, UPDATED_AT) "
            "VALUES (?,?,?,?,?,?,?)",
            (job_id, user_id, eqp_id, "INIT", 1, ts, ts),
        )
        conn.commit()
    finally:
        conn.close()
    return job_id


def get_job(job_id: str) -> dict | None:
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM PARSE_JOBS WHERE JOB_ID=?", (job_id,))
        return _row_to_dict(cur.fetchone())
    finally:
        conn.close()


def latest_job(eqp_id: str | None = None) -> dict | None:
    """가장 최근 작업 1건(있으면). 앱 재시작 시 진행 복원용."""
    conn = connect()
    try:
        if eqp_id:
            cur = conn.execute(
                "SELECT * FROM PARSE_JOBS WHERE EQP_ID=? ORDER BY CREATED_AT DESC LIMIT 1",
                (eqp_id,),
            )
        else:
            cur = conn.execute("SELECT * FROM PARSE_JOBS ORDER BY CREATED_AT DESC LIMIT 1")
        return _row_to_dict(cur.fetchone())
    finally:
        conn.close()


def update_job(job_id: str, **fields: Any) -> None:
    """PARSE_JOBS 임의 컬럼 갱신 + UPDATED_AT 자동."""
    if not fields:
        return
    fields["UPDATED_AT"] = now()
    cols = ", ".join(f"{k}=?" for k in fields)
    conn = connect()
    try:
        conn.execute(f"UPDATE PARSE_JOBS SET {cols} WHERE JOB_ID=?", (*fields.values(), job_id))
        conn.commit()
    finally:
        conn.close()


def advance_status(job_id: str, status: str, current_step: int) -> None:
    """STATUS/CURRENT_STEP 전진(역행 방지 — 더 높은 단계로만)."""
    job = get_job(job_id)
    if job is None:
        return
    cur_idx = STATUS_ORDER.index(job["STATUS"]) if job["STATUS"] in STATUS_ORDER else 0
    new_idx = STATUS_ORDER.index(status) if status in STATUS_ORDER else 0
    fields: dict[str, Any] = {"CURRENT_STEP": current_step}
    if new_idx >= cur_idx:
        fields["STATUS"] = status
    if status == "STEP5_DONE":
        fields["ENDED_AT"] = now()
    update_job(job_id, **fields)


# ─────────────────────────────────────────────
# EQP_PROMPTS (장비로드 프롬프트)
# ─────────────────────────────────────────────
def _default_analysis_strategy() -> dict:
    return {
        "pair_matrix": [],
        "instance_regex": {},
        "noise_codes": [],
        "pending_pairs": [],
        "confirmed_pairs": 0,
        "discovery_log": [],
    }


def eqp_prompt_load(eqp_id: str) -> dict | None:
    """EQP_PROMPTS row 로드. ANALYSIS_STRATEGY 는 dict 로 파싱해 'analysis' 키에 담는다."""
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM EQP_PROMPTS WHERE EQP_ID=? ORDER BY UPDATED_AT DESC LIMIT 1", (eqp_id,))
        row = _row_to_dict(cur.fetchone())
    finally:
        conn.close()
    if row is None:
        return None
    try:
        row["analysis"] = json.loads(row.get("ANALYSIS_STRATEGY") or "{}")
    except Exception:
        row["analysis"] = _default_analysis_strategy()
    return row


def is_first_run(eqp_id: str) -> bool:
    """row 없음 또는 ANALYSIS_STRATEGY NULL/빈값 → First-Run."""
    row = eqp_prompt_load(eqp_id)
    if row is None:
        return True
    return not (row.get("analysis") or {}).get("pair_matrix")


def eqp_prompt_insert(
    eqp_id: str,
    eqp_type: str,
    analysis: dict,
    eqp_model: str = "",
    firmware_version: str = "",
    interview_md_path: str = "",
    interview_session_id: str = "",
    interview_turns: int = 0,
    interview_llm_calls: int = 0,
) -> str:
    """STEP 2-④ 인터뷰 합의 → EQP_PROMPTS INSERT (LOCKED=N, draft)."""
    prompt_id = new_id()
    ts = now()
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO EQP_PROMPTS (PROMPT_ID, EQP_TYPE, EQP_ID, EQP_MODEL, FIRMWARE_VERSION, "
            "SCHEMA_VERSION, PAIRING_STRATEGY, ANALYSIS_STRATEGY, LOCKED, FIRST_RUN_FLAG, "
            "INTERVIEW_MD_PATH, INTERVIEW_SESSION_ID, INTERVIEW_TURNS, INTERVIEW_LLM_CALLS, UPDATED_AT) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                prompt_id, eqp_type, eqp_id, eqp_model, firmware_version,
                "1.0", None, json.dumps(analysis, ensure_ascii=False), "N", "Y",
                interview_md_path, interview_session_id, interview_turns, interview_llm_calls, ts,
            ),
        )
        conn.commit()
    finally:
        conn.close()
    return prompt_id


def eqp_prompt_update_analysis(eqp_id: str, analysis: dict) -> None:
    """ANALYSIS_STRATEGY 전체 갱신(preflight overlay 등). LOCKED 무관."""
    conn = connect()
    try:
        conn.execute(
            "UPDATE EQP_PROMPTS SET ANALYSIS_STRATEGY=?, UPDATED_AT=? WHERE EQP_ID=?",
            (json.dumps(analysis, ensure_ascii=False), now(), eqp_id),
        )
        conn.commit()
    finally:
        conn.close()


def eqp_prompt_propose(eqp_id: str, new_pairs: list[dict], who: str = "llm", what: str = "") -> None:
    """LLM이 발견한 신규 페어를 pending_pairs[] 에 append + discovery_log 기록."""
    row = eqp_prompt_load(eqp_id)
    if row is None:
        return
    analysis = row.get("analysis") or _default_analysis_strategy()
    pending = analysis.setdefault("pending_pairs", [])
    existing = {(p.get("start"), p.get("end")) for p in pending}
    for p in new_pairs:
        key = (p.get("start"), p.get("end"))
        if key not in existing and key != (None, None):
            pending.append(p)
            existing.add(key)
    analysis.setdefault("discovery_log", []).append(
        {"ts": now(), "who": who, "what": what or f"{len(new_pairs)} pairs proposed"}
    )
    eqp_prompt_update_analysis(eqp_id, analysis)


def eqp_prompt_confirm(
    eqp_id: str,
    pairing_strategy: str,
    engineer_id: str,
    confirmed_pairs: list[dict] | None = None,
    job_id: str | None = None,
) -> str:
    """STEP 3-⑤ 엔지니어 확정 — pending→pair_matrix 이동, pairing_strategy 잠금(LOCKED=Y) + audit."""
    row = eqp_prompt_load(eqp_id)
    if row is None:
        raise ValueError(f"EQP_PROMPTS row 없음: {eqp_id}")
    before = json.dumps({"LOCKED": row.get("LOCKED"), "PAIRING_STRATEGY": row.get("PAIRING_STRATEGY")}, ensure_ascii=False)

    analysis = row.get("analysis") or _default_analysis_strategy()
    if confirmed_pairs is not None:
        analysis["pair_matrix"] = confirmed_pairs
    # pending 중 사람이 받아들인 것은 confirmed_pairs 로 이미 반영됨 → pending 비움
    analysis["pending_pairs"] = []
    analysis["confirmed_pairs"] = len(analysis.get("pair_matrix", []))
    analysis.setdefault("discovery_log", []).append(
        {"ts": now(), "who": f"engineer:{engineer_id}", "what": f"strategy={pairing_strategy} confirmed"}
    )

    ts = now()
    conn = connect()
    try:
        conn.execute(
            "UPDATE EQP_PROMPTS SET PAIRING_STRATEGY=?, ANALYSIS_STRATEGY=?, LOCKED='Y', FIRST_RUN_FLAG='N', "
            "ENGINEER_SIGNOFF=?, STRATEGY_LOCKED_AT=?, STRATEGY_LOCKED_BY=?, UPDATED_AT=? WHERE EQP_ID=?",
            (pairing_strategy, json.dumps(analysis, ensure_ascii=False), engineer_id, ts, engineer_id, ts, eqp_id),
        )
        conn.commit()
    finally:
        conn.close()

    after = json.dumps({"LOCKED": "Y", "PAIRING_STRATEGY": pairing_strategy}, ensure_ascii=False)
    return audit_insert(job_id or "", engineer_id, "confirm", row.get("PROMPT_ID", eqp_id), f"{before} => {after}")


# ─────────────────────────────────────────────
# MEA
# ─────────────────────────────────────────────
MEA_INSERT_COLS = [
    "JOB_ID", "DATETIME", "EVENT_CODE", "ORIGIN_MESSAGE", "REMARK", "CREATED_AT", "UPDATED_AT",
]


def mea_clear(job_id: str) -> None:
    conn = connect()
    try:
        conn.execute("DELETE FROM MEA WHERE JOB_ID=?", (job_id,))
        conn.commit()
    finally:
        conn.close()


def mea_bulk_insert(job_id: str, rows: list[dict]) -> int:
    """STEP 3-③ regex 전수 추출 → MEA bulk INSERT. rows: {datetime, event_code, origin_message, remark}."""
    ts = now()
    payload = [
        (job_id, r.get("datetime"), r.get("event_code"), r.get("origin_message"), r.get("remark"), ts, ts)
        for r in rows
    ]
    conn = connect()
    try:
        conn.executemany(
            "INSERT INTO MEA (JOB_ID, DATETIME, EVENT_CODE, ORIGIN_MESSAGE, REMARK, CREATED_AT, UPDATED_AT) "
            "VALUES (?,?,?,?,?,?,?)",
            payload,
        )
        conn.commit()
        return len(payload)
    finally:
        conn.close()


def mea_select(job_id: str, motion_only: bool = False) -> list[dict]:
    conn = connect()
    try:
        sql = "SELECT * FROM MEA WHERE JOB_ID=?"
        if motion_only:
            sql += " AND IS_MOTION_RELATED='Y'"
        sql += " ORDER BY DATETIME, MEA_ID"
        cur = conn.execute(sql, (job_id,))
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


_MEA_UPDATABLE = {
    "EVENT_NAME", "SIGNAL", "START_CODE", "END_CODE", "LLM_INTERPRETATION",
    "IS_MOTION_RELATED", "ENGINEER_INTERPRETATION", "REMARK", "PROCESS_TIME_MS", "CODE_GEN_OK",
}


def mea_update(mea_id: int, fields: dict) -> None:
    fields = {k: v for k, v in fields.items() if k in _MEA_UPDATABLE}
    if not fields:
        return
    fields["UPDATED_AT"] = now()
    cols = ", ".join(f"{k}=?" for k in fields)
    conn = connect()
    try:
        conn.execute(f"UPDATE MEA SET {cols} WHERE MEA_ID=?", (*fields.values(), mea_id))
        conn.commit()
    finally:
        conn.close()


def mea_update_batch(updates: list[dict]) -> None:
    """updates: [{'mea_id': int, 'fields': {...}}, ...] — 청크당 1트랜잭션."""
    if not updates:
        return
    ts = now()
    conn = connect()
    try:
        for u in updates:
            fields = {k: v for k, v in (u.get("fields") or {}).items() if k in _MEA_UPDATABLE}
            if not fields:
                continue
            fields["UPDATED_AT"] = ts
            cols = ", ".join(f"{k}=?" for k in fields)
            conn.execute(f"UPDATE MEA SET {cols} WHERE MEA_ID=?", (*fields.values(), u["mea_id"]))
        conn.commit()
    finally:
        conn.close()


# ─────────────────────────────────────────────
# MOTION_EVENTS
# ─────────────────────────────────────────────
def motion_events_clear(job_id: str) -> None:
    conn = connect()
    try:
        conn.execute("DELETE FROM MOTION_EVENTS WHERE JOB_ID=?", (job_id,))
        conn.commit()
    finally:
        conn.close()


def motion_events_bulk_insert(job_id: str, eqp_id: str, rows: list[dict], parser_version: str = "v1") -> int:
    """STEP 4-⑤ DONE — 파서 산출 motions 를 MOTION_EVENTS 에 적재(정렬 후)."""
    ts = now()
    ordered = sorted(rows, key=lambda m: (
        str(m.get("start_ts") or m.get("START_TS") or ""),
        str(m.get("motion_type") or m.get("MOTION_TYPE") or ""),
        str(m.get("entity_keys") or m.get("ENTITY_KEYS") or ""),
    ))
    payload = [
        (
            job_id, eqp_id,
            m.get("motion_type") or m.get("MOTION_TYPE"),
            m.get("start_ts") or m.get("START_TS"),
            m.get("end_ts") or m.get("END_TS"),
            m.get("duration_ms") if m.get("duration_ms") is not None else m.get("DURATION_MS"),
            m.get("entity_keys") or m.get("ENTITY_KEYS"),
            parser_version, ts,
        )
        for m in ordered
    ]
    conn = connect()
    try:
        conn.executemany(
            "INSERT INTO MOTION_EVENTS (JOB_ID, EQP_ID, MOTION_TYPE, START_TS, END_TS, DURATION_MS, "
            "ENTITY_KEYS, PARSER_VERSION, TS) VALUES (?,?,?,?,?,?,?,?,?)",
            payload,
        )
        conn.commit()
        return len(payload)
    finally:
        conn.close()


def motion_events_select(job_id: str) -> list[dict]:
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM MOTION_EVENTS WHERE JOB_ID=? ORDER BY START_TS, EVENT_ID", (job_id,))
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


# ─────────────────────────────────────────────
# REACT_LOOPS
# ─────────────────────────────────────────────
def react_loop_insert(
    job_id: str, iter_n: int, status: str, diff_json: dict | str,
    stderr: str = "", parser_path: str = "", duration_s: float = 0.0,
) -> None:
    if isinstance(diff_json, (dict, list)):
        diff_json = json.dumps(diff_json, ensure_ascii=False)
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO REACT_LOOPS (JOB_ID, ITER_N, STATUS, DIFF_JSON, STDERR, PARSER_PATH, DURATION_S, TS) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (job_id, iter_n, status, diff_json, stderr, parser_path, duration_s, now()),
        )
        conn.commit()
    finally:
        conn.close()


def react_loops_select(job_id: str) -> list[dict]:
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM REACT_LOOPS WHERE JOB_ID=? ORDER BY ITER_N", (job_id,))
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


# ─────────────────────────────────────────────
# CHAT_SESSIONS / CHAT_MESSAGES (L2 메모리)
# ─────────────────────────────────────────────
def chat_session_find_or_create(job_id: str, eqp_id: str, engineer_id: str, phase: str) -> str:
    """동일 (job, phase) ACTIVE 세션이 있으면 재사용, 없으면 생성."""
    conn = connect()
    try:
        cur = conn.execute(
            "SELECT SESSION_ID FROM CHAT_SESSIONS WHERE JOB_ID=? AND SESSION_PHASE=? AND STATE='ACTIVE' "
            "ORDER BY STARTED_AT DESC LIMIT 1",
            (job_id, phase),
        )
        row = cur.fetchone()
        if row:
            return row["SESSION_ID"]
        session_id = new_id()
        conn.execute(
            "INSERT INTO CHAT_SESSIONS (SESSION_ID, JOB_ID, EQP_ID, ENGINEER_ID, SESSION_PHASE, STATE, "
            "TURN_COUNT, LLM_CALL_COUNT, STARTED_AT) VALUES (?,?,?,?,?,?,?,?,?)",
            (session_id, job_id, eqp_id, engineer_id, phase, "ACTIVE", 0, 0, now()),
        )
        conn.commit()
        return session_id
    finally:
        conn.close()


def chat_session_get(session_id: str) -> dict | None:
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM CHAT_SESSIONS WHERE SESSION_ID=?", (session_id,))
        return _row_to_dict(cur.fetchone())
    finally:
        conn.close()


def chat_session_update(session_id: str, **fields: Any) -> None:
    if not fields:
        return
    cols = ", ".join(f"{k}=?" for k in fields)
    conn = connect()
    try:
        conn.execute(f"UPDATE CHAT_SESSIONS SET {cols} WHERE SESSION_ID=?", (*fields.values(), session_id))
        conn.commit()
    finally:
        conn.close()


def chat_session_complete(session_id: str) -> None:
    chat_session_update(session_id, STATE="COMPLETED", ENDED_AT=now())


def chat_message_insert(
    session_id: str, role: str, content: str, llm_model: str = "", token_count: int = 0,
) -> int:
    """턴 추가 + 세션 TURN_COUNT 증가(assistant 응답 시 LLM_CALL_COUNT 증가)."""
    conn = connect()
    try:
        cur = conn.execute("SELECT COALESCE(MAX(TURN_N),0) AS m FROM CHAT_MESSAGES WHERE SESSION_ID=?", (session_id,))
        turn_n = cur.fetchone()["m"] + 1
        conn.execute(
            "INSERT INTO CHAT_MESSAGES (SESSION_ID, TURN_N, ROLE, CONTENT, TS, LLM_MODEL, TOKEN_COUNT) "
            "VALUES (?,?,?,?,?,?,?)",
            (session_id, turn_n, role, content, now(), llm_model, token_count),
        )
        if role == "assistant":
            conn.execute(
                "UPDATE CHAT_SESSIONS SET TURN_COUNT=TURN_COUNT+1, LLM_CALL_COUNT=LLM_CALL_COUNT+1 WHERE SESSION_ID=?",
                (session_id,),
            )
        conn.commit()
        return turn_n
    finally:
        conn.close()


def chat_messages_recent(session_id: str, n: int = 10) -> list[dict]:
    """최근 n턴(시간순 오름차순)."""
    conn = connect()
    try:
        cur = conn.execute(
            "SELECT * FROM CHAT_MESSAGES WHERE SESSION_ID=? ORDER BY TURN_N DESC LIMIT ?",
            (session_id, n),
        )
        rows = [dict(r) for r in cur.fetchall()]
        return list(reversed(rows))
    finally:
        conn.close()


def chat_messages_all(session_id: str) -> list[dict]:
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM CHAT_MESSAGES WHERE SESSION_ID=? ORDER BY TURN_N", (session_id,))
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


# ─────────────────────────────────────────────
# audit_log
# ─────────────────────────────────────────────
def audit_insert(job_id: str, engineer_id: str, action: str, row_id: str, snapshot: str) -> str:
    audit_id = new_id()
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO audit_log (AUDIT_ID, JOB_ID, ENGINEER_ID, ACTION, ROW_ID, BEFORE_AFTER_SNAPSHOT, TS) "
            "VALUES (?,?,?,?,?,?,?)",
            (audit_id, job_id, engineer_id, action, row_id, snapshot, now()),
        )
        conn.commit()
    finally:
        conn.close()
    return audit_id


# ─────────────────────────────────────────────
# LOG_FILES
# ─────────────────────────────────────────────
def log_files_replace(job_id: str, file_infos: list[dict], selected_paths: set[str]) -> None:
    """선택 파일 메타를 LOG_FILES 에 기록(기존 job 레코드는 교체)."""
    conn = connect()
    try:
        conn.execute("DELETE FROM LOG_FILES WHERE JOB_ID=?", (job_id,))
        payload = [
            (
                job_id, info.get("rel"), info.get("path"), info.get("size_mb"),
                info.get("total_lines"), info.get("encoding"),
                "Y" if info.get("path") in selected_paths else "N",
            )
            for info in file_infos
        ]
        conn.executemany(
            "INSERT INTO LOG_FILES (JOB_ID, FILE_NAME, FILE_PATH, FILE_SIZE_MB, TOTAL_LINES, ENCODING, SELECTED) "
            "VALUES (?,?,?,?,?,?,?)",
            payload,
        )
        conn.commit()
    finally:
        conn.close()


def log_files_selected(job_id: str) -> list[dict]:
    conn = connect()
    try:
        cur = conn.execute("SELECT * FROM LOG_FILES WHERE JOB_ID=? AND SELECTED='Y'", (job_id,))
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


# ─────────────────────────────────────────────
# STEP 5 집계
# ─────────────────────────────────────────────
def aggregate_summary(job_id: str) -> dict:
    """5테이블 집계 → summary dict (STEP 5 리포트/대시보드용)."""
    conn = connect()
    try:
        def scalar(sql: str, params=()) -> Any:
            return conn.execute(sql, params).fetchone()[0]

        total_events = scalar("SELECT COUNT(*) FROM MEA WHERE JOB_ID=?", (job_id,))
        motion_events_mea = scalar("SELECT COUNT(*) FROM MEA WHERE JOB_ID=? AND IS_MOTION_RELATED='Y'", (job_id,))
        paired = scalar("SELECT COUNT(*) FROM MOTION_EVENTS WHERE JOB_ID=?", (job_id,))
        avg_ms = scalar("SELECT AVG(DURATION_MS) FROM MOTION_EVENTS WHERE JOB_ID=? AND DURATION_MS IS NOT NULL", (job_id,))
        iter_count = scalar("SELECT COUNT(*) FROM REACT_LOOPS WHERE JOB_ID=?", (job_id,))
        llm_calls = scalar("SELECT COALESCE(SUM(LLM_CALL_COUNT),0) FROM CHAT_SESSIONS WHERE JOB_ID=?", (job_id,))

        # 모션 유형 분포
        cur = conn.execute(
            "SELECT MOTION_TYPE, COUNT(*) AS cnt FROM MOTION_EVENTS WHERE JOB_ID=? GROUP BY MOTION_TYPE ORDER BY cnt DESC",
            (job_id,),
        )
        motion_dist = {r["MOTION_TYPE"]: r["cnt"] for r in cur.fetchall()}

        # ReAct 수렴(이터별 상태)
        cur = conn.execute(
            "SELECT ITER_N, STATUS FROM REACT_LOOPS WHERE JOB_ID=? ORDER BY ITER_N", (job_id,)
        )
        iter_convergence = [{"iter": r["ITER_N"], "status": r["STATUS"]} for r in cur.fetchall()]

        job = get_job(job_id) or {}
        eqp = eqp_prompt_load(job.get("EQP_ID", "")) or {}
    finally:
        conn.close()

    return {
        "job_id": job_id,
        "eqp_id": job.get("EQP_ID"),
        "status": job.get("STATUS"),
        "pairing_strategy": eqp.get("PAIRING_STRATEGY"),
        "total_events": total_events,
        "motion_events_mea": motion_events_mea,
        "paired_motions": paired,
        "avg_process_time_ms": round(avg_ms, 1) if avg_ms else 0.0,
        "react_iters": iter_count,
        "llm_calls": llm_calls,
        "motion_type_dist": motion_dist,
        "iter_convergence": iter_convergence,
    }
