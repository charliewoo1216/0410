"""calculate_process_time.py — carry-state 페어링 → process_time (LLM 0회)."""
import json
from collections import defaultdict
from datetime import datetime

DT_FMT = "%m/%d/%Y %H:%M:%S.%f"


def _ek(ev, strategy):
    if strategy == "A":
        return (ev.get("task", ""), ev.get("wafer", ""), ev.get("lot", ""), ev.get("field", ""))
    if strategy == "B":
        return (ev.get("wafer", ""), ev.get("lot", ""))
    if strategy == "C":
        return (ev.get("task", ""),)
    if strategy == "D":
        if ev.get("wafer") or ev.get("lot"):
            return (ev.get("wafer", ""), ev.get("lot", ""))
        return (ev.get("task", ""),)
    return (ev.get("task", ""),)


def _key(ev):
    sig = ev.get("signal", "")
    rank = 0 if sig == "START" else (1 if sig == "END" else 2)
    return (ev.get("datetime", ""), rank, ev.get("code", ""),
            ev.get("task", ""), ev.get("wafer", ""), ev.get("lot", ""), ev.get("field", ""))


def pair_and_time(starts, ends, pair_matrix, strategy):
    start_codes = {p["start"] for p in pair_matrix}
    end_to_start = {p["end"]: p["start"] for p in pair_matrix}
    end_to_motion = {p["end"]: p.get("motion", "motion") for p in pair_matrix}
    pop_i = 0 if strategy == "B" else -1

    events = starts + ends
    ordered = sorted(events, key=_key)
    open_map = defaultdict(list)
    motions = []
    for ev in ordered:
        code = ev["code"]
        if code in start_codes:
            open_map[(code, _ek(ev, strategy))].append(ev)
        elif code in end_to_start:
            sc = end_to_start[code]
            key = (sc, _ek(ev, strategy))
            if open_map[key]:
                s = open_map[key].pop(pop_i)
                try:
                    sd = datetime.strptime(s["datetime"], DT_FMT)
                    ed = datetime.strptime(ev["datetime"], DT_FMT)
                    dur = round((ed - sd).total_seconds() * 1000.0, 3)
                except Exception:
                    dur = None
                ek = {k: s.get(k, "") for k in ("task", "wafer", "lot", "field")}
                motions.append({
                    "motion_type": end_to_motion.get(code, "motion"),
                    "start_ts": s["datetime"], "end_ts": ev["datetime"],
                    "duration_ms": dur,
                    "entity_keys": json.dumps(ek, ensure_ascii=False, sort_keys=True),
                })
    mea_rows = [{"datetime": e["datetime"], "code": e["code"], "signal": e["signal"]} for e in events]
    return motions, mea_rows
