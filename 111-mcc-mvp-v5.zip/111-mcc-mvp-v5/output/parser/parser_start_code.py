"""parser_start_code.py — start_code 추출 (LLM 0회)."""
import re


def extract_starts(lines, regex, start_codes):
    rc = {k: re.compile(v) for k, v in regex.items()}
    out = []
    for ln in lines:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        mc = rc["code"].search(ln)
        if not mc or mc.group(1) not in start_codes:
            continue
        if "started" not in ln.lower():
            continue
        out.append(_row(rc, ln, mc.group(1), "START"))
    return out


def _row(rc, ln, code, signal):
    def g(k):
        m = rc[k].search(ln)
        return m.group(1) if m else ""
    return {"datetime": g("datetime"), "code": code, "task": g("task_id"),
            "wafer": g("wafer"), "lot": g("lot"), "field": g("field"),
            "origin": ln.rstrip("\n"), "signal": signal}
