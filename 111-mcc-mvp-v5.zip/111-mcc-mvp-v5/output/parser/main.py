"""main.py — 4-모듈 오케스트레이션 · 단일 진입점.
사용: python main.py --input <log> --db <sqlite> [--job <id>]
실행 시 LLM 호출 0회 · 결정론(byte-equal).
"""
import argparse
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from parser_start_code import extract_starts
from parser_end_code import extract_ends
from calculate_process_time import pair_and_time

# ── 인라인 codegen_strategy (STEP 3 확정값) ──
REGEX = {
    "datetime": "(\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}:\\d{2}\\.\\d{4})",
    "machine": "Machine:(\\w+)",
    "source": "(LOMWx\\w+\\.\\w+)",
    "code": "SYSTEM EVENT:\\s*(LO-\\w+)",
    "task_id": "LOMW\\[(\\d+)\\]",
    "wafer": "wafer number (\\d+)",
    "lot": "lot id (\\d+)",
    "field": "field (\\d+)"
}
PAIR_MATRIX = [
    {
        "start": "LO-806F",
        "end": "LO-8070",
        "motion": "offset",
        "source": "LOMWxKF_offset.c",
        "count": 480,
        "conf": "confirmed"
    },
    {
        "start": "LO-8053",
        "end": "LO-8054",
        "motion": "pre_scan",
        "source": "LOMWxKE_pre_scan.c",
        "count": 480,
        "conf": "confirmed"
    },
    {
        "start": "LO-8063",
        "end": "LO-8064",
        "motion": "settle",
        "source": "LOMWxKS_settle.c",
        "count": 480,
        "conf": "confirmed"
    },
    {
        "start": "LO-8061",
        "end": "LO-8062",
        "motion": "move_stage",
        "source": "LOMWxKS_move_stage.c",
        "count": 480,
        "conf": "confirmed"
    },
    {
        "start": "LO-8051",
        "end": "LO-8052",
        "motion": "expose",
        "source": "LOMWxKE_expose.c",
        "count": 480,
        "conf": "confirmed"
    },
    {
        "start": "LO-8037",
        "end": "LO-8038",
        "motion": "wafer_map",
        "source": "LOMWxKM_wafer_map.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8021",
        "end": "LO-8022",
        "motion": "prealign",
        "source": "LOMWxKA_prealign.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8017",
        "end": "LO-8018",
        "motion": "read_id",
        "source": "LOMWxKW_read_id.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8033",
        "end": "LO-8034",
        "motion": "tilt_adj",
        "source": "LOMWxKL_tilt_adj.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-802D",
        "end": "LO-802E",
        "motion": "align",
        "source": "LOMWxKA_align.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-801D",
        "end": "LO-801E",
        "motion": "transfer",
        "source": "LOMWxKW_transfer.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-801F",
        "end": "LO-8020",
        "motion": "chuck",
        "source": "LOMWxKW_chuck.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8031",
        "end": "LO-8032",
        "motion": "level",
        "source": "LOMWxKL_level.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-801B",
        "end": "LO-801C",
        "motion": "unload_wafer",
        "source": "LOMWxKL_unload_wafer.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8023",
        "end": "LO-8024",
        "motion": "mark_search",
        "source": "LOMWxKA_mark_search.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8019",
        "end": "LO-801A",
        "motion": "load_wafer",
        "source": "LOMWxKL_load_wafer.c",
        "count": 32,
        "conf": "confirmed"
    },
    {
        "start": "LO-8067",
        "end": "LO-8068",
        "motion": "z_move",
        "source": "LOMWxKS_z_move.c",
        "count": 16,
        "conf": "confirmed"
    },
    {
        "start": "LO-8057",
        "end": "LO-8058",
        "motion": "stitch",
        "source": "LOMWxKE_stitch.c",
        "count": 11,
        "conf": "confirmed"
    },
    {
        "start": "LO-8069",
        "end": "LO-806A",
        "motion": "accel",
        "source": "LOMWxKS_accel.c",
        "count": 9,
        "conf": "confirmed"
    },
    {
        "start": "LO-8055",
        "end": "LO-8056",
        "motion": "post_dwell",
        "source": "LOMWxKE_post_dwell.c",
        "count": 8,
        "conf": "confirmed"
    },
    {
        "start": "LO-806B",
        "end": "LO-806C",
        "motion": "decel",
        "source": "LOMWxKS_decel.c",
        "count": 6,
        "conf": "confirmed"
    },
    {
        "start": "LO-802B",
        "end": "LO-802C",
        "motion": "color_align",
        "source": "LOMWxKA_color_align.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8011",
        "end": "LO-8012",
        "motion": "load_cassette",
        "source": "LOMWxKC_load_cassette.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-805B",
        "end": "LO-805C",
        "motion": "on",
        "source": "LOMWxIL_on.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8035",
        "end": "LO-8036",
        "motion": "height_map",
        "source": "LOMWxKM_height_map.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8015",
        "end": "LO-8016",
        "motion": "map_cassette",
        "source": "LOMWxKC_map_cassette.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8041",
        "end": "LO-8042",
        "motion": "load_pod",
        "source": "LOMWxKR_load_pod.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8047",
        "end": "LO-8048",
        "motion": "read_id",
        "source": "LOMWxKR_read_id.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-802F",
        "end": "LO-8030",
        "motion": "backside",
        "source": "LOMWxKA_backside.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8043",
        "end": "LO-8044",
        "motion": "load_reticle",
        "source": "LOMWxKR_load_reticle.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-804B",
        "end": "LO-804C",
        "motion": "inspect",
        "source": "LOMWxKR_inspect.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-804D",
        "end": "LO-804E",
        "motion": "clamp",
        "source": "LOMWxKR_clamp.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8045",
        "end": "LO-8046",
        "motion": "align_reticle",
        "source": "LOMWxKR_align_reticle.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-805F",
        "end": "LO-8060",
        "motion": "pupil",
        "source": "LOMWxIL_pupil.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8071",
        "end": "LO-8072",
        "motion": "beam_shape",
        "source": "LOMWxIL_beam_shape.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8073",
        "end": "LO-8074",
        "motion": "check",
        "source": "LOMWxKV_check.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8059",
        "end": "LO-805A",
        "motion": "dose_cal",
        "source": "LOMWxKE_dose_cal.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-803D",
        "end": "LO-803E",
        "motion": "sensor_cal",
        "source": "LOMWxKC_sensor_cal.c",
        "count": 2,
        "conf": "confirmed"
    },
    {
        "start": "LO-8027",
        "end": "LO-8028",
        "motion": "clean_chuck",
        "source": "LOMWxKS_clean_chuck.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-8065",
        "end": "LO-8066",
        "motion": "stabilize",
        "source": "LOMWxKS_stabilize.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-805D",
        "end": "LO-805E",
        "motion": "off",
        "source": "LOMWxIL_off.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-8049",
        "end": "LO-804A",
        "motion": "unload_reticle",
        "source": "LOMWxKR_unload_reticle.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-803B",
        "end": "LO-803C",
        "motion": "mark_detect",
        "source": "LOMWxKA_mark_detect.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-804F",
        "end": "LO-8050",
        "motion": "unload_pod",
        "source": "LOMWxKR_unload_pod.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-8013",
        "end": "LO-8014",
        "motion": "unload_cassette",
        "source": "LOMWxKC_unload_cassette.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-8025",
        "end": "LO-8026",
        "motion": "request",
        "source": "LOMWxKS_request.swap",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-8039",
        "end": "LO-803A",
        "motion": "pellicle_check",
        "source": "LOMWxKM_pellicle_check.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-803F",
        "end": "LO-8040",
        "motion": "verify_id",
        "source": "LOMWxKW_verify_id.c",
        "count": 1,
        "conf": "confirmed"
    },
    {
        "start": "LO-806D",
        "end": "LO-806E",
        "motion": "focus",
        "source": "LOMWxKF_focus.c",
        "count": 1,
        "conf": "confirmed"
    }
]
STRATEGY = 'C'
NOISE_CODES = ["LO-7001", "LO-7011", "LO-7021", "LO-9001", "LO-9011", "LO-9013", "LO-9015", "LO-9021", "LO-9031", "LO-9041", "LO-9051", "LO-9061"]
EQP_ID = 'JB64'
PARSER_VERSION = "v1"
START_CODES = set(p["start"] for p in PAIR_MATRIX)
END_CODES = set(p["end"] for p in PAIR_MATRIX)

DDL = """
CREATE TABLE IF NOT EXISTS MEA (
  MEA_ID INTEGER PRIMARY KEY AUTOINCREMENT, JOB_ID VARCHAR2(36), DATETIME TIMESTAMP, EVENT_CODE VARCHAR2(50),
  ORIGIN_MESSAGE VARCHAR2(2000), EVENT_NAME VARCHAR2(200), SIGNAL VARCHAR2(10), START_CODE VARCHAR2(50), END_CODE VARCHAR2(50),
  LLM_INTERPRETATION CLOB, IS_MOTION_RELATED CHAR(1), ENGINEER_INTERPRETATION CLOB, REMARK VARCHAR2(500),
  PROCESS_TIME_MS NUMBER(12,3), CODE_GEN_OK CHAR(1), CREATED_AT TIMESTAMP, UPDATED_AT TIMESTAMP);
CREATE TABLE IF NOT EXISTS MOTION_EVENTS (
  EVENT_ID INTEGER PRIMARY KEY AUTOINCREMENT, JOB_ID VARCHAR2(36), EQP_ID VARCHAR2(50), MOTION_TYPE VARCHAR2(50),
  START_TS TIMESTAMP, END_TS TIMESTAMP, DURATION_MS NUMBER, ENTITY_KEYS CLOB, PARSER_VERSION VARCHAR2(10), TS TIMESTAMP);
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--db", required=True)
    ap.add_argument("--job", default="cli")
    args = ap.parse_args()

    with open(args.input, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()

    starts = extract_starts(lines, REGEX, START_CODES)
    ends = extract_ends(lines, REGEX, END_CODES)
    motions, mea_rows = pair_and_time(starts, ends, PAIR_MATRIX, STRATEGY)

    conn = sqlite3.connect(args.db)
    conn.executescript(DDL)
    # MEA (START/END 모션 행) — 결정론 정렬 후 INSERT
    mea_sorted = sorted(mea_rows, key=lambda r: (r["datetime"], r["code"], r["signal"]))
    conn.executemany(
        "INSERT INTO MEA (JOB_ID, DATETIME, EVENT_CODE, SIGNAL, IS_MOTION_RELATED) VALUES (?,?,?,?,'Y')",
        [(args.job, r["datetime"], r["code"], r["signal"]) for r in mea_sorted],
    )
    # MOTION_EVENTS — 결정론 정렬 후 INSERT
    mot_sorted = sorted(motions, key=lambda m: (m["start_ts"], m["motion_type"], m["entity_keys"]))
    conn.executemany(
        "INSERT INTO MOTION_EVENTS (JOB_ID, EQP_ID, MOTION_TYPE, START_TS, END_TS, DURATION_MS, ENTITY_KEYS, PARSER_VERSION, TS) "
        "VALUES (?,?,?,?,?,?,?,?,'')",
        [(args.job, EQP_ID, m["motion_type"], m["start_ts"], m["end_ts"], m["duration_ms"], m["entity_keys"], PARSER_VERSION) for m in mot_sorted],
    )
    conn.commit()
    conn.close()
    print(json.dumps({"mea_rows": len(mea_sorted), "motions": len(mot_sorted)}))


if __name__ == "__main__":
    main()
