"""
STEP 2 — 장비로드 프롬프트 생성 (First-Run only · 4 sub).

벡터DB/RAG 없이 '잦은 LLM 호출'로 대체:
  ② AI 사전분석 카드 — 샘플 로그 heuristic 페어 발견 + (가능 시) LLM 요약
  ② 엔지니어 인터뷰(멀티턴) — DB-backed CHAT_SESSIONS/MESSAGES (phase=interview)
  ④ 3종 영구화 — output/prompts/{eqp}.md + EQP_PROMPTS INSERT(LOCKED=N) + audit_log
완료 시 PARSE_JOBS.STATUS=STEP2_DONE.
"""
from __future__ import annotations

import json

import pandas as pd
import streamlit as st

from utils import db, file_manager, parser_templates as pt
from utils.debug_logger import log_event
from utils.llm_client import build_client_from_session, compose_messages

INTERVIEW_SYSTEM = (
    "당신은 반도체 장비 로그 분석 전문가입니다. 엔지니어와 대화하며 이 장비의 "
    "모션 이벤트 페어(start↔end), 노이즈 코드, 페어링 키(task/wafer/lot/field)를 "
    "확정하도록 돕습니다. 추측은 명확히 표시하고, 확정은 엔지니어에게 맡깁니다. 한국어로 답하세요."
)


def _sampled_events() -> list[dict]:
    lines = st.session_state.get("sampled_lines", [])
    return [e for ln in lines if (e := pt.parse_log_line(ln))]


def render() -> None:
    st.header("2 · 장비로드 프롬프트 생성")
    st.caption("First-Run 전용. 인터뷰로 pair_matrix·noise·regex 초안을 만들어 EQP_PROMPTS(LOCKED=N) 로 영구화한다.")
    st.divider()

    ctx = st.session_state["job_ctx"]
    job_id = st.session_state["job_id"]
    eqp_id = ctx["eqp_id"]

    if not st.session_state.get("sampled_lines"):
        st.warning("STEP 1에서 먼저 샘플링을 완료하세요.")
        return

    if not db.is_first_run(eqp_id):
        st.info(f"이미 `{eqp_id}` 의 EQP_PROMPTS 가 존재합니다. STEP 3(AI Analysis)로 직진하세요.")
        st.stop()

    events = _sampled_events()
    discovered = pt.discover_pairs_heuristic(events)
    noise_codes = sorted({e["code"] for e in events if pt.is_noise(e["code"])})

    # ── ② AI 사전분석 카드 ──
    st.subheader("▸ ② AI 사전분석 카드")
    c1, c2, c3 = st.columns(3)
    c1.metric("샘플 이벤트", f"{len(events):,}")
    c2.metric("발견 페어 후보", f"{len(discovered)}")
    c3.metric("노이즈 코드", f"{len(noise_codes)}")

    st.markdown("**발견된 페어 후보 (편집 가능 — motion 이름/불필요 행 정리)**")
    pair_df = pd.DataFrame(discovered) if discovered else pd.DataFrame(columns=["start", "end", "motion", "source", "count"])
    edited_pairs = st.data_editor(
        pair_df, hide_index=True, width="stretch", num_rows="dynamic", key="step2_pairs",
    )

    with st.expander("노이즈 코드 후보"):
        st.write(", ".join(noise_codes) or "(없음)")

    if st.button("🤖 AI 요약 생성 (선택 · LLM 호출)"):
        try:
            client = build_client_from_session()
            sample_txt = "\n".join(st.session_state["sampled_lines"][:300])
            msgs = compose_messages(
                INTERVIEW_SYSTEM,
                context_blocks=[
                    ("샘플 로그(앞 300줄)", sample_txt),
                    ("heuristic 페어 후보", json.dumps(discovered[:40], ensure_ascii=False)),
                ],
                user="이 장비 로그의 모션 구조를 5줄 이내로 요약하고, 페어링 키로 무엇이 적절한지 추천하세요.",
            )
            with st.chat_message("assistant"):
                st.write_stream(client.stream_collect(msgs))
        except Exception as e:
            st.error(f"LLM 호출 실패 (heuristic 결과로 진행 가능): {e}")

    # ── ② 엔지니어 인터뷰 (DB-backed) ──
    st.divider()
    st.subheader("▸ ② 엔지니어 인터뷰 (멀티턴 · DB 저장)")
    session_id = db.chat_session_find_or_create(job_id, eqp_id, ctx["user_id"], "interview")
    history = db.chat_messages_all(session_id)
    for m in history:
        with st.chat_message("user" if m["ROLE"] == "user" else "assistant"):
            st.markdown(m["CONTENT"])

    if prompt := st.chat_input("도메인 지식을 입력하세요 (예: stage_move 는 task_id 로 페어링)"):
        db.chat_message_insert(session_id, "user", prompt)
        with st.chat_message("user"):
            st.markdown(prompt)
        try:
            client = build_client_from_session()
            recent = db.chat_messages_recent(session_id, 10)
            sess = db.chat_session_get(session_id) or {}
            msgs = compose_messages(
                INTERVIEW_SYSTEM,
                context_blocks=[
                    ("샘플 로그(앞 200줄)", "\n".join(st.session_state["sampled_lines"][:200])),
                    ("발견 페어 후보", json.dumps(discovered[:40], ensure_ascii=False)),
                    ("대화 요약", sess.get("CURRENT_SUMMARY") or "(없음)"),
                ],
                history=[{"role": "user" if r["ROLE"] == "user" else "assistant", "content": r["CONTENT"]} for r in recent[:-1]],
                user=prompt,
            )
            with st.chat_message("assistant"):
                reply = st.write_stream(client.stream_collect(msgs))
            db.chat_message_insert(session_id, "assistant", reply, llm_model=st.session_state["ai_config"]["model"])
        except Exception as e:
            fallback = f"(LLM 미연결 — heuristic 페어 후보 {len(discovered)}건으로 진행하세요.) 오류: {e}"
            with st.chat_message("assistant"):
                st.markdown(fallback)
            db.chat_message_insert(session_id, "assistant", fallback)
        st.rerun()

    # ── ④ 3종 영구화 ──
    st.divider()
    st.subheader("▸ ④ 확정 저장 (EQP_PROMPTS · .md · audit)")
    if st.button("💾 장비로드 프롬프트 저장 (LOCKED=N)", type="primary"):
        pairs = [
            {"start": r["start"], "end": r["end"], "motion": r.get("motion") or "motion",
             "source": r.get("source", ""), "conf": "draft"}
            for r in edited_pairs.to_dict("records") if r.get("start") and r.get("end")
        ]
        analysis = pt.DEFAULT_INSTANCE_REGEX and {
            "pair_matrix": pairs,
            "instance_regex": pt.DEFAULT_INSTANCE_REGEX,
            "noise_codes": noise_codes,
            "pending_pairs": [],
            "confirmed_pairs": len(pairs),
            "discovery_log": [{"ts": db.now(), "who": "step2", "what": f"{len(pairs)} pairs drafted (heuristic)"}],
        }
        sess = db.chat_session_get(session_id) or {}
        md = _build_prompt_md(eqp_id, ctx["eqp_type"], analysis, db.chat_messages_all(session_id))
        md_path = file_manager.prompts_path(f"{eqp_id}.md")
        file_manager.save_text(md_path, md)
        db.chat_session_complete(session_id)
        prompt_id = db.eqp_prompt_insert(
            eqp_id=eqp_id, eqp_type=ctx["eqp_type"], analysis=analysis,
            interview_md_path=str(md_path), interview_session_id=session_id,
            interview_turns=sess.get("TURN_COUNT", 0), interview_llm_calls=sess.get("LLM_CALL_COUNT", 0),
        )
        db.update_job(job_id, EQP_PROMPT_ID=prompt_id)
        db.audit_insert(job_id, ctx["user_id"], "interview", prompt_id, f"pairs={len(pairs)}")
        db.advance_status(job_id, "STEP2_DONE", current_step=2)
        log_event("step2", "EQP_PROMPTS 저장", f"eqp={eqp_id} pairs={len(pairs)}")
        st.success(f"✓ EQP_PROMPTS 저장 완료 (pairs={len(pairs)}). STEP 3 으로 이동하세요.")
        st.rerun()


def _build_prompt_md(eqp_id: str, eqp_type: str, analysis: dict, messages: list[dict]) -> str:
    lines = [f"# 장비로드 프롬프트 — {eqp_id} ({eqp_type})", "", "## Pair Matrix", "",
             "| start | end | motion | source |", "|---|---|---|---|"]
    for p in analysis["pair_matrix"]:
        lines.append(f"| {p['start']} | {p['end']} | {p['motion']} | {p.get('source','')} |")
    lines += ["", "## Noise Codes", "", ", ".join(analysis["noise_codes"]) or "(없음)", "",
              "## Instance Regex", "", "```json", json.dumps(analysis["instance_regex"], ensure_ascii=False, indent=2), "```",
              "", "## 인터뷰 기록", ""]
    for m in messages:
        lines.append(f"- **{m['ROLE']}**: {m['CONTENT']}")
    return "\n".join(lines)
