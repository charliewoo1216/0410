"""
STEP 1 — Log Selection (9 sub → 로컬 단순화).
mcc-log-file/ 재귀 탐색 → 파일 선택(체크박스) → LOG_FILES 기록 → 균등 샘플링.
EDS API/NAS/XML/임베딩 없음. LLM 미사용.
완료 시 PARSE_JOBS.STATUS=STEP1_DONE.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from utils import db, log_sampler
from utils.debug_logger import log_event

MCC_DIR = "mcc-log-file"


def render() -> None:
    st.header("1 · Log Selection")
    st.caption("mcc-log-file/ 로컬 로그를 탐색·선택하고 균등 샘플링한다. (EDS/NAS 없음 · No LLM)")
    st.divider()

    job_id = st.session_state["job_id"]

    mcc_path = Path(MCC_DIR)
    if not mcc_path.exists():
        st.warning(f"📁 `{MCC_DIR}/` 폴더가 없습니다. 원시 로그(.log/.txt/.csv)를 추가하세요.")
        return

    with st.spinner("로그 파일 스캔 중..."):
        file_infos = log_sampler.scan_log_files(MCC_DIR)
    if not file_infos:
        st.warning(f"📄 `{MCC_DIR}/` 에 로그 파일이 없습니다.")
        return

    # ── 파일 선택 테이블 ──
    st.subheader("▸ ① 파일 선택")
    df = pd.DataFrame([
        {
            "선택": True,
            "파일": i["rel"],
            "크기(MB)": i["size_mb"],
            "총 라인": i["total_lines"],
            "인코딩": i.get("encoding") or "FAIL",
            "_path": i["path"],
        }
        for i in file_infos
    ])
    edited = st.data_editor(
        df,
        column_config={"_path": None},  # 숨김
        disabled=["파일", "크기(MB)", "총 라인", "인코딩"],
        hide_index=True,
        width="stretch",
        key="step1_file_editor",
    )
    selected_paths = set(edited[edited["선택"]]["_path"].tolist())
    selected_infos = [i for i in file_infos if i["path"] in selected_paths and i.get("encoding")]

    total_lines = sum(i["total_lines"] for i in selected_infos)
    c1, c2, c3 = st.columns(3)
    c1.metric("선택 파일", f"{len(selected_infos):,}")
    c2.metric("선택 라인", f"{total_lines:,}")
    c3.metric("총 크기(MB)", f"{sum(i['size_mb'] for i in selected_infos):,.1f}")

    # ── 샘플링 설정 ──
    st.subheader("▸ ② 균등 샘플링")
    default_target = min(120_000, max(10_000, total_lines or 10_000))
    target_lines = st.slider("샘플 라인 수 (180k 토큰 안전 마진 기준)", 10_000, 200_000, default_target, 5_000)

    if st.button("▶ 샘플링 시작", type="primary", disabled=not selected_infos):
        db.log_files_replace(job_id, file_infos, selected_paths)
        log_event("step1", "샘플링 시작", f"target={target_lines:,} files={len(selected_infos)}")
        progress = st.progress(0.0, text="샘플링...")

        def _cb(i: int, total: int, name: str) -> None:
            progress.progress(min(1.0, (i + 1) / max(1, total)), text=f"처리 중: {name}")

        sampled = log_sampler.sample_logs(selected_infos, target_lines, progress_cb=_cb)
        progress.progress(1.0, text="완료")
        st.session_state["sampled_lines"] = sampled
        if sampled:
            db.advance_status(job_id, "STEP1_DONE", current_step=1)
            log_event("step1", "샘플링 완료", f"sampled={len(sampled):,}")
        st.rerun()

    # ── 결과 ──
    sampled = st.session_state.get("sampled_lines", [])
    if sampled:
        est = log_sampler.estimate_tokens(sampled)
        st.divider()
        st.subheader("▸ 샘플링 결과")
        c1, c2, c3 = st.columns(3)
        c1.metric("샘플 라인", f"{len(sampled):,}")
        c2.metric("예상 토큰", f"{est:,}")
        c3.metric("예산 대비", f"{est / 180_000:.0%}")
        if est > 180_000:
            st.error("⚠ 예상 토큰이 180k 예산 초과 — 슬라이더를 낮추세요.")
        else:
            first_run = db.is_first_run(st.session_state["job_ctx"]["eqp_id"])
            nxt = "STEP 2(장비로드 프롬프트)" if first_run else "STEP 3(AI Analysis)"
            st.success(f"✓ 샘플 {len(sampled):,}줄 확보. {nxt} 로 이동하세요.")
        with st.expander("샘플 미리보기 (앞 100줄)"):
            st.code("\n".join(sampled[:100]), language="text")
