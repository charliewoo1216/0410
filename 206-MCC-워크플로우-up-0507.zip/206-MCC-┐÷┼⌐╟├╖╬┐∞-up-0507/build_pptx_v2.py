# -*- coding: utf-8 -*-
"""
MCC 워크플로우 발표자료 v2 (white / grey / black 톤)
output: MCC_Workflow_Presentation_v2.pptx
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from lxml import etree

# ---------- palette: white / grey / black ----------
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
SOFT       = RGBColor(0xFA, 0xFA, 0xFA)
PANEL      = RGBColor(0xF3, 0xF4, 0xF6)
LINE       = RGBColor(0xE5, 0xE7, 0xEB)
LINE_2     = RGBColor(0xD1, 0xD5, 0xDB)
INK_4      = RGBColor(0x9C, 0xA3, 0xAF)
INK_3      = RGBColor(0x6B, 0x72, 0x80)
INK_2      = RGBColor(0x37, 0x41, 0x51)
INK_1      = RGBColor(0x11, 0x18, 0x27)
INK_0      = RGBColor(0x0A, 0x0A, 0x0A)
BLACK      = RGBColor(0x00, 0x00, 0x00)

FONT = '맑은 고딕'

# ---------- helpers ----------
def set_slide_bg(slide, color=WHITE):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_text(slide, x, y, w, h, text, *, size=14, bold=False,
             color=INK_1, align=PP_ALIGN.LEFT, font=FONT,
             anchor=MSO_ANCHOR.TOP, line_spacing=1.15):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor
    lines = text.split('\n')
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line_spacing
        run = p.add_run()
        run.text = line
        run.font.name = font
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = color
    return tb


def add_box(slide, x, y, w, h, *, fill=WHITE, line=LINE, line_w=0.75,
            text=None, text_color=INK_1, text_size=13, text_bold=False,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER,
            anchor=MSO_ANCHOR.MIDDLE):
    sh = slide.shapes.add_shape(shape, x, y, w, h)
    sh.fill.solid()
    sh.fill.fore_color.rgb = fill
    sh.line.color.rgb = line
    sh.line.width = Pt(line_w)
    sh.shadow.inherit = False
    if text is not None:
        tf = sh.text_frame
        tf.word_wrap = True
        tf.margin_left = Emu(60000)
        tf.margin_right = Emu(60000)
        tf.margin_top = Emu(40000)
        tf.margin_bottom = Emu(40000)
        tf.vertical_anchor = anchor
        lines = text.split('\n')
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align
            p.line_spacing = 1.15
            r = p.add_run()
            r.text = line
            r.font.name = FONT
            r.font.size = Pt(text_size)
            r.font.bold = text_bold
            r.font.color.rgb = text_color
    return sh


def add_arrow(slide, x1, y1, x2, y2, color=INK_3, weight=1.25, dashed=False):
    line = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, x1, y1, x2, y2)
    line.line.color.rgb = color
    line.line.width = Pt(weight)
    ln = line.line._get_or_add_ln()
    if dashed:
        prst = etree.SubElement(ln, qn('a:prstDash'))
        prst.set('val', 'dash')
    tail = etree.SubElement(ln, qn('a:tailEnd'))
    tail.set('type', 'triangle')
    tail.set('w', 'med')
    tail.set('h', 'med')
    return line


def set_slide_title(slide, prs, title, subtitle=None, num=None):
    if num is not None:
        # number chip
        chip = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                      Inches(0.55), Inches(0.40),
                                      Inches(0.42), Inches(0.42))
        chip.fill.solid(); chip.fill.fore_color.rgb = INK_1
        chip.line.fill.background(); chip.shadow.inherit = False
        tf = chip.text_frame
        tf.margin_left = Emu(0); tf.margin_right = Emu(0)
        tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        r = p.add_run(); r.text = num
        r.font.name = FONT; r.font.size = Pt(14); r.font.bold = True
        r.font.color.rgb = WHITE
        title_x = Inches(1.10)
    else:
        title_x = Inches(0.55)
    add_text(slide, title_x, Inches(0.42), Inches(11.5), Inches(0.5),
             title, size=24, bold=True, color=INK_0)
    if subtitle:
        add_text(slide, title_x, Inches(0.92), Inches(11.5), Inches(0.4),
                 subtitle, size=12, color=INK_3)
    # underline (thin)
    ul = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0.55), Inches(1.35),
        Inches(12.2), Emu(12700)
    )
    ul.line.fill.background()
    ul.fill.solid(); ul.fill.fore_color.rgb = LINE
    ul.shadow.inherit = False


def add_pill(slide, x, y, text, dark=False, w=Inches(1.6), h=Inches(0.32)):
    box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    if dark:
        box.fill.solid(); box.fill.fore_color.rgb = INK_1
        box.line.fill.background()
        col = WHITE
    else:
        box.fill.solid(); box.fill.fore_color.rgb = PANEL
        box.line.color.rgb = LINE; box.line.width = Pt(0.5)
        col = INK_2
    box.shadow.inherit = False
    tf = box.text_frame
    tf.margin_left = Emu(0); tf.margin_right = Emu(0)
    tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = text
    r.font.name = FONT; r.font.size = Pt(10); r.font.bold = True
    r.font.color.rgb = col


def add_bullets(slide, x, y, w, h, items, *, size=12, color=INK_2, gap_pt=4):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Emu(0); tf.margin_right = Emu(0)
    tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
    for i, it in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.space_after = Pt(gap_pt)
        p.line_spacing = 1.25
        r = p.add_run()
        r.text = "•  " + it
        r.font.name = FONT
        r.font.size = Pt(size)
        r.font.color.rgb = color
    return tb


# ---------- build ----------
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank = prs.slide_layouts[6]

def new_slide():
    s = prs.slides.add_slide(blank)
    set_slide_bg(s, WHITE)
    return s


TOTAL = 16

def add_footer(slide, idx):
    add_text(slide, Inches(0.55), Inches(7.10), Inches(8), Inches(0.3),
             "205 · MCC Workflow · Architecture Brief · v2",
             size=9, color=INK_4)
    add_text(slide, Inches(11.5), Inches(7.10), Inches(1.4), Inches(0.3),
             f"{idx} / {TOTAL}", size=9, color=INK_4, align=PP_ALIGN.RIGHT)


# =========================================================
# SLIDE 1 — Cover
# =========================================================
s = new_slide()
# top eyebrow
add_text(s, Inches(0.8), Inches(0.7), Inches(11), Inches(0.4),
         "205 · MCC WORKFLOW · v2",
         size=11, bold=True, color=INK_3)
# big title
add_text(s, Inches(0.8), Inches(2.3), Inches(11.5), Inches(1.4),
         "로그 → AI 분석 → 자동 파서",
         size=48, bold=True, color=INK_0)
add_text(s, Inches(0.8), Inches(3.4), Inches(11.5), Inches(0.7),
         "MCC 워크플로우 시스템 아키텍처",
         size=22, color=INK_2)

# divider
div = s.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                         Inches(0.8), Inches(4.3),
                         Inches(1.5), Emu(25400))
div.line.fill.background(); div.fill.solid(); div.fill.fore_color.rgb = INK_1
div.shadow.inherit = False

add_text(s, Inches(0.8), Inches(4.5), Inches(11.5), Inches(0.6),
         "장비 로그 → LLM 이벤트 분석 → 모션 페어링 → ReAct 자동 파서 → 전체 볼륨 검증",
         size=14, color=INK_3)

# bottom meta
add_text(s, Inches(0.8), Inches(6.7), Inches(6), Inches(0.4),
         "발표일 · 2026-05-08", size=11, color=INK_3)
add_text(s, Inches(7.5), Inches(6.7), Inches(5.3), Inches(0.4),
         "발표자 ·                     ", size=11, color=INK_3, align=PP_ALIGN.RIGHT)

# tiny accent square top right
acc = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(12.0), Inches(0.7),
                         Inches(0.5), Inches(0.5))
acc.fill.solid(); acc.fill.fore_color.rgb = INK_1
acc.line.fill.background(); acc.shadow.inherit = False

add_footer(s, 1)

# =========================================================
# SLIDE 2 — Agenda
# =========================================================
s = new_slide()
set_slide_title(s, prs, "발표 순서", "Agenda", num="00")
items = [
    ("01", "전체 개요 & 핵심 수치"),
    ("02", "★ 전체 시스템 흐름도 (Master Flow)"),
    ("03", "컴포넌트 아키텍처"),
    ("04", "Stage 1 — Log Selection"),
    ("05", "Stage 2 — AI Analysis"),
    ("06", "Stage 3 — Verification"),
    ("07", "Stage 4 — Code Generation (ReAct)"),
    ("08", "Stage 4 — parser_v1.py 산출 명세"),
    ("09", "Stage 5 — Volume Test"),
    ("10", "데이터 표준 · 저장소 · DB"),
    ("11", "산출물 매트릭스"),
    ("12", "기술 스택"),
    ("13", "리스크 & 다음 단계 / Q&A"),
]
left_x = Inches(0.7)
top_y  = Inches(1.7)
col_w  = Inches(6.0)
row_h  = Inches(0.40)
for i, (n, t) in enumerate(items):
    col = i // 7
    row = i % 7
    x = left_x + Inches(6.2) * col
    y = top_y + (row_h + Inches(0.05)) * row
    add_box(s, x, y, col_w, row_h, fill=WHITE, line=LINE, text=None)
    add_text(s, x + Inches(0.18), y + Inches(0.08), Inches(0.6), Inches(0.3),
             n, size=11, bold=True, color=INK_0)
    add_text(s, x + Inches(0.85), y + Inches(0.08), Inches(5.0), Inches(0.3),
             t, size=13, color=INK_2)
add_footer(s, 2)

# =========================================================
# SLIDE 3 — 5-stage at a glance
# =========================================================
s = new_slide()
set_slide_title(s, prs, "시스템 한눈에 보기", "5단계 End-to-End 파이프라인", num="01")

stages = [
    ("STAGE 01", "Log Selection", "EDS API · 검색·다운로드·전처리·저장"),
    ("STAGE 02", "AI Analysis", "LLM 대화 · 이벤트 v1→v2"),
    ("STAGE 03", "Verification", "모션 페어링·시퀀스 v1→v2"),
    ("STAGE 04", "Code Generation", "ReAct 루프 · parser_v1.py"),
    ("STAGE 05", "Volume Test", "전체 로그 · 진행 시각화"),
]
x0 = Inches(0.55); y0 = Inches(2.0)
bw, bh = Inches(2.35), Inches(2.6)
gap = Inches(0.10)
arrow_y = y0 + bh / 2

for i, (n, t, d) in enumerate(stages):
    x = x0 + (bw + gap) * i
    add_box(s, x, y0, bw, bh, fill=WHITE, line=LINE_2)
    add_text(s, x + Inches(0.2), y0 + Inches(0.18), bw - Inches(0.4), Inches(0.3),
             n, size=10, bold=True, color=INK_3)
    add_text(s, x + Inches(0.2), y0 + Inches(0.55), bw - Inches(0.4), Inches(0.6),
             t, size=18, bold=True, color=INK_0)
    add_text(s, x + Inches(0.2), y0 + Inches(1.25), bw - Inches(0.4), Inches(1.3),
             d, size=12, color=INK_3)
    if i < len(stages) - 1:
        ax1 = x + bw
        ax2 = x + bw + gap
        add_arrow(s, ax1, arrow_y, ax2, arrow_y, color=INK_1, weight=1.5)

# bottom note
add_text(s, Inches(0.55), Inches(5.0), Inches(12.2), Inches(0.4),
         "User → 로그 수집 → LLM 분석 → 사용자 검증 → 자동 코드생성 → 전체 검증 → SQLite",
         size=13, color=INK_2)

# key metrics row
metrics = [("5단계", "E2E"), ("~30 MB", "1차 로그"),
           ("1 ~ 5 GB", "Volume Test"), ("최대 10회", "ReAct 루프")]
mx = Inches(0.55); my = Inches(5.6); mw = Inches(3.05); mh = Inches(1.1)
for i, (n, l) in enumerate(metrics):
    x = mx + (mw + Inches(0.10)) * i
    add_box(s, x, my, mw, mh, fill=WHITE, line=LINE_2)
    add_text(s, x + Inches(0.2), my + Inches(0.15), mw, Inches(0.55),
             n, size=22, bold=True, color=INK_0)
    add_text(s, x + Inches(0.2), my + Inches(0.72), mw, Inches(0.4),
             l, size=11, color=INK_3)
add_footer(s, 3)

# =========================================================
# SLIDE 4 — ★ 전체 시스템 흐름도 (Master Flow)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "전체 시스템 흐름도",
                "5단계 · 모든 산출물 · 사용자 피드백 · 외부 의존을 한 장으로", num="02")

# Lane labels (left)
lanes = [
    ("USER",     Inches(1.55), INK_3),
    ("STAGE 1",  Inches(2.10), INK_3),
    ("STAGE 2",  Inches(3.30), INK_3),
    ("STAGE 3",  Inches(4.50), INK_3),
    ("STAGE 4",  Inches(5.50), INK_3),
    ("STAGE 5",  Inches(6.50), INK_3),
]
# we'll layout horizontally instead — left-to-right master flow with branches.

# Layout the master flow horizontally with rows for: Storage row, Main path row, Feedback row
# Top row: external services (EDS, LLM)
# Mid: main pipeline boxes
# Bottom row: storage / outputs

# === Top — externals ===
add_box(s, Inches(2.4),  Inches(1.65), Inches(1.5), Inches(0.55),
        fill=WHITE, line=LINE_2, text="EDS API",
        text_size=11, text_color=INK_2)
add_box(s, Inches(4.95), Inches(1.65), Inches(1.5), Inches(0.55),
        fill=WHITE, line=LINE_2, text="LLM API",
        text_size=11, text_color=INK_2)
add_box(s, Inches(8.0),  Inches(1.65), Inches(1.5), Inches(0.55),
        fill=WHITE, line=LINE_2, text="LLM API",
        text_size=11, text_color=INK_2)
# label: external
add_text(s, Inches(0.55), Inches(1.7), Inches(1.7), Inches(0.4),
         "EXTERNAL", size=9, bold=True, color=INK_4)

# === Mid — main pipeline ===
mid_y = Inches(2.55)
mid_h = Inches(0.85)
boxes = [
    ("사용자 시작",   Inches(0.55), Inches(2.55)),
    ("로그 검색·\n다운로드·전처리", Inches(2.10), Inches(2.55)),
    ("LLM 이벤트\n분석 v1",        Inches(3.95), Inches(2.55)),
    ("LLM 모션\n페어링 v1",        Inches(5.80), Inches(2.55)),
    ("ReAct\n자동 파서",           Inches(7.65), Inches(2.55)),
    ("Volume Test\n전체 검증",     Inches(9.50), Inches(2.55)),
    ("SQLite",                     Inches(11.35), Inches(2.55)),
]
widths = [Inches(1.4), Inches(1.7), Inches(1.7), Inches(1.7), Inches(1.7), Inches(1.7), Inches(1.4)]
for (t, x, y), w in zip(boxes, widths):
    add_box(s, x, y, w, mid_h, fill=WHITE, line=INK_1, line_w=1.0,
            text=t, text_size=11, text_bold=True, text_color=INK_0)

# label: pipeline
add_text(s, Inches(0.55), Inches(2.05), Inches(2.0), Inches(0.4),
         "PIPELINE", size=9, bold=True, color=INK_4)

# arrows along main pipeline
mid_arrow_y = mid_y + mid_h / 2
edges = [
    (Inches(1.95),  Inches(2.10)),  # 시작 -> Stage1
    (Inches(3.80),  Inches(3.95)),  # Stage1 -> Stage2
    (Inches(5.65),  Inches(5.80)),  # Stage2 -> Stage3
    (Inches(7.50),  Inches(7.65)),  # Stage3 -> Stage4
    (Inches(9.35),  Inches(9.50)),  # Stage4 -> Stage5
    (Inches(11.20), Inches(11.35)), # Stage5 -> SQLite
]
for x1, x2 in edges:
    add_arrow(s, x1, mid_arrow_y, x2, mid_arrow_y, color=INK_1, weight=1.5)

# Stage4 -> SQLite direct arrow (curved path -- straight diagonal will do)
add_arrow(s, Inches(8.50), Inches(3.40), Inches(11.55), Inches(3.40),
          color=INK_3, weight=1.0)

# vertical down: from externals to main pipeline (EDS into Stage1, LLM into Stage2, LLM into Stage3)
add_arrow(s, Inches(3.15), Inches(2.20), Inches(3.0),  Inches(2.55), color=INK_3, weight=1.0, dashed=True)
add_arrow(s, Inches(5.70), Inches(2.20), Inches(4.80), Inches(2.55), color=INK_3, weight=1.0, dashed=True)
add_arrow(s, Inches(8.75), Inches(2.20), Inches(6.65), Inches(2.55), color=INK_3, weight=1.0, dashed=True)
# LLM into Stage4 (ReAct)
add_arrow(s, Inches(8.75), Inches(2.20), Inches(8.50), Inches(2.55), color=INK_3, weight=1.0, dashed=True)

# === Bottom — outputs / storage ===
add_text(s, Inches(0.55), Inches(4.6), Inches(2.0), Inches(0.4),
         "OUTPUTS", size=9, bold=True, color=INK_4)

# Output cards
outs = [
    ("Web · MinIO/S3\n원시 로그 저장",    Inches(2.10), Inches(4.55)),
    ("이벤트분석\nv1.md → v2.md",          Inches(3.95), Inches(4.55)),
    ("모션_페어링\nv1.md → v2.md",         Inches(5.80), Inches(4.55)),
    ("parser_v1.py\n(자동 생성)",          Inches(7.65), Inches(4.55)),
    ("진행 시각화 UI\n실패율·처리율",       Inches(9.50), Inches(4.55)),
    ("events 테이블\n파싱 결과",           Inches(11.35), Inches(4.55)),
]
ow = [Inches(1.7), Inches(1.7), Inches(1.7), Inches(1.7), Inches(1.7), Inches(1.4)]
for (t, x, y), w in zip(outs, ow):
    add_box(s, x, y, w, Inches(0.85), fill=PANEL, line=LINE_2,
            text=t, text_size=10, text_color=INK_2)

# arrows main -> outputs
out_arrows = [
    (Inches(2.95), Inches(2.95)),  # stage1 -> output
    (Inches(4.80), Inches(4.80)),
    (Inches(6.65), Inches(6.65)),
    (Inches(8.50), Inches(8.50)),
    (Inches(10.35), Inches(10.35)),
    (Inches(12.05), Inches(12.05)),
]
for x1, x2 in out_arrows:
    add_arrow(s, x1, Inches(3.40), x2, Inches(4.55), color=INK_3, weight=0.9, dashed=True)

# === Feedback loop row ===
add_text(s, Inches(0.55), Inches(5.85), Inches(2.0), Inches(0.4),
         "FEEDBACK", size=9, bold=True, color=INK_4)

add_box(s, Inches(3.95), Inches(5.85), Inches(1.7), Inches(0.55),
        fill=WHITE, line=INK_1, text="사용자 검토 v2",
        text_size=11, text_bold=True, text_color=INK_0)
add_box(s, Inches(5.80), Inches(5.85), Inches(1.7), Inches(0.55),
        fill=WHITE, line=INK_1, text="사용자 검토 v2",
        text_size=11, text_bold=True, text_color=INK_0)
add_box(s, Inches(9.50), Inches(5.85), Inches(1.7), Inches(0.55),
        fill=WHITE, line=INK_1, text="실패 케이스 환류",
        text_size=11, text_bold=True, text_color=INK_0)

# arrows from output to feedback box
add_arrow(s, Inches(4.80), Inches(5.40), Inches(4.80), Inches(5.85), color=INK_2, weight=1.0)
add_arrow(s, Inches(6.65), Inches(5.40), Inches(6.65), Inches(5.85), color=INK_2, weight=1.0)
add_arrow(s, Inches(10.35),Inches(5.40), Inches(10.35),Inches(5.85), color=INK_2, weight=1.0)

# arrows from feedback box back to LLM call (Stage 2 / 3)
add_arrow(s, Inches(4.80), Inches(6.40), Inches(4.80), Inches(6.7),  color=INK_3, weight=1.0, dashed=True)
add_arrow(s, Inches(4.80), Inches(6.7),  Inches(4.20), Inches(6.7),  color=INK_3, weight=1.0, dashed=True)
add_arrow(s, Inches(4.20), Inches(6.7),  Inches(4.20), Inches(3.40), color=INK_3, weight=1.0, dashed=True)
add_arrow(s, Inches(4.20), Inches(3.40), Inches(3.95), Inches(2.95), color=INK_3, weight=1.0, dashed=True)
# (Stage 3 same pattern reused visually -- keep one labeled to reduce clutter)

# Reading legend (right side or bottom-left)
lg_y = Inches(6.55)
add_text(s, Inches(0.55), lg_y, Inches(3.5), Inches(0.3),
         "──  메인 흐름     ", size=9, bold=True, color=INK_2)
add_text(s, Inches(2.30), lg_y, Inches(3.5), Inches(0.3),
         "----  외부 호출 / 피드백",
         size=9, bold=True, color=INK_3)
add_text(s, Inches(5.05), lg_y, Inches(3.5), Inches(0.3),
         "■ 검은 테두리 = 핵심 단계 / 회색 = 산출·외부",
         size=9, color=INK_3)

add_footer(s, 4)

# =========================================================
# SLIDE 5 — Component Architecture
# =========================================================
s = new_slide()
set_slide_title(s, prs, "컴포넌트 아키텍처",
                "사용자 · Web · External · Storage · Engine", num="03")

# User
add_box(s, Inches(0.6), Inches(1.7), Inches(2.2), Inches(0.7),
        fill=WHITE, line=INK_1, text="User",
        text_size=14, text_bold=True, text_color=INK_0)

# Web Server
add_box(s, Inches(3.4), Inches(1.6), Inches(6.0), Inches(0.95),
        fill=PANEL, line=LINE_2)
add_text(s, Inches(3.55), Inches(1.7), Inches(2.0), Inches(0.3),
         "Web Server (Python)", size=11, bold=True, color=INK_3)
add_box(s, Inches(3.55), Inches(2.05), Inches(1.7), Inches(0.4),
        fill=WHITE, line=LINE, text="대화 / 진행 UI",
        text_size=11, text_color=INK_2)
add_box(s, Inches(5.35), Inches(2.05), Inches(1.7), Inches(0.4),
        fill=WHITE, line=LINE, text="전처리 (KST)",
        text_size=11, text_color=INK_2)
add_box(s, Inches(7.15), Inches(2.05), Inches(2.05), Inches(0.4),
        fill=WHITE, line=LINE, text="오케스트레이션",
        text_size=11, text_color=INK_2)

# External
add_box(s, Inches(9.95), Inches(1.6), Inches(2.85), Inches(0.95),
        fill=PANEL, line=LINE_2)
add_text(s, Inches(10.1), Inches(1.7), Inches(2.5), Inches(0.3),
         "External", size=11, bold=True, color=INK_3)
add_box(s, Inches(10.05), Inches(2.05), Inches(1.3), Inches(0.4),
        fill=WHITE, line=LINE, text="EDS API",
        text_size=11, text_color=INK_2)
add_box(s, Inches(11.4), Inches(2.05), Inches(1.35), Inches(0.4),
        fill=WHITE, line=LINE, text="LLM API",
        text_size=11, text_color=INK_2)

# Engine
add_box(s, Inches(3.4), Inches(3.4), Inches(6.0), Inches(1.0),
        fill=INK_1, line=INK_1)
add_text(s, Inches(3.55), Inches(3.5), Inches(2.5), Inches(0.3),
         "Code Gen Engine", size=11, bold=True, color=WHITE)
add_box(s, Inches(3.55), Inches(3.85), Inches(2.5), Inches(0.45),
        fill=WHITE, line=LINE, text="ReAct Loop · max 10",
        text_size=11, text_color=INK_1)
add_box(s, Inches(6.2), Inches(3.85), Inches(3.05), Inches(0.45),
        fill=WHITE, line=LINE, text="parser_v1.py",
        text_size=11, text_color=INK_1)

# Storage
add_box(s, Inches(0.6), Inches(5.0), Inches(12.2), Inches(1.7),
        fill=PANEL, line=LINE_2)
add_text(s, Inches(0.8), Inches(5.1), Inches(4), Inches(0.3),
         "Storage / DB", size=11, bold=True, color=INK_3)
add_box(s, Inches(0.8), Inches(5.55), Inches(3.7), Inches(1.05),
        fill=WHITE, line=LINE,
        text="MinIO / S3\n원시 로그 (1G ~ 5G)",
        text_size=12, text_color=INK_1)
add_box(s, Inches(4.7), Inches(5.55), Inches(4.0), Inches(1.05),
        fill=WHITE, line=LINE,
        text="Markdown 산출물\n로그구조템플릿 / 이벤트 v1·v2 / 모션페어링 v1·v2",
        text_size=11, text_color=INK_1)
add_box(s, Inches(8.9), Inches(5.55), Inches(3.9), Inches(1.05),
        fill=WHITE, line=LINE,
        text="SQLite\nstart / end / motion / desc",
        text_size=12, text_color=INK_1)

# arrows
add_arrow(s, Inches(2.8), Inches(2.05), Inches(3.4), Inches(2.05), color=INK_1, weight=1.5)
add_arrow(s, Inches(9.4), Inches(2.05), Inches(9.95), Inches(2.05), color=INK_1, weight=1.5)
add_arrow(s, Inches(6.4), Inches(2.55), Inches(6.4), Inches(3.4),   color=INK_1, weight=1.5)
add_arrow(s, Inches(6.4), Inches(4.4),  Inches(6.4), Inches(5.0),   color=INK_1, weight=1.5)
add_arrow(s, Inches(11.0),Inches(2.45), Inches(10.85), Inches(5.55),color=INK_3, weight=0.9, dashed=True)
add_arrow(s, Inches(10.7),Inches(2.45), Inches(2.7),  Inches(5.55), color=INK_3, weight=0.9, dashed=True)

add_footer(s, 5)

# =========================================================
# SLIDE 6 — Stage 1
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 1 · Log Selection",
                "장비 로그 검색 · 다운로드 · 전처리 · 저장", num="04")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 01", dark=True)

flow = [
    ("사용자 시작",),
    ("검색 조건\neqp · 기간",),
    ("EDS\nfile meta",),
    ("웹 UI 목록",),
    ("사용자 선택",),
    ("EDS\nfile download",),
    ("전처리\nKST · 행처리",),
    ("저장\nWeb / MinIO·S3",),
]
fx = Inches(0.55); fy = Inches(2.0)
fw, fh = Inches(1.45), Inches(1.1)
fgap = Inches(0.12)
for i, (t,) in enumerate(flow):
    x = fx + (fw + fgap) * i
    add_box(s, x, fy, fw, fh, fill=WHITE, line=LINE_2,
            text=t, text_size=11, text_color=INK_1)
    if i < len(flow) - 1:
        add_arrow(s, x + fw, fy + fh / 2, x + fw + fgap, fy + fh / 2,
                  color=INK_1, weight=1.4)

add_text(s, Inches(0.55), Inches(3.5), Inches(12), Inches(0.4),
         "핵심 포인트", size=14, bold=True, color=INK_0)
add_bullets(s, Inches(0.65), Inches(3.85), Inches(12.5), Inches(2.8), [
    "EDS API · Datalake 2.0 메타 검색 — eqp id · 날짜시간 기간 기반",
    "웹 UI에서 사용자가 다중 선택 가능 → 선택분만 다운로드",
    "전처리: 타임스탬프 KST 통일, 행 단위 정규화",
    "저장 위치: 1차 ~ 30 MB는 Web 서버 로컬, 향후 MinIO/S3 전환 검토",
    "본 단계 산출물이 모든 후속 단계의 입력 — 일관성·재현성 핵심",
], size=13)
add_footer(s, 6)

# =========================================================
# SLIDE 7 — Stage 2
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 2 · AI Analysis",
                "LLM 대화로 이벤트 정의 (v1 → v2)", num="05")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 02", dark=True)

# Left: sequence
sx = Inches(0.55); sy = Inches(2.0)
add_box(s, sx, sy, Inches(7.0), Inches(4.5), fill=WHITE, line=LINE_2)
add_text(s, sx + Inches(0.3), sy + Inches(0.18), Inches(6.5), Inches(0.4),
         "대화 시퀀스", size=14, bold=True, color=INK_0)

steps = [
    ("①  Web → LLM",       "원시 로그 + 템플릿 요청"),
    ("②  LLM → 산출물",     "로그구조템플릿.md"),
    ("③  Web → LLM",       "모션 이벤트 추출 요청"),
    ("④  LLM → 산출물",     "이벤트분석_v1.md"),
    ("⑤  User ↔ Web ↔ LLM","도메인 지식 반영 (반복)"),
    ("⑥  User → Web",      "최종 확정"),
    ("⑦  Web → 산출물",     "이벤트분석_v2.md"),
]
ssx = sx + Inches(0.3); ssy = sy + Inches(0.65)
for i, (t, d) in enumerate(steps):
    y = ssy + Inches(0.50) * i
    add_text(s, ssx, y, Inches(2.7), Inches(0.45), t,
             size=12, bold=True, color=INK_0)
    add_text(s, ssx + Inches(2.8), y, Inches(4.0), Inches(0.45), d,
             size=12, color=INK_3)

# Right: outputs
ox = Inches(7.85); oy = Inches(2.0)
add_box(s, ox, oy, Inches(5.0), Inches(4.5), fill=PANEL, line=LINE_2)
add_text(s, ox + Inches(0.3), oy + Inches(0.18), Inches(4.5), Inches(0.4),
         "산출물 (Markdown)", size=14, bold=True, color=INK_0)
outs = [
    ("로그구조템플릿.md", "원시 로그 구조 자동 추론"),
    ("이벤트분석_v1.md",  "모션·동작 중심 1차 후보"),
    ("이벤트분석_v2.md",  "사용자 확정 최종 정의"),
]
for i, (name, desc) in enumerate(outs):
    y = oy + Inches(0.7) + Inches(1.15) * i
    add_box(s, ox + Inches(0.3), y, Inches(4.4), Inches(0.95),
            fill=WHITE, line=LINE)
    add_text(s, ox + Inches(0.45), y + Inches(0.12), Inches(4.0), Inches(0.4),
             name, size=13, bold=True, color=INK_0)
    add_text(s, ox + Inches(0.45), y + Inches(0.52), Inches(4.0), Inches(0.4),
             desc, size=11, color=INK_3)

add_text(s, Inches(0.55), Inches(6.65), Inches(12), Inches(0.4),
         "사용자 대화로 도메인 지식이 반영되어야 v2가 신뢰 가능한 정의가 됨",
         size=12, color=INK_3)
add_footer(s, 7)

# =========================================================
# SLIDE 8 — Stage 3
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 3 · Verification",
                "모션 페어링 · 시퀀스 (v1 → v2)", num="06")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 03", dark=True)

specs = [
    ("이벤트분석 v2",            Inches(0.7),  Inches(2.2)),
    ("LLM\n페어링·시퀀스 추출",   Inches(3.4),  Inches(2.2)),
    ("모션_페어링_분석 v1.md",    Inches(6.5),  Inches(2.2)),
    ("사용자 검토",               Inches(9.5),  Inches(2.2)),
    ("모션_페어링_분석 v2.md",    Inches(9.5),  Inches(4.5)),
]
fb_h = Inches(1.2)
for t, x, y in specs:
    add_box(s, x, y, Inches(2.6), fb_h, fill=WHITE, line=INK_1, line_w=1.0,
            text=t, text_size=12, text_bold=True, text_color=INK_0)

add_arrow(s, Inches(3.3),  Inches(2.8), Inches(3.4),  Inches(2.8), color=INK_1, weight=1.5)
add_arrow(s, Inches(6.0),  Inches(2.8), Inches(6.5),  Inches(2.8), color=INK_1, weight=1.5)
add_arrow(s, Inches(9.1),  Inches(2.8), Inches(9.5),  Inches(2.8), color=INK_1, weight=1.5)
add_arrow(s, Inches(9.5),  Inches(2.4), Inches(4.7),  Inches(2.0),
          color=INK_3, weight=1.0, dashed=True)
add_text(s, Inches(5.0), Inches(1.7), Inches(4), Inches(0.3),
         "수정·보정 (반복)", size=11, color=INK_3)
add_arrow(s, Inches(10.8), Inches(3.4), Inches(10.8), Inches(4.5),
          color=INK_1, weight=1.5)
add_text(s, Inches(11.3), Inches(3.7), Inches(2), Inches(0.4),
         "확정", size=12, color=INK_0, bold=True)

add_text(s, Inches(0.55), Inches(6.0), Inches(12), Inches(0.4),
         "이 단계에서 동작(모션) 중심의 페어링·시퀀스 데이터가 명시적으로 정의됨",
         size=14, color=INK_1)
add_text(s, Inches(0.55), Inches(6.4), Inches(12), Inches(0.4),
         "→ Stage 4의 ReAct 루프가 참고할 가장 중요한 도메인 명세 (정확도가 코드 품질을 결정)",
         size=12, color=INK_3)
add_footer(s, 8)

# =========================================================
# SLIDE 9 — Stage 4 (ReAct Loop)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 4 · Code Generation",
                "ReAct 자가수정 루프 — 최대 10회", num="07")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 04", dark=True)

nodes = [
    ("Thought\n코드 설계",       Inches(4.5),  Inches(2.0)),
    ("Action\n코드 작성/수정",   Inches(7.5),  Inches(2.0)),
    ("Observation\n샘플 로그 실행", Inches(7.5),  Inches(4.0)),
    ("Pass / Fail\n판정",        Inches(4.5),  Inches(4.0)),
]
for t, x, y in nodes:
    add_box(s, x, y, Inches(2.6), Inches(1.4), fill=WHITE, line=INK_1, line_w=1.0,
            text=t, text_size=13, text_bold=True, text_color=INK_0)

add_arrow(s, Inches(7.1),  Inches(2.7), Inches(7.5),  Inches(2.7), color=INK_1, weight=1.5)
add_arrow(s, Inches(8.8),  Inches(3.4), Inches(8.8),  Inches(4.0), color=INK_1, weight=1.5)
add_arrow(s, Inches(7.5),  Inches(4.7), Inches(7.1),  Inches(4.7), color=INK_1, weight=1.5)
add_arrow(s, Inches(5.0),  Inches(4.0), Inches(5.0),  Inches(3.4), color=INK_1, weight=1.5)

# Pass exit
add_box(s, Inches(0.7), Inches(4.3), Inches(2.6), Inches(0.9),
        fill=INK_1, line=INK_1,
        text="✓ Pass\nparser_v1.py 확정",
        text_size=12, text_bold=True, text_color=WHITE)
add_arrow(s, Inches(4.5),  Inches(4.7), Inches(3.3),  Inches(4.7), color=INK_1, weight=1.5)
add_text(s, Inches(3.4), Inches(4.4), Inches(1.0), Inches(0.3),
         "성공", size=10, color=INK_1, bold=True)

# Give up
add_box(s, Inches(10.5), Inches(2.0), Inches(2.4), Inches(0.9),
        fill=PANEL, line=LINE_2,
        text="✗ Give up\n10회 초과 → 점검",
        text_size=11, text_bold=True, text_color=INK_2)
add_arrow(s, Inches(10.1), Inches(2.5), Inches(10.5), Inches(2.5),
          color=INK_3, weight=1.0, dashed=True)

add_text(s, Inches(0.55), Inches(5.6), Inches(12), Inches(0.4),
         "참고 입력 / 탈출 조건", size=14, bold=True, color=INK_0)
add_bullets(s, Inches(0.65), Inches(5.95), Inches(12.5), Inches(1.2), [
    "참고: 원시로그템플릿.md · 이벤트분석_v2.md · 모션_페어링_분석_v2.md",
    "탈출 조건: 1번의 로그를 무오류로 통과 (가능하면 10회 이내 빠르게 수렴)",
    "최신 하네스 기법 적용 — 실패 로그를 다음 Thought 컨텍스트에 슬라이싱하여 주입",
], size=12)
add_footer(s, 9)

# =========================================================
# SLIDE 10 — Stage 4: parser spec
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 4 · parser_v1.py 산출",
                "원시 로그 → 이벤트 레코드 → SQLite", num="08")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 04", dark=True)

add_box(s, Inches(0.55), Inches(2.0), Inches(2.8), Inches(1.0),
        fill=WHITE, line=LINE_2,
        text="원시 로그\n(타임스탬프 정렬)",
        text_size=13, text_bold=True, text_color=INK_1)
add_box(s, Inches(4.0),  Inches(2.0), Inches(2.8), Inches(1.0),
        fill=INK_1, line=INK_1,
        text="parser_v1.py\n(자동 생성)",
        text_size=13, text_bold=True, text_color=WHITE)
add_box(s, Inches(7.45), Inches(2.0), Inches(5.4), Inches(1.0),
        fill=WHITE, line=LINE_2,
        text="이벤트 레코드\nstart / end / motion event / desc",
        text_size=13, text_bold=True, text_color=INK_1)
add_arrow(s, Inches(3.35), Inches(2.5), Inches(4.0), Inches(2.5), color=INK_1, weight=1.5)
add_arrow(s, Inches(6.8),  Inches(2.5), Inches(7.45),Inches(2.5), color=INK_1, weight=1.5)

# DB box (right)
add_box(s, Inches(7.45), Inches(3.4), Inches(5.4), Inches(1.6),
        fill=PANEL, line=LINE_2)
add_text(s, Inches(7.65), Inches(3.55), Inches(5), Inches(0.4),
         "SQLite — events 테이블 (예시)",
         size=13, bold=True, color=INK_0)
schema = "id INTEGER PK\nts_start TEXT\nts_end   TEXT\nmotion   TEXT\ndesc     TEXT"
add_text(s, Inches(7.65), Inches(3.95), Inches(5), Inches(1.2),
         schema, size=11, color=INK_2)

# Left bullets
add_text(s, Inches(0.55), Inches(3.4), Inches(6.5), Inches(0.4),
         "처리 방식", size=14, bold=True, color=INK_0)
add_bullets(s, Inches(0.65), Inches(3.8), Inches(6.5), Inches(2.5), [
    "타임스탬프 기준으로 정렬 후 순차 읽기",
    "시작 / 종료 / 모션 이벤트 / 설명을 한 레코드로 묶음",
    "이벤트 단위로 SQLite에 적재",
    "실패 시 실패 위치·로그 라인을 다음 ReAct 루프에 전달",
    "전 과정·전 진행 로그를 시각적으로 노출",
], size=12)
add_footer(s, 10)

# =========================================================
# SLIDE 11 — Stage 5
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 5 · Volume Test",
                "전체 원시 로그 검증 · 진행 시각화", num="09")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 05", dark=True)

add_box(s, Inches(0.55), Inches(2.2), Inches(2.6), Inches(1.0),
        fill=INK_1, line=INK_1, text="parser_v1.py\n(Stage 4 산출)",
        text_size=12, text_bold=True, text_color=WHITE)
add_box(s, Inches(3.4),  Inches(2.2), Inches(2.6), Inches(1.0),
        fill=WHITE, line=LINE_2, text="전체 원시 로그\n1G ~ 5G",
        text_size=12, text_bold=True, text_color=INK_1)
add_box(s, Inches(6.25), Inches(2.2), Inches(2.6), Inches(1.0),
        fill=WHITE, line=LINE_2, text="순차 실행\nTS 정렬",
        text_size=12, text_bold=True, text_color=INK_1)
add_box(s, Inches(9.1),  Inches(1.6), Inches(3.7), Inches(1.0),
        fill=PANEL, line=LINE_2, text="SQLite\nevents 적재",
        text_size=12, text_bold=True, text_color=INK_1)
add_box(s, Inches(9.1),  Inches(2.8), Inches(3.7), Inches(1.0),
        fill=PANEL, line=LINE_2, text="진행 시각화 UI\n실패율·처리율",
        text_size=12, text_bold=True, text_color=INK_1)

add_arrow(s, Inches(3.15), Inches(2.7), Inches(3.4), Inches(2.7), color=INK_1, weight=1.5)
add_arrow(s, Inches(6.0),  Inches(2.7), Inches(6.25),Inches(2.7), color=INK_1, weight=1.5)
add_arrow(s, Inches(8.85), Inches(2.5), Inches(9.1), Inches(2.1), color=INK_1, weight=1.5)
add_arrow(s, Inches(8.85), Inches(2.9), Inches(9.1), Inches(3.3), color=INK_1, weight=1.5)

add_box(s, Inches(9.1), Inches(4.0), Inches(3.7), Inches(0.9),
        fill=PANEL, line=LINE_2, text="오퍼레이터 트리아지\n실패 케이스 보강",
        text_size=12, text_bold=True, text_color=INK_1)
add_arrow(s, Inches(10.95), Inches(3.8), Inches(10.95), Inches(4.0),
          color=INK_3, weight=1.0, dashed=True)

add_text(s, Inches(0.55), Inches(5.0), Inches(12), Inches(0.4),
         "포인트", size=14, bold=True, color=INK_0)
add_bullets(s, Inches(0.65), Inches(5.4), Inches(12.5), Inches(1.6), [
    "Stage 4가 일부 로그(샘플)에 대한 무오류 통과만 검증한 반면, Stage 5는 전체 운영 규모 검증",
    "메모리·I/O 부담 — 청크 단위 스트리밍 + 진행 상태 영속화 권장",
    "실패 케이스는 다시 Stage 2/3의 v2 산출물 보강 인풋으로 환류",
], size=12)
add_footer(s, 11)

# =========================================================
# SLIDE 12 — Data Standard / Storage / DB
# =========================================================
s = new_slide()
set_slide_title(s, prs, "데이터 표준 · 저장소 · DB",
                "타임스탬프 KST · 행처리 · MinIO/S3 · SQLite", num="10")

cards = [
    ("타임스탬프 표준", "전 단계 KST(Asia/Seoul) 통일",
     ["YYYY-MM-DD HH:mm:ss.SSS", "KST · UTC+9", "후속 분석·정렬·페어링의 기준"]),
    ("스토리지", "단기 Web 서버 / 후보 MinIO·S3",
     ["1차 다운로드 ~ 30 MB", "Volume Test 1 ~ 5 GB", "객체 스토리지 전환 검토"]),
    ("산출물 (MD)", "분석 결과 문서",
     ["로그구조템플릿.md", "이벤트분석 v1·v2.md", "모션_페어링_분석 v1·v2.md"]),
    ("SQLite", "parser 결과 영속화",
     ["events(id, ts_start, ts_end, motion, desc)", "Volume Test 시 대량 적재", "분석·재현성 기반"]),
]
cx0 = Inches(0.55); cy0 = Inches(1.8)
cw, ch = Inches(6.2), Inches(2.5)
gx, gy = Inches(0.20), Inches(0.20)
for i, (h, sub, items) in enumerate(cards):
    col = i % 2; row = i // 2
    x = cx0 + (cw + gx) * col
    y = cy0 + (ch + gy) * row
    add_box(s, x, y, cw, ch, fill=WHITE, line=LINE_2)
    add_text(s, x + Inches(0.25), y + Inches(0.18), cw - Inches(0.4), Inches(0.4),
             h, size=15, bold=True, color=INK_0)
    add_text(s, x + Inches(0.25), y + Inches(0.58), cw - Inches(0.4), Inches(0.35),
             sub, size=11, color=INK_3)
    add_bullets(s, x + Inches(0.25), y + Inches(0.98), cw - Inches(0.5), Inches(1.5),
                items, size=12)
add_footer(s, 12)

# =========================================================
# SLIDE 13 — 산출물 매트릭스 (table)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "산출물 매트릭스",
                "단계별 산출물 · 형식 · 설명", num="11")

rows = [
    ("Stage 01", "전처리 로그", "raw / line", "KST·행 단위 정규화"),
    ("Stage 02", "로그구조템플릿.md", "Markdown", "구조 자동 추론 (LLM)"),
    ("Stage 02", "이벤트분석_v1.md / v2.md", "Markdown", "모션 이벤트 정의 (v2 = 사용자 확정)"),
    ("Stage 03", "모션_페어링_분석_v1.md / v2.md", "Markdown", "페어링·시퀀스 정의 (v2 = 사용자 확정)"),
    ("Stage 04", "parser_v1.py", "Python", "ReAct 루프 산출 — SQLite 적재"),
    ("Stage 04/05", "events 테이블", "SQLite", "start / end / motion / desc"),
    ("Stage 05", "진행 로그·실패 케이스", "UI / log", "전체 진행 시각화"),
]
# header
hx = Inches(0.55); hy = Inches(1.8)
col_widths = [Inches(2.0), Inches(4.5), Inches(2.0), Inches(3.7)]
headers = ["단계", "산출물", "형식", "설명"]
xs = [hx]
for w in col_widths[:-1]:
    xs.append(xs[-1] + w)

# header row
add_box(s, hx, hy, sum(col_widths, Inches(0)), Inches(0.5),
        fill=PANEL, line=LINE_2)
for i, (htxt, x, w) in enumerate(zip(headers, xs, col_widths)):
    add_text(s, x + Inches(0.18), hy + Inches(0.13), w - Inches(0.2), Inches(0.3),
             htxt, size=12, bold=True, color=INK_0)

# data rows
ry = hy + Inches(0.5)
rh = Inches(0.55)
for r, (a, b, c, d) in enumerate(rows):
    yr = ry + rh * r
    fill_color = WHITE if r % 2 == 0 else SOFT
    add_box(s, hx, yr, sum(col_widths, Inches(0)), rh,
            fill=fill_color, line=LINE)
    for i, (text, x, w) in enumerate(zip([a, b, c, d], xs, col_widths)):
        add_text(s, x + Inches(0.18), yr + Inches(0.16), w - Inches(0.2), Inches(0.3),
                 text, size=11, bold=(i == 0), color=INK_1 if i == 0 else INK_2)
add_footer(s, 13)

# =========================================================
# SLIDE 14 — Tech stack
# =========================================================
s = new_slide()
set_slide_title(s, prs, "기술 스택",
                "주요 컴포넌트 · 외부 의존", num="12")

stack = [
    ("Python", "주 코딩 언어"),
    ("Web Server", "대화·진행 UI · 임시 저장"),
    ("EDS API", "Datalake 2.0 · 메타·다운로드"),
    ("LLM API", "템플릿·이벤트·페어링·ReAct"),
    ("MinIO / S3", "원시 로그 (후보)"),
    ("SQLite", "parser 결과 저장"),
]
sx0 = Inches(0.55); sy0 = Inches(2.0)
sw, sh_ = Inches(4.05), Inches(1.5)
gx, gy = Inches(0.15), Inches(0.20)
for i, (n, d) in enumerate(stack):
    col = i % 3; row = i // 3
    x = sx0 + (sw + gx) * col
    y = sy0 + (sh_ + gy) * row
    add_box(s, x, y, sw, sh_, fill=WHITE, line=LINE_2)
    add_text(s, x + Inches(0.3), y + Inches(0.25), sw - Inches(0.5), Inches(0.5),
             n, size=20, bold=True, color=INK_0)
    add_text(s, x + Inches(0.3), y + Inches(0.85), sw - Inches(0.5), Inches(0.5),
             d, size=12, color=INK_3)

add_text(s, Inches(0.55), Inches(5.4), Inches(12), Inches(0.4),
         "주요 의존 흐름", size=14, bold=True, color=INK_0)
add_text(s, Inches(0.55), Inches(5.8), Inches(12.5), Inches(1.0),
         "Browser ↔ Web (Python) ↔ EDS / LLM / Storage / SQLite     |     Engine: ReAct Loop → parser_v1.py",
         size=13, color=INK_2)
add_footer(s, 14)

# =========================================================
# SLIDE 15 — Risks
# =========================================================
s = new_slide()
set_slide_title(s, prs, "리스크 · 다음 단계", "발표 Q&A 대비", num="13")

risks = [
    ("① Volume Test 비용", "1~5GB 처리 시 메모리·I/O 폭증. 청크 스트리밍·중간 저장 전략 필요."),
    ("② ReAct 루프 비용·시간", "최대 10회 LLM 호출. 컨텍스트 슬라이싱·캐시·중단 조건 정교화."),
    ("③ 사용자 대화 정합성", "v1→v2 단계 누락 시 후속 단계 오염. 대화 이력·확정 시점 명시 저장."),
    ("④ 저장소 결정", "Web 서버 vs MinIO/S3. 30MB는 단기 OK / 1~5GB는 객체 스토리지 권장."),
    ("⑤ 파서 일반화", "parser_v1은 특정 장비/포맷 한정. 다른 eqp는 v2 재정의 필요."),
    ("⑥ 관측·재현성", "전체 진행 로그 / LLM 호출 기록 / 시드로 재현성 확보."),
]
rx0 = Inches(0.55); ry0 = Inches(1.8)
rw, rh = Inches(6.2), Inches(1.55)
gx, gy = Inches(0.20), Inches(0.18)
for i, (h, body) in enumerate(risks):
    col = i % 2; row = i // 2
    x = rx0 + (rw + gx) * col
    y = ry0 + (rh + gy) * row
    add_box(s, x, y, rw, rh, fill=WHITE, line=LINE_2)
    add_text(s, x + Inches(0.25), y + Inches(0.20), rw - Inches(0.4), Inches(0.4),
             h, size=14, bold=True, color=INK_0)
    add_text(s, x + Inches(0.25), y + Inches(0.65), rw - Inches(0.4), Inches(1.0),
             body, size=12, color=INK_2)
add_footer(s, 15)

# =========================================================
# SLIDE 16 — Q&A
# =========================================================
s = new_slide()
add_text(s, Inches(0.8), Inches(2.6), Inches(12), Inches(1.5),
         "Q & A", size=80, bold=True, color=INK_0)
# divider
div = s.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                         Inches(0.8), Inches(4.1),
                         Inches(1.5), Emu(25400))
div.line.fill.background(); div.fill.solid(); div.fill.fore_color.rgb = INK_1
div.shadow.inherit = False

add_text(s, Inches(0.8), Inches(4.3), Inches(12), Inches(0.6),
         "MCC 워크플로우에 대한 질문을 주세요.",
         size=20, color=INK_2)
add_text(s, Inches(0.8), Inches(5.0), Inches(12), Inches(0.5),
         "Thank you.", size=16, color=INK_3)
add_footer(s, 16)

# ---------- save ----------
out = r'c:\205-MCC-워크플로우\MCC_Workflow_Presentation_v2.pptx'
prs.save(out)
print('saved:', out)
