# -*- coding: utf-8 -*-
"""OpenAI-compatible chat completion client (JSON + SSE 둘 다 지원)"""
import json
import re
from typing import Iterable

import requests

from config import (
    LLM_BASE_URL, LLM_API_KEY, LLM_MODEL,
    REQUEST_TIMEOUT, LLM_TEMPERATURE, LLM_MAX_TOKENS,
    LLM_REPETITION_PENALTY, LLM_FREQUENCY_PENALTY,
)


class LLMError(RuntimeError):
    pass


def _build_request(messages, model, temperature, stream, max_tokens,
                   *, json_mode=False, prefill=None,
                   repetition_penalty=None, frequency_penalty=None,
                   stop=None):
    url = f"{LLM_BASE_URL.rstrip('/')}/chat/completions"
    headers = {
        "Authorization": f"Bearer {LLM_API_KEY}",
        "Content-Type": "application/json",
        "Accept": "text/event-stream" if stream else "application/json",
    }
    msgs = list(messages)
    if prefill:
        msgs.append({"role": "assistant", "content": prefill})
    payload = {
        "model": model or LLM_MODEL,
        "messages": msgs,
        "temperature": LLM_TEMPERATURE if temperature is None else temperature,
        "max_tokens": max_tokens or LLM_MAX_TOKENS,
        "stream": stream,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    if repetition_penalty is not None:
        payload["repetition_penalty"] = repetition_penalty
    if frequency_penalty is not None:
        payload["frequency_penalty"] = frequency_penalty
    if stop:
        payload["stop"] = stop
    return url, headers, payload


def _extract_content_from_obj(obj: dict) -> str:
    """SSE chunk 또는 non-stream 응답 객체에서 content 추출."""
    try:
        choice = obj["choices"][0]
    except (KeyError, IndexError, TypeError):
        return ""
    # SSE delta
    delta = choice.get("delta")
    if isinstance(delta, dict) and isinstance(delta.get("content"), str):
        return delta["content"]
    # Non-stream message
    msg = choice.get("message")
    if isinstance(msg, dict) and isinstance(msg.get("content"), str):
        return msg["content"]
    # Fallback (some servers use 'text')
    if isinstance(choice.get("text"), str):
        return choice["text"]
    return ""


def _detect_repetition(buf: str, *, window: int = 240, threshold: int = 6) -> bool:
    """누적 문자열의 끝부분에서 동일 패턴이 N번 이상 반복되면 True.
    LLM 무한 루프 (예: '*(Wait, I need to ensure...*' 반복) 조기 탈출용."""
    if len(buf) < window * threshold:
        return False
    tail = buf[-window:]
    # tail 안에서 같은 문자열이 threshold 회 이상 발견되면 반복
    # 가장 흔한 짧은 라인 단위로 검사
    last_line = tail.rstrip().split("\n")[-1].strip()
    if len(last_line) < 20:
        return False
    return buf.count(last_line) >= threshold


def _parse_sse_lines(lines):
    """SSE iterable(라인 단위) → 누적 content 문자열.
    반복 루프 감지 시 조기 종료."""
    chunks: list[str] = []
    accumulated = ""
    check_at = 4096  # bytes accumulated → 다음 검사 시점
    for raw in lines:
        if raw is None:
            continue
        line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
        line = line.strip()
        if not line or line.startswith(":"):
            continue
        if line.startswith("data:"):
            payload = line[5:].lstrip()
        elif line.startswith("data "):
            payload = line[5:].lstrip()
        else:
            payload = line
        if payload == "[DONE]":
            break
        try:
            obj = json.loads(payload)
        except json.JSONDecodeError:
            continue
        chunk = _extract_content_from_obj(obj)
        if chunk:
            chunks.append(chunk)
            accumulated += chunk
            if len(accumulated) >= check_at:
                if _detect_repetition(accumulated):
                    chunks.append(
                        "\n\n[REPETITION DETECTED — aborting stream]"
                    )
                    break
                check_at = len(accumulated) + 4096
    return "".join(chunks)


def chat(messages: Iterable[dict], *, model: str | None = None,
         temperature: float | None = None, stream: bool = True,
         max_tokens: int | None = None,
         json_mode: bool = False, prefill: str | None = None,
         repetition_penalty: float | None = None,
         frequency_penalty: float | None = None,
         stop: list | None = None) -> str:
    """LLM 호출. stream=True 면 SSE, False 면 JSON.
    어느 쪽이든 서버 형식에 맞춰 자동 보정한다.

    옵션:
    - json_mode: response_format=json_object (서버 지원 시 valid JSON 강제)
    - prefill:   assistant 메시지 prefix (응답 시작을 강제. 예: "{")
    - repetition_penalty / frequency_penalty: 반복 루프 억제
    - stop: stop sequences
    """
    url, headers, payload = _build_request(
        messages, model, temperature, stream, max_tokens,
        json_mode=json_mode, prefill=prefill,
        repetition_penalty=repetition_penalty,
        frequency_penalty=frequency_penalty,
        stop=stop,
    )
    try:
        r = requests.post(url, headers=headers, json=payload,
                          timeout=REQUEST_TIMEOUT, stream=stream)
    except requests.exceptions.RequestException as e:
        raise LLMError(f"LLM 호출 실패: {e}") from e
    if r.status_code != 200:
        raise LLMError(f"LLM HTTP {r.status_code}: {r.text[:500]}")

    content_type = r.headers.get("Content-Type", "").lower()

    def _with_prefill(out: str) -> str:
        return (prefill + out) if prefill else out

    # 1) 서버가 SSE 로 응답
    if "event-stream" in content_type:
        return _with_prefill(_parse_sse_lines(r.iter_lines(decode_unicode=True)))

    # 2) JSON 으로 응답
    if "application/json" in content_type:
        try:
            obj = r.json()
        except ValueError as e:
            raise LLMError(
                f"JSON 파싱 실패. Content-Type={content_type}\n"
                f"본문 일부:\n{r.text[:500]}"
            ) from e
        out = _extract_content_from_obj(obj)
        if not out:
            raise LLMError(f"응답 구조 비정상: {obj}")
        return _with_prefill(out)

    # 3) Content-Type 이 모호한 경우 — 본문으로 분기
    text = r.text
    stripped = text.lstrip()
    if not stripped:
        raise LLMError(
            f"빈 응답. status={r.status_code} content-type={content_type!r}\n"
            "(서버가 예상과 다른 형식으로 응답했습니다)"
        )
    if stripped.startswith("{"):
        try:
            obj = json.loads(stripped)
        except json.JSONDecodeError as e:
            raise LLMError(
                f"JSON 파싱 실패. Content-Type={content_type}\n"
                f"본문 일부:\n{text[:500]}"
            ) from e
        out = _extract_content_from_obj(obj)
        if not out:
            raise LLMError(f"응답 구조 비정상: {obj}")
        return _with_prefill(out)
    if "data:" in stripped[:200]:
        return _with_prefill(_parse_sse_lines(text.splitlines()))
    raise LLMError(
        f"알 수 없는 응답 형식. Content-Type={content_type}\n"
        f"본문 일부:\n{text[:500]}"
    )


def ping() -> tuple[bool, str]:
    """간단한 헬스 체크 — 'ping' 한 마디만 보낸다."""
    try:
        out = chat(
            [{"role": "user", "content": "ping"}],
            temperature=0.0, stream=True,
        )
        return True, (out[:80].strip() or "(빈 응답)")
    except Exception as e:
        return False, str(e)


_FENCE_RE = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.DOTALL)
_THINK_TAG_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def strip_thinking(text: str) -> str:
    """<think>...</think> 블록만 안전하게 제거. 나머지 prose 는 보존하고
    extract_json 의 '가장 큰 균형 JSON' 휴리스틱이 처리하게 둔다."""
    if not text:
        return text
    return _THINK_TAG_RE.sub("", text).strip()


def _find_balanced_json_spans(text: str) -> list[tuple[int, int]]:
    """텍스트 안의 모든 `{` 시작점에서 매칭되는 `}` 까지의 균형 범위를 수집.
    각 `{` 를 독립적인 후보 시작점으로 취급하여,
    응답 어딘가에 짝 없는 brace 가 섞여 있어도 실제 JSON 을 놓치지 않는다.
    중첩/내부 candidates 도 모두 포함됨."""
    spans: list[tuple[int, int]] = []
    n = len(text)
    for s in range(n):
        if text[s] != '{':
            continue
        depth = 0
        for i in range(s, n):
            ch = text[i]
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    spans.append((s, i + 1))
                    break
    return spans


def extract_json(text: str) -> dict:
    """LLM 응답에서 가장 그럴듯한 JSON 객체 추출.
    전략:
    1) <think>...</think> 제거
    2) ```json ... ``` 코드펜스가 있으면 우선 시도
    3) 균형 잡힌 {...} 후보들을 모두 수집 → 길이 내림차순으로 시도 → 처음 파싱 성공한 것 반환
       (thinking 안의 자잘한 {...} 조각이 실제 spec 보다 먼저 잡히는 사고 방지)
    """
    if not text:
        raise LLMError("빈 응답")
    cleaned = strip_thinking(text)
    if not cleaned:
        raise LLMError("응답이 비어 있습니다 (thinking 제거 후).\n원문 일부:\n" + text[:800])

    # 1) fenced JSON 우선
    m = _FENCE_RE.search(cleaned)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass

    # 2) 모든 top-level 균형 JSON 후보를 길이 큰 것부터 시도
    spans = _find_balanced_json_spans(cleaned)
    spans.sort(key=lambda se: se[1] - se[0], reverse=True)
    last_err: str | None = None
    for s, e in spans:
        candidate = cleaned[s:e]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError as ex:
            last_err = str(ex)
            continue

    if not spans:
        raise LLMError(
            "응답에서 JSON 객체를 찾을 수 없습니다 ({...} 패턴 자체가 없음).\n"
            "→ 사이드바에서 'Qwen /no_think' 토글을 켜고 다시 시도하세요.\n"
            "원문 일부:\n" + text[:800]
        )
    raise LLMError(
        f"JSON 후보 {len(spans)}개 모두 파싱 실패. (마지막 에러: {last_err})\n"
        "원문 일부:\n" + text[:800]
    )
