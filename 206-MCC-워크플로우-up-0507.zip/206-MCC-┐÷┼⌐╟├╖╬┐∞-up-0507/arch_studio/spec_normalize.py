# -*- coding: utf-8 -*-
"""Spec 정규화 — LLM 출력의 누락/타입 차이를 안전한 기본값으로 보정"""
from typing import Any


def _str(v, default=""):
    if v is None: return default
    return str(v)


def _list(v):
    if v is None: return []
    if isinstance(v, list): return v
    return [v]


def _dict(v):
    if isinstance(v, dict): return v
    return {}


def normalize(spec: dict) -> dict:
    if not isinstance(spec, dict):
        spec = {}

    proj = _dict(spec.get("project"))
    project = {
        "title":    _str(proj.get("title"),    "시스템 아키텍처"),
        "subtitle": _str(proj.get("subtitle"), ""),
        "eyebrow":  _str(proj.get("eyebrow"),  "ARCHITECTURE BRIEF"),
        "tagline":  _str(proj.get("tagline"),  ""),
        "metrics":  [],
    }
    for m in _list(proj.get("metrics"))[:4]:
        m = _dict(m)
        project["metrics"].append({
            "num":   _str(m.get("num")),
            "label": _str(m.get("label")),
        })

    stages = []
    for st in _list(spec.get("stages")):
        st = _dict(st)
        stages.append({
            "no":       _str(st.get("no"),       f"{len(stages)+1:02d}"),
            "name":     _str(st.get("name"),     "Stage"),
            "tagline":  _str(st.get("tagline"),  ""),
            "summary":  _str(st.get("summary"),  ""),
            "subtitle": _str(st.get("subtitle"), ""),
            "bullets":  [_str(b) for b in _list(st.get("bullets"))[:6]],
        })

    components = _dict(spec.get("components"))
    comp = {
        "user":     _str(components.get("user"), "User"),
        "web":      [_str(x) for x in _list(components.get("web"))],
        "external": [_str(x) for x in _list(components.get("external"))],
        "engine":   [_str(x) for x in _list(components.get("engine"))],
        "storage":  [_str(x) for x in _list(components.get("storage"))],
    }

    data_specs = []
    for ds in _list(spec.get("data_specs"))[:6]:
        ds = _dict(ds)
        item = {
            "title": _str(ds.get("title")),
            "desc":  _str(ds.get("desc")),
            "chips": [_str(c) for c in _list(ds.get("chips"))],
            "code":  _str(ds.get("code")),
        }
        data_specs.append(item)

    outputs_matrix = []
    for row in _list(spec.get("outputs_matrix")):
        if isinstance(row, list):
            cells = [_str(c) for c in row]
        elif isinstance(row, dict):
            cells = [
                _str(row.get("stage")),
                _str(row.get("name")),
                _str(row.get("format")),
                _str(row.get("desc")),
            ]
        else:
            continue
        cells = (cells + ["", "", "", ""])[:4]
        outputs_matrix.append(cells)

    tech_stack = []
    for t in _list(spec.get("tech_stack"))[:9]:
        t = _dict(t)
        tech_stack.append({
            "name": _str(t.get("name")),
            "desc": _str(t.get("desc")),
        })

    risks = []
    for r in _list(spec.get("risks"))[:8]:
        r = _dict(r)
        risks.append({
            "title": _str(r.get("title")),
            "body":  _str(r.get("body")),
        })

    return {
        "project":               project,
        "stages":                stages,
        "full_flow_mermaid":     _str(spec.get("full_flow_mermaid")),
        "component_arch_mermaid":_str(spec.get("component_arch_mermaid")),
        "components":            comp,
        "data_specs":            data_specs,
        "outputs_matrix":        outputs_matrix,
        "tech_stack":            tech_stack,
        "risks":                 risks,
    }
