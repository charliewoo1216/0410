# -*- coding: utf-8 -*-
"""LLM 프롬프트 — 시스템 설명 → 아키텍처 spec(JSON)

설계 원칙
- 모델이 스스로 검증·재고하는 'ensure', 'verify', 'check' 류 어휘 금지
  → Qwen 등 reasoning 모델이 무한 루프에 빠지는 직접 원인
- 짧고 단정적인 명령형
- 스키마는 가능한 한 간결한 1개의 예시
"""

SYSTEM_PROMPT = """You output a single JSON object only. No prose. No thinking.
Start with `{` and end with `}`. Korean text values."""


SCHEMA_GUIDE = """다음 키를 가진 JSON 한 개를 채우세요. 모든 텍스트는 한국어.

{
  "project": {
    "title": "한 줄 카피", "subtitle": "정식명", "eyebrow": "프로젝트 코드",
    "tagline": "1-2 문장 요약",
    "metrics": [{"num": "5단계", "label": "라벨"}]
  },
  "stages": [
    {"no": "01", "name": "Stage Name", "tagline": "한 줄",
     "summary": "요약 제목", "subtitle": "부제",
     "bullets": ["포인트1", "포인트2"]}
  ],
  "full_flow_mermaid": "flowchart TB\\n  ...",
  "component_arch_mermaid": "flowchart TB\\n  subgraph ... ",
  "components": {
    "user": "User",
    "web": ["..."], "external": ["..."],
    "engine": ["..."], "storage": ["..."]
  },
  "data_specs": [
    {"title": "...", "desc": "...", "chips": ["..."]}
  ],
  "outputs_matrix": [["Stage 01", "산출물", "형식", "설명"]],
  "tech_stack": [{"name": "...", "desc": "..."}],
  "risks": [{"title": "...", "body": "..."}]
}

가이드:
- stages 3~6 개
- full_flow_mermaid: flowchart TB 또는 LR. 단계+외부+산출물+피드백 포함
- component_arch_mermaid: subgraph 5개 (Client·Web·External·Engine·Storage)
- bullets 5개 이내
- data_specs 카드는 chips 또는 code 중 하나
"""


def build_messages(user_input: str, project_hint: str = "",
                   no_think: bool = True) -> list[dict]:
    nothink = "/no_think " if no_think else ""
    user_msg = (
        f"{nothink}{SCHEMA_GUIDE}\n"
        f"[프로젝트 힌트] {project_hint or '(없음)'}\n"
        f"[시스템 설명] {user_input.strip()}\n"
        f"[즉시 JSON 출력]"
    )
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user",   "content": user_msg},
    ]
