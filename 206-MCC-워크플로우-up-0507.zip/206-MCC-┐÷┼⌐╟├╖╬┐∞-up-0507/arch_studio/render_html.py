# -*- coding: utf-8 -*-
"""v2 스타일 (white / grey / black) HTML 문서 렌더러"""
from html import escape as h
from pathlib import Path

import config


def mermaid_status() -> dict:
    """Mermaid 자산 상태 — UI 가 사이드바에서 보여줄 때 사용."""
    local = Path(__file__).parent / config.MERMAID_LOCAL_PATH
    if local.exists() and local.stat().st_size > 50_000:
        return {
            "mode":  "local",
            "path":  str(local),
            "bytes": local.stat().st_size,
            "ok":    True,
        }
    if config.ALLOW_CDN_FALLBACK:
        return {"mode": "cdn", "url": config.MERMAID_CDN_URL, "ok": True}
    return {
        "mode":  "missing",
        "ok":    False,
        "hint":  (
            f"{config.MERMAID_LOCAL_PATH} 가 없습니다. "
            "사내 Nexus에서 mermaid.min.js 를 받아 해당 경로에 두거나, "
            "config.MERMAID_NEXUS_URL 을 설정한 뒤 "
            "`python install_assets.py` 실행하세요."
        ),
    }


def _mermaid_script_tag() -> str:
    """결과 HTML 안에 들어갈 mermaid <script>. 가능한 경우 inline (오프라인 OK)."""
    st = mermaid_status()
    if st["mode"] == "local":
        js = Path(st["path"]).read_text(encoding="utf-8", errors="ignore")
        return f"<script>\n{js}\n</script>"
    if st["mode"] == "cdn":
        return f'<script src="{config.MERMAID_CDN_URL}"></script>'
    # missing — emit a visible error block + no-op script
    return (
        '<script>console.warn("mermaid.min.js missing — diagrams will not render.");</script>'
        '<style>.mermaid::before{content:"⚠️ mermaid.min.js 없음 — 사내 Nexus에서 받아 assets/ 에 배치하세요."; '
        'display:block; color:#b91c1c; font-size:12px; margin-bottom:8px}</style>'
    )


CSS = """
:root{
  --bg:#ffffff; --bg-soft:#fafafa; --panel:#ffffff;
  --ink-0:#0a0a0a; --ink-1:#111827; --ink-2:#374151;
  --ink-3:#6b7280; --ink-4:#9ca3af;
  --line:#e5e7eb; --line-2:#d1d5db;
  --shadow:0 1px 2px rgba(15,23,42,.04), 0 4px 14px rgba(15,23,42,.06);
}
*{box-sizing:border-box} html,body{margin:0;padding:0}
body{font-family:'Pretendard','맑은 고딕','Malgun Gothic',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  color:var(--ink-1); background:var(--bg); line-height:1.6; -webkit-font-smoothing:antialiased}
.wrap{max-width:1280px; margin:0 auto; padding:48px 28px 96px}
header.hero{padding:56px 40px 48px; border-radius:20px; background:var(--panel);
  border:1px solid var(--line); box-shadow:var(--shadow); position:relative}
.eyebrow{display:inline-flex; gap:8px; align-items:center; padding:6px 12px; border-radius:999px;
  background:#f3f4f6; border:1px solid var(--line); font-size:11px; letter-spacing:.18em;
  text-transform:uppercase; color:var(--ink-3); font-weight:600}
.eyebrow .dot{width:6px; height:6px; border-radius:50%; background:var(--ink-1)}
h1{font-size:clamp(28px,4.2vw,46px); line-height:1.15; margin:18px 0 12px; letter-spacing:-.02em;
  font-weight:800; color:var(--ink-0)}
h1 .accent{color:var(--ink-3)}
.lede{max-width:820px; color:var(--ink-2); font-size:16px}
.metrics{display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; margin-top:32px}
.metric{padding:18px 20px; border-radius:14px; background:var(--panel); border:1px solid var(--line)}
.metric .num{font-size:24px; font-weight:800; letter-spacing:-.02em; color:var(--ink-0)}
.metric .lbl{font-size:12px; color:var(--ink-3); margin-top:4px; font-weight:500}
section{margin-top:56px}
.section-head{display:flex; align-items:end; justify-content:space-between; gap:18px;
  margin-bottom:18px; flex-wrap:wrap; border-bottom:1px solid var(--line); padding-bottom:14px}
.section-head h2{font-size:22px; margin:0; letter-spacing:-.01em; color:var(--ink-0); font-weight:800}
.section-head h2 .num{display:inline-block; width:28px; height:28px; border-radius:8px;
  background:var(--ink-1); color:#fff; font-size:13px; line-height:28px; text-align:center;
  margin-right:10px; vertical-align:middle; font-weight:700}
.section-head p{margin:0; color:var(--ink-3); font-size:13px}
.pill{display:inline-block; padding:4px 10px; border-radius:999px; font-size:11px; font-weight:600;
  background:#f3f4f6; color:var(--ink-2); border:1px solid var(--line); letter-spacing:.04em}
.pill.dark{background:var(--ink-1); color:#fff; border-color:var(--ink-1)}
.card{padding:22px; border-radius:16px; background:var(--panel); border:1px solid var(--line);
  box-shadow:var(--shadow)}
.grid-2{display:grid; grid-template-columns:1fr 1fr; gap:16px}
.grid-3{display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:14px}
.grid-5{display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:12px}
.grid-6{display:grid; grid-template-columns:repeat(6,minmax(0,1fr)); gap:10px}
@media (max-width:980px){.grid-2,.grid-5,.grid-6{grid-template-columns:1fr 1fr}.grid-3{grid-template-columns:1fr}.metrics{grid-template-columns:1fr 1fr}}
.stage-card{position:relative}
.stage-card .stage-no{position:absolute; right:18px; top:14px; font-size:56px; font-weight:900;
  color:#f3f4f6; letter-spacing:-.04em; line-height:1}
.stage-card h3{margin:6px 0 2px; font-size:17px; color:var(--ink-0)}
.stage-card .sub{color:var(--ink-3); font-size:12px; margin-bottom:10px}
.stage-card ul{padding-left:18px; margin:6px 0; color:var(--ink-2); font-size:13px}
.stage-card ul li{margin:4px 0}
.pipeline{display:grid; gap:10px; padding:14px; border-radius:14px;
  background:var(--bg-soft); border:1px solid var(--line)}
.pstep{padding:14px; border-radius:12px; background:#fff; border:1px solid var(--line);
  position:relative; box-shadow:var(--shadow)}
.pstep .n{font-size:11px; letter-spacing:.18em; color:var(--ink-3); font-weight:600}
.pstep .t{font-weight:700; margin:2px 0 4px; color:var(--ink-0)}
.pstep .d{font-size:12px; color:var(--ink-3)}
.chip{font-size:12px; padding:6px 10px; border-radius:8px; background:#f3f4f6;
  border:1px solid var(--line); color:var(--ink-2); font-weight:500; display:inline-block; margin:3px 4px 0 0}
.mermaid{background:var(--bg-soft); border:1px solid var(--line); border-radius:14px;
  padding:18px; overflow-x:auto}
.risk{display:grid; grid-template-columns:repeat(3,1fr); gap:12px}
.risk .card{padding:18px}
.risk h4{margin:0 0 4px; font-size:14px; color:var(--ink-0)}
.risk p{margin:0; color:var(--ink-3); font-size:13px}
pre{margin:0; font-size:12px; color:var(--ink-1); background:var(--bg-soft); padding:10px;
  border-radius:8px; border:1px solid var(--line); overflow:auto}
table.spec{width:100%; border-collapse:collapse; font-size:13px}
table.spec th, table.spec td{padding:10px 12px; border-bottom:1px solid var(--line);
  text-align:left; vertical-align:top}
table.spec th{font-weight:700; color:var(--ink-1); background:var(--bg-soft)}
table.spec td{color:var(--ink-2)}
table.spec tr:last-child td{border-bottom:none}
footer{margin-top:80px; color:var(--ink-3); font-size:12px; text-align:center}
@media print{body{background:#fff} section{break-inside:avoid; page-break-inside:avoid}
  .card,.mermaid,.pipeline,.pstep,.metric{box-shadow:none}}
"""

MERMAID_INIT = """
mermaid.initialize({
  startOnLoad: true, theme: 'base', securityLevel: 'loose',
  fontFamily: "'Pretendard','맑은 고딕','Malgun Gothic',sans-serif",
  themeVariables: {
    background:'#fafafa', primaryColor:'#ffffff', primaryBorderColor:'#374151',
    primaryTextColor:'#111827', lineColor:'#6b7280', secondaryColor:'#f3f4f6',
    tertiaryColor:'#ffffff', noteBkgColor:'#f9fafb', noteTextColor:'#111827',
    noteBorderColor:'#9ca3af', clusterBkg:'#ffffff', clusterBorder:'#9ca3af',
    titleColor:'#0a0a0a', edgeLabelBackground:'#ffffff', actorBkg:'#ffffff',
    actorBorder:'#374151', actorTextColor:'#111827', actorLineColor:'#9ca3af',
    signalColor:'#111827', signalTextColor:'#111827', labelBoxBkgColor:'#ffffff',
    labelBoxBorderColor:'#9ca3af', labelTextColor:'#111827', loopTextColor:'#374151',
    activationBorderColor:'#374151', activationBkgColor:'#f3f4f6',
    sequenceNumberColor:'#ffffff'
  },
  flowchart:{curve:'basis', useMaxWidth:true, htmlLabels:true},
  sequence:{useMaxWidth:true, mirrorActors:false}
});
"""


def _mermaid_block(code: str) -> str:
    if not code or not code.strip():
        return ""
    return f'<div class="mermaid">\n{code.strip()}\n</div>'


def _hero(project: dict) -> str:
    metrics_html = ""
    for m in project.get("metrics", []):
        metrics_html += (
            f'<div class="metric"><div class="num">{h(m["num"])}</div>'
            f'<div class="lbl">{h(m["label"])}</div></div>'
        )
    return f"""
<header class="hero">
  <span class="eyebrow"><span class="dot"></span>{h(project["eyebrow"])}</span>
  <h1>{h(project["title"])}<br/><span class="accent">{h(project["subtitle"])}</span></h1>
  <p class="lede">{h(project["tagline"])}</p>
  <div class="metrics">{metrics_html}</div>
</header>
"""


def _pipeline_section(stages: list) -> str:
    if not stages:
        return ""
    n = len(stages)
    cols = f"grid-template-columns:repeat({n},1fr)"
    pstep_html = ""
    for st in stages:
        pstep_html += (
            f'<div class="pstep"><div class="n">STAGE {h(st["no"])}</div>'
            f'<div class="t">{h(st["name"])}</div>'
            f'<div class="d">{h(st["tagline"])}</div></div>'
        )
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">1</span>시스템 한눈에 보기</h2>
      <p>{n}단계 End-to-End 파이프라인</p>
    </div>
    <span class="pill">End-to-End</span>
  </div>
  <div class="pipeline" style="{cols}">{pstep_html}</div>
</section>
"""


def _full_flow_section(mermaid: str) -> str:
    if not mermaid:
        return ""
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">2</span>전체 시스템 흐름도 (End-to-End)</h2>
      <p>모든 단계 · 산출물 · 사용자 피드백 · 외부 의존을 한 장으로</p>
    </div>
    <span class="pill dark">Master Flow</span>
  </div>
  {_mermaid_block(mermaid)}
</section>
"""


def _component_arch_section(mermaid: str) -> str:
    if not mermaid:
        return ""
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">3</span>컴포넌트 아키텍처</h2>
      <p>사용자 · Web · External · Storage · Engine</p>
    </div>
    <span class="pill">Architecture</span>
  </div>
  {_mermaid_block(mermaid)}
</section>
"""


def _stage_cards_section(stages: list) -> str:
    if not stages:
        return ""
    cards = ""
    for st in stages:
        bullets = "".join(f"<li>{h(b)}</li>" for b in st.get("bullets", []))
        cards += f"""
    <div class="card stage-card">
      <span class="stage-no">{h(st["no"])}</span>
      <span class="pill dark">{h(st["name"])}</span>
      <h3>{h(st.get("summary") or st["name"])}</h3>
      <div class="sub">{h(st["subtitle"])}</div>
      <ul>{bullets}</ul>
    </div>"""
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">4</span>단계별 핵심 요약</h2>
      <p>각 단계의 입력 · 산출물 · 핵심 결정사항</p>
    </div>
    <span class="pill">Stages</span>
  </div>
  <div class="grid-3">{cards}</div>
</section>
"""


def _data_specs_section(specs: list) -> str:
    if not specs:
        return ""
    cards = ""
    for d in specs:
        if d.get("code"):
            body = f'<pre><code>{h(d["code"])}</code></pre>'
        else:
            chips = "".join(f'<span class="chip">{h(c)}</span>' for c in d.get("chips", []))
            body = chips or ""
        cards += f"""
    <div class="card">
      <h3 style="margin-top:0">{h(d["title"])}</h3>
      <p style="color:var(--ink-3); margin:6px 0">{h(d["desc"])}</p>
      {body}
    </div>"""
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">5</span>데이터 표준 & 산출물 스키마</h2>
      <p>타임스탬프 · 행처리 · 저장소 · DB</p>
    </div>
    <span class="pill">Data Spec</span>
  </div>
  <div class="grid-3">{cards}</div>
</section>
"""


def _outputs_matrix_section(rows: list) -> str:
    if not rows:
        return ""
    body = "".join(
        f"<tr><td>{h(r[0])}</td><td>{h(r[1])}</td><td>{h(r[2])}</td><td>{h(r[3])}</td></tr>"
        for r in rows
    )
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">6</span>산출물 매트릭스</h2>
      <p>단계별 산출물 · 형식 · 설명</p>
    </div>
    <span class="pill">Outputs</span>
  </div>
  <div class="card">
    <table class="spec">
      <thead><tr><th style="width:130px">단계</th><th>산출물</th><th style="width:130px">형식</th><th>설명</th></tr></thead>
      <tbody>{body}</tbody>
    </table>
  </div>
</section>
"""


def _tech_stack_section(items: list) -> str:
    if not items:
        return ""
    n = max(2, min(6, len(items)))
    grid = "grid-3" if n <= 3 else ("grid-5" if n <= 5 else "grid-6")
    cards = "".join(
        f'<div class="card"><strong>{h(t["name"])}</strong>'
        f'<div style="color:var(--ink-3); font-size:12px">{h(t["desc"])}</div></div>'
        for t in items
    )
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">7</span>기술 스택</h2>
      <p>주요 컴포넌트 · 외부 의존</p>
    </div>
    <span class="pill">Tech Stack</span>
  </div>
  <div class="{grid}">{cards}</div>
</section>
"""


def _risks_section(risks: list) -> str:
    if not risks:
        return ""
    cards = "".join(
        f'<div class="card"><h4>{h(r["title"])}</h4><p>{h(r["body"])}</p></div>'
        for r in risks
    )
    return f"""
<section>
  <div class="section-head">
    <div>
      <h2><span class="num">8</span>리스크 · 고려사항 · 다음 단계</h2>
      <p>발표 시 Q&amp;A 대비</p>
    </div>
    <span class="pill">Risks</span>
  </div>
  <div class="risk">{cards}</div>
</section>
"""


def render(spec: dict, *, brief_id: str = "ARCH BRIEF") -> str:
    project = spec["project"]
    title_text = f"{project['title']} — {project['subtitle']}".strip(" —")
    sections = [
        _hero(project),
        _pipeline_section(spec["stages"]),
        _full_flow_section(spec["full_flow_mermaid"]),
        _component_arch_section(spec["component_arch_mermaid"]),
        _stage_cards_section(spec["stages"]),
        _data_specs_section(spec["data_specs"]),
        _outputs_matrix_section(spec["outputs_matrix"]),
        _tech_stack_section(spec["tech_stack"]),
        _risks_section(spec["risks"]),
    ]
    body = "\n".join(s for s in sections if s)
    return f"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{h(title_text)}</title>
{_mermaid_script_tag()}
<style>{CSS}</style>
</head>
<body>
<div class="wrap">
{body}
<footer>© {h(brief_id)} — generated by Architecture Studio</footer>
</div>
<script>{MERMAID_INIT}</script>
</body>
</html>
"""
