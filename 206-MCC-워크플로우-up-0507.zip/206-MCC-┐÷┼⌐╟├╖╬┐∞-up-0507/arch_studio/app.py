# -*- coding: utf-8 -*-
"""Architecture Studio — Streamlit 앱
LLM 입력(시스템 설명) → 구조화 spec → v2 스타일 HTML + PPTX 생성
"""
from __future__ import annotations
import json
import re
import time
from datetime import date

import streamlit as st

import config
from llm_client import chat, extract_json, LLMError, ping
from prompts import build_messages
from spec_normalize import normalize
from render_html import render as render_html, mermaid_status
from render_pptx import render_to_bytes as render_pptx
import debug_log

st.set_page_config(
    page_title=config.APP_TITLE,
    page_icon="🧭",
    layout="wide",
)


# ---------- helpers ----------
def _safe_filename(s: str) -> str:
    s = (s or "arch_brief").strip()
    s = re.sub(r"[\\/:\"*?<>|]+", "_", s)
    s = re.sub(r"\s+", "_", s)
    return s[:60] or "arch_brief"


def _estimate_slide_count(spec: dict) -> int:
    n = 1 + 1 + 1  # cover + agenda + glance
    if spec.get("full_flow_mermaid") or spec.get("stages"): n += 1
    if any(spec["components"].get(k) for k in ("web", "external", "engine", "storage")): n += 1
    n += len(spec.get("stages", []))
    if spec.get("data_specs"): n += 1
    if spec.get("outputs_matrix"): n += 1
    if spec.get("tech_stack"): n += 1
    if spec.get("risks"): n += 1
    n += 1  # Q&A
    return n


# ---------- session ----------
if "spec" not in st.session_state:
    st.session_state.spec = None
if "raw_response" not in st.session_state:
    st.session_state.raw_response = None
if "last_input" not in st.session_state:
    st.session_state.last_input = ""
if "elapsed" not in st.session_state:
    st.session_state.elapsed = 0.0


# ---------- sidebar ----------
with st.sidebar:
    st.markdown(f"### {config.APP_TITLE}")
    st.caption(config.APP_TAGLINE)
    st.divider()
    st.markdown("**LLM 설정** (config.py)")
    st.code(
        f"base_url : {config.LLM_BASE_URL}\n"
        f"model    : {config.LLM_MODEL}\n"
        f"timeout  : {config.REQUEST_TIMEOUT}s",
        language="text",
    )
    st.markdown("**파라미터**")
    temperature = st.slider("temperature", 0.0, 1.0,
                            value=config.LLM_TEMPERATURE, step=0.1)
    use_stream = st.toggle("SSE 스트리밍 모드", value=True,
                           help="대다수 OpenAI-호환 서버는 stream=true(SSE)로 응답. 끄면 일반 JSON 응답으로 호출.")
    no_think = st.toggle("Qwen /no_think (사고 모드 OFF)", value=True,
                         help="Qwen3 계열은 기본 reasoning 모드. 켜두면 /no_think 디렉티브를 자동 주입.")
    use_json_mode = st.toggle("JSON 모드 (response_format)", value=config.LLM_USE_JSON_MODE,
                              help="OpenAI-호환 서버가 지원하면 valid JSON 만 출력하도록 강제. 미지원이면 자동 무시됨.")
    use_prefill = st.toggle("Assistant prefill ('{' 강제)", value=config.LLM_USE_PREFILL,
                            help="응답을 '{' 로 시작하도록 강제. thinking 차단의 가장 강력한 방법.")
    use_anti_repeat = st.toggle("반복 루프 방지", value=True,
                                help="repetition_penalty + 스트리밍 중 반복 감지 시 조기 중단.")
    st.divider()
    st.markdown("**Mermaid 자산** (HTML 다이어그램용)")
    _ms = mermaid_status()
    if _ms["mode"] == "local":
        st.success(f"🟢 로컬 inline · {_ms['bytes']:,} bytes (오프라인 OK)")
    elif _ms["mode"] == "cdn":
        st.warning("🟡 CDN 폴백 (HTML 열 때 인터넷 필요)")
    else:
        st.error("🔴 mermaid.min.js 없음 — 다이어그램 미렌더링")
        st.caption(_ms.get("hint", ""))
        with st.expander("설치 방법"):
            st.markdown(
                "1) 사내 Nexus 에서 `mermaid.min.js` 직접 URL 을 알아낸 뒤 "
                "`config.MERMAID_NEXUS_URL` 에 설정\n"
                "2) `python install_assets.py` 실행\n"
                "3) 또는 다른 PC 에서 `mermaid.min.js` 를 받아 "
                "`arch_studio/assets/mermaid.min.js` 로 직접 복사"
            )
    st.divider()
    if st.button("🔌 연결 테스트", use_container_width=True):
        with st.spinner("ping..."):
            ok, msg = ping()
        if ok:
            st.success(f"OK · {msg}")
        else:
            st.error(msg)
    if st.button("세션 초기화", use_container_width=True):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        st.rerun()

    st.divider()
    st.markdown("**🪵 디버그 로그**")
    st.caption(f"저장 위치: `{debug_log.LOG_DIR.relative_to(debug_log.LOG_DIR.parent.parent)}`")
    _logs = debug_log.list_logs(limit=10)
    if not _logs:
        st.caption("(아직 로그 없음)")
    else:
        for p in _logs:
            stem = p.stem
            status = "✅" if stem.endswith("_ok") else ("⚠️" if stem.endswith("_partial") else "❌")
            label = stem[:-3] if stem.endswith(("_ok", "err")) else stem
            with st.expander(f"{status}  {p.stem}"):
                try:
                    rec = debug_log.read_log(p)
                    st.caption(
                        f"{rec.get('timestamp','-')}  ·  {rec.get('duration_sec','-')}s"
                    )
                    if rec.get("response", {}).get("error"):
                        st.error(rec["response"]["error"][:300])
                    summary = rec.get("response", {}).get("spec_summary")
                    if summary:
                        st.json(summary, expanded=False)
                    st.download_button(
                        "💾 이 로그 다운로드",
                        data=p.read_bytes(),
                        file_name=p.name,
                        mime="application/json",
                        use_container_width=True,
                        key=f"dl_{p.name}",
                    )
                except Exception as e:
                    st.error(f"로그 읽기 실패: {e}")
    if st.button("오래된 로그 정리 (최신 50개만 유지)", use_container_width=True):
        n = debug_log.cleanup_logs(keep=50)
        st.success(f"{n}개 정리됨")
        st.rerun()


# ---------- header ----------
st.markdown(
    f"## {config.APP_TITLE}  \n"
    f"<span style='color:#6b7280;font-size:14px'>{config.APP_TAGLINE}</span>",
    unsafe_allow_html=True,
)


# ---------- inputs ----------
col_a, col_b = st.columns([3, 2])
with col_a:
    user_input = st.text_area(
        "시스템 로직 / 설명",
        height=320,
        placeholder=(
            "예) 5단계 파이프라인. 1) 사용자가 EDS API로 장비 로그를 검색·다운로드 "
            "한다. 2) LLM으로 이벤트 분석 v1을 생성하고 사용자 대화로 v2로 확정 ..."
        ),
        key="user_input",
        value=st.session_state.last_input,
    )

with col_b:
    project_hint = st.text_area(
        "프로젝트 힌트 (선택)",
        height=140,
        placeholder=(
            "프로젝트명, 코드명, 발표 대상, 강조 포인트 등.\n"
            "예) 205 · MCC Workflow · 사내 발표"
        ),
        key="project_hint",
    )
    brief_id = st.text_input(
        "Brief ID (HTML/PPT 푸터)",
        value=f"ARCH BRIEF · {date.today().isoformat()}",
    )

go = st.button("✨ 생성하기", type="primary", use_container_width=True,
               disabled=not user_input.strip())


# ---------- generate ----------
if go:
    st.session_state.last_input = user_input
    messages = build_messages(user_input, project_hint, no_think=no_think)
    raw = None; parsed = None; spec = None; err = None
    chat_kwargs = dict(
        temperature=temperature,
        stream=use_stream,
        json_mode=use_json_mode,
        prefill="{" if use_prefill else None,
    )
    if use_anti_repeat:
        chat_kwargs["repetition_penalty"] = config.LLM_REPETITION_PENALTY
        chat_kwargs["frequency_penalty"]  = config.LLM_FREQUENCY_PENALTY
    with st.spinner(f"LLM 호출 중… ({config.LLM_MODEL})"):
        t0 = time.time()
        try:
            raw = chat(messages, **chat_kwargs)
        except LLMError as e:
            err = f"LLM 호출 실패: {e}"
        elapsed = time.time() - t0

    if raw is not None and err is None:
        try:
            parsed = extract_json(raw)
            spec = normalize(parsed)
        except LLMError as e:
            err = str(e)

    # --- 디버그 로그 저장 (성공/실패 무관) ---
    try:
        log_path = debug_log.log_llm_call(
            user_input=user_input,
            project_hint=project_hint,
            no_think=no_think,
            stream=use_stream,
            temperature=temperature,
            messages=messages,
            raw_response=raw,
            elapsed_sec=elapsed,
            extracted=parsed,
            spec=spec,
            error=err,
        )
    except Exception as _e:
        log_path = None

    st.session_state.raw_response = raw
    st.session_state.elapsed = elapsed
    st.session_state.last_log_path = str(log_path) if log_path else None

    if err:
        st.error(err)
        if log_path:
            st.caption(f"디버그 로그 저장됨: `{log_path.name}`")
        if raw:
            with st.expander("LLM 원문 응답 보기"):
                st.code(raw, language="text")
        st.stop()

    st.session_state.spec = spec
    st.success(
        f"생성 완료 · {elapsed:.1f}s"
        + (f"  ·  로그: `{log_path.name}`" if log_path else "")
    )


# ---------- output ----------
spec = st.session_state.spec
if spec:
    st.divider()
    title = spec["project"]["title"] or "(제목 없음)"
    subtitle = spec["project"]["subtitle"]
    st.markdown(f"### 결과 미리보기  \n**{title}**  \n_{subtitle}_")

    tabs = st.tabs(["📄 HTML 미리보기", "📊 PPT 다운로드", "🧩 Spec (JSON)", "🪵 LLM 원문"])

    # --- HTML preview tab ---
    with tabs[0]:
        try:
            html = render_html(spec, brief_id=brief_id)
        except Exception as e:
            st.error(f"HTML 렌더링 실패: {e}")
        else:
            st.download_button(
                "💾 HTML 다운로드",
                data=html.encode("utf-8"),
                file_name=_safe_filename(title) + ".html",
                mime="text/html",
                use_container_width=True,
            )
            st.components.v1.html(html, height=900, scrolling=True)

    # --- PPT tab ---
    with tabs[1]:
        try:
            pptx_bytes = render_pptx(spec)
        except Exception as e:
            st.error(f"PPT 렌더링 실패: {e}")
        else:
            st.download_button(
                "💾 PPT 다운로드",
                data=pptx_bytes,
                file_name=_safe_filename(title) + ".pptx",
                mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                use_container_width=True,
            )
            st.info(
                f"PPT 슬라이드 약 {_estimate_slide_count(spec)}장 생성 (16:9, 한글 맑은 고딕)."
                " 다운로드 후 PowerPoint 또는 Keynote에서 열어 확인하세요."
            )

    # --- Spec tab ---
    with tabs[2]:
        st.caption("LLM이 생성한 구조화 spec. 이 spec으로 HTML/PPT가 결정론적으로 렌더링됩니다.")
        st.json(spec, expanded=False)
        st.download_button(
            "💾 Spec JSON 다운로드",
            data=json.dumps(spec, ensure_ascii=False, indent=2).encode("utf-8"),
            file_name=_safe_filename(title) + ".spec.json",
            mime="application/json",
        )

    # --- Raw LLM tab ---
    with tabs[3]:
        st.caption(f"LLM 원문 응답 · {st.session_state.elapsed:.1f}s")
        st.code(st.session_state.raw_response or "(없음)", language="text")
