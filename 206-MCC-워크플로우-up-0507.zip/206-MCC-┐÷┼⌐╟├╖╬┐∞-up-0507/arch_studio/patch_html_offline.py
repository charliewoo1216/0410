# -*- coding: utf-8 -*-
"""기존 HTML 파일의 CDN <script src="..."> 를 로컬 inline 으로 교체.

사용법
------
python patch_html_offline.py <파일들...>

예)
python patch_html_offline.py ../MCC_Workflow_Diagram_v2.html
python patch_html_offline.py ..\*.html

assets/mermaid.min.js 가 있어야 함 (없으면 먼저 install_assets.py 실행).
"""
from __future__ import annotations
import re
import sys
import glob
from pathlib import Path

import config

CDN_PATTERNS = [
    re.compile(
        r'<script\b[^>]*src=["\'][^"\']*mermaid[^"\']*\.min\.js[^"\']*["\'][^>]*>\s*</script>',
        re.IGNORECASE,
    ),
]


def patch(path: Path, js: str) -> bool:
    if not path.exists():
        print(f"[skip] not found: {path}"); return False
    if path.suffix.lower() not in (".html", ".htm"):
        print(f"[skip] not html: {path}"); return False
    text = path.read_text(encoding="utf-8")
    inline = f"<script>\n{js}\n</script>"
    new_text = text
    replaced = 0
    for pat in CDN_PATTERNS:
        # 람다로 우회: JS 본문의 \s, \1 같은 시퀀스가 치환 템플릿으로 해석되지 않도록
        new_text, n = pat.subn(lambda _m: inline, new_text)
        replaced += n
    if replaced == 0:
        print(f"[skip] no CDN script tag found: {path}")
        return False
    backup = path.with_suffix(path.suffix + ".bak")
    backup.write_text(text, encoding="utf-8")
    path.write_text(new_text, encoding="utf-8")
    print(f"[ok]   {path}  (replaced {replaced} tag, backup: {backup.name})")
    return True


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__); return 2
    js_path = Path(__file__).parent / config.MERMAID_LOCAL_PATH
    if not js_path.exists():
        print(f"[ERR] {js_path} 가 없습니다.")
        print("       먼저 install_assets.py 를 실행하거나 파일을 직접 배치하세요.")
        return 3
    js = js_path.read_text(encoding="utf-8", errors="ignore")
    print(f"[INFO] using {js_path} ({js_path.stat().st_size:,} bytes)")

    targets = []
    for arg in sys.argv[1:]:
        targets.extend(glob.glob(arg))
    if not targets:
        print("대상 파일이 없습니다."); return 2

    ok = 0
    for t in targets:
        if patch(Path(t), js):
            ok += 1
    print(f"\n총 {ok}/{len(targets)} 파일 패치 완료")
    return 0


if __name__ == "__main__":
    sys.exit(main())
