# -*- coding: utf-8 -*-
"""v2 스타일 (white / grey / black) PPTX 렌더러"""
from __future__ import annotations
from io import BytesIO

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from lxml import etree

# ---------- palette ----------
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
SOFT  = RGBColor(0xFA, 0xFA, 0xFA)
PANEL = RGBColor(0xF3, 0xF4, 0xF6)
LINE  = RGBColor(0xE5, 0xE7, 0xEB)
LINE2 = RGBColor(0xD1, 0xD5, 0xDB)
INK4  = RGBColor(0x9C, 0xA3, 0xAF)
INK3  = RGBColor(0x6B, 0x72, 0x80)
INK2  = RGBColor(0x37, 0x41, 0x51)
INK1  = RGBColor(0x11, 0x18, 0x27)
INK0  = RGBColor(0x0A, 0x0A, 0x0A)

FONT = '맑은 고딕'


# ---------- low-level helpers ----------
def _set_bg(slide, color=WHITE):
    bg = slide.background
    bg.fill.solid()
    bg.fill.fore_color.rgb = color


def _text(slide, x, y, w, h, text, *, size=14, bold=False, color=INK1,
          align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line_spacing=1.15):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor
    for i, line in enumerate(str(text).split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align; p.line_spacing = line_spacing
        r = p.add_run(); r.text = line
        r.font.name = FONT; r.font.size = Pt(size); r.font.bold = bold
        r.font.color.rgb = color
    return tb


def _box(slide, x, y, w, h, *, fill=WHITE, line=LINE, line_w=0.75,
         text=None, text_color=INK1, text_size=13, text_bold=False,
         shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER,
         anchor=MSO_ANCHOR.MIDDLE):
    sh = slide.shapes.add_shape(shape, x, y, w, h)
    sh.fill.solid(); sh.fill.fore_color.rgb = fill
    sh.line.color.rgb = line; sh.line.width = Pt(line_w)
    sh.shadow.inherit = False
    if text is not None:
        tf = sh.text_frame
        tf.word_wrap = True
        tf.margin_left = Emu(60000); tf.margin_right = Emu(60000)
        tf.margin_top = Emu(40000); tf.margin_bottom = Emu(40000)
        tf.vertical_anchor = anchor
        for i, line in enumerate(str(text).split('\n')):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align; p.line_spacing = 1.15
            r = p.add_run(); r.text = line
            r.font.name = FONT; r.font.size = Pt(text_size); r.font.bold = text_bold
            r.font.color.rgb = text_color
    return sh


def _arrow(slide, x1, y1, x2, y2, *, color=INK3, weight=1.25, dashed=False):
    line = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, x1, y1, x2, y2)
    line.line.color.rgb = color; line.line.width = Pt(weight)
    ln = line.line._get_or_add_ln()
    if dashed:
        prst = etree.SubElement(ln, qn('a:prstDash')); prst.set('val', 'dash')
    tail = etree.SubElement(ln, qn('a:tailEnd'))
    tail.set('type', 'triangle'); tail.set('w', 'med'); tail.set('h', 'med')
    return line


def _pill(slide, x, y, text, *, dark=False, w=Inches(1.6), h=Inches(0.32)):
    box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    if dark:
        box.fill.solid(); box.fill.fore_color.rgb = INK1
        box.line.fill.background(); col = WHITE
    else:
        box.fill.solid(); box.fill.fore_color.rgb = PANEL
        box.line.color.rgb = LINE; box.line.width = Pt(0.5); col = INK2
    box.shadow.inherit = False
    tf = box.text_frame
    tf.margin_left = Emu(0); tf.margin_right = Emu(0)
    tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = text
    r.font.name = FONT; r.font.size = Pt(10); r.font.bold = True
    r.font.color.rgb = col


def _bullets(slide, x, y, w, h, items, *, size=12, color=INK2, gap_pt=4):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Emu(0); tf.margin_right = Emu(0)
    tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
    for i, it in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.space_after = Pt(gap_pt); p.line_spacing = 1.25
        r = p.add_run(); r.text = "•  " + str(it)
        r.font.name = FONT; r.font.size = Pt(size); r.font.color.rgb = color


def _slide_title(slide, *, title, subtitle=None, num=None):
    if num is not None:
        chip = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                      Inches(0.55), Inches(0.40),
                                      Inches(0.42), Inches(0.42))
        chip.fill.solid(); chip.fill.fore_color.rgb = INK1
        chip.line.fill.background(); chip.shadow.inherit = False
        tf = chip.text_frame
        tf.margin_left = Emu(0); tf.margin_right = Emu(0)
        tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        r = p.add_run(); r.text = num
        r.font.name = FONT; r.font.size = Pt(14); r.font.bold = True
        r.font.color.rgb = WHITE
        title_x = Inches(1.10)
    else:
        title_x = Inches(0.55)
    _text(slide, title_x, Inches(0.42), Inches(11.5), Inches(0.5),
          title, size=24, bold=True, color=INK0)
    if subtitle:
        _text(slide, title_x, Inches(0.92), Inches(11.5), Inches(0.4),
              subtitle, size=12, color=INK3)
    ul = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0.55), Inches(1.35),
        Inches(12.2), Emu(12700))
    ul.line.fill.background(); ul.fill.solid(); ul.fill.fore_color.rgb = LINE
    ul.shadow.inherit = False


def _footer(slide, idx, total, eyebrow):
    _text(slide, Inches(0.55), Inches(7.10), Inches(8), Inches(0.3),
          eyebrow, size=9, color=INK4)
    _text(slide, Inches(11.5), Inches(7.10), Inches(1.4), Inches(0.3),
          f"{idx} / {total}", size=9, color=INK4, align=PP_ALIGN.RIGHT)


# ---------- builders ----------
def _build(spec: dict) -> Presentation:
    project = spec["project"]
    stages = spec["stages"]
    components = spec["components"]
    eyebrow = project["eyebrow"]

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]

    slides = []  # collect (build_fn) — count first to compute totals
    # We instead keep building and number afterwards via counter.

    def new_slide():
        s = prs.slides.add_slide(blank)
        _set_bg(s, WHITE)
        return s

    # Plan slides count
    n_stages = len(stages)
    total = (
        1   # cover
        + 1 # agenda
        + 1 # n-stage glance
        + (1 if spec.get("full_flow_mermaid") or stages else 0)  # master flow (always shown if stages)
        + (1 if any(components.get(k) for k in ("web","external","engine","storage")) else 0)
        + n_stages
        + (1 if spec.get("data_specs") else 0)
        + (1 if spec.get("outputs_matrix") else 0)
        + (1 if spec.get("tech_stack") else 0)
        + (1 if spec.get("risks") else 0)
        + 1 # Q&A
    )

    idx = 0
    def f(s):
        nonlocal idx
        idx += 1
        _footer(s, idx, total, eyebrow)

    # ===== 1. Cover =====
    s = new_slide()
    _text(s, Inches(0.8), Inches(0.7), Inches(11), Inches(0.4),
          eyebrow, size=11, bold=True, color=INK3)
    _text(s, Inches(0.8), Inches(2.3), Inches(11.5), Inches(1.4),
          project["title"], size=46, bold=True, color=INK0)
    if project["subtitle"]:
        _text(s, Inches(0.8), Inches(3.4), Inches(11.5), Inches(0.7),
              project["subtitle"], size=22, color=INK2)
    div = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(4.3),
                             Inches(1.5), Emu(25400))
    div.line.fill.background(); div.fill.solid(); div.fill.fore_color.rgb = INK1
    div.shadow.inherit = False
    if project["tagline"]:
        _text(s, Inches(0.8), Inches(4.5), Inches(11.5), Inches(1.0),
              project["tagline"], size=14, color=INK3)
    # accent
    acc = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(12.0), Inches(0.7),
                             Inches(0.5), Inches(0.5))
    acc.fill.solid(); acc.fill.fore_color.rgb = INK1
    acc.line.fill.background(); acc.shadow.inherit = False
    f(s)

    # ===== 2. Agenda =====
    s = new_slide()
    _slide_title(s, title="발표 순서", subtitle="Agenda", num="00")
    items = []
    items.append(("01", "전체 개요 & 핵심 수치"))
    items.append(("02", "★ 전체 시스템 흐름도"))
    items.append(("03", "컴포넌트 아키텍처"))
    next_no = 4
    for st in stages:
        items.append((f"{next_no:02d}", f"Stage {st['no']} — {st['name']}"))
        next_no += 1
    if spec.get("data_specs"):
        items.append((f"{next_no:02d}", "데이터 표준")); next_no += 1
    if spec.get("outputs_matrix"):
        items.append((f"{next_no:02d}", "산출물 매트릭스")); next_no += 1
    if spec.get("tech_stack"):
        items.append((f"{next_no:02d}", "기술 스택")); next_no += 1
    if spec.get("risks"):
        items.append((f"{next_no:02d}", "리스크 / Q&A"))
    left_x = Inches(0.7); top_y = Inches(1.7)
    col_w = Inches(6.0); row_h = Inches(0.40)
    per_col = max(1, (len(items) + 1) // 2)
    for i, (n, t) in enumerate(items):
        col = i // per_col; row = i % per_col
        x = left_x + Inches(6.2) * col
        y = top_y + (row_h + Inches(0.05)) * row
        _box(s, x, y, col_w, row_h, fill=WHITE, line=LINE)
        _text(s, x + Inches(0.18), y + Inches(0.08), Inches(0.6), Inches(0.3),
              n, size=11, bold=True, color=INK0)
        _text(s, x + Inches(0.85), y + Inches(0.08), Inches(5.0), Inches(0.3),
              t, size=13, color=INK2)
    f(s)

    # ===== 3. N-stage at glance =====
    s = new_slide()
    _slide_title(s, title="시스템 한눈에 보기",
                 subtitle=f"{n_stages}단계 End-to-End 파이프라인", num="01")
    if n_stages:
        # Pipeline row
        avail_w = Inches(12.78); gap = Inches(0.10)
        bw = (avail_w - gap * (n_stages - 1)) / max(n_stages, 1)
        bh = Inches(2.6)
        x0 = Inches(0.55); y0 = Inches(2.0)
        arrow_y = y0 + bh / 2
        for i, st in enumerate(stages):
            x = x0 + (bw + gap) * i
            _box(s, x, y0, bw, bh, fill=WHITE, line=LINE2)
            _text(s, x + Inches(0.2), y0 + Inches(0.18), bw - Inches(0.4), Inches(0.3),
                  f"STAGE {st['no']}", size=10, bold=True, color=INK3)
            _text(s, x + Inches(0.2), y0 + Inches(0.55), bw - Inches(0.4), Inches(0.6),
                  st["name"], size=18, bold=True, color=INK0)
            _text(s, x + Inches(0.2), y0 + Inches(1.25), bw - Inches(0.4), Inches(1.3),
                  st["tagline"], size=12, color=INK3)
            if i < n_stages - 1:
                _arrow(s, x + bw, arrow_y, x + bw + gap, arrow_y,
                       color=INK1, weight=1.5)
    # metrics
    metrics = project.get("metrics", [])[:4]
    if metrics:
        mx = Inches(0.55); my = Inches(5.6)
        avail = Inches(12.78); gap = Inches(0.10)
        mw = (avail - gap * (len(metrics) - 1)) / max(len(metrics), 1)
        mh = Inches(1.1)
        for i, m in enumerate(metrics):
            x = mx + (mw + gap) * i
            _box(s, x, my, mw, mh, fill=WHITE, line=LINE2)
            _text(s, x + Inches(0.2), my + Inches(0.15), mw, Inches(0.55),
                  m["num"], size=22, bold=True, color=INK0)
            _text(s, x + Inches(0.2), my + Inches(0.72), mw, Inches(0.4),
                  m["label"], size=11, color=INK3)
    f(s)

    # ===== 4. Master Flow =====
    if stages:
        s = new_slide()
        _slide_title(s, title="전체 시스템 흐름도",
                     subtitle="단계 · 외부 · 산출물 · 피드백을 한 장으로",
                     num="02")
        external = components.get("external", []) or []
        # Top — external row
        _text(s, Inches(0.55), Inches(1.7), Inches(2.0), Inches(0.4),
              "EXTERNAL", size=9, bold=True, color=INK4)
        if external:
            ex_w = Inches(1.6); ex_gap = Inches(0.20)
            ex_total = ex_w * len(external) + ex_gap * (len(external) - 1)
            ex_x0 = Inches(0.55) + Inches(2.0) + (Inches(10.78) - ex_total) / 2
            for i, ext in enumerate(external):
                x = ex_x0 + (ex_w + ex_gap) * i
                _box(s, x, Inches(1.65), ex_w, Inches(0.55),
                     fill=WHITE, line=LINE2, text=ext, text_size=11,
                     text_color=INK2)

        # Mid — pipeline
        pipe_n = n_stages + 2  # leading 사용자, trailing 결과
        pipe_avail = Inches(12.78)
        pipe_gap = Inches(0.10)
        pipe_w = (pipe_avail - pipe_gap * (pipe_n - 1)) / pipe_n
        pipe_y = Inches(2.55); pipe_h = Inches(0.85)
        pipe_arrow_y = pipe_y + pipe_h / 2
        _text(s, Inches(0.55), Inches(2.05), Inches(2.0), Inches(0.4),
              "PIPELINE", size=9, bold=True, color=INK4)
        labels = ["사용자\n시작"] + [f"{st['no']} · {st['name']}" for st in stages] + ["결과\nSQLite/DB"]
        positions = []
        for i, lbl in enumerate(labels):
            x = Inches(0.55) + (pipe_w + pipe_gap) * i
            _box(s, x, pipe_y, pipe_w, pipe_h, fill=WHITE, line=INK1, line_w=1.0,
                 text=lbl, text_size=10, text_bold=True, text_color=INK0)
            positions.append((x, x + pipe_w))
        for i in range(len(positions) - 1):
            x1 = positions[i][1]; x2 = positions[i + 1][0]
            _arrow(s, x1, pipe_arrow_y, x2, pipe_arrow_y, color=INK1, weight=1.5)

        # External -> pipeline (dashed)
        if external:
            ex_w = Inches(1.6); ex_gap = Inches(0.20)
            ex_total = ex_w * len(external) + ex_gap * (len(external) - 1)
            ex_x0 = Inches(0.55) + Inches(2.0) + (Inches(10.78) - ex_total) / 2
            stage_indices = list(range(1, n_stages + 1))
            for i in range(len(external)):
                ex_cx = ex_x0 + (ex_w + ex_gap) * i + ex_w / 2
                tgt_idx = stage_indices[min(i, len(stage_indices) - 1)]
                tgt_x_l, tgt_x_r = positions[tgt_idx]
                tgt_cx = (tgt_x_l + tgt_x_r) / 2
                _arrow(s, ex_cx, Inches(2.20), tgt_cx, pipe_y,
                       color=INK3, weight=1.0, dashed=True)

        # Outputs row — one per stage
        _text(s, Inches(0.55), Inches(4.6), Inches(2.0), Inches(0.4),
              "OUTPUTS", size=9, bold=True, color=INK4)
        out_y = Inches(4.55); out_h = Inches(0.85)
        for i, st in enumerate(stages):
            x_l, x_r = positions[i + 1]
            cw = x_r - x_l
            _box(s, x_l, out_y, cw, out_h, fill=PANEL, line=LINE2,
                 text=st.get("summary") or st["name"],
                 text_size=10, text_color=INK2)
            cx = (x_l + x_r) / 2
            _arrow(s, cx, pipe_y + pipe_h, cx, out_y,
                   color=INK3, weight=0.9, dashed=True)

        # Feedback row
        _text(s, Inches(0.55), Inches(5.85), Inches(2.0), Inches(0.4),
              "FEEDBACK", size=9, bold=True, color=INK4)
        _box(s, Inches(2.5), Inches(5.85), Inches(8.5), Inches(0.55),
             fill=WHITE, line=INK1,
             text="사용자 검토 / 실패 케이스 환류 (v1 → v2 / 재시도)",
             text_size=11, text_bold=True, text_color=INK0)

        # Reading legend
        _text(s, Inches(0.55), Inches(6.55), Inches(3.5), Inches(0.3),
              "──  메인 흐름     ", size=9, bold=True, color=INK2)
        _text(s, Inches(2.30), Inches(6.55), Inches(4.0), Inches(0.3),
              "----  외부 호출 / 피드백",
              size=9, bold=True, color=INK3)
        _text(s, Inches(5.30), Inches(6.55), Inches(7.0), Inches(0.3),
              "■ 검은 테두리 = 핵심 단계 / 회색 = 산출·외부",
              size=9, color=INK3)
        f(s)

    # ===== 5. Component Architecture =====
    if any(components.get(k) for k in ("web", "external", "engine", "storage")):
        s = new_slide()
        _slide_title(s, title="컴포넌트 아키텍처",
                     subtitle="사용자 · Web · External · Storage · Engine",
                     num="03")

        _box(s, Inches(0.6), Inches(1.7), Inches(2.2), Inches(0.7),
             fill=WHITE, line=INK1, text=components.get("user", "User"),
             text_size=14, text_bold=True, text_color=INK0)

        _row_group(s, Inches(3.4), Inches(1.6), Inches(6.0),
                   "Web Server", components.get("web", []))
        _row_group(s, Inches(9.95), Inches(1.6), Inches(2.85),
                   "External", components.get("external", []))

        # Engine (dark)
        engine = components.get("engine", [])
        _box(s, Inches(3.4), Inches(3.4), Inches(6.0), Inches(1.0),
             fill=INK1, line=INK1)
        _text(s, Inches(3.55), Inches(3.5), Inches(2.5), Inches(0.3),
              "Code Gen Engine", size=11, bold=True, color=WHITE)
        if engine:
            inner_w = Inches(6.0) - Inches(0.3) * 2
            unit_w = (inner_w - Inches(0.15) * (len(engine) - 1)) / max(len(engine), 1)
            for i, e in enumerate(engine):
                ex = Inches(3.55) + (unit_w + Inches(0.15)) * i
                _box(s, ex, Inches(3.85), unit_w, Inches(0.45),
                     fill=WHITE, line=LINE, text=e,
                     text_size=11, text_color=INK1)

        # Storage row
        storage = components.get("storage", [])
        _box(s, Inches(0.6), Inches(5.0), Inches(12.2), Inches(1.7),
             fill=PANEL, line=LINE2)
        _text(s, Inches(0.8), Inches(5.1), Inches(4), Inches(0.3),
              "Storage / DB", size=11, bold=True, color=INK3)
        if storage:
            inner_w = Inches(12.2) - Inches(0.4)
            n = len(storage)
            unit_w = (inner_w - Inches(0.2) * (n - 1)) / n
            for i, st in enumerate(storage):
                ex = Inches(0.8) + (unit_w + Inches(0.2)) * i
                _box(s, ex, Inches(5.55), unit_w, Inches(1.05),
                     fill=WHITE, line=LINE, text=st,
                     text_size=12, text_color=INK1)

        # arrows
        _arrow(s, Inches(2.8), Inches(2.05), Inches(3.4), Inches(2.05), color=INK1, weight=1.5)
        _arrow(s, Inches(9.4), Inches(2.05), Inches(9.95), Inches(2.05), color=INK1, weight=1.5)
        _arrow(s, Inches(6.4), Inches(2.55), Inches(6.4), Inches(3.4),  color=INK1, weight=1.5)
        _arrow(s, Inches(6.4), Inches(4.4),  Inches(6.4), Inches(5.0),  color=INK1, weight=1.5)
        f(s)

    # ===== 6. per-stage detail =====
    for i, st in enumerate(stages, start=4):
        s = new_slide()
        _slide_title(s,
                     title=f"Stage {st['no']} · {st['name']}",
                     subtitle=st.get("tagline", ""),
                     num=f"{i:02d}")
        _pill(s, Inches(11.4), Inches(0.4), f"STAGE {st['no']}", dark=True)

        _box(s, Inches(0.55), Inches(1.85), Inches(12.2), Inches(1.0),
             fill=PANEL, line=LINE2)
        _text(s, Inches(0.8), Inches(2.0), Inches(8), Inches(0.4),
              st.get("summary") or st["name"],
              size=18, bold=True, color=INK0)
        if st.get("subtitle"):
            _text(s, Inches(0.8), Inches(2.5), Inches(11), Inches(0.4),
                  st["subtitle"], size=12, color=INK3)

        if st.get("bullets"):
            _text(s, Inches(0.55), Inches(3.2), Inches(12), Inches(0.4),
                  "핵심 포인트", size=14, bold=True, color=INK0)
            _bullets(s, Inches(0.65), Inches(3.55), Inches(12.5), Inches(3.5),
                     st["bullets"], size=13)
        f(s)

    # ===== 7. Data Spec =====
    if spec.get("data_specs"):
        s = new_slide()
        _slide_title(s, title="데이터 표준 · 저장소 · DB",
                     subtitle="Data Specs", num=f"{4 + n_stages:02d}")
        cards = spec["data_specs"][:4]
        cx0 = Inches(0.55); cy0 = Inches(1.8)
        cw, ch = Inches(6.2), Inches(2.5)
        gx, gy = Inches(0.20), Inches(0.20)
        for i, d in enumerate(cards):
            col = i % 2; row = i // 2
            x = cx0 + (cw + gx) * col; y = cy0 + (ch + gy) * row
            _box(s, x, y, cw, ch, fill=WHITE, line=LINE2)
            _text(s, x + Inches(0.25), y + Inches(0.18), cw - Inches(0.4), Inches(0.4),
                  d["title"], size=15, bold=True, color=INK0)
            _text(s, x + Inches(0.25), y + Inches(0.58), cw - Inches(0.4), Inches(0.35),
                  d["desc"], size=11, color=INK3)
            if d.get("code"):
                _text(s, x + Inches(0.25), y + Inches(0.98), cw - Inches(0.5), Inches(1.5),
                      d["code"], size=11, color=INK2)
            else:
                _bullets(s, x + Inches(0.25), y + Inches(0.98), cw - Inches(0.5), Inches(1.5),
                         d.get("chips", []), size=12)
        f(s)

    # ===== 8. Outputs Matrix =====
    if spec.get("outputs_matrix"):
        s = new_slide()
        _slide_title(s, title="산출물 매트릭스",
                     subtitle="단계별 산출물 · 형식 · 설명",
                     num=f"{4 + n_stages + 1:02d}")
        rows = spec["outputs_matrix"][:9]
        col_widths = [Inches(2.0), Inches(4.5), Inches(2.0), Inches(3.7)]
        headers = ["단계", "산출물", "형식", "설명"]
        hx = Inches(0.55); hy = Inches(1.8)
        xs = [hx]
        for w in col_widths[:-1]:
            xs.append(xs[-1] + w)
        _box(s, hx, hy, sum(col_widths, Inches(0)), Inches(0.5),
             fill=PANEL, line=LINE2)
        for htxt, x, w in zip(headers, xs, col_widths):
            _text(s, x + Inches(0.18), hy + Inches(0.13), w - Inches(0.2), Inches(0.3),
                  htxt, size=12, bold=True, color=INK0)
        ry = hy + Inches(0.5); rh = Inches(0.55)
        for r, row in enumerate(rows):
            yr = ry + rh * r
            fill_color = WHITE if r % 2 == 0 else SOFT
            _box(s, hx, yr, sum(col_widths, Inches(0)), rh,
                 fill=fill_color, line=LINE)
            for i, (cell, x, w) in enumerate(zip(row, xs, col_widths)):
                _text(s, x + Inches(0.18), yr + Inches(0.16), w - Inches(0.2), Inches(0.3),
                      cell, size=11, bold=(i == 0),
                      color=INK1 if i == 0 else INK2)
        f(s)

    # ===== 9. Tech Stack =====
    if spec.get("tech_stack"):
        s = new_slide()
        _slide_title(s, title="기술 스택", subtitle="주요 컴포넌트 · 외부 의존",
                     num=f"{4 + n_stages + 2:02d}")
        items = spec["tech_stack"][:9]
        cols = 3 if len(items) <= 6 else 3
        rows = (len(items) + cols - 1) // cols
        sx0 = Inches(0.55); sy0 = Inches(2.0)
        avail = Inches(12.78); gx = Inches(0.15)
        sw = (avail - gx * (cols - 1)) / cols
        sh_ = Inches(1.5); gy = Inches(0.20)
        for i, t in enumerate(items):
            col = i % cols; row = i // cols
            x = sx0 + (sw + gx) * col
            y = sy0 + (sh_ + gy) * row
            _box(s, x, y, sw, sh_, fill=WHITE, line=LINE2)
            _text(s, x + Inches(0.3), y + Inches(0.25), sw - Inches(0.5), Inches(0.5),
                  t["name"], size=20, bold=True, color=INK0)
            _text(s, x + Inches(0.3), y + Inches(0.85), sw - Inches(0.5), Inches(0.5),
                  t["desc"], size=12, color=INK3)
        f(s)

    # ===== 10. Risks =====
    if spec.get("risks"):
        s = new_slide()
        _slide_title(s, title="리스크 · 다음 단계", subtitle="발표 Q&A 대비",
                     num=f"{4 + n_stages + 3:02d}")
        risks = spec["risks"][:6]
        rx0 = Inches(0.55); ry0 = Inches(1.8)
        rw, rh = Inches(6.2), Inches(1.55)
        gx, gy = Inches(0.20), Inches(0.18)
        for i, r in enumerate(risks):
            col = i % 2; row = i // 2
            x = rx0 + (rw + gx) * col
            y = ry0 + (rh + gy) * row
            _box(s, x, y, rw, rh, fill=WHITE, line=LINE2)
            _text(s, x + Inches(0.25), y + Inches(0.20), rw - Inches(0.4), Inches(0.4),
                  r["title"], size=14, bold=True, color=INK0)
            _text(s, x + Inches(0.25), y + Inches(0.65), rw - Inches(0.4), Inches(1.0),
                  r["body"], size=12, color=INK2)
        f(s)

    # ===== 11. Q&A =====
    s = new_slide()
    _text(s, Inches(0.8), Inches(2.6), Inches(12), Inches(1.5),
          "Q & A", size=80, bold=True, color=INK0)
    div = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(4.1),
                             Inches(1.5), Emu(25400))
    div.line.fill.background(); div.fill.solid(); div.fill.fore_color.rgb = INK1
    div.shadow.inherit = False
    _text(s, Inches(0.8), Inches(4.3), Inches(12), Inches(0.6),
          "질문을 주세요.", size=20, color=INK2)
    _text(s, Inches(0.8), Inches(5.0), Inches(12), Inches(0.5),
          "Thank you.", size=16, color=INK3)
    f(s)

    return prs


def _row_group(slide, x, y, group_w, label, items: list):
    """Web/External 그룹 박스 — 라벨 + 내부 작은 박스들"""
    _box(slide, x, y, group_w, Inches(0.95), fill=PANEL, line=LINE2)
    _text(slide, x + Inches(0.15), y + Inches(0.10), group_w - Inches(0.3), Inches(0.3),
          label, size=11, bold=True, color=INK3)
    if not items:
        return
    inner_w = group_w - Inches(0.2)
    n = len(items)
    gap = Inches(0.10)
    unit_w = (inner_w - gap * (n - 1)) / n
    for i, it in enumerate(items):
        ex = x + Inches(0.10) + (unit_w + gap) * i
        _box(slide, ex, y + Inches(0.45), unit_w, Inches(0.4),
             fill=WHITE, line=LINE, text=it,
             text_size=11, text_color=INK2)


def render_to_bytes(spec: dict) -> bytes:
    prs = _build(spec)
    buf = BytesIO()
    prs.save(buf)
    return buf.getvalue()
