# -*- coding: utf-8 -*-
"""LLM API & 앱 설정"""

LLM_BASE_URL = "http://192.168.0.8:8080/v1"
LLM_API_KEY  = "sk_123!"
LLM_MODEL    = "qwen3.5:9b"

REQUEST_TIMEOUT = 240          # seconds
LLM_TEMPERATURE = 0.2
LLM_MAX_TOKENS  = 8192         # spec JSON 잘림 방지 (충분히 크게)
LLM_MAX_RETRIES = 2

# 반복 루프 억제 — 1.05~1.15 사이가 적당. 너무 크면 한국어 자연스러움 떨어짐
LLM_REPETITION_PENALTY = 1.10
LLM_FREQUENCY_PENALTY  = 0.4   # OpenAI 호환 서버용 대안

# JSON 모드 — 서버가 지원하면 valid JSON 강제
LLM_USE_JSON_MODE = True

# Assistant prefill — 응답을 "{"로 시작하게 강제 (thinking 차단 가장 강력한 방법)
LLM_USE_PREFILL = True

APP_TITLE      = "Architecture Studio"
APP_TAGLINE    = "LLM 기반 시스템 아키텍처 문서 생성기 (HTML + PPT)"
DEFAULT_DOC_ID = "arch_brief"

# ---- Mermaid 자산 (사내 오프라인 운영) ----
# 로컬 mermaid.min.js 경로 — install_assets.py 가 이 위치에 다운로드
MERMAID_LOCAL_PATH = "assets/mermaid.min.js"

# Nexus(또는 사내 raw repo)에서 mermaid.min.js 를 가져올 직접 다운로드 URL.
# 예) "https://nexus.company.local/repository/raw/mermaid/10.9.1/mermaid.min.js"
# 사내 환경에 맞게 수정하세요.
MERMAID_NEXUS_URL = ""

# 외부 CDN 사용 허용 여부 — 사내 정책상 False 권장
ALLOW_CDN_FALLBACK = False
MERMAID_CDN_URL    = "https://cdn.jsdelivr.net/npm/mermaid@10.9.1/dist/mermaid.min.js"
