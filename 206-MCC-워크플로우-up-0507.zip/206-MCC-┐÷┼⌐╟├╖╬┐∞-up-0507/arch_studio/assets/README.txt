이 폴더에는 mermaid.min.js 파일이 있어야 합니다.

설치 방법 (택1)
==================

A) 자동 — config.py 의 MERMAID_NEXUS_URL 설정 후
   python install_assets.py

B) 수동 — 사내 Nexus 의 npm 프록시에서 mermaid 패키지 받기
   1) Nexus npm 저장소에서 mermaid@10.9.1 또는 호환 버전 tarball 다운로드
   2) tarball 압축해제 (npm pack 형식: package/dist/mermaid.min.js)
   3) dist/mermaid.min.js 파일을 이 폴더에 복사
      → arch_studio/assets/mermaid.min.js

C) 동료 PC 등에서 mermaid.min.js 파일만 복사

확인
====
파일 크기는 대략 2~3 MB 입니다.
50 KB 미만이면 install_assets.py 가 거부합니다 (응답 본문이 잘못됐을 가능성).
