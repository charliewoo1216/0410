# -*- coding: utf-8 -*-
"""디버그 로그 — LLM 호출/응답/에러를 debug_logs/ 아래 JSON 으로 저장"""
from __future__ import annotations
import json
import secrets
from datetime import datetime
from pathlib import Path
from typing import Any

LOG_DIR = Path(__file__).parent / "debug_logs"


def _ensure_dir() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return LOG_DIR


def log_llm_call(
    *,
    user_input: str,
    project_hint: str,
    no_think: bool,
    stream: bool,
    temperature: float,
    messages: list[dict],
    raw_response: str | None,
    elapsed_sec: float,
    extracted: Any = None,
    spec: Any = None,
    error: str | None = None,
) -> Path:
    """한 번의 LLM 호출을 단일 JSON 파일로 저장.

    파일명: YYYY-MM-DD_HH-MM-SS_<6자hex>_<status>.json
    status: ok | err | partial
    """
    _ensure_dir()
    now = datetime.now()
    sid = secrets.token_hex(3)
    if error:
        status = "err"
    elif spec is None and extracted is None:
        status = "partial"
    else:
        status = "ok"
    name = f"{now.strftime('%Y-%m-%d_%H-%M-%S')}_{sid}_{status}.json"

    payload = {
        "id": sid,
        "status": status,
        "timestamp": now.isoformat(timespec="seconds"),
        "duration_sec": round(elapsed_sec, 3),
        "input": {
            "user_input": user_input,
            "project_hint": project_hint,
            "no_think": no_think,
            "stream": stream,
            "temperature": temperature,
        },
        "request": {"messages": messages},
        "response": {
            "raw": raw_response,
            "extracted": extracted,
            "spec_summary": _summarize_spec(spec),
            "error": error,
        },
    }
    path = LOG_DIR / name
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 더 큰 spec 본문은 별도 파일로 분리해 보존성 유지
    if spec is not None:
        side = LOG_DIR / f"{path.stem}.spec.json"
        side.write_text(
            json.dumps(spec, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return path


def _summarize_spec(spec: Any) -> Any:
    if not isinstance(spec, dict):
        return None
    return {
        "project_title":      (spec.get("project") or {}).get("title"),
        "stages_count":       len(spec.get("stages") or []),
        "has_full_flow":      bool(spec.get("full_flow_mermaid")),
        "has_component_arch": bool(spec.get("component_arch_mermaid")),
        "tech_stack_count":   len(spec.get("tech_stack") or []),
        "risks_count":        len(spec.get("risks") or []),
    }


def list_logs(limit: int = 30) -> list[Path]:
    if not LOG_DIR.exists():
        return []
    files = sorted(
        (p for p in LOG_DIR.glob("*.json") if not p.name.endswith(".spec.json")),
        reverse=True,
    )
    return files[:limit]


def read_log(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def cleanup_logs(keep: int = 50) -> int:
    if not LOG_DIR.exists():
        return 0
    files = sorted(LOG_DIR.glob("*"), reverse=True)
    removed = 0
    # 최신 keep 개의 main JSON 만 유지하고 나머지 (사이드 spec 포함) 삭제
    main_files = [p for p in files if not p.name.endswith(".spec.json") and p.suffix == ".json"]
    keep_stems = {p.stem for p in main_files[:keep]}
    for p in LOG_DIR.iterdir():
        stem = p.stem.replace(".spec", "")
        if stem in keep_stems:
            continue
        if p.suffix in (".json",):
            try:
                p.unlink(); removed += 1
            except OSError:
                pass
    return removed
