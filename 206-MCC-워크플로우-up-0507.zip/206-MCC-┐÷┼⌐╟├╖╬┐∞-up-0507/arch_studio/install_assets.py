# -*- coding: utf-8 -*-
"""사내 Nexus(또는 raw 저장소)에서 mermaid.min.js 를 받아 assets/ 에 배치.

사용법
------
1) config.py 의 MERMAID_NEXUS_URL 을 사내 직접 다운로드 URL 로 설정
   예)  https://nexus.company.local/repository/raw/mermaid/10.9.1/mermaid.min.js
2) python install_assets.py

수동으로 배치할 수도 있음
- 동료 PC, 또는 npm 프록시 tarball 의 dist/mermaid.min.js 를
- arch_studio/assets/mermaid.min.js 로 직접 복사
"""
from __future__ import annotations
import sys
from pathlib import Path

import requests

import config


def main() -> int:
    if not config.MERMAID_NEXUS_URL:
        print("[ERR] config.MERMAID_NEXUS_URL 가 비어 있습니다.")
        print("      사내 Nexus 의 mermaid.min.js 직접 다운로드 URL 을 넣어주세요.")
        return 2

    target = Path(__file__).parent / config.MERMAID_LOCAL_PATH
    target.parent.mkdir(parents=True, exist_ok=True)

    url = config.MERMAID_NEXUS_URL
    print(f"[INFO] 다운로드: {url}")
    try:
        r = requests.get(url, timeout=120, verify=True)
    except requests.exceptions.SSLError as e:
        print(f"[WARN] SSL 검증 실패 — 사내 인증서일 경우 verify=False 로 재시도합니다: {e}")
        r = requests.get(url, timeout=120, verify=False)
    if r.status_code != 200:
        print(f"[ERR] HTTP {r.status_code} — 응답 일부:\n{r.text[:300]}")
        return 3

    body = r.content
    if len(body) < 50_000:
        print(f"[ERR] 응답이 너무 작습니다 ({len(body)} bytes). URL 확인 필요.")
        print(f"[HINT] 첫 200 chars:\n{body[:200].decode('utf-8', errors='replace')}")
        return 4

    target.write_bytes(body)
    print(f"[OK]  저장: {target}  ({len(body):,} bytes)")
    print("[OK]  이제 Streamlit 앱에서 생성한 HTML 이 오프라인에서도 동작합니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
