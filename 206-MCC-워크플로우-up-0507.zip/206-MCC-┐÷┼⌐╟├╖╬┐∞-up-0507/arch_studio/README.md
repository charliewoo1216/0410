# Architecture Studio

LLM 기반 시스템 아키텍처 문서 생성기. 시스템 설명을 입력하면 v2 스타일의 HTML과 PPT를 한 번에 생성.

## 동작 원리

```
[시스템 설명 텍스트]
        │
        ▼
   LLM (qwen3.5:9b)
   → 구조화 spec(JSON)
        │
   ┌────┴────┐
   ▼         ▼
HTML 렌더링  PPTX 렌더링
(Mermaid)   (도형 합성)
```

LLM은 **spec(JSON)만** 생성하고, HTML/PPT는 파이썬이 결정론적으로 렌더링합니다 → v2 스타일 일관성 보장.

## 실행

```powershell
# (이미 python-pptx, streamlit, requests 설치되어 있다면 생략 가능)
python -m pip install -r requirements.txt

# 앱 실행
streamlit run app.py
```

기본 포트는 8501. 브라우저에서 http://localhost:8501 으로 접속.

## LLM 설정

`config.py`에서 변경:
```python
LLM_BASE_URL = "http://192.168.0.8:8080/v1"
LLM_API_KEY  = "sk_123!"
LLM_MODEL    = "qwen3.5:9b"
```

## 산출물

| 탭 | 설명 |
| --- | --- |
| HTML 미리보기 | 인-앱 미리보기 + .html 다운로드 |
| PPT 다운로드 | 16:9, 한글 맑은 고딕, v2 스타일 |
| Spec (JSON) | 렌더링에 사용된 구조화 데이터 |
| LLM 원문 | 디버깅용 raw 응답 |

## Mermaid (오프라인 / 사내 운영)

생성된 HTML 의 다이어그램은 **Mermaid.js** 가 브라우저에서 렌더링합니다.
사내 환경(인터넷 차단)에서는 외부 CDN 사용 불가이므로, 한 번만 사내 Nexus 에서
`mermaid.min.js` 를 받아 `assets/` 에 두면 이후 생성되는 HTML 이 JS 를 inline 으로
포함 → **인터넷 없이도 열림**.

**상태 확인**: 앱 사이드바의 "Mermaid 자산"
- 🟢 **로컬 inline** — 정상, 오프라인 OK
- 🟡 CDN 폴백 — `ALLOW_CDN_FALLBACK=True` 일 때만, 인터넷 필요
- 🔴 누락 — 다이어그램 미렌더링 (HTML 안에서 경고 표시)

**설치 (택1)**

```powershell
# A) 자동 — config.py 의 MERMAID_NEXUS_URL 설정 후
python install_assets.py

# B) 수동 — Nexus npm 프록시에서 mermaid 패키지 다운로드 후
#          tarball 의 dist/mermaid.min.js 를 arch_studio/assets/ 로 복사

# C) 동료 PC 에서 mermaid.min.js 만 복사 → arch_studio/assets/mermaid.min.js
```

**기존 HTML 패치** (CDN 의존하던 v1/v2 단독 HTML 도 inline 으로 교체)

```powershell
python patch_html_offline.py ..\MCC_Workflow_Diagram_v2.html
python patch_html_offline.py ..\MCC_Workflow_Diagram.html
# *.html 일괄 처리도 가능
```

원본은 `.bak` 백업이 함께 생성됩니다.

## 디버그 로그

매 LLM 호출(성공/실패 모두)을 `debug_logs/` 아래 JSON 으로 자동 저장합니다.

- 파일명: `YYYY-MM-DD_HH-MM-SS_<6자hex>_<status>.json`
- status: `ok` / `err` / `partial`
- 동봉 정보: 입력 텍스트 · 프롬프트 메시지 · LLM 원문 응답 · 추출된 JSON · 정규화 spec 요약 · 에러
- 큰 spec 본문은 `<같은이름>.spec.json` 사이드카로 분리 저장

사이드바의 **🪵 디버그 로그** 패널에서:
- 최근 10개 표시 + 상태 아이콘 (✅ / ⚠️ / ❌)
- 각 로그 펼쳐서 요약 확인 + JSON 다운로드
- "오래된 로그 정리" 버튼으로 최신 50개만 유지

## 파일 구조

```
arch_studio/
├── app.py                  Streamlit UI
├── config.py               LLM 및 Mermaid 자산 설정
├── llm_client.py           OpenAI-compatible 챗 클라이언트 (JSON+SSE, /no_think 대응)
├── prompts.py              시스템 프롬프트 + 스키마 가이드
├── spec_normalize.py       LLM 응답 정규화 (방어적)
├── render_html.py          v2 스타일 HTML 렌더러 (Mermaid inline)
├── render_pptx.py          v2 스타일 PPTX 렌더러 (도형 합성)
├── install_assets.py       Nexus 에서 mermaid.min.js 다운로드
├── patch_html_offline.py   기존 HTML 의 CDN script 를 inline 으로 교체
├── debug_log.py            LLM 호출/응답/에러 자동 저장
├── assets/
│   ├── README.txt
│   └── mermaid.min.js      ← 사내 Nexus 에서 받아 배치
├── debug_logs/             LLM 호출 로그 자동 저장 (.json)
└── requirements.txt
```
