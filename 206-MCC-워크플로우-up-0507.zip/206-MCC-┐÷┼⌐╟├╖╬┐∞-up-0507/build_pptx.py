# -*- coding: utf-8 -*-
"""
MCC 워크플로우 발표자료 생성기
output: MCC_Workflow_Presentation.pptx
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from lxml import etree

# ---------- palette ----------
BG_DARK     = RGBColor(0x07, 0x0B, 0x1A)
BG_PANEL    = RGBColor(0x0F, 0x17, 0x2A)
INK         = RGBColor(0xE2, 0xE8, 0xF0)
INK_SOFT    = RGBColor(0x94, 0xA3, 0xB8)
LINE        = RGBColor(0x33, 0x3F, 0x55)
CYAN        = RGBColor(0x22, 0xD3, 0xEE)
VIOLET      = RGBColor(0xA7, 0x8B, 0xFA)
PINK        = RGBColor(0xF4, 0x72, 0xB6)
LIME        = RGBColor(0xA3, 0xE6, 0x35)
AMBER       = RGBColor(0xFB, 0xBF, 0x24)
WHITE       = RGBColor(0xFF, 0xFF, 0xFF)

STAGE_COLORS = [CYAN, VIOLET, PINK, LIME, AMBER]

FONT = '맑은 고딕'

# ---------- helpers ----------
def set_slide_bg(slide, color=BG_DARK):
    # solid background fill
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_gradient_band(slide, prs):
    # subtle top gradient band
    band = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, Inches(0.18)
    )
    band.line.fill.background()
    f = band.fill
    f.solid()
    f.fore_color.rgb = CYAN
    band.shadow.inherit = False


def add_text(slide, x, y, w, h, text, *, size=18, bold=False,
             color=INK, align=PP_ALIGN.LEFT, font=FONT, anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return tb


def add_box(slide, x, y, w, h, *, fill=BG_PANEL, line=LINE,
            text=None, text_color=INK, text_size=14, text_bold=False,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER):
    sh = slide.shapes.add_shape(shape, x, y, w, h)
    sh.fill.solid()
    sh.fill.fore_color.rgb = fill
    sh.line.color.rgb = line
    sh.line.width = Pt(0.75)
    sh.shadow.inherit = False
    if text is not None:
        tf = sh.text_frame
        tf.word_wrap = True
        tf.margin_left = Emu(60000)
        tf.margin_right = Emu(60000)
        tf.margin_top = Emu(40000)
        tf.margin_bottom = Emu(40000)
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = align
        r = p.add_run()
        r.text = text
        r.font.name = FONT
        r.font.size = Pt(text_size)
        r.font.bold = text_bold
        r.font.color.rgb = text_color
    return sh


def add_arrow(slide, x1, y1, x2, y2, color=INK_SOFT, weight=1.25):
    line = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, x1, y1, x2, y2)
    line.line.color.rgb = color
    line.line.width = Pt(weight)
    # add arrow head
    ln = line.line._get_or_add_ln()
    tail = etree.SubElement(ln, qn('a:tailEnd'))
    tail.set('type', 'triangle')
    tail.set('w', 'med')
    tail.set('h', 'med')
    return line


def set_slide_title(slide, prs, title, subtitle=None):
    add_text(slide, Inches(0.55), Inches(0.32), Inches(12.2), Inches(0.55),
             title, size=26, bold=True, color=WHITE)
    if subtitle:
        add_text(slide, Inches(0.55), Inches(0.85), Inches(12.2), Inches(0.4),
                 subtitle, size=13, color=INK_SOFT)
    # accent underline
    ul = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0.55), Inches(1.28), Inches(1.0), Emu(38000)
    )
    ul.line.fill.background()
    ul.fill.solid(); ul.fill.fore_color.rgb = CYAN
    ul.shadow.inherit = False
    # page chip (top right)
    return


def add_pill(slide, x, y, text, color=CYAN):
    w, h = Inches(1.4), Inches(0.32)
    box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    box.fill.solid(); box.fill.fore_color.rgb = BG_PANEL
    box.line.color.rgb = color
    box.line.width = Pt(0.75)
    box.shadow.inherit = False
    tf = box.text_frame
    tf.margin_left = Emu(0); tf.margin_right = Emu(0)
    tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = text
    r.font.name = FONT; r.font.size = Pt(10); r.font.bold = True
    r.font.color.rgb = color


def add_bullets(slide, x, y, w, h, items, *, size=13, color=INK,
                soft=INK_SOFT, gap_pt=4):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Emu(0); tf.margin_right = Emu(0)
    tf.margin_top = Emu(0); tf.margin_bottom = Emu(0)
    for i, it in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.space_after = Pt(gap_pt)
        r = p.add_run()
        r.text = "•  " + it
        r.font.name = FONT
        r.font.size = Pt(size)
        r.font.color.rgb = color
    return tb


# ---------- build ----------
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank = prs.slide_layouts[6]

SW = prs.slide_width
SH = prs.slide_height


def new_slide():
    s = prs.slides.add_slide(blank)
    set_slide_bg(s)
    add_gradient_band(s, prs)
    return s


# ---- footer helper ----
def add_footer(slide, idx, total):
    add_text(slide, Inches(0.55), Inches(7.05), Inches(8), Inches(0.3),
             "205 · MCC Workflow · Architecture Brief",
             size=10, color=INK_SOFT)
    add_text(slide, Inches(11.5), Inches(7.05), Inches(1.5), Inches(0.3),
             f"{idx} / {total}", size=10, color=INK_SOFT, align=PP_ALIGN.RIGHT)


# =========================================================
# SLIDE 1 — Cover
# =========================================================
TOTAL = 14
s = new_slide()
# big title block
add_text(s, Inches(0.8), Inches(2.2), Inches(11), Inches(0.6),
         "205 · MCC WORKFLOW", size=14, bold=True, color=CYAN)
add_text(s, Inches(0.8), Inches(2.6), Inches(11.5), Inches(1.4),
         "로그 → AI 분석 → 자동 파서", size=46, bold=True, color=WHITE)
add_text(s, Inches(0.8), Inches(3.7), Inches(11.5), Inches(0.7),
         "MCC 워크플로우 시스템 아키텍처", size=24, color=VIOLET)
add_text(s, Inches(0.8), Inches(4.5), Inches(11.5), Inches(1.0),
         "장비 로그 → LLM 이벤트 분석 → 모션 페어링 → ReAct 자동 파서 → 전체 볼륨 검증",
         size=14, color=INK_SOFT)
# meta row
add_text(s, Inches(0.8), Inches(6.4), Inches(6), Inches(0.4),
         "발표일 · 2026-05-08", size=12, color=INK_SOFT)
add_text(s, Inches(7.5), Inches(6.4), Inches(5.3), Inches(0.4),
         "발표자 ·                     ", size=12, color=INK_SOFT, align=PP_ALIGN.RIGHT)
# subtle right accent
acc = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(10.5), Inches(0.6),
                         Inches(2.2), Inches(2.2))
acc.fill.solid(); acc.fill.fore_color.rgb = VIOLET
acc.line.fill.background(); acc.shadow.inherit = False
acc2 = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(11.5), Inches(1.1),
                          Inches(1.3), Inches(1.3))
acc2.fill.solid(); acc2.fill.fore_color.rgb = CYAN
acc2.line.fill.background(); acc2.shadow.inherit = False
add_footer(s, 1, TOTAL)

# =========================================================
# SLIDE 2 — Agenda
# =========================================================
s = new_slide()
set_slide_title(s, prs, "발표 순서", "Agenda")
items = [
    ("01", "전체 개요 & 핵심 수치", CYAN),
    ("02", "시스템 아키텍처 (데이터 플로우)", VIOLET),
    ("03", "Stage 1 — Log Selection", CYAN),
    ("04", "Stage 2 — AI Analysis (LLM 대화)", VIOLET),
    ("05", "Stage 3 — Verification (모션 페어링)", PINK),
    ("06", "Stage 4 — Code Generation (ReAct)", LIME),
    ("07", "Stage 4 — parser_v1.py 산출", LIME),
    ("08", "Stage 5 — Volume Test", AMBER),
    ("09", "데이터 표준 · 저장소 · DB", CYAN),
    ("10", "리스크 & 다음 단계 / Q&A", AMBER),
]
left_x = Inches(0.7)
top_y  = Inches(1.7)
col_w  = Inches(6.0)
row_h  = Inches(0.50)
for i, (n, t, c) in enumerate(items):
    col = i // 5
    row = i % 5
    x = left_x + Inches(6.2) * col
    y = top_y + row_h * row + Inches(0.05) * row
    box = add_box(s, x, y, col_w, row_h, fill=BG_PANEL, line=c, text=None)
    add_text(s, x + Inches(0.18), y + Inches(0.1), Inches(0.6), Inches(0.3),
             n, size=13, bold=True, color=c)
    add_text(s, x + Inches(0.85), y + Inches(0.1), Inches(5.0), Inches(0.3),
             t, size=14, color=INK)
add_footer(s, 2, TOTAL)

# =========================================================
# SLIDE 3 — System at a glance (5-stage pipeline)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "시스템 한눈에 보기", "5단계 End-to-End 파이프라인")

stages = [
    ("STAGE 01", "Log Selection", "EDS API · 검색·다운로드·전처리·저장"),
    ("STAGE 02", "AI Analysis", "LLM 대화 · 이벤트 v1→v2"),
    ("STAGE 03", "Verification", "모션 페어링·시퀀스 v1→v2"),
    ("STAGE 04", "Code Generation", "ReAct 루프 · parser_v1.py"),
    ("STAGE 05", "Volume Test", "전체 로그 · 진행 시각화"),
]
x0 = Inches(0.55); y0 = Inches(2.0)
bw, bh = Inches(2.35), Inches(2.6)
gap = Inches(0.10)
arrow_y = y0 + bh / 2

for i, (n, t, d) in enumerate(stages):
    x = x0 + (bw + gap) * i
    color = STAGE_COLORS[i]
    # Card
    box = add_box(s, x, y0, bw, bh, fill=BG_PANEL, line=color, text=None)
    add_text(s, x + Inches(0.2), y0 + Inches(0.18), bw - Inches(0.4), Inches(0.3),
             n, size=10, bold=True, color=color)
    add_text(s, x + Inches(0.2), y0 + Inches(0.55), bw - Inches(0.4), Inches(0.6),
             t, size=18, bold=True, color=WHITE)
    add_text(s, x + Inches(0.2), y0 + Inches(1.2), bw - Inches(0.4), Inches(1.3),
             d, size=12, color=INK_SOFT)
    # connecting arrow
    if i < len(stages) - 1:
        ax1 = x + bw
        ax2 = x + bw + gap
        add_arrow(s, ax1, arrow_y, ax2, arrow_y, color=color, weight=2.0)

# bottom note
note = "User → 로그 수집 → LLM 분석 → 사용자 검증 → 자동 코드생성 → 전체 검증 → SQLite"
add_text(s, Inches(0.55), Inches(5.0), Inches(12.2), Inches(0.4),
         note, size=14, color=INK)

# key metrics row
metrics = [("5단계", "E2E"), ("~30 MB", "1차 로그"),
           ("1 ~ 5 GB", "Volume Test"), ("최대 10회", "ReAct 루프")]
mx = Inches(0.55); my = Inches(5.6); mw = Inches(3.05); mh = Inches(1.1)
for i, (n, l) in enumerate(metrics):
    x = mx + (mw + Inches(0.10)) * i
    add_box(s, x, my, mw, mh, fill=BG_PANEL, line=STAGE_COLORS[i % 5])
    add_text(s, x + Inches(0.2), my + Inches(0.12), mw, Inches(0.55),
             n, size=20, bold=True, color=STAGE_COLORS[i % 5])
    add_text(s, x + Inches(0.2), my + Inches(0.65), mw, Inches(0.4),
             l, size=11, color=INK_SOFT)
add_footer(s, 3, TOTAL)

# =========================================================
# SLIDE 4 — System Architecture (block diagram)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "시스템 아키텍처", "사용자 · Web · External · Storage · Engine")

# layout
# Row 1: User
add_box(s, Inches(0.6), Inches(1.7), Inches(2.2), Inches(0.7),
        fill=BG_PANEL, line=CYAN, text="User", text_size=14, text_bold=True, text_color=CYAN)

# Row 2: Web Server (3 sub-blocks)
add_box(s, Inches(3.4), Inches(1.6), Inches(6.0), Inches(0.9),
        fill=BG_PANEL, line=VIOLET)
add_text(s, Inches(3.55), Inches(1.7), Inches(2.0), Inches(0.3),
         "Web Server (Python)", size=11, bold=True, color=VIOLET)
add_box(s, Inches(3.55), Inches(2.05), Inches(1.7), Inches(0.4),
        fill=BG_DARK, line=LINE, text="대화 / 진행 UI", text_size=11, text_color=INK)
add_box(s, Inches(5.35), Inches(2.05), Inches(1.7), Inches(0.4),
        fill=BG_DARK, line=LINE, text="전처리 (KST)", text_size=11, text_color=INK)
add_box(s, Inches(7.15), Inches(2.05), Inches(2.05), Inches(0.4),
        fill=BG_DARK, line=LINE, text="오케스트레이션", text_size=11, text_color=INK)

# Row 2 right: External
add_box(s, Inches(9.95), Inches(1.6), Inches(2.85), Inches(0.9),
        fill=BG_PANEL, line=CYAN)
add_text(s, Inches(10.1), Inches(1.7), Inches(2.5), Inches(0.3),
         "External", size=11, bold=True, color=CYAN)
add_box(s, Inches(10.05), Inches(2.05), Inches(1.3), Inches(0.4),
        fill=BG_DARK, line=LINE, text="EDS API", text_size=11, text_color=INK)
add_box(s, Inches(11.4), Inches(2.05), Inches(1.35), Inches(0.4),
        fill=BG_DARK, line=LINE, text="LLM API", text_size=11, text_color=INK)

# Row 3: Engine
add_box(s, Inches(3.4), Inches(3.4), Inches(6.0), Inches(1.0),
        fill=BG_PANEL, line=LIME)
add_text(s, Inches(3.55), Inches(3.5), Inches(2.5), Inches(0.3),
         "Code Gen Engine", size=11, bold=True, color=LIME)
add_box(s, Inches(3.55), Inches(3.85), Inches(2.5), Inches(0.45),
        fill=BG_DARK, line=LINE, text="ReAct Loop  · max 10", text_size=11, text_color=INK)
add_box(s, Inches(6.2), Inches(3.85), Inches(3.05), Inches(0.45),
        fill=BG_DARK, line=LINE, text="parser_v1.py", text_size=11, text_color=INK)

# Row 4: Storage
add_box(s, Inches(0.6), Inches(5.0), Inches(12.2), Inches(1.7),
        fill=BG_PANEL, line=PINK)
add_text(s, Inches(0.8), Inches(5.1), Inches(4), Inches(0.3),
         "Storage / DB", size=11, bold=True, color=PINK)
add_box(s, Inches(0.8), Inches(5.55), Inches(3.7), Inches(1.05),
        fill=BG_DARK, line=LINE, text="MinIO / S3\n원시 로그 (1G ~ 5G)",
        text_size=12, text_color=INK)
add_box(s, Inches(4.7), Inches(5.55), Inches(4.0), Inches(1.05),
        fill=BG_DARK, line=LINE,
        text="Markdown 산출물\n로그구조템플릿 / 이벤트 v1·v2 / 모션페어링 v1·v2",
        text_size=11, text_color=INK)
add_box(s, Inches(8.9), Inches(5.55), Inches(3.9), Inches(1.05),
        fill=BG_DARK, line=LINE,
        text="SQLite\nstart / end / motion / desc",
        text_size=12, text_color=INK)

# arrows
add_arrow(s, Inches(2.8), Inches(2.05), Inches(3.4), Inches(2.05), color=CYAN, weight=2)
add_arrow(s, Inches(9.4), Inches(2.05), Inches(9.95), Inches(2.05), color=VIOLET, weight=2)
# Web -> Engine
add_arrow(s, Inches(6.4), Inches(2.5), Inches(6.4), Inches(3.4), color=LIME, weight=2)
# Engine -> Storage
add_arrow(s, Inches(6.4), Inches(4.4), Inches(6.4), Inches(5.0), color=PINK, weight=2)
# External -> Storage (LLM->MD, EDS->S3)
add_arrow(s, Inches(11.0), Inches(2.45), Inches(10.85), Inches(5.55), color=INK_SOFT, weight=1)
add_arrow(s, Inches(10.7), Inches(2.45), Inches(2.7), Inches(5.55), color=INK_SOFT, weight=1)

add_footer(s, 4, TOTAL)

# =========================================================
# SLIDE 5 — Stage 1: Log Selection
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 1 · Log Selection", "장비 로그 검색 · 다운로드 · 전처리 · 저장")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 01", CYAN)

# Flow: 사용자 시작 -> 검색 -> 메타 -> 목록 -> 선택 -> 다운로드 -> 전처리 -> 저장
flow = [
    ("사용자 시작", CYAN),
    ("검색 조건\neqp · 기간", CYAN),
    ("EDS\nfile meta search", VIOLET),
    ("웹 UI 목록", CYAN),
    ("사용자 선택", PINK),
    ("EDS\nfile download", VIOLET),
    ("전처리\nKST · 행처리", LIME),
    ("저장\nWeb / MinIO·S3", AMBER),
]
fx = Inches(0.55); fy = Inches(2.0)
fw, fh = Inches(1.45), Inches(1.1)
fgap = Inches(0.12)
for i, (t, c) in enumerate(flow):
    x = fx + (fw + fgap) * i
    add_box(s, x, fy, fw, fh, fill=BG_PANEL, line=c, text=t,
            text_size=11, text_color=INK)
    if i < len(flow) - 1:
        add_arrow(s, x + fw, fy + fh / 2, x + fw + fgap, fy + fh / 2,
                  color=c, weight=1.6)

# Notes
add_text(s, Inches(0.55), Inches(3.5), Inches(12), Inches(0.4),
         "핵심 포인트", size=14, bold=True, color=CYAN)
add_bullets(s, Inches(0.65), Inches(3.85), Inches(12), Inches(2.8), [
    "EDS API · Datalake 2.0 메타 검색 — eqp id · 날짜시간 기간 기반",
    "웹 UI에서 사용자가 다중 선택 가능 → 선택분만 다운로드",
    "전처리: 타임스탬프 KST 통일, 행 단위 정규화",
    "저장 위치: 1차 ~ 30 MB는 Web 서버 로컬, 향후 MinIO/S3 전환 검토",
    "본 단계의 산출물이 모든 후속 단계의 입력 — 일관성·재현성 핵심",
], size=14)

add_footer(s, 5, TOTAL)

# =========================================================
# SLIDE 6 — Stage 2: AI Analysis (LLM 대화)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 2 · AI Analysis", "LLM 대화로 이벤트 정의 (v1 → v2)")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 02", VIOLET)

# Two-column: left flow, right outputs
# Left: sequence-style boxes
sx = Inches(0.55); sy = Inches(2.0)
add_box(s, sx, sy, Inches(7.0), Inches(4.5), fill=BG_PANEL, line=VIOLET)
add_text(s, sx + Inches(0.3), sy + Inches(0.15), Inches(6.5), Inches(0.4),
         "대화 시퀀스", size=14, bold=True, color=VIOLET)

steps = [
    ("①  Web → LLM", "원시 로그 + 템플릿 요청"),
    ("②  LLM → 산출물", "로그구조템플릿.md"),
    ("③  Web → LLM", "모션 이벤트 추출 요청"),
    ("④  LLM → 산출물", "이벤트분석_v1.md"),
    ("⑤  User ↔ Web ↔ LLM", "도메인 지식 반영 (반복)"),
    ("⑥  User → Web", "최종 확정"),
    ("⑦  Web → 산출물", "이벤트분석_v2.md"),
]
ssx = sx + Inches(0.3); ssy = sy + Inches(0.6)
for i, (t, d) in enumerate(steps):
    y = ssy + Inches(0.50) * i
    add_text(s, ssx, y, Inches(2.6), Inches(0.45),
             t, size=12, bold=True, color=INK)
    add_text(s, ssx + Inches(2.7), y, Inches(4.0), Inches(0.45),
             d, size=12, color=INK_SOFT)

# Right: outputs table
ox = Inches(7.85); oy = Inches(2.0)
add_box(s, ox, oy, Inches(5.0), Inches(4.5), fill=BG_PANEL, line=PINK)
add_text(s, ox + Inches(0.3), oy + Inches(0.15), Inches(4.5), Inches(0.4),
         "산출물 (Markdown)", size=14, bold=True, color=PINK)
outs = [
    ("로그구조템플릿.md", "원시 로그 구조 1차 자동 추론"),
    ("이벤트분석_v1.md", "모션·동작 중심 1차 후보"),
    ("이벤트분석_v2.md", "사용자 확정 최종 정의"),
]
for i, (name, desc) in enumerate(outs):
    y = oy + Inches(0.7) + Inches(1.15) * i
    add_box(s, ox + Inches(0.3), y, Inches(4.4), Inches(0.95),
            fill=BG_DARK, line=LINE)
    add_text(s, ox + Inches(0.45), y + Inches(0.1), Inches(4.0), Inches(0.4),
             name, size=13, bold=True, color=PINK)
    add_text(s, ox + Inches(0.45), y + Inches(0.5), Inches(4.0), Inches(0.4),
             desc, size=11, color=INK_SOFT)

add_text(s, Inches(0.55), Inches(6.65), Inches(12), Inches(0.4),
         "사용자 대화로 도메인 지식이 반영되어야 v2가 신뢰 가능한 정의가 됨",
         size=12, color=INK_SOFT)
add_footer(s, 6, TOTAL)

# =========================================================
# SLIDE 7 — Stage 3: Verification
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 3 · Verification", "모션 페어링 · 시퀀스 (v1 → v2)")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 03", PINK)

# flow with feedback loop
flow_y = Inches(2.2)
fb_h = Inches(1.2)
specs = [
    ("이벤트분석 v2", CYAN, Inches(0.7),  Inches(2.2)),
    ("LLM\n페어링·시퀀스 추출", VIOLET, Inches(3.4),  Inches(2.2)),
    ("모션_페어링_분석 v1.md", PINK, Inches(6.5),  Inches(2.2)),
    ("사용자 검토", AMBER, Inches(9.5),  Inches(2.2)),
    ("모션_페어링_분석 v2.md", LIME, Inches(9.5),  Inches(4.5)),
]
for t, c, x, y in specs:
    add_box(s, x, y, Inches(2.6), fb_h, fill=BG_PANEL, line=c,
            text=t, text_size=12, text_bold=True, text_color=INK)

# arrows
add_arrow(s, Inches(3.3),  Inches(2.8), Inches(3.4),  Inches(2.8), color=CYAN, weight=2)
add_arrow(s, Inches(6.0),  Inches(2.8), Inches(6.5),  Inches(2.8), color=VIOLET, weight=2)
add_arrow(s, Inches(9.1),  Inches(2.8), Inches(9.5),  Inches(2.8), color=PINK, weight=2)
# feedback loop (검토 -> LLM)
add_arrow(s, Inches(9.5),  Inches(2.4), Inches(4.7),  Inches(2.0), color=AMBER, weight=1.5)
add_text(s, Inches(5.0), Inches(1.7), Inches(4), Inches(0.3),
         "수정 / 보정 (반복)", size=11, color=AMBER)
# 확정 -> v2
add_arrow(s, Inches(10.8), Inches(3.4), Inches(10.8), Inches(4.5), color=LIME, weight=2)
add_text(s, Inches(11.3), Inches(3.7), Inches(2), Inches(0.4),
         "확정", size=12, color=LIME, bold=True)

add_text(s, Inches(0.55), Inches(6.0), Inches(12), Inches(0.4),
         "이 단계에서 동작(모션) 중심의 페어링·시퀀스 데이터가 명시적으로 정의됨",
         size=14, color=INK)
add_text(s, Inches(0.55), Inches(6.4), Inches(12), Inches(0.4),
         "→ Stage 4의 ReAct 루프가 참고할 가장 중요한 도메인 명세 (정확도가 코드 품질을 결정)",
         size=12, color=INK_SOFT)
add_footer(s, 7, TOTAL)

# =========================================================
# SLIDE 8 — Stage 4: Code Generation (ReAct)
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 4 · Code Generation", "ReAct 자가수정 루프 — 최대 10회")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 04", LIME)

# Loop diagram
cx = Inches(4.5); cy = Inches(2.1)
nodes = [
    ("Thought\n코드 설계",  Inches(4.5),  Inches(2.0), VIOLET),
    ("Action\n코드 작성/수정", Inches(7.5),  Inches(2.0), CYAN),
    ("Observation\n샘플 로그 실행", Inches(7.5),  Inches(4.0), AMBER),
    ("Pass / Fail\n판정",     Inches(4.5),  Inches(4.0), PINK),
]
for t, x, y, c in nodes:
    add_box(s, x, y, Inches(2.6), Inches(1.4), fill=BG_PANEL, line=c,
            text=t, text_size=13, text_bold=True, text_color=INK)

# loop arrows
add_arrow(s, Inches(7.1),  Inches(2.7), Inches(7.5),  Inches(2.7), color=CYAN, weight=2)
add_arrow(s, Inches(8.8),  Inches(3.4), Inches(8.8),  Inches(4.0), color=AMBER, weight=2)
add_arrow(s, Inches(7.5),  Inches(4.7), Inches(7.1),  Inches(4.7), color=PINK, weight=2)
# Fail -> Thought (back-loop)
add_arrow(s, Inches(5.0),  Inches(4.0), Inches(5.0),  Inches(3.4), color=PINK, weight=2)

# Pass exit
add_box(s, Inches(0.7), Inches(4.3), Inches(2.6), Inches(0.9), fill=BG_PANEL, line=LIME,
        text="✓ Pass\nparser_v1.py 확정", text_size=12, text_bold=True, text_color=LIME)
add_arrow(s, Inches(4.5),  Inches(4.7), Inches(3.3),  Inches(4.7), color=LIME, weight=2)
add_text(s, Inches(3.4), Inches(4.4), Inches(1.0), Inches(0.3),
         "성공", size=10, color=LIME, bold=True)

# Give up
add_box(s, Inches(10.5), Inches(2.0), Inches(2.4), Inches(0.9), fill=BG_PANEL, line=AMBER,
        text="✗ Give up\n10회 초과 → 점검", text_size=11, text_bold=True, text_color=AMBER)
add_arrow(s, Inches(10.1), Inches(2.5), Inches(10.5), Inches(2.5), color=AMBER, weight=1.5)

# bullets at bottom
add_text(s, Inches(0.55), Inches(5.6), Inches(12), Inches(0.4),
         "참고 입력 / 탈출 조건", size=14, bold=True, color=LIME)
add_bullets(s, Inches(0.65), Inches(5.95), Inches(12.5), Inches(1.2), [
    "참고: 원시로그템플릿.md · 이벤트분석_v2.md · 모션_페어링_분석_v2.md",
    "탈출 조건: 1번의 로그를 무오류로 통과 (가능하면 10회 이내 빠르게 수렴)",
    "최신 하네스 기법 적용 — 실패 로그를 다음 Thought 컨텍스트에 슬라이싱하여 주입",
], size=12)
add_footer(s, 8, TOTAL)

# =========================================================
# SLIDE 9 — Stage 4: parser_v1.py 산출 명세
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 4 · parser_v1.py 산출", "원시로그 → 이벤트 레코드 → SQLite")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 04", LIME)

# Left: input/output flow
add_box(s, Inches(0.55), Inches(2.0), Inches(2.8), Inches(1.0),
        fill=BG_PANEL, line=AMBER, text="원시 로그\n(타임스탬프 정렬)",
        text_size=13, text_bold=True, text_color=INK)
add_box(s, Inches(4.0), Inches(2.0), Inches(2.8), Inches(1.0),
        fill=BG_PANEL, line=LIME, text="parser_v1.py\n(자동 생성)",
        text_size=13, text_bold=True, text_color=INK)
add_box(s, Inches(7.45), Inches(2.0), Inches(5.4), Inches(1.0),
        fill=BG_PANEL, line=CYAN,
        text="이벤트 레코드\nstart / end / motion event / desc",
        text_size=13, text_bold=True, text_color=INK)
add_arrow(s, Inches(3.35), Inches(2.5), Inches(4.0), Inches(2.5), color=LIME, weight=2)
add_arrow(s, Inches(6.8),  Inches(2.5), Inches(7.45),Inches(2.5), color=CYAN, weight=2)

# DB box
add_box(s, Inches(7.45), Inches(3.4), Inches(5.4), Inches(1.6),
        fill=BG_PANEL, line=PINK)
add_text(s, Inches(7.65), Inches(3.55), Inches(5), Inches(0.4),
         "SQLite — events 테이블 (예시)", size=13, bold=True, color=PINK)
schema = "id INTEGER PK\nts_start TEXT\nts_end   TEXT\nmotion   TEXT\ndesc     TEXT"
tbox = add_text(s, Inches(7.65), Inches(3.95), Inches(5), Inches(1.2),
                schema, size=11, color=INK)

# Left bullets
add_text(s, Inches(0.55), Inches(3.4), Inches(6.5), Inches(0.4),
         "처리 방식", size=14, bold=True, color=LIME)
add_bullets(s, Inches(0.65), Inches(3.8), Inches(6.5), Inches(2.5), [
    "타임스탬프 기준으로 정렬 후 순차 읽기",
    "시작 / 종료 / 모션 이벤트 / 설명을 한 레코드로 묶음",
    "이벤트 단위로 SQLite에 적재",
    "실패 시 실패 위치·로그 라인을 다음 ReAct 루프에 전달",
    "전 과정·전 진행 로그를 시각적으로 노출",
], size=12)
add_footer(s, 9, TOTAL)

# =========================================================
# SLIDE 10 — Stage 5: Volume Test
# =========================================================
s = new_slide()
set_slide_title(s, prs, "Stage 5 · Volume Test", "전체 원시 로그 검증 · 진행 시각화")
add_pill(s, Inches(11.4), Inches(0.4), "STAGE 05", AMBER)

# Pipeline: parser -> 전체로그 -> 순차실행 -> SQLite + UI
add_box(s, Inches(0.55), Inches(2.2), Inches(2.6), Inches(1.0),
        fill=BG_PANEL, line=LIME, text="parser_v1.py\n(Stage 4 산출)",
        text_size=12, text_bold=True, text_color=INK)
add_box(s, Inches(3.4), Inches(2.2), Inches(2.6), Inches(1.0),
        fill=BG_PANEL, line=AMBER, text="전체 원시 로그\n1G ~ 5G",
        text_size=12, text_bold=True, text_color=INK)
add_box(s, Inches(6.25), Inches(2.2), Inches(2.6), Inches(1.0),
        fill=BG_PANEL, line=VIOLET, text="순차 실행\nTS 정렬",
        text_size=12, text_bold=True, text_color=INK)
add_box(s, Inches(9.1), Inches(1.6), Inches(3.7), Inches(1.0),
        fill=BG_PANEL, line=CYAN, text="SQLite\nevents 적재",
        text_size=12, text_bold=True, text_color=INK)
add_box(s, Inches(9.1), Inches(2.8), Inches(3.7), Inches(1.0),
        fill=BG_PANEL, line=PINK, text="진행 시각화 UI\n실패율·처리율",
        text_size=12, text_bold=True, text_color=INK)

add_arrow(s, Inches(3.15), Inches(2.7), Inches(3.4), Inches(2.7), color=AMBER, weight=2)
add_arrow(s, Inches(6.0),  Inches(2.7), Inches(6.25),Inches(2.7), color=VIOLET, weight=2)
add_arrow(s, Inches(8.85), Inches(2.5), Inches(9.1), Inches(2.1), color=CYAN, weight=2)
add_arrow(s, Inches(8.85), Inches(2.9), Inches(9.1), Inches(3.3), color=PINK, weight=2)

# Operator triage
add_box(s, Inches(9.1), Inches(4.0), Inches(3.7), Inches(0.9),
        fill=BG_PANEL, line=AMBER, text="오퍼레이터 트리아지\n실패 케이스 보강",
        text_size=12, text_bold=True, text_color=INK)
add_arrow(s, Inches(10.95), Inches(3.8), Inches(10.95), Inches(4.0), color=AMBER, weight=1.5)

# Notes
add_text(s, Inches(0.55), Inches(5.0), Inches(12), Inches(0.4),
         "포인트", size=14, bold=True, color=AMBER)
add_bullets(s, Inches(0.65), Inches(5.4), Inches(12.5), Inches(1.6), [
    "Stage 4가 일부 로그(샘플)에 대한 무오류 통과만 검증한 반면, Stage 5는 전체 운영 규모를 검증",
    "메모리·I/O 부담 — 청크 단위 스트리밍 + 진행 상태 영속화 권장",
    "실패 케이스는 다시 Stage 2/3의 v2 산출물 보강 인풋으로 환류",
], size=12)
add_footer(s, 10, TOTAL)

# =========================================================
# SLIDE 11 — Data Standard / Storage / DB
# =========================================================
s = new_slide()
set_slide_title(s, prs, "데이터 표준 · 저장소 · DB",
                "타임스탬프 KST · 행처리 · MinIO/S3 · SQLite")

cards = [
    ("타임스탬프 표준", "전 단계 KST(Asia/Seoul) 통일",
     ["YYYY-MM-DD HH:mm:ss.SSS", "KST · UTC+9", "후속 분석·정렬·페어링의 기준"], CYAN),
    ("스토리지", "단기 Web 서버 / 후보 MinIO·S3",
     ["1차 다운로드 ~ 30 MB", "Volume Test 1 ~ 5 GB", "객체 스토리지 전환 검토"], PINK),
    ("산출물 (MD)", "분석 결과 문서",
     ["로그구조템플릿.md", "이벤트분석 v1·v2.md", "모션_페어링_분석 v1·v2.md"], VIOLET),
    ("SQLite", "parser 결과 영속화",
     ["events(id, ts_start, ts_end, motion, desc)", "Volume Test 시 대량 적재", "분석·재현성 기반"], LIME),
]
cx0 = Inches(0.55); cy0 = Inches(1.8)
cw, ch = Inches(6.2), Inches(2.5)
gx, gy = Inches(0.20), Inches(0.20)
for i, (h, sub, items, c) in enumerate(cards):
    col = i % 2; row = i // 2
    x = cx0 + (cw + gx) * col
    y = cy0 + (ch + gy) * row
    add_box(s, x, y, cw, ch, fill=BG_PANEL, line=c)
    add_text(s, x + Inches(0.25), y + Inches(0.15), cw - Inches(0.4), Inches(0.4),
             h, size=15, bold=True, color=c)
    add_text(s, x + Inches(0.25), y + Inches(0.55), cw - Inches(0.4), Inches(0.35),
             sub, size=11, color=INK_SOFT)
    add_bullets(s, x + Inches(0.25), y + Inches(0.95), cw - Inches(0.5), Inches(1.5),
                items, size=12)
add_footer(s, 11, TOTAL)

# =========================================================
# SLIDE 12 — Tech stack
# =========================================================
s = new_slide()
set_slide_title(s, prs, "기술 스택", "주요 컴포넌트 · 외부 의존")

stack = [
    ("Python", "주 코딩 언어", CYAN),
    ("Web Server", "대화·진행 UI · 임시 저장", VIOLET),
    ("EDS API", "Datalake 2.0 · 메타·다운로드", PINK),
    ("LLM API", "템플릿·이벤트·페어링·ReAct", LIME),
    ("MinIO / S3", "원시 로그 (후보)", AMBER),
    ("SQLite", "parser 결과 저장", CYAN),
]
sx0 = Inches(0.55); sy0 = Inches(2.0)
sw, sh = Inches(4.05), Inches(1.5)
gx, gy = Inches(0.15), Inches(0.20)
for i, (n, d, c) in enumerate(stack):
    col = i % 3; row = i // 3
    x = sx0 + (sw + gx) * col
    y = sy0 + (sh + gy) * row
    add_box(s, x, y, sw, sh, fill=BG_PANEL, line=c)
    add_text(s, x + Inches(0.3), y + Inches(0.25), sw - Inches(0.5), Inches(0.5),
             n, size=20, bold=True, color=c)
    add_text(s, x + Inches(0.3), y + Inches(0.85), sw - Inches(0.5), Inches(0.5),
             d, size=12, color=INK_SOFT)

add_text(s, Inches(0.55), Inches(5.4), Inches(12), Inches(0.4),
         "주요 의존 흐름", size=14, bold=True, color=CYAN)
add_text(s, Inches(0.55), Inches(5.8), Inches(12.5), Inches(1.0),
         "Browser ↔ Web (Python) ↔ EDS / LLM / Storage / SQLite     |     Engine: ReAct Loop → parser_v1.py",
         size=13, color=INK)
add_footer(s, 12, TOTAL)

# =========================================================
# SLIDE 13 — Risks & Next steps
# =========================================================
s = new_slide()
set_slide_title(s, prs, "리스크 · 다음 단계", "발표 Q&A 대비")

risks = [
    ("Volume Test 비용", "1~5GB 처리 시 메모리·I/O 폭증. 청크 스트리밍·중간 저장 전략 필요.", AMBER),
    ("ReAct 루프 비용·시간", "최대 10회 LLM 호출. 컨텍스트 슬라이싱·캐시·중단 조건 정교화.", LIME),
    ("사용자 대화 정합성", "v1→v2 단계 누락 시 후속 단계 오염. 대화 이력·확정 시점 명시 저장.", PINK),
    ("저장소 결정", "Web 서버 vs MinIO/S3. 30MB는 단기 OK / 1~5GB는 객체 스토리지 권장.", CYAN),
    ("파서 일반화", "parser_v1은 특정 장비/포맷 한정. 다른 eqp는 v2 재정의 필요.", VIOLET),
    ("관측·재현성", "전체 진행 로그 / LLM 호출 기록 / 시드로 재현성 확보.", CYAN),
]
rx0 = Inches(0.55); ry0 = Inches(1.8)
rw, rh = Inches(6.2), Inches(1.55)
gx, gy = Inches(0.20), Inches(0.18)
for i, (h, body, c) in enumerate(risks):
    col = i % 2; row = i // 2
    x = rx0 + (rw + gx) * col
    y = ry0 + (rh + gy) * row
    add_box(s, x, y, rw, rh, fill=BG_PANEL, line=c)
    add_text(s, x + Inches(0.25), y + Inches(0.18), rw - Inches(0.4), Inches(0.4),
             h, size=14, bold=True, color=c)
    add_text(s, x + Inches(0.25), y + Inches(0.6), rw - Inches(0.4), Inches(1.0),
             body, size=12, color=INK)

add_footer(s, 13, TOTAL)

# =========================================================
# SLIDE 14 — Q&A
# =========================================================
s = new_slide()
add_text(s, Inches(0.8), Inches(2.6), Inches(12), Inches(1.5),
         "Q & A", size=80, bold=True, color=WHITE)
add_text(s, Inches(0.8), Inches(4.2), Inches(12), Inches(0.6),
         "MCC 워크플로우에 대한 질문을 주세요.", size=20, color=VIOLET)
add_text(s, Inches(0.8), Inches(4.9), Inches(12), Inches(0.5),
         "Thank you.", size=16, color=INK_SOFT)
add_footer(s, 14, TOTAL)

# ---------- save ----------
out = r'c:\205-MCC-워크플로우\MCC_Workflow_Presentation.pptx'
prs.save(out)
print('saved:', out)
