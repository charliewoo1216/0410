# LH01. MinIO — 로컬 S3 호환 스토리지

> 실습 코드: [`python/lakehouse/lh01_minio_setup.py`](../../python/lakehouse/lh01_minio_setup.py)

## 1. 핵심 개념

**MinIO**: S3 API 와 100% 호환되는 오픈소스 객체 스토리지. AWS S3 클라이언트(boto3, s3a 등)가 그대로 사용 가능해 **로컬 개발용 S3** 로 가장 많이 쓰인다.

```
┌────────┐  S3 API   ┌─────────────┐
│ App    │──────────►│ MinIO       │
│ (Spark │   HTTP     │ (Docker)    │
│  Pandas│           │             │
│  boto3)│           │ Bucket      │
└────────┘           │  └─ Object  │
                     └─────────────┘
```

## 2. 객체 스토리지 핵심 용어

| 용어 | 의미 | 비교 (파일시스템) |
|------|------|------------------|
| **Bucket** | 객체를 담는 최상위 컨테이너 | 디렉토리 |
| **Object** | 저장되는 단위 (key + value + meta) | 파일 |
| **Key** | bucket 내에서 객체를 식별하는 경로 문자열 | 파일 경로 |
| **Endpoint** | 접속 URL | 서버 주소 |

⚠️ 객체 스토리지는 **진짜 디렉토리가 없다**. `logs/2025/10/data.parquet` 같은 키는 단지 문자열이며, 슬래시는 표시 편의용일 뿐.

## 3. 컨테이너 실행

```bash
docker run -d -p 9000:9000 -p 9001:9001 \
  -e "MINIO_ROOT_USER=minioadmin" \
  -e "MINIO_ROOT_PASSWORD=minioadmin" \
  --name minio quay.io/minio/minio \
  server /data --console-address ":9001"
```

| 포트 | 용도 |
|------|------|
| 9000 | S3 API |
| 9001 | 웹 콘솔 |

웹 콘솔: http://localhost:9001 (minioadmin / minioadmin)

## 4. 라이브러리

| 라이브러리 | 용도 |
|----------|------|
| `minio` (공식) | MinIO 전용 SDK (간결) |
| `boto3` | AWS S3 SDK — endpoint 만 바꾸면 동일 |
| `s3fs` | 파일시스템 추상화 (Pandas 가 사용) |
| Spark `s3a://` | Hadoop S3A 커넥터 (LH02) |

## 5. 인증

| 환경 | 방법 |
|------|------|
| 로컬 MinIO | endpoint + access/secret key |
| AWS S3 | IAM role / access key / 환경변수 |
| 클라우드 | aws-vault, 임시 자격증명 |

## 6. 학습 포인트

- 운영 코드는 항상 환경변수에서 자격증명을 읽도록 설계
- `client.bucket_exists()` 로 멱등성 보장
- 큰 파일은 멀티파트 업로드(SDK 가 자동 처리)
- MinIO 콘솔(9001) 에서 버킷·객체를 GUI 로 확인 가능

## 7. 연습 문제

### Q1. MinIO 의 가장 큰 특징은?
① Hadoop 호환 파일시스템
② AWS S3 API 와 호환되는 객체 스토리지
③ 분산 SQL 엔진
④ NoSQL DB

<details><summary>정답</summary>

**②** — S3 API 호환. 로컬 개발/온프레미스 환경에서 S3 대용으로 자주 사용.

</details>

### Q2. 객체 스토리지의 "key" 가 의미하는 것은?
① 파일 시스템의 절대 경로
② bucket 내 객체를 식별하는 임의의 문자열 (디렉토리는 사실 없음)
③ 암호화 키
④ 인덱스 ID

<details><summary>정답</summary>

**②** — 슬래시가 들어간 키는 보기 좋게 표시될 뿐, 진짜 디렉토리는 아니다.

</details>

### Q3. AWS S3 SDK(boto3)로 MinIO 에 접속할 때 변경해야 하는 옵션은?
① `region`
② `endpoint_url` 을 MinIO 주소로
③ S3 와 MinIO 는 호환되지 않으므로 boto3 사용 불가
④ `bucket_name` 만 바꾸면 됨

<details><summary>정답</summary>

**②** — `endpoint_url="http://localhost:9000"` 만 지정하면 boto3 그대로 사용 가능.

</details>

### Q4. MinIO 콘솔 기본 포트는?
① 80   ② 8080   ③ 9000   ④ 9001

<details><summary>정답</summary>

**④ 9001** — 9000 은 S3 API, 9001 은 웹 콘솔.

</details>

### Q5. 다음 중 객체 스토리지의 일반적인 특징이 아닌 것은?
① 무한 확장성
② RESTful API 접근
③ 파일시스템처럼 in-place 부분 수정이 자유로움
④ 메타데이터를 객체에 첨부 가능

<details><summary>정답</summary>

**③** — 객체 스토리지는 보통 **불변(immutable)**. 일부 바이트만 수정 못하고 전체 객체 교체.

</details>
