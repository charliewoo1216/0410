# 데이터레이크 / Lakehouse 학습 노트 색인

객체 스토리지 → Parquet → Delta/Iceberg → 메달리온 → DuckDB 까지 Lakehouse 의 핵심 개념을 정리한 학습 노트.
각 문서는 동일한 번호의 실습 코드(`python/lakehouse/lhNN_*.py`)와 1:1 매칭된다.

## 📚 학습 노트

### 1. 스토리지 기초 (LH01~LH03)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| LH01 | [MinIO](./lh01_minio_setup.md) | S3 호환 객체 스토리지, bucket/key |
| LH02 | [Spark → S3 Parquet](./lh02_spark_to_s3_parquet.md) | s3a 커넥터, 자격증명 |
| LH03 | [파티션 키 설계](./lh03_partition_strategy.md) | partition pruning, 카디널리티 |

### 2. Delta Lake (LH04~LH06)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| LH04 | [Delta Lake 기초](./lh04_delta_basic.md) | _delta_log, ACID, OCC |
| LH05 | [Delta MERGE](./lh05_delta_merge_upsert.md) | Upsert, SCD Type 1/2 |
| LH06 | [Delta Time Travel](./lh06_delta_time_travel.md) | versionAsOf, RESTORE, CDC |

### 3. Iceberg (LH07)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| LH07 | [Apache Iceberg](./lh07_iceberg_basic.md) | hidden partitioning, schema/partition evolution |

### 4. ETL 패턴 (LH08~LH09)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| LH08 | [메달리온 아키텍처](./lh08_etl_pipeline.md) | Bronze/Silver/Gold |
| LH09 | [Streaming → Delta](./lh09_streaming_to_lake.md) | exactly-once, foreachBatch |

### 5. 임베디드 OLAP (LH10)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| LH10 | [DuckDB on Parquet](./lh10_duckdb_on_parquet.md) | 단일 노드 OLAP, vectorized |

## 🧭 핵심 포맷 비교

| 항목 | Parquet | Delta | Iceberg | Hudi |
|------|---------|-------|---------|------|
| ACID | ❌ | ✅ | ✅ | ✅ |
| Time travel | ❌ | ✅ | ✅ | ✅ |
| MERGE | ❌ | ✅ | ✅ | ✅ |
| Hidden partitioning | – | ❌ | ✅ | 일부 |
| Partition evolution | – | ❌ | ✅ | 제한 |
| 주도사 | Apache | Databricks | Netflix→Apache | Uber→Apache |
| 기본 적합 | 정적 데이터 | Spark 중심 운영 | Engine-neutral | 스트리밍 upsert |

## 🛠 실행 환경

```bash
pip install pyspark==3.5.0 delta-spark==3.2.0 minio duckdb pyarrow

# MinIO 컨테이너
docker run -d -p 9000:9000 -p 9001:9001 \
  -e "MINIO_ROOT_USER=minioadmin" \
  -e "MINIO_ROOT_PASSWORD=minioadmin" \
  --name minio quay.io/minio/minio \
  server /data --console-address ":9001"
```

| 외부 의존 | 용도 |
|----------|------|
| Docker | MinIO 컨테이너 |
| Java 17 | Spark / Delta / Iceberg |
| MinIO 콘솔 (9001) | 버킷·객체 GUI 확인 |

## 💡 학습 팁

- **메달리온 3계층(Bronze/Silver/Gold)** 의 책임 분리를 머리에 새기기
- 파일 포맷보다 **트랜잭션 로그**가 Lakehouse 의 본질
- partition 은 **카디널리티**와 **쿼리 패턴** 둘 다 고려
- 단일 노드면 DuckDB 부터 시도, 페타바이트면 Spark
- 운영 코드는 **자격증명을 코드에 박지 않기** (IAM/환경변수)

## 🔗 학습 순서

```
[LH01 MinIO] ─► [LH02 Spark→S3] ─► [LH03 Partition]
                                          │
   ┌──────────────────────────────────────┘
   ▼
[LH04 Delta] ─► [LH05 MERGE] ─► [LH06 Time Travel]
                                          │
   ┌──────────────────────────────────────┘
   ▼
[LH07 Iceberg]
   │
   ▼
[LH08 메달리온] ─► [LH09 Streaming→Delta] ─► [LH10 DuckDB]
```

전제 조건: PySpark 기본기 ([`docs/spark/`](../spark/README.md))
