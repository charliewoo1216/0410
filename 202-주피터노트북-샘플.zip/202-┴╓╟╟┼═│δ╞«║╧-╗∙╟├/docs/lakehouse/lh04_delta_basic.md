# LH04. Delta Lake 기초

> 실습 코드: [`python/lakehouse/lh04_delta_basic.py`](../../python/lakehouse/lh04_delta_basic.py)

## 1. 핵심 개념

**Delta Lake**: 일반 Parquet 위에 **트랜잭션 로그(JSON)** 를 추가해 데이터레이크에 ACID 를 부여한 포맷.

```
my_table/                          ← Delta 테이블 디렉토리
├── _delta_log/                    ← 트랜잭션 로그 (JSON)
│   ├── 00000000000000000000.json
│   ├── 00000000000000000001.json
│   └── ...
├── part-00000-...-c000.snappy.parquet  ← 데이터 파일
└── part-00001-...-c000.snappy.parquet
```

## 2. ACID 보장

| 특성 | 동작 |
|------|------|
| **Atomicity** | 한 트랜잭션은 모두 성공 또는 모두 실패 |
| **Consistency** | 스키마·제약 위반 시 거부 |
| **Isolation** | 동시 쓰기 충돌 감지 (Optimistic Concurrency Control) |
| **Durability** | 로그가 영속화된 이후만 commit 인정 |

## 3. 사용

### 환경 설정 (Spark 3.5 + Delta 3.2)
```python
from delta import configure_spark_with_delta_pip

builder = (SparkSession.builder
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog"))
spark = configure_spark_with_delta_pip(builder).getOrCreate()
```

### 쓰기·읽기
```python
df.write.format("delta").mode("overwrite").save("/tmp/delta-table")
spark.read.format("delta").load("/tmp/delta-table").show()
```

### 테이블 객체 다루기
```python
from delta.tables import DeltaTable

dt = DeltaTable.forPath(spark, "/tmp/delta-table")
dt.history().show()           # 모든 변경 이력
dt.toDF().show()              # 현재 상태 DataFrame
```

## 4. _delta_log 구조

각 commit 은 JSON 파일 한 개. 내용은 다음 액션들의 모음:
- `add`: 새 Parquet 파일 추가
- `remove`: 파일 제거 (실제 삭제는 VACUUM 시)
- `metaData`: 스키마 변경
- `commitInfo`: 커밋 메타 (user, time, op)

매 10번째 commit 마다 **체크포인트(.parquet)** 가 만들어져 빠른 로그 재생.

## 5. 주요 작업

| 작업 | 메서드 |
|------|--------|
| 읽기 | `spark.read.format("delta").load(path)` |
| 추가 | `df.write.format("delta").mode("append").save(path)` |
| 덮어쓰기 | `mode("overwrite")` |
| 갱신 | `dt.update(...)` |
| 삭제 | `dt.delete(...)` |
| Upsert | `dt.merge(...)` (LH05) |
| 시간여행 | `option("versionAsOf", n)` (LH06) |
| 진공 | `dt.vacuum(retentionHours=168)` |

## 6. Delta vs Parquet vs Iceberg/Hudi

| 항목 | Parquet | Delta | Iceberg | Hudi |
|------|---------|-------|---------|------|
| ACID | ❌ | ✅ | ✅ | ✅ |
| Time travel | ❌ | ✅ | ✅ | ✅ |
| MERGE | ❌ | ✅ | ✅ | ✅ |
| Schema evolution | 제한 | ✅ | ✅ | ✅ |
| 주도사 | Apache | Databricks | Netflix | Uber |

## 7. 학습 포인트

- Delta = Parquet + `_delta_log`
- 동시 쓰기 충돌은 OCC 로 감지 → 한쪽이 retry
- VACUUM 은 시간여행 기록도 지움 → 7일 이상 보관 권장
- Spark 3.5 + Delta 3.2 처럼 **버전 매칭** 필수

## 8. 연습 문제

### Q1. Delta Lake 가 Parquet 위에 추가하는 핵심 요소는?
① 인덱스 파일
② 트랜잭션 로그(_delta_log)
③ 스키마 캐시
④ 압축 알고리즘

<details><summary>정답</summary>

**②** — JSON 기반 트랜잭션 로그가 ACID 와 시간여행을 가능하게 함.

</details>

### Q2. Delta Lake 가 보장하는 동시성 제어 방식은?
① 비관적 락
② OCC (Optimistic Concurrency Control)
③ 단일 라이터 강제
④ 동시 쓰기 불가

<details><summary>정답</summary>

**②** — 충돌 시 한쪽이 retry. 작은 변경에서 효율적.

</details>

### Q3. Delta 테이블의 모든 변경 이력을 보려면?
① `df.show()`
② `dt.history()`
③ `spark.sql("SHOW HISTORY")`
④ `dt.versions()`

<details><summary>정답</summary>

**② `dt.history()`** — DeltaTable 객체의 메서드.

</details>

### Q4. `_delta_log` 폴더의 JSON 파일 한 개에 해당하는 것은?
① 한 행의 변경
② 한 트랜잭션(commit)
③ 한 시간의 처리량
④ 한 사용자의 활동

<details><summary>정답</summary>

**②** — 매 commit 마다 새 JSON. 매 10개마다 체크포인트 .parquet.

</details>

### Q5. Delta Lake 에서 더 이상 필요 없는 옛 파일을 정리하는 작업은?
① CLEANUP   ② COMPACT   ③ VACUUM   ④ SHRINK

<details><summary>정답</summary>

**③ VACUUM** — 단, retention 기간 (기본 7일) 이전의 파일만 삭제. 그 전에는 시간여행도 가능.

</details>
