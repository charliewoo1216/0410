# LH02. Spark → S3(MinIO) Parquet

> 실습 코드: [`python/lakehouse/lh02_spark_to_s3_parquet.py`](../../python/lakehouse/lh02_spark_to_s3_parquet.py)

## 1. 핵심 개념

Spark 가 S3 와 통신하려면 Hadoop 의 **S3A 커넥터**(`hadoop-aws`) JAR 가 필요하다.
URL scheme 으로 `s3a://bucket/path` 를 사용한다.

```
┌──────────┐      JAR       ┌──────────────┐
│  Spark   │──────────────► │ hadoop-aws   │
│          │                │ aws-sdk      │
└──────────┘                └──────┬───────┘
                                   │ HTTPS
                                   ▼
                           ┌──────────────┐
                           │  S3 / MinIO  │
                           └──────────────┘
```

## 2. 필수 설정 6가지

```python
spark = (SparkSession.builder
    .config("spark.jars.packages",
            "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262")
    .config("spark.hadoop.fs.s3a.endpoint", "http://localhost:9000")
    .config("spark.hadoop.fs.s3a.access.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.secret.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.path.style.access", "true")
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    .getOrCreate())
```

| 설정 | 의미 |
|------|------|
| `jars.packages` | 빌드 의존성 자동 다운로드 |
| `endpoint` | MinIO 주소 (AWS S3 면 생략) |
| `access.key`, `secret.key` | 자격증명 |
| `path.style.access=true` | MinIO 는 path-style 만 지원 |
| `s3a.impl` | 구현체 (보통 자동 인식) |

## 3. URL Scheme 차이

| Scheme | 설명 | 상태 |
|--------|------|------|
| `s3://` | EMR 전용 | AWS EMR 외에서는 사용 X |
| `s3n://` | 옛 S3 Native | 폐기 (deprecated) |
| **`s3a://`** | Hadoop S3A | **권장 (현재 표준)** |

## 4. 쓰기·읽기

```python
df.write.mode("overwrite").parquet("s3a://warehouse/employees/")
df = spark.read.parquet("s3a://warehouse/employees/")
```

쓰기 모드:
| 모드 | 의미 |
|------|------|
| `error`/`errorifexists` (기본) | 이미 있으면 에러 |
| `overwrite` | 덮어쓰기 |
| `append` | 추가 |
| `ignore` | 이미 있으면 무시 |

## 5. 운영에서의 자격증명

```python
# 환경변수 또는 IAM 역할 권장
.config("spark.hadoop.fs.s3a.aws.credentials.provider",
        "com.amazonaws.auth.DefaultAWSCredentialsProviderChain")
```

`DefaultAWSCredentialsProviderChain` 은 다음 순서로 찾는다:
1. 환경변수 (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`)
2. Java system properties
3. `~/.aws/credentials`
4. EC2 IAM Role / EKS IRSA

## 6. 학습 포인트

- s3a 커넥터의 버전과 Hadoop 버전을 맞춰야 함 (Spark 3.5 + hadoop-aws 3.3.x)
- MinIO 면 `path.style.access=true` 필수
- 운영 코드는 자격증명을 코드에 박지 말고 IAM/환경변수 사용
- 큰 데이터는 partition 으로 나눠서 쓰기 (LH03)

## 7. 연습 문제

### Q1. Spark 가 S3 에 접근할 때 권장되는 URL scheme 은?
① `s3://`   ② `s3n://`   ③ `s3a://`   ④ `hdfs://`

<details><summary>정답</summary>

**③ `s3a://`** — Hadoop S3A 커넥터. 현재 표준.

</details>

### Q2. MinIO 사용 시 Spark 에 반드시 필요한 설정이 아닌 것은?
① `endpoint`
② `access.key`, `secret.key`
③ `path.style.access=true`
④ `bucket.region`

<details><summary>정답</summary>

**④** — region 은 MinIO 에선 의미 없음 (AWS S3 일 때만 필요).

</details>

### Q3. Spark 작업에서 자격증명을 코드에 박지 않으려면?
① `spark-defaults.conf` 만 사용
② `DefaultAWSCredentialsProviderChain` 으로 환경변수/IAM 활용
③ Spark 가 자동으로 IAM 을 인식하니 무시
④ 자격증명 없이도 동작

<details><summary>정답</summary>

**②** — Provider Chain 으로 환경변수, ~/.aws, IAM 등을 자동 탐색.

</details>

### Q4. `df.write.mode("overwrite").parquet("s3a://b/p/")` 의 동작은?
① 기존 파일이 없으면 에러
② 기존 디렉토리를 모두 삭제 후 새로 씀
③ 기존 데이터에 추가
④ 변경 사항만 패치

<details><summary>정답</summary>

**②** — overwrite 는 대상 경로의 기존 데이터를 덮어쓴다.

</details>

### Q5. Spark 의 `s3a://` 사용에 필요한 핵심 JAR 두 개는?
① `hadoop-common`, `hadoop-hdfs`
② `hadoop-aws`, `aws-java-sdk-bundle`
③ `aws-cli`, `boto3`
④ `spark-aws`, `delta-storage`

<details><summary>정답</summary>

**②** — `hadoop-aws` 가 S3A 구현체, `aws-java-sdk-bundle` 이 AWS SDK.

</details>
