# LH10. DuckDB 로 Parquet 직접 쿼리

> 실습 코드: [`python/lakehouse/lh10_duckdb_on_parquet.py`](../../python/lakehouse/lh10_duckdb_on_parquet.py)

## 1. 핵심 개념

**DuckDB**: 단일 프로세스에서 동작하는 **임베디드 OLAP DB**. SQLite 가 OLTP 쪽이라면, DuckDB 는 OLAP 쪽.

```
┌──────────────────────────────────────┐
│      Python / R / CLI 프로세스       │
│  ┌───────┐                           │
│  │DuckDB │ ◄──────► Parquet/CSV/Arrow│
│  └───────┘                           │
└──────────────────────────────────────┘
```

특징:
- **JVM/클러스터 불필요** (Spark 와 정반대)
- **Vectorized execution** + 컬럼 기반 처리 → Pandas 대비 5~50배 빠름
- **Parquet/CSV/Arrow** 를 직접 SQL 로 쿼리
- 단일 노드 메모리 한도까지 처리 가능 (수~수십 GB)

## 2. 기본 사용

```python
import duckdb

con = duckdb.connect()                   # 인메모리 DB
con.sql("SELECT * FROM 'logs/*.parquet'").show()

# Pandas 와 자유롭게 왕복
df_pandas = con.sql("SELECT level, COUNT(*) FROM 'logs/*.parquet' GROUP BY level").df()
```

## 3. Parquet 직접 쿼리

```sql
SELECT service, COUNT(*) AS errors,
       QUANTILE_CONT(duration_ms, 0.95) AS p95
FROM 'logs/*.parquet'
WHERE level = 'ERROR'
GROUP BY service;
```

- glob 패턴 지원
- predicate / projection pushdown 자동
- S3/HTTPS 직접 접근도 가능 (`httpfs` 확장)

## 4. S3·MinIO 접근

```python
con.execute("INSTALL httpfs; LOAD httpfs;")
con.execute("""
    SET s3_endpoint='localhost:9000';
    SET s3_access_key_id='minioadmin';
    SET s3_secret_access_key='minioadmin';
    SET s3_use_ssl=false;
    SET s3_url_style='path';
""")
con.sql("SELECT COUNT(*) FROM 's3://warehouse/logs/*.parquet'").show()
```

## 5. Delta / Iceberg 확장

```python
con.execute("INSTALL delta; LOAD delta;")
con.sql("SELECT * FROM delta_scan('/tmp/delta-table')").show()

con.execute("INSTALL iceberg; LOAD iceberg;")
con.sql("SELECT * FROM iceberg_scan('s3://bucket/iceberg-table')").show()
```

## 6. 언제 DuckDB / Spark 를 써야 하나?

| 데이터 크기 | 권장 |
|-------------|------|
| ~ 수백 MB | Pandas |
| 수백 MB ~ 수십 GB | **DuckDB** |
| 수십 GB ~ 페타바이트 | Spark / Trino |

DuckDB 가 적합한 사용 사례:
- BI 대시보드 백엔드 (단일 노드 충분)
- ad-hoc 분석 / 노트북 EDA
- ETL 파이프라인 중간 단계
- 작은 Lakehouse (개인·팀 단위)

## 7. Pandas 와 비교

| 항목 | Pandas | DuckDB |
|------|--------|--------|
| 엔진 | row-oriented | column-oriented |
| 실행 | iterative | vectorized |
| API | pandas 함수 | SQL |
| 메모리 | 모두 메모리 | streaming + spill |
| 외부 파일 | `pd.read_*` | SQL 에서 직접 |

## 8. 학습 포인트

- DuckDB 는 "SQL 가능한 Pandas" 처럼 사용
- 노트북에서 Spark 띄우기 부담스러울 때 좋은 대안
- Lakehouse 의 **읽기 엔진** 으로 점점 인기 (Motherduck 등 클라우드도 등장)
- 같은 SQL 을 Spark 와 DuckDB 양쪽에서 써 볼 수 있어 학습에도 좋음

## 9. 연습 문제

### Q1. DuckDB 의 가장 큰 차별점은?
① 분산 처리
② 단일 프로세스 + 컬럼 기반 + 벡터화 실행으로 빠른 OLAP
③ NoSQL 지원
④ JVM 기반

<details><summary>정답</summary>

**②** — Spark 의 분산 vs DuckDB 의 단일 노드 OLAP.

</details>

### Q2. DuckDB 가 가장 적합한 데이터 크기는?
① 수십 KB ~ 수 MB   ② 수백 MB ~ 수십 GB   ③ 수백 GB ~ 페타바이트   ④ 모든 크기에서 동일

<details><summary>정답</summary>

**②** — 단일 노드 메모리 한도가 상한선. 수십 GB 까지 부드럽게.

</details>

### Q3. DuckDB 에서 Parquet 파일을 직접 쿼리하려면?
① 별도 import 후 to_table
② SQL 의 FROM 절에 파일 경로/glob 직접 사용
③ 메타스토어 등록 필수
④ Spark 가 필요

<details><summary>정답</summary>

**②** — `FROM 'logs/*.parquet'` 처럼 직접 사용 가능.

</details>

### Q4. DuckDB 가 S3 에 접근하려면?
① 기본 지원
② `httpfs` 확장 설치 후 endpoint 설정
③ Hadoop S3A 필요
④ 불가능

<details><summary>정답</summary>

**②** — `INSTALL httpfs; LOAD httpfs;` 후 S3 옵션 설정.

</details>

### Q5. DuckDB vs Pandas 의 가장 본질적인 차이는?
① Pandas 는 SQL 만 사용
② Pandas 는 row-oriented + iterative, DuckDB 는 columnar + vectorized
③ DuckDB 는 분산 처리
④ Pandas 가 더 빠르다

<details><summary>정답</summary>

**②** — DuckDB 의 컬럼 + 벡터화가 OLAP 쿼리에서 큰 이점.

</details>
