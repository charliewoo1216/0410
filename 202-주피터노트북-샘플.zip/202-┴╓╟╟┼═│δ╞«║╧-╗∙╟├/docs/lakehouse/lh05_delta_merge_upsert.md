# LH05. Delta MERGE — Upsert (SCD Type 1/2)

> 실습 코드: [`python/lakehouse/lh05_delta_merge_upsert.py`](../../python/lakehouse/lh05_delta_merge_upsert.py)

## 1. 핵심 개념

**MERGE INTO**: 한 번의 트랜잭션에서 **존재하면 UPDATE, 없으면 INSERT** 를 수행.
SQL 표준이며, Delta/Iceberg/Hudi 모두 지원하는 가장 자주 쓰는 패턴.

```python
from delta.tables import DeltaTable

(DeltaTable.forPath(spark, path).alias("t")
   .merge(updates.alias("u"), "t.id = u.id")
   .whenMatchedUpdate(set={"v": "u.v"})
   .whenNotMatchedInsertAll()
   .execute())
```

## 2. SCD (Slowly Changing Dimension)

| 유형 | 동작 |
|------|------|
| **Type 0** | 변경 무시 (불변 데이터) |
| **Type 1** | 그냥 덮어쓰기 (이력 미보존) |
| **Type 2** | 새 행 추가 + 이전 행 종료일 갱신 (이력 보존) |
| **Type 3** | 컬럼으로 일부 이력 보존 |
| **Type 4** | 별도 history 테이블 |

대부분의 운영 환경에서는 **Type 1** (간단한 동기화) 또는 **Type 2** (이력 추적).

## 3. SCD Type 1 — 간단한 Upsert

```python
(target.alias("t")
   .merge(source.alias("s"), "t.id = s.id")
   .whenMatchedUpdate(set={"name": "s.name", "salary": "s.salary"})
   .whenNotMatchedInsertAll()
   .execute())
```

## 4. SCD Type 2 — 이력 보존 (시작일/종료일/현재행 플래그)

```python
(target.alias("t")
   .merge(
       source.alias("s"),
       "t.id = s.id AND t.is_current = true"
   )
   # 변경된 행: 기존 행을 종료 처리
   .whenMatchedUpdate(
       condition="t.value <> s.value",
       set={"is_current": "false", "end_date": "current_date()"}
   )
   .execute())

# 그 다음 새 버전을 INSERT
new_rows = source.withColumn("is_current", lit(True)) \
                 .withColumn("start_date", current_date()) \
                 .withColumn("end_date", lit(None).cast("date"))
new_rows.write.format("delta").mode("append").save(path)
```

## 5. 다양한 절(clause)

| 절 | 의미 |
|----|------|
| `whenMatchedUpdate(set={...}, condition="...")` | 매칭되고 조건 시 UPDATE |
| `whenMatchedDelete(condition="...")` | 매칭되면 DELETE |
| `whenNotMatchedInsert(values={...})` | 미매칭이면 INSERT |
| `whenNotMatchedInsertAll()` | source 전체를 INSERT |
| `whenNotMatchedBySourceUpdate/Delete` | target 에만 있을 때 (Iceberg/Delta 3.x+) |

## 6. SQL 형태

```sql
MERGE INTO target t
USING source s ON t.id = s.id
WHEN MATCHED AND t.value <> s.value THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *
```

## 7. 성능 팁

- 조인 키에 **bloom filter / Z-order** 적용 (Delta optimize)
- Merge 가 무거우면 source 를 broadcast (작은 변경분일 때)
- `merge` 후 `OPTIMIZE` + `VACUUM` 으로 작은 파일 정리
- Delta 3.2+ 의 **Deletion Vectors** 옵션으로 더 빠른 update

## 8. 학습 포인트

- 한 번의 MERGE 는 한 번의 트랜잭션 (atomic)
- `whenMatchedUpdate(set=...)` 를 빠뜨리면 매칭 행이 그대로 남음
- 같은 키가 source 에 여러 개 있으면 비결정적 → 사전 dedup 필요
- 성능을 위해 source 와 target 모두 적절히 partition 설계

## 9. 연습 문제

### Q1. SCD Type 1 의 특징은?
① 이력을 모두 보존
② 변경 시 행을 추가하고 이전 행은 종료일 표시
③ 변경 사항을 그냥 덮어쓰고 이력은 보존하지 않음
④ 변경을 무시

<details><summary>정답</summary>

**③** — 가장 단순한 Upsert. 이력이 필요 없을 때.

</details>

### Q2. Delta MERGE 의 동시성 보장은?
① 한 번에 한 명만 MERGE 가능
② 한 MERGE 는 atomic 트랜잭션
③ 행 단위 락
④ 트랜잭션이 없음

<details><summary>정답</summary>

**②** — 전체가 한 트랜잭션. 충돌 시 OCC 로 한쪽 retry.

</details>

### Q3. source 에 같은 키가 여러 행 있을 때?
① Spark 가 자동으로 가장 마지막 행 사용
② 비결정적 동작이라 보통 사전 dedup 필요
③ 자동으로 모두 INSERT
④ 에러 없이 평균값으로 합쳐짐

<details><summary>정답</summary>

**②** — 사전에 source 를 dedup 하지 않으면 결과가 비결정적이라 운영에서 위험.

</details>

### Q4. SCD Type 2 의 핵심 특징은?
① 가장 최근 값만 유지
② 변경 이력을 별도 테이블에 분리
③ 변경 시 새 행을 추가하고 이전 행에 종료일을 표기해 이력 보존
④ 컬럼 하나로 이전 값을 보관

<details><summary>정답</summary>

**③** — start_date / end_date / is_current 플래그로 시계열 이력 관리.

</details>

### Q5. Delta MERGE 후 누적된 작은 파일을 정리하는 명령은?
① `VACUUM`
② `OPTIMIZE`
③ `CLEANUP`
④ `COMPACT`

<details><summary>정답</summary>

**② OPTIMIZE** — 작은 파일을 큰 파일로 합치는 compaction. (VACUUM 은 옛 파일 정리)

</details>
