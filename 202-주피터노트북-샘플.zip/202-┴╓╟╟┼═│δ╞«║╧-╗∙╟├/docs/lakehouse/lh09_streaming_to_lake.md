# LH09. Structured Streaming → Delta Lake

> 실습 코드: [`python/lakehouse/lh09_streaming_to_lake.py`](../../python/lakehouse/lh09_streaming_to_lake.py)

## 1. 핵심 개념

배치와 스트림이 같은 DataFrame API → 같은 Delta 테이블에 쓰기 가능.
이를 **Lambda 통합** 또는 **Kappa 아키텍처** 로 단순화.

```
[Kafka / Kinesis / Files]
        │
        ▼
   readStream
        │
        ▼
   Transformations (DataFrame API)
        │
        ▼
   writeStream.format("delta")
        │
        ▼
   Delta Table (LH04)
        │
        ▼
   Batch readers / dashboards
```

## 2. 기본 패턴

```python
stream = (spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "host:9092")
    .option("subscribe", "events")
    .load())

(stream.selectExpr("CAST(value AS STRING) AS json", "timestamp")
       .writeStream
       .format("delta")
       .outputMode("append")
       .option("checkpointLocation", "/lake/_chk/events")
       .trigger(processingTime="30 seconds")
       .start("/lake/bronze/events"))
```

## 3. 핵심 옵션

| 옵션 | 의미 |
|------|------|
| `checkpointLocation` | **반드시** 설정. offset/state 저장 |
| `outputMode` | append (보통), update, complete |
| `trigger` | processingTime / availableNow / once / continuous |
| `mergeSchema` | 스키마 진화 허용 |

## 4. Exactly-once 보장

다음 3 조건이 모두 충족되어야 정확히 한 번:

| 조건 | 어떻게 |
|------|--------|
| Source 가 replay 가능 | Kafka offset, Delta CDF, Parquet 의 source-side increment |
| State 영속화 | `checkpointLocation` |
| Sink 가 idempotent | Delta 가 트랜잭션 ID 로 중복 commit 방지 |

→ Spark Streaming + Delta 는 기본적으로 exactly-once.

## 5. Watermark + 늦은 데이터

```python
events.withWatermark("event_time", "10 minutes") \
      .groupBy(window("event_time", "1 hour"), "user_id").count()
```

10분 늦은 이벤트까지는 받고, 그보다 더 늦으면 폐기. → State 메모리 관리에 필수.

## 6. foreachBatch — 임의 sink

```python
def to_delta_with_merge(batch_df, batch_id):
    target = DeltaTable.forPath(spark, "/lake/silver/events")
    (target.alias("t")
       .merge(batch_df.alias("s"), "t.id = s.id")
       .whenMatchedUpdateAll()
       .whenNotMatchedInsertAll()
       .execute())

stream.writeStream.foreachBatch(to_delta_with_merge) \
      .option("checkpointLocation", "/lake/_chk/silver") \
      .start()
```

→ Stream 안에서 MERGE/UPSERT 가능. **CDC + Lakehouse 의 핵심 패턴**.

## 7. Trigger 전략

| Trigger | 용도 |
|---------|------|
| `processingTime="30 seconds"` | 준실시간 |
| `availableNow=True` | 현재까지 모든 데이터 처리 후 종료 (배치 ETL 대체) |
| `once=True` | 한 번 처리 (deprecated, availableNow 권장) |
| `continuous="1 second"` | 실험적 ms 단위 latency |

## 8. 학습 포인트

- 운영에서는 **반드시** `checkpointLocation` 별도 디렉토리에 저장
- 같은 checkpoint 를 두 쿼리가 공유하면 충돌
- `foreachBatch` 로 Delta MERGE / 외부 DB 적재 등 자유로운 sink 구현
- 재시작 시 자동으로 마지막 offset 부터 이어 처리

## 9. 연습 문제

### Q1. Spark 스트리밍 → Delta 로 정확히 한 번(exactly-once) 을 보장하기 위해 반드시 필요한 옵션은?
① `outputMode`
② `checkpointLocation`
③ `numPartitions`
④ `trigger`

<details><summary>정답</summary>

**②** — offset/state 저장이 안 되면 재시작 시 중복 처리.

</details>

### Q2. 스트리밍 안에서 MERGE 등 임의 로직을 적용하려면?
① `foreach`
② `foreachBatch`
③ 불가능
④ `merge` 직접

<details><summary>정답</summary>

**② foreachBatch** — 매 마이크로배치마다 일반 DataFrame 으로 받아 자유롭게 처리.

</details>

### Q3. `availableNow=True` trigger 의 동작은?
① 매초 트리거
② 현재까지의 모든 미처리 데이터를 일괄 처리한 뒤 종료
③ 한 번만 처리하고 종료 (deprecated)
④ 영구 실행

<details><summary>정답</summary>

**②** — 일종의 catch-up 모드. 배치성 ETL 의 대체.

</details>

### Q4. Watermark 의 역할은?
① 데이터 무결성 검증
② 늦게 도착하는 이벤트의 허용 한계 설정 (이를 넘어가면 폐기)
③ 워터마크가 있는 데이터만 처리
④ 데이터의 우선순위 부여

<details><summary>정답</summary>

**②** — State 메모리가 무한히 늘어나지 않도록 한다.

</details>

### Q5. 두 개의 스트리밍 쿼리가 같은 `checkpointLocation` 을 사용하면?
① Spark 가 자동으로 분리
② 충돌 / 동작 보장 안 됨
③ 두 쿼리가 동기화됨
④ 첫 쿼리만 동작

<details><summary>정답</summary>

**②** — 각 쿼리는 고유한 checkpoint 디렉토리를 사용해야 한다.

</details>
