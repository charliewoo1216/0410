# LH08. 메달리온 아키텍처 — Bronze / Silver / Gold

> 실습 코드: [`python/lakehouse/lh08_etl_pipeline.py`](../../python/lakehouse/lh08_etl_pipeline.py)

## 1. 핵심 개념

**메달리온 아키텍처(Medallion Architecture)**: Databricks 가 정립한 데이터레이크 ETL 의 3 계층 구조.

```
[원본 시스템]
   │
   ▼
┌──────────┐  raw, immutable
│ BRONZE   │  ← schema-on-read, 원본 그대로
└────┬─────┘
     ▼ 정제·중복제거·표준화
┌──────────┐  validated, conformed
│ SILVER   │
└────┬─────┘
     ▼ 비즈니스 집계, KPI
┌──────────┐  business-ready, aggregated
│ GOLD     │
└──────────┘
   │
   ▼
[BI / Dashboard / ML]
```

| 계층 | 별칭 | 데이터 상태 |
|------|------|------------|
| **Bronze** | Raw | 원본 그대로 + 적재 시각 메타 |
| **Silver** | Cleansed / Conformed | 정제·중복제거·타입 정규화·결측 처리 |
| **Gold** | Curated / Business | 비즈니스 KPI, dim/fact 테이블 |

## 2. 각 계층의 책임

### 2.1 Bronze — 원본 보존
- 원본 그대로 (스키마 강제 X)
- 추적성 컬럼: `_source`, `_ingested_at`, `_batch_id`
- Append-only (절대 수정·삭제 X)
- 장애 시 재처리의 시작점

### 2.2 Silver — 신뢰 가능한 데이터셋
- 결측·이상치 처리
- 중복 제거 (`dropDuplicates`)
- 타입 통일 / 단위 통일 / 코드 매핑
- 마스터 데이터와 조인
- ⭐ MERGE INTO 로 upsert (LH05)

### 2.3 Gold — 비즈니스 메트릭
- 사용자별 활성도, 상품별 매출, 코호트 분석
- BI 도구에 직접 노출
- 작은 규모, 빠른 쿼리

## 3. 구현 패턴

```python
# Bronze
raw.withColumn("_ingested_at", current_timestamp()) \
   .write.format("delta").mode("append").save("/lake/bronze/events")

# Silver — 정제 + dedup + 타입 보정
(spark.read.format("delta").load("/lake/bronze/events")
   .dropna(subset=["user"])
   .dropDuplicates(["event_id"])
   .withColumn("ts", to_timestamp("ts_str"))
   .write.format("delta").mode("overwrite").save("/lake/silver/events"))

# Gold — 사용자별 메트릭
(spark.read.format("delta").load("/lake/silver/events")
   .groupBy("user")
   .agg(count(when(col("event") == "view", 1)).alias("views"),
        count(when(col("event") == "buy",  1)).alias("buys"))
   .withColumn("conv_rate", col("buys") / col("views"))
   .write.format("delta").mode("overwrite").save("/lake/gold/user_metrics"))
```

## 4. 변형/확장

| 변형 | 설명 |
|------|------|
| **Bronze++** | Raw + Standardized 두 단계 |
| **Silver Type 2** | SCD Type 2 로 이력 보존 |
| **Gold per-team** | 팀/부서별 별도 Gold |
| **Aggregates** | Gold 위에 OLAP cube 추가 |

## 5. 운영 팁

- 각 계층은 **다른 디렉토리/카탈로그**로 분리
- Bronze 는 절대 삭제하지 말 것 (재처리의 보험)
- Silver/Gold 는 idempotent 하게 (overwrite 또는 merge)
- 스케줄링: Airflow, Dagster, Databricks Workflows 등으로 의존성 관리

## 6. 학습 포인트

- 메달리온은 **개념적 가이드** — 도메인에 맞게 변형 가능
- 핵심은 "**원본은 절대 잃지 않는다**" + "각 단계의 책임 분리"
- 아래 단계가 깨졌을 때 위 단계만 다시 돌리면 됨 (idempotent + replayable)

## 7. 연습 문제

### Q1. 메달리온 아키텍처의 3계층을 순서대로 나열한 것은?
① Bronze → Silver → Gold
② Gold → Silver → Bronze
③ Raw → Cooked → Served
④ Stage → Refine → Publish

<details><summary>정답</summary>

**①** Bronze (raw) → Silver (cleansed) → Gold (business).

</details>

### Q2. Bronze 계층의 가장 중요한 원칙은?
① 모든 데이터를 정규화한다
② 원본을 그대로 보존하고 절대 수정하지 않는다
③ BI 도구에서 직접 사용한다
④ 비즈니스 메트릭을 계산한다

<details><summary>정답</summary>

**②** — 원본을 잃으면 재처리도 불가능. Append-only 가 원칙.

</details>

### Q3. Silver 계층에서 일반적으로 수행하는 작업이 아닌 것은?
① 결측치 처리
② 중복 제거
③ 타입 정규화
④ KPI 산출

<details><summary>정답</summary>

**④** — KPI 는 Gold 의 역할.

</details>

### Q4. 다음 중 Gold 계층의 산출물에 가장 가까운 것은?
① CDC 변경분 로그
② 정제된 사용자 이벤트 테이블
③ 부서별 월간 매출 대시보드용 집계 테이블
④ S3 에 적재된 raw JSON

<details><summary>정답</summary>

**③** — Gold 는 비즈니스 친화적인 집계·KPI.

</details>

### Q5. Silver/Gold 단계에서 흔히 쓰이는 멱등성(idempotent) 보장 방법은?
① append-only
② overwrite 또는 MERGE INTO
③ insert 만 사용
④ delete 후 insert

<details><summary>정답</summary>

**②** — 같은 입력에 대해 같은 결과가 보장되도록 overwrite/merge 사용.

</details>
