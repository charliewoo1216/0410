# LH07. Apache Iceberg + Schema Evolution

> 실습 코드: [`python/lakehouse/lh07_iceberg_basic.py`](../../python/lakehouse/lh07_iceberg_basic.py)

## 1. 핵심 개념

**Apache Iceberg**: Netflix 가 시작한 오픈 테이블 포맷. 대규모 분석에서 Delta 와 양강 구도.

핵심 차별점:
- **Hidden Partitioning** — 사용자는 partition 컬럼을 쿼리에 안 써도 됨
- **Snapshot 기반** — 모든 트랜잭션이 새 snapshot
- **Schema Evolution** — 안전한 스키마 변경 (rename, reorder, add, drop)
- **Partition Evolution** — 시간 지나며 partition 전략을 바꿀 수 있음 (Delta 는 못 함)

## 2. 메타데이터 구조

```
my_table/
├── metadata/
│   ├── v1.metadata.json      ← 현재 스키마, partition spec
│   ├── snap-...-1.avro       ← snapshot 단위 manifest list
│   └── ...
└── data/                      ← Parquet 파일
    └── ...
```

| 계층 | 역할 |
|------|------|
| metadata.json | 테이블의 현재 상태 |
| manifest list | 한 snapshot 의 manifest 들 |
| manifest | 데이터 파일 그룹의 통계 |
| 데이터 파일 | Parquet/ORC/Avro |

## 3. Catalog 종류

| 종류 | 특징 |
|------|------|
| **Hadoop catalog** | 디렉토리 기반 (학습용) |
| **Hive catalog** | Hive Metastore 사용 |
| **REST catalog** | REST API 기반 (Tabular, Polaris 등) |
| **AWS Glue catalog** | AWS Glue 통합 |

## 4. 사용

```python
spark = (SparkSession.builder
    .config("spark.jars.packages",
            "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.0")
    .config("spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
    .config("spark.sql.catalog.local.type", "hadoop")
    .config("spark.sql.catalog.local.warehouse", "file:///tmp/iceberg-warehouse")
    .getOrCreate())

spark.sql("""
    CREATE TABLE local.demo.events (
        id BIGINT, ts TIMESTAMP, kind STRING
    ) USING iceberg
    PARTITIONED BY (days(ts))
""")
```

## 5. Hidden Partitioning 의 장점

```sql
-- Delta/일반 Parquet
SELECT * FROM events
WHERE event_date = '2025-10-10'   -- ← partition 컬럼을 명시해야 pruning

-- Iceberg
SELECT * FROM events
WHERE ts >= '2025-10-10' AND ts < '2025-10-11'   -- ← ts 만 써도 자동 pruning
```

→ 사용자는 도메인 컬럼만 다루고, Iceberg 가 알아서 파티션 변환을 처리.

## 6. Schema Evolution

```sql
ALTER TABLE local.demo.events ADD COLUMN user_id STRING;
ALTER TABLE local.demo.events DROP COLUMN kind;
ALTER TABLE local.demo.events RENAME COLUMN ts TO event_time;
ALTER TABLE local.demo.events ALTER COLUMN id TYPE BIGINT;
```

ID 기반 컬럼 매핑이라 **이름·순서를 바꿔도 옛 데이터를 안 잃음**.

## 7. Partition Evolution (Iceberg 만의 강점)

```sql
-- 처음엔 days(ts) 로 분할
ALTER TABLE events ADD PARTITION FIELD hours(ts);  -- 이후엔 시간 단위로
```
→ 옛 데이터는 일별, 새 데이터는 시간별로 자연스럽게 진화.

## 8. Iceberg vs Delta vs Hudi

| 항목 | Delta | Iceberg | Hudi |
|------|-------|---------|------|
| 주도 | Databricks | Netflix → Apache | Uber → Apache |
| Hidden partitioning | ❌ | ✅ | 일부 |
| Partition evolution | ❌ | ✅ | 제한 |
| MERGE | ✅ | ✅ | ✅ |
| 시간여행 | ✅ | ✅ | ✅ |
| Engine 호환 | Spark 중심 | Spark/Trino/Flink | Spark/Flink |
| Streaming upsert | OK | OK | **최고** (CoW/MoR) |

## 9. 학습 포인트

- Iceberg = "engine-neutral" — Spark 외 Trino, Flink 등에서도 같은 테이블 사용
- Hidden partitioning 과 partition evolution 은 Delta 가 못 하는 차별점
- 최근 트렌드는 REST catalog (Tabular, Polaris)
- Apache Polaris 는 Iceberg 의 표준 catalog 가 되는 중

## 10. 연습 문제

### Q1. Iceberg 의 hidden partitioning 의 장점은?
① 사용자가 partition 컬럼을 쿼리에 명시하지 않아도 자동 pruning
② 데이터를 자동 압축
③ 데이터 무결성 보장
④ 디스크 공간 절약

<details><summary>정답</summary>

**①** — 도메인 컬럼만 쓰고, Iceberg 가 자동으로 partition 변환식 적용.

</details>

### Q2. Iceberg 의 가장 두드러진 특징으로 Delta 가 (현재 시점) 따라가지 못하는 것은?
① ACID
② Schema evolution
③ Partition evolution
④ Time travel

<details><summary>정답</summary>

**③ Partition evolution** — Iceberg 는 partition 전략을 바꿔도 옛 데이터 호환 유지.

</details>

### Q3. Iceberg 의 catalog 가 아닌 것은?
① Hadoop catalog   ② Hive catalog   ③ REST catalog   ④ Spark catalog

<details><summary>정답</summary>

**④ Spark catalog** — Spark 의 일반 catalog 와 다름. Iceberg 는 Hadoop / Hive / REST / Glue 등 자체 catalog 사용.

</details>

### Q4. 다음 SQL 의 의미는?
```sql
ALTER TABLE events ADD PARTITION FIELD hours(ts);
```
① 모든 옛 데이터를 시간 단위로 다시 쓴다
② 이후 데이터는 시간 단위 partition 으로 추가하지만, 옛 데이터는 그대로 둔다
③ 에러
④ partition 을 모두 제거

<details><summary>정답</summary>

**②** — Partition Evolution. 옛 데이터는 그대로, 새 데이터부터 새 spec 적용.

</details>

### Q5. 같은 Iceberg 테이블을 Spark 외 Trino, Flink 등에서도 동일하게 다룰 수 있는 이유는?
① 모두 Apache 오픈소스라서
② Iceberg 가 engine 중립적인 표준 메타데이터 포맷이기 때문
③ Catalog 가 자동으로 변환해 주기 때문
④ 사실 Spark 에서만 동작한다

<details><summary>정답</summary>

**②** — 메타데이터 스펙이 표준화되어 있어 다양한 엔진이 동일 테이블을 안전하게 읽고 씀.

</details>
