# LH03. 파티션 키 설계

> 실습 코드: [`python/lakehouse/lh03_partition_strategy.py`](../../python/lakehouse/lh03_partition_strategy.py)

## 1. 핵심 개념

**파티션(Partition)** = 디렉토리(또는 prefix)로 나누어 저장한 단위.
쿼리 시 **partition pruning** 으로 필요한 디렉토리만 스캔한다.

```
sales/
├── region=KR/
│   ├── order_date=2025-10-08/  → file1.parquet
│   └── order_date=2025-10-09/
├── region=US/
│   └── ...
└── region=JP/
    └── ...
```

## 2. 쓰기

```python
df.write.partitionBy("region", "order_date").parquet("sales/")
```

### Partition pruning 효과
```python
# region=KR 디렉토리만 읽음 (다른 지역 디렉토리는 무시)
spark.read.parquet("sales/").filter("region = 'KR'")
```

## 3. 좋은 파티션 키의 조건

| 기준 | 설명 |
|------|------|
| **WHERE 절에 자주 사용** | 그래야 pruning 효과 |
| **카디널리티 적정** | 너무 많으면 작은 파일 폭증 |
| **균일한 분포** | 한 키에 몰리면 skew |

### 카디널리티 가이드

| 카디널리티 | 적합성 |
|-----------|--------|
| 2 ~ 수십 | ✅ 좋음 (region, env) |
| 수백 ~ 수천 | ⚠️ 1차/2차 파티션 결합 (`year=/month=`) |
| 수만 이상 | ❌ 피해야 함 (user_id 직접) |

## 4. 시간 파티션 패턴

| 패턴 | 권장 상황 |
|------|----------|
| `date=YYYY-MM-DD` | 일별 분석이 흔함 |
| `year=YYYY/month=MM/day=DD` | 다양한 시간 범위 분석 |
| `year=YYYY/month=MM` | 월별 분석 위주 (일별 너무 잘게) |

> Hive 스타일 `key=value` 디렉토리는 Spark 가 자동 인식.

## 5. 안티 패턴

### 5.1 너무 잘게 쪼개기
```
order_date=2025-10-10/order_id=123/   ❌
```
order_id 는 매우 높은 카디널리티 → 작은 파일 폭증.

### 5.2 균형 깨진 파티션
시간 파티션에서 일별로 했는데 특정 일에 99% 몰림 → skew.

### 5.3 너무 큰 파티션
한 파티션에 10GB 이상 → 단일 task 가 OOM.

## 6. Bucketing (대안)

```python
df.write.bucketBy(8, "user_id").saveAsTable("events")
```
- 디렉토리 분할 없이 파일 내부 해시 분할
- 같은 키 반복 조인 시 셔플 회피
- Hive 메타스토어 필요

## 7. 학습 포인트

- 파티션 = "이 디렉토리만 읽고 싶다" 라고 생각하면 쉬움
- 너무 잘게 쪼개면 작은 파일 문제 → 1파티션당 **128MB ~ 1GB** 가 권장
- 시간 + 지역 조합이 가장 흔한 실무 패턴
- Iceberg 의 **hidden partitioning** 은 사용자 쿼리에 없어도 자동 pruning (LH07)

## 8. 연습 문제

### Q1. 파티셔닝의 가장 큰 효과는?
① 압축률 증가
② Partition pruning 으로 쿼리 시 필요한 디렉토리만 스캔
③ 자동 인덱스 생성
④ 데이터 정렬

<details><summary>정답</summary>

**②** — 디렉토리 단위로 잘라 두어 WHERE 절 컬럼이 partition 키이면 다른 디렉토리를 건너뜀.

</details>

### Q2. 다음 중 파티션 키로 가장 부적합한 것은?
① `region` (3종)
② `country` (200국)
③ `year/month` (수십~수백)
④ `user_id` (수백만)

<details><summary>정답</summary>

**④** — 너무 높은 카디널리티 → 작은 파일 폭증.

</details>

### Q3. Hive-style 파티션 디렉토리의 형식은?
① `region/KR/`
② `region=KR/`
③ `region.KR/`
④ `partition_region_KR/`

<details><summary>정답</summary>

**② `key=value/`** — Spark/Hive 가 자동 인식.

</details>

### Q4. 파티션 디렉토리 안에 매우 작은 파일이 너무 많다. 흔한 원인이 아닌 것은?
① 파티션 키가 너무 많음
② Spark 의 partition 수가 큼 (예: 200) 인 채로 쓰기
③ Snappy 압축 사용
④ 매 마이크로배치마다 append

<details><summary>정답</summary>

**③** — 압축은 작은 파일 문제와 직접 관련 없음.

</details>

### Q5. 디렉토리 분할 대신 파일 내부 해시 분할로 셔플을 줄이는 기법은?
① Partitioning   ② Bucketing   ③ Caching   ④ Z-ordering

<details><summary>정답</summary>

**② Bucketing** — `bucketBy(n, "key").saveAsTable(...)`.

</details>
