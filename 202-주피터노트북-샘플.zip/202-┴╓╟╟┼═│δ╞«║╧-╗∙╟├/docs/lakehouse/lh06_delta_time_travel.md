# LH06. Delta Time Travel

> 실습 코드: [`python/lakehouse/lh06_delta_time_travel.py`](../../python/lakehouse/lh06_delta_time_travel.py)

## 1. 핵심 개념

**Time Travel** = 과거 시점의 테이블 상태를 그대로 조회하는 기능.
Delta 의 `_delta_log` 가 모든 변경을 기록하므로 임의 버전·시각 재구성이 가능하다.

```
v0  ─► Insert (id=1, 2)
v1  ─► Append  (id=3)
v2  ─► Update  (id=1 → 999)
v3  ─► Delete  (id=2)
```

각 버전을 그대로 조회 가능.

## 2. 사용

### 버전 기반
```python
spark.read.format("delta").option("versionAsOf", 0).load(path)
spark.read.format("delta").option("versionAsOf", 2).load(path)
```

### 타임스탬프 기반
```python
spark.read.format("delta") \
    .option("timestampAsOf", "2025-10-10 12:00:00") \
    .load(path)
```

### SQL
```sql
SELECT * FROM delta.`/path/to/table` VERSION AS OF 5;
SELECT * FROM delta.`/path/to/table` TIMESTAMP AS OF '2025-10-10';
```

## 3. 활용 사례

| 사례 | 설명 |
|------|------|
| **실수 복구** | 잘못된 UPDATE 직전 버전으로 ROLLBACK (RESTORE) |
| **재현 가능 분석** | "어제 모델 학습에 쓴 데이터" 그대로 재조회 |
| **감사(audit)** | 시점별 데이터 비교 |
| **A/B 비교** | 같은 쿼리를 두 버전에 실행해 차이 분석 |
| **CDC** | 두 버전의 차이로 변경분 추출 |

## 4. RESTORE — 과거 버전으로 되돌리기

```python
from delta.tables import DeltaTable
dt = DeltaTable.forPath(spark, path)
dt.restoreToVersion(0)              # v0 으로 복원 → 새 commit 생성
dt.restoreToTimestamp("2025-10-10")
```

⚠️ Restore 는 **새 트랜잭션** 으로 기록됨 — v3 였던 테이블이 RESTORE 후 v4 가 되며 그 v4 의 내용이 v0 과 동일.

## 5. VACUUM 의 영향

`VACUUM` 은 retention 기간(기본 7일) 이전의 파일을 영구 삭제 → **그보다 옛날 시점의 time travel 은 불가능해짐**.

```python
dt.vacuum(168)            # 168시간 = 7일
dt.vacuum(0)              # 즉시 삭제 (시간여행 모두 잃음, 운영에선 위험)
```

운영 권장: `delta.deletedFileRetentionDuration` 를 30일 이상 유지.

## 6. CHANGE DATA FEED (CDC)

Delta 2.0+ 의 기능. 변경분만 스트림으로 읽음.

```sql
ALTER TABLE my_table SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
SELECT * FROM table_changes('my_table', 0, 10);
```

→ 행마다 `_change_type` (insert/update_preimage/update_postimage/delete) 컬럼 부여.

## 7. 학습 포인트

- 버전 기반과 타임스탬프 기반 둘 다 자유롭게 사용
- VACUUM 전에는 모든 옛 버전 조회 가능
- 운영에선 retention 기간을 충분히 길게
- 큰 데이터셋도 trivial 하게 시간여행 가능 (Parquet 파일을 그대로 재조합)

## 8. 연습 문제

### Q1. Delta time travel 을 가능하게 하는 핵심 메커니즘은?
① 자동 백업
② `_delta_log` 의 모든 변경 기록
③ HDFS 스냅샷
④ 데이터 압축

<details><summary>정답</summary>

**②** — 매 commit 의 add/remove 액션이 로그로 남아 있어 임의 시점 재구성 가능.

</details>

### Q2. 다음 코드의 결과는?
```python
spark.read.format("delta").option("versionAsOf", 0).load(path)
```
① 가장 최근 버전 조회
② 첫 번째 commit (v0) 시점의 테이블 조회
③ 빈 DataFrame
④ 에러

<details><summary>정답</summary>

**②** — v0 = 최초 commit. 그 시점의 테이블 상태.

</details>

### Q3. VACUUM 이 time travel 에 미치는 영향은?
① 영향 없음
② retention 기간 이전의 파일을 삭제해 그보다 옛날의 time travel 이 불가능해짐
③ 모든 시간여행을 즉시 차단
④ time travel 속도가 빨라짐

<details><summary>정답</summary>

**②** — 그래서 운영에서는 retention 을 충분히 길게(보통 30일+) 설정.

</details>

### Q4. RESTORE 의 동작으로 옳은 것은?
① 옛 commit 을 직접 수정한다
② 옛 버전으로 되돌리되, 그 결과를 **새 commit** 으로 기록
③ time travel 만 가능, 실제 복원은 불가
④ vacuum 후엔 동작하지 않는다

<details><summary>정답</summary>

**②** — 새 commit 으로 남으므로 RESTORE 자체도 미래에서 time travel 가능.

</details>

### Q5. Delta 의 CHANGE DATA FEED (CDC) 가 제공하는 것은?
① 모든 시점의 전체 스냅샷
② 변경된 행만 (insert/update/delete) 스트림으로
③ time travel 의 다른 이름
④ 데이터 보안 감사

<details><summary>정답</summary>

**②** — `_change_type` 컬럼과 함께 변경분만 추출.

</details>
