# S14. 실행 계획 보기 — explain()

> 실습 코드: [`python/spark/spark14_explain_plan.py`](../../python/spark/spark14_explain_plan.py)

## 1. 핵심 개념

Spark 는 SQL/DataFrame 코드를 4단계 plan 으로 변환한다.

```
SQL/DataFrame 코드
        │
        ▼
1. Parsed Logical Plan          (구문 검증)
        │
        ▼
2. Analyzed Logical Plan         (메타데이터 확인 — 컬럼 존재, 타입)
        │
        ▼
3. Optimized Logical Plan        (Catalyst 최적화: predicate pushdown, projection prune)
        │
        ▼
4. Physical Plan                 (실제 실행 — exchange, broadcast, scan)
        │
        ▼
   RDD 변환 → 실행
```

## 2. explain 모드

```python
df.explain()              # Physical Plan 만
df.explain(True)          # 4단계 모두
df.explain("formatted")   # 단계별 정리
df.explain("cost")        # 비용 추정 포함
```

## 3. Physical Plan 의 주요 키워드

| 키워드 | 의미 |
|--------|------|
| `Scan parquet/csv` | 데이터 스캔 |
| `Filter` | 행 필터 |
| `Project` | 컬럼 선택 |
| `Exchange` | 셔플 (성능 핵심) |
| `BroadcastExchange` | 작은 테이블 broadcast |
| `BroadcastHashJoin` | broadcast join |
| `SortMergeJoin` | 정렬 병합 join |
| `HashAggregate` | 해시 집계 |
| `*(WholeStageCodegen)` | 단계별 코드생성 (성능 좋음) |

## 4. 최적화 사례

### 4.1 Predicate Pushdown
```python
df = spark.read.parquet("path").filter(col("date") == "2025-01-01")
```
→ optimized plan 에서 filter 가 **scan 쪽으로 내려가** Parquet 의 row group 을 건너뜀.

### 4.2 Projection Pruning
```python
df.select("a", "b").show()
```
→ Parquet 컬럼 c, d 는 디스크에서 아예 읽지 않음.

### 4.3 Constant Folding
```python
df.filter(lit(1) == 1)
```
→ optimizer 가 항상 참으로 판단해 filter 자체를 제거.

## 5. AQE (Adaptive Query Execution)

Spark 3.0+ 에서 런타임 통계를 보고 plan 을 동적으로 조정.

| 기능 | 동작 |
|------|------|
| 동적 partition 합치기 | 결과 partition 이 작으면 자동 coalesce |
| Skew Join 처리 | 한쪽으로 몰린 키를 자동 분리 |
| Sort Merge → Broadcast | 런타임에 작아지면 변경 |

```python
spark.conf.set("spark.sql.adaptive.enabled", "true")
```

## 6. 학습 포인트

- 성능 문제는 거의 항상 **Exchange (셔플)** 와 **SortMergeJoin** 이 원인
- broadcast 가 안 되고 있다면 hint 또는 threshold 조정
- `formatted` 모드가 가장 읽기 쉬움
- AQE 는 3.2+ 에서 기본 활성화 (확인 권장)

## 7. 연습 문제

### Q1. Spark plan 의 4단계 순서가 올바른 것은?
① Physical → Optimized Logical → Analyzed → Parsed
② Parsed → Analyzed → Optimized Logical → Physical
③ Logical → Optimized → Analyzed → Physical
④ Analyzed → Parsed → Logical → Physical

<details><summary>정답</summary>

**②** Parsed → Analyzed → Optimized Logical → Physical

</details>

### Q2. `Exchange` 노드가 의미하는 것은?
① 두 DataFrame 의 swap
② 셔플(shuffle) 발생
③ 데이터 캐시
④ broadcast

<details><summary>정답</summary>

**② 셔플** — Exchange 가 많을수록 비용 큼.

</details>

### Q3. `WHERE date = '2025-01-01'` 가 Parquet scan 으로 내려가는 최적화 이름은?
① Constant Folding
② Predicate Pushdown
③ Projection Pruning
④ Cost-Based Optimization

<details><summary>정답</summary>

**② Predicate Pushdown** — 필터를 데이터 소스 레벨로 내려 scan 비용 감소.

</details>

### Q4. AQE (Adaptive Query Execution) 가 런타임에 할 수 있는 것이 아닌 것은?
① 작은 partition 자동 합치기
② Skew 키 자동 분리
③ Sort Merge Join 을 Broadcast Join 으로 변경
④ Python UDF 를 내장 함수로 변환

<details><summary>정답</summary>

**④** — UDF 의 내부는 black-box 이므로 자동 치환 불가.

</details>

### Q5. 가장 읽기 쉬운 explain 모드는?
① `explain()`
② `explain(True)`
③ `explain("formatted")`
④ `explain("cost")`

<details><summary>정답</summary>

**③ `formatted`** — 노드별 입출력·인자 등이 표 형식으로 정리되어 보기 좋다.

</details>
