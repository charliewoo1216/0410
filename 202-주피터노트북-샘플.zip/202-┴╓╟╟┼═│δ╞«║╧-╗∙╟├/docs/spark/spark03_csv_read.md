# S03. CSV 읽기 + 스키마 추론

> 실습 코드: [`python/spark/spark03_csv_read.py`](../../python/spark/spark03_csv_read.py)

## 1. 핵심 개념

```python
df = (spark.read
      .option("header", True)
      .option("inferSchema", True)
      .option("sep", ",")
      .csv("path/*.csv"))
```

### DataFrameReader 사용 가능 포맷

| 메서드 | 포맷 |
|--------|------|
| `.csv(path)` | CSV/TSV |
| `.json(path)` | JSON Lines |
| `.parquet(path)` | Parquet |
| `.orc(path)` | ORC |
| `.text(path)` | 줄당 한 행 (`value` 컬럼) |
| `.format("delta").load(path)` | Delta Lake |
| `.format("jdbc").load()` | RDBMS |

## 2. CSV 옵션

| 옵션 | 설명 | 기본값 |
|------|------|--------|
| `header` | 첫 행을 컬럼명으로 | `false` |
| `inferSchema` | 타입 자동 추론 | `false` |
| `sep` / `delimiter` | 구분자 | `,` |
| `quote` | 따옴표 문자 | `"` |
| `escape` | 이스케이프 | `\` |
| `nullValue` | NULL 로 처리할 문자열 | `""` |
| `dateFormat` | 날짜 포맷 | `yyyy-MM-dd` |
| `timestampFormat` | 타임스탬프 포맷 | ISO 8601 |
| `mode` | 잘못된 행 처리 | `PERMISSIVE` |

### `mode` 옵션

| 값 | 동작 |
|----|------|
| `PERMISSIVE` | 잘못된 필드는 NULL, 전체 raw 는 `_corrupt_record` 로 저장 |
| `DROPMALFORMED` | 잘못된 행 제거 |
| `FAILFAST` | 즉시 예외 발생 |

## 3. inferSchema 의 함정

`inferSchema=True` 는 **데이터를 두 번 읽는다**:
1. 1차: 타입 추론용 스캔
2. 2차: 실제 로딩

큰 파일에서는 비용이 크므로 **운영에서는 `schema` 직접 명시** 권장.

```python
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

schema = StructType([...])
df = spark.read.option("header", True).schema(schema).csv("data.csv")
```

## 4. 여러 파일·디렉토리 읽기

```python
spark.read.csv("data/2025-*.csv")            # glob
spark.read.csv("data/")                       # 디렉토리 전체
spark.read.csv(["a.csv", "b.csv", "c.csv"])  # 명시적 리스트
```

## 5. 학습 포인트

- 읽기 자체도 **lazy** 이다 — `read()` 호출 시점에는 파일을 열지 않음
- `count()`, `show()`, `collect()` 등 **action** 시 실제 IO 발생
- 잘못된 인코딩(UTF-8 BOM 등)은 `option("encoding", "UTF-8")` 로 해결
- 큰 파일에서 `inferSchema` 는 비용이 크니 schema 명시

## 6. 연습 문제

### Q1. CSV 의 첫 줄이 컬럼명일 때 사용하는 옵션은?
① `option("header", True)`
② `option("schema", True)`
③ `option("first_row", True)`
④ `option("colname", True)`

<details><summary>정답</summary>

**①** `option("header", True)`

</details>

### Q2. `inferSchema=True` 의 단점으로 옳은 것은?
① 메모리 사용량이 늘어난다
② 데이터를 두 번 스캔하므로 비용이 크다
③ 컬럼이 많아지면 잘못 동작한다
④ Spark 3 에서는 사용 불가

<details><summary>정답</summary>

**②** — 1차 스캔으로 타입 추론, 2차 스캔으로 실제 로딩.

</details>

### Q3. 잘못된 형식의 행을 만나면 즉시 작업을 실패시키는 mode 는?
① PERMISSIVE   ② DROPMALFORMED   ③ FAILFAST   ④ STRICT

<details><summary>정답</summary>

**③ FAILFAST**

</details>

### Q4. 다음 코드에서 IO 가 실제로 발생하는 시점은?
```python
df = spark.read.csv("big.csv")  # ①
schema = df.schema              # ②
result = df.filter(...).count() # ③
```
① ① 시점   ② ② 시점   ③ ③ 시점   ④ 모두 동시에

<details><summary>정답</summary>

**③** — Spark 는 lazy. `count()` 와 같은 action 시 실제 계산·IO 발생.
(② 의 schema 접근은 inferSchema=True 인 경우 한 번 IO 가 발생할 수 있음)

</details>

### Q5. 여러 파일을 한 번에 읽으려면?
① 파일을 미리 합쳐야 한다
② glob 패턴(`*.csv`) 또는 디렉토리를 지정한다
③ 반복문으로 union 한다
④ Spark 는 한 번에 한 파일만 읽는다

<details><summary>정답</summary>

**②** — `spark.read.csv("dir/*.csv")` 또는 디렉토리 경로 모두 가능.

</details>
