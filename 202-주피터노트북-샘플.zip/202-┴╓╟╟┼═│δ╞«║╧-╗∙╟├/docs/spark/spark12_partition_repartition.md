# S12. Partition 수 조절 — repartition / coalesce

> 실습 코드: [`python/spark/spark12_partition_repartition.py`](../../python/spark/spark12_partition_repartition.py)

## 1. 핵심 개념

**Partition** = 분산 처리 단위. 각 partition 은 한 task 로 처리되어 한 executor 에서 실행된다.

```
DataFrame  ── partition 1 ─┐
              partition 2  ├──► Executor 1 (cores=4) → 4 task 동시 실행
              partition 3  │
              partition 4 ─┘
              partition 5 ─┐
              ...          ├──► Executor 2
```

| 함수 | 셔플 | 용도 |
|------|------|------|
| `repartition(n)` | **Yes** | n으로 늘리거나 줄이기, 균등 분포 |
| `repartition(n, col)` | **Yes** | 컬럼 기준 해시 분할 |
| `coalesce(n)` | **No** (기존 partition 합치기만) | n으로 줄이기만 |

## 2. coalesce vs repartition

```
초기:  [P1=10][P2=10][P3=10][P4=10]   (총 40)

repartition(2):
       [P1=20][P2=20]                   ← 셔플하며 균등 재분배

coalesce(2):
       [P1=20(=P1+P2)][P2=20(=P3+P4)]   ← 인접 합치기만, 셔플 없음
```

→ **줄일 때 빠른 건 coalesce**, **균등 분배가 필요하면 repartition**.

## 3. 핵심 설정값

| 설정 | 의미 | 기본값 |
|------|------|--------|
| `spark.sql.shuffle.partitions` | groupBy/join 후 셔플 partition 수 | **200** |
| `spark.default.parallelism` | RDD 기본 병렬도 | 코어 수 기반 |
| `spark.sql.adaptive.enabled` | AQE 활성화 (런타임 동적 조정) | 3.2+ 기본 true |

## 4. 적정 partition 수 가이드

- 한 partition 의 크기는 **128MB ~ 256MB** 가 적정 (너무 작으면 오버헤드 ↑, 너무 크면 OOM)
- 작은 데이터에서 `shuffle.partitions=200` 은 오히려 비효율 → 8 ~ 32 정도로 조정
- 쓸 때 (`write`) 직전에 `coalesce` 로 너무 많은 작은 파일 생성 방지

## 5. 컬럼 기반 repartition

조인·groupBy 키와 일치시켜 미리 분할하면 셔플을 피할 수 있다.

```python
# 키로 미리 분할 → 후속 join 에서 셔플 없음
df_keyed = df.repartition(8, "user_id")
```

## 6. 학습 포인트

- partition 수 = 동시 task 수 (이론상)
- 작은 파일 많을 때 → `coalesce` 또는 `repartition(N)` 후 쓰기
- skew 발생 시 partition 수를 늘려도 한 키에 몰린 데이터는 분산 안 됨 → AQE / Salting
- `getNumPartitions()` 로 현재 수 확인

## 7. 연습 문제

### Q1. partition 수를 줄일 때 셔플 없이 빠른 함수는?
① `repartition`   ② `coalesce`   ③ `partitionBy`   ④ `bucketBy`

<details><summary>정답</summary>

**② `coalesce`** — 인접 partition 을 단순 합치므로 셔플 없음.

</details>

### Q2. `spark.sql.shuffle.partitions` 의 기본값은?
① 8   ② 100   ③ 200   ④ 코어 수

<details><summary>정답</summary>

**③ 200** — 작은 데이터에서는 줄이는 편이 빠르다.

</details>

### Q3. 한 partition 의 적정 크기는 일반적으로?
① 1MB 이하   ② 약 128MB ~ 256MB   ③ 1GB 이상   ④ 데이터 전체

<details><summary>정답</summary>

**②** — 너무 작으면 task 오버헤드, 너무 크면 OOM.

</details>

### Q4. 후속 조인이 같은 키로 자주 일어날 때 셔플을 줄이는 방법은?
① `coalesce(1)` 호출
② `repartition(n, key)` 로 미리 키로 분할
③ `groupBy` 먼저 호출
④ partition 수를 1로 줄이기

<details><summary>정답</summary>

**②** — 키로 해시 분할하면 동일 키가 같은 partition 에 모임. 후속 join 의 셔플을 피할 수 있다.

</details>

### Q5. 출력 시 작은 파일이 너무 많이 생긴다. 적절한 대응은?
① `repartition(1)` 로 강제 한 파일 (대용량은 위험)
② `coalesce(N)` 으로 적절한 수로 합치기
③ Spark 가 자동 처리하므로 무시
④ partition 수를 늘림

<details><summary>정답</summary>

**②** — 적절한 N (예: 데이터 크기에 따라 8~64) 으로 `coalesce(N)` 후 쓰기.

</details>
