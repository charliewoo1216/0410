# S06. groupBy + 다중 집계

> 실습 코드: [`python/spark/spark06_groupby_agg.py`](../../python/spark/spark06_groupby_agg.py)

## 1. 핵심 개념

`groupBy(*cols).agg(*exprs)` — SQL 의 `GROUP BY` + 집계 함수에 대응.

```python
from pyspark.sql.functions import avg, count, max as smax, min as smin, sum as ssum

df.groupBy("dept").agg(
    count("*").alias("n"),
    avg("salary").alias("avg_sal"),
    smax("salary").alias("max_sal"),
)
```

## 2. 자주 쓰는 집계 함수

| 함수 | 의미 |
|------|------|
| `count("*")` | 행 개수 (NULL 포함) |
| `count("col")` | NULL 제외 카운트 |
| `countDistinct("col")` | 중복 제거 카운트 |
| `sum("col")` | 합계 |
| `avg("col")` / `mean` | 평균 |
| `max`, `min` | 최댓값/최솟값 |
| `stddev`, `variance` | 표준편차/분산 |
| `first("col", ignorenulls=True)` | 첫 값 |
| `collect_list`, `collect_set` | 그룹의 값을 배열로 모음 |
| `approx_count_distinct` | HLL 기반 근사 |

⚠️ Python 의 내장 `max`, `min`, `sum` 과 충돌할 수 있어 별칭(`smax`, `ssum`)을 자주 사용.

## 3. 여러 컬럼으로 그룹화

```python
df.groupBy("dept", "gender").agg(avg("salary"))
```

## 4. agg 에서 dict 형태도 가능

```python
df.groupBy("dept").agg({"salary": "avg", "id": "count"})
```

## 5. pivot

```python
df.groupBy("dept").pivot("gender").avg("salary")
# 결과: dept | F | M  (행: 부서, 열: 성별)
```

## 6. 셔플과 `spark.sql.shuffle.partitions`

`groupBy` 는 **셔플(shuffle)** 을 일으킨다 (값이 동일한 키를 같은 파티션으로 모음).
기본 셔플 파티션 수 = **200**. 작은 데이터에선 줄이는 편이 빠르다.

```python
spark.conf.set("spark.sql.shuffle.partitions", "8")
```

## 7. 학습 포인트

- `count("*")` 와 `count("col")` 은 **NULL 처리**에서 다름
- 큰 카디널리티의 distinct 카운트는 `approx_count_distinct` 가 압도적으로 빠름
- 작은 데이터에서 `shuffle.partitions=200` 이면 오히려 느려짐
- pivot 은 unique 값을 미리 알면 두 번째 인자에 명시: `pivot("col", ["A", "B"])`

## 8. 연습 문제

### Q1. `count("*")` 와 `count("col")` 의 차이는?
① 둘은 완전히 동일하다
② `count("*")` 는 NULL 도 포함, `count("col")` 은 NULL 을 제외
③ `count("col")` 은 distinct 카운트
④ `count("*")` 는 분산 처리되지 않는다

<details><summary>정답</summary>

**②** — `*` 는 NULL 포함 모든 행, 컬럼 지정은 해당 컬럼 NULL 행 제외.

</details>

### Q2. 큰 데이터셋에서 distinct 카운트의 빠른 근사값을 얻으려면?
① `count("col").distinct()`
② `countDistinct("col")`
③ `approx_count_distinct("col")`
④ `count("*")`

<details><summary>정답</summary>

**③** — HyperLogLog 기반 근사 알고리즘. 메모리·속도에서 압도적으로 유리.

</details>

### Q3. `groupBy` 가 일으키는 분산 처리 단계의 핵심은?
① broadcast   ② shuffle   ③ partition prune   ④ checkpoint

<details><summary>정답</summary>

**② shuffle** — 같은 키를 같은 파티션으로 재분배.

</details>

### Q4. 다음 중 pivot 결과를 가장 잘 설명한 것은?
```python
df.groupBy("dept").pivot("gender").avg("salary")
```
① 행: gender, 열: dept
② 행: dept, 열: gender, 값: 평균 salary
③ 행: salary, 열: dept
④ 모든 컬럼이 합쳐진 단일 값

<details><summary>정답</summary>

**②** — index 는 groupBy 키, columns 는 pivot 키, value 는 집계.

</details>

### Q5. 작은 DataFrame 에서 groupBy 가 느린 이유로 가장 흔한 것은?
① 데이터가 한 노드에만 있어서
② `spark.sql.shuffle.partitions` 의 기본값 200 이 너무 크기 때문
③ Spark 가 작은 데이터를 처리할 수 없어서
④ groupBy 는 항상 느리다

<details><summary>정답</summary>

**②** — 작은 데이터에 200개 파티션은 오버헤드. 줄이는 편이 더 빠르다.

</details>
