# S09. Python UDF

> 실습 코드: [`python/spark/spark09_udf.py`](../../python/spark/spark09_udf.py)

## 1. 핵심 개념

**UDF** (User-Defined Function): 내장 함수로 표현하기 어려운 로직을 Python 함수로 등록해 컬럼 단위로 적용.

```python
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

@udf(returnType=StringType())
def email_domain(email):
    return email.split("@", 1)[1] if email and "@" in email else None

df.withColumn("domain", email_domain(col("email")))
```

## 2. UDF 의 비용

```
JVM (Spark)            Python (UDF)
   │                       │
   ├── 직렬화 ─────────────►│
   │   (Pickle)             │
   │                       ├─ 함수 실행
   ◄────────────── 직렬화 ──┤
   │   (역직렬화)           │
```

- 행마다 **JVM ↔ Python 직렬화/역직렬화** 발생
- Catalyst 옵티마이저가 **내부를 못 보므로** 최적화 불가
- 내장 함수 대비 **수십 배 느릴 수 있음**

## 3. 권장 우선순위

```
1. pyspark.sql.functions   (가장 빠름)
        │
        ▼ (없으면)
2. expr() / SQL 표현식
        │
        ▼
3. Pandas UDF (S10)         (벡터화, 중간 빠름)
        │
        ▼ (정말 없으면)
4. Python UDF              (최후의 수단)
```

## 4. UDF 등록 방법 두 가지

### 4.1 데코레이터 (DataFrame API 전용)
```python
@udf(returnType=IntegerType())
def add1(x): return x + 1

df.withColumn("plus", add1(col("v")))
```

### 4.2 SQL 에서도 사용하려면 `register`
```python
spark.udf.register("add1_sql", lambda x: x + 1, IntegerType())
spark.sql("SELECT add1_sql(v) FROM t")
```

## 5. 반환 타입 명시 필수

`returnType` 을 생략하면 기본 `StringType`. 정수를 반환해도 문자열로 캐스팅되니 반드시 지정.

## 6. NULL 처리

```python
@udf(returnType=StringType())
def safe_upper(s):
    if s is None:
        return None  # NULL 입력 → NULL 반환 (Spark 의 일반 동작과 일치)
    return s.upper()
```

## 7. 학습 포인트

- 행이 수억 개 이상이면 UDF 한 번 적용에 분 단위 시간 차이
- UDF 가 단순한 산술/문자열이라면 거의 항상 내장으로 가능
- 속도가 필요하면 **Pandas UDF (S10)** 로 전환 (Arrow 기반 벡터화)
- UDF 안에서 외부 자원(DB, 모델) 접근 시 executor 마다 로드되므로 broadcast 필요

## 8. 연습 문제

### Q1. UDF 가 내장 함수보다 느린 가장 큰 이유는?
① Python 이 느려서
② JVM ↔ Python 직렬화/역직렬화 비용과 옵티마이저 미적용
③ 캐싱이 안 되기 때문
④ 분산 처리가 안 되기 때문

<details><summary>정답</summary>

**②** — 행마다 직렬화 + Catalyst 가 블랙박스로 보아 최적화 못함.

</details>

### Q2. UDF 의 반환 타입을 명시하지 않으면 기본값은?
① IntegerType   ② StringType   ③ DoubleType   ④ Spark 가 자동 추론

<details><summary>정답</summary>

**② StringType** — 명시하지 않으면 모두 문자열로 처리.

</details>

### Q3. SQL 쿼리에서 사용하려면 UDF 를 어떻게 등록해야 하나?
① 데코레이터로만 정의하면 자동 등록
② `spark.udf.register(name, fn, returnType)` 호출
③ `spark.sql.udf` 에 직접 추가
④ 불가능하다

<details><summary>정답</summary>

**②** — SQL 쿼리에서 사용하려면 register 가 필요.

</details>

### Q4. 다음 중 UDF 를 피해야 할 가장 적절한 상황은?
① 외부 ML 모델로 inference 해야 한다
② 단순히 두 컬럼을 더한다
③ 복잡한 비즈니스 규칙이 있다
④ 정규식을 적용한다

<details><summary>정답</summary>

**②** — 단순 산술은 `col("a") + col("b")` 로 가능. 내장이 압도적으로 빠르다.

</details>

### Q5. UDF 보다 빠르고, 배치 단위로 Pandas Series 를 다루는 함수는?
① Standard UDF
② Pandas UDF (Vectorized UDF)
③ Higher-Order Function
④ Python lambda

<details><summary>정답</summary>

**② Pandas UDF** — Apache Arrow 로 묶음 단위 전송, 일반 UDF 보다 10배+ 빠름.

</details>
