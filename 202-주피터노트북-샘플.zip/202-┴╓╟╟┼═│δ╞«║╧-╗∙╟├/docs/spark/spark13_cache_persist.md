# S13. cache / persist — 반복 사용 DataFrame 캐싱

> 실습 코드: [`python/spark/spark13_cache_persist.py`](../../python/spark/spark13_cache_persist.py)

## 1. 핵심 개념

Spark 는 lazy 평가이므로 같은 DataFrame 을 두 번 사용하면 **두 번 다시 계산**한다.
계산 비용이 큰 중간 결과를 메모리/디스크에 보관해 재사용하는 것이 **cache / persist**.

```
df_heavy = df.filter(...).join(...).groupBy(...).agg(...)
df_heavy.count()         # 1회 계산
df_heavy.show()          # 다시 처음부터 계산 (X)
```

→ `df_heavy.cache()` 후 첫 action 에서 메모리에 적재, 이후 재사용.

## 2. cache vs persist

| 메서드 | 저장 레벨 |
|--------|----------|
| `cache()` | `MEMORY_AND_DISK` (DataFrame 기본) — 메모리 부족 시 디스크 |
| `persist()` | StorageLevel 직접 지정 |

## 3. StorageLevel 종류

| 레벨 | 메모리 | 디스크 | 직렬화 | 복제 |
|------|--------|--------|--------|------|
| `MEMORY_ONLY` | ✓ | – | – | 1 |
| `MEMORY_AND_DISK` | ✓ | ✓ (보조) | – | 1 |
| `MEMORY_ONLY_SER` | ✓ | – | ✓ | 1 |
| `MEMORY_AND_DISK_SER` | ✓ | ✓ | ✓ | 1 |
| `DISK_ONLY` | – | ✓ | – | 1 |
| `*_2` | … | … | … | **2** (장애 대비) |

DataFrame 의 `cache()` 는 `MEMORY_AND_DISK` (직렬화 형태). RDD 의 `cache()` 는 `MEMORY_ONLY`.

## 4. 사용 절차

```python
from pyspark import StorageLevel

df.cache()                              # 메모리+디스크
# 또는
df.persist(StorageLevel.MEMORY_ONLY)    # 메모리만
df.count()                              # 첫 action — 이때 적재됨

# ... 여러 번 재사용 ...

df.unpersist()                          # 끝나면 해제
```

⚠️ **`cache()` 만 호출하면 적재되지 않는다** — `count()` 등 action 이 한 번 일어나야 실제 캐시된다.

## 5. 캐시 전략

| 상황 | 권장 |
|------|------|
| 같은 DataFrame 을 여러 액션에서 사용 | `cache` 효과 큼 |
| 한 번만 쓰는 DataFrame | 캐시 불필요 |
| 메모리가 작음 | `MEMORY_AND_DISK_SER` 또는 `DISK_ONLY` |
| 셔플 결과를 보존하고 싶다 | `checkpoint` 도 고려 |

## 6. cache vs checkpoint

| 항목 | cache | checkpoint |
|------|-------|-----------|
| 저장 위치 | 메모리/디스크 (executor) | 영구 디스크 (HDFS/S3) |
| Lineage | 보존 | **자름** (장애 복구 가속) |
| 사용 시점 | 반복 사용 | 긴 lineage 절단 |

## 7. 학습 포인트

- `cache()` 는 lazy — action 으로 트리거 필요
- 끝나면 반드시 `unpersist()` (메모리 누수 방지)
- 메모리 압박 시 `MEMORY_AND_DISK_SER` 가 좋음
- Spark UI > Storage 탭에서 캐시 상태 확인 가능

## 8. 연습 문제

### Q1. `df.cache()` 만 호출하면 즉시 캐시되는가?
① 즉시 메모리에 적재된다
② Lazy 평가 — action 호출 시 적재
③ 자동으로 disk 에 저장된다
④ 호출 자체가 에러를 낸다

<details><summary>정답</summary>

**②** — `cache()` 는 캐시 마킹만. 첫 action 에서 적재.

</details>

### Q2. DataFrame 의 `cache()` 가 사용하는 기본 StorageLevel 은?
① MEMORY_ONLY
② MEMORY_AND_DISK
③ DISK_ONLY
④ MEMORY_ONLY_SER

<details><summary>정답</summary>

**② MEMORY_AND_DISK** — RDD 의 cache 와 다르다는 점에 주의 (RDD 는 MEMORY_ONLY).

</details>

### Q3. 캐시 해제는?
① `df.uncache()`   ② `df.unpersist()`   ③ `df.release()`   ④ `df.dispose()`

<details><summary>정답</summary>

**② `unpersist()`**

</details>

### Q4. 매우 긴 lineage 를 잘라서 장애 복구 시간을 줄이려면?
① cache   ② checkpoint   ③ persist(DISK_ONLY)   ④ repartition

<details><summary>정답</summary>

**② checkpoint** — HDFS/S3 등 영구 저장 + lineage 절단.

</details>

### Q5. 메모리가 부족한데도 캐시하고 싶을 때 가장 적절한 레벨은?
① `MEMORY_ONLY`   ② `MEMORY_AND_DISK_SER`   ③ `DISK_ONLY`   ④ `OFF_HEAP`

<details><summary>정답</summary>

**②** — 직렬화하여 공간을 줄이고, 부족 시 디스크로 spill. 운영 환경에서 자주 쓰는 옵션.

</details>
