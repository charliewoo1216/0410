# PySpark 학습 노트 색인

PySpark 핵심 개념과 API 를 정리한 학습 노트.
각 문서는 동일한 번호의 실습 코드(`python/spark/sparkNN_*.py`)와 1:1 매칭된다.

## 📚 학습 노트

### 1. 기초 (S01~S05)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| S01 | [SparkSession 시작·종료](./spark01_session_init.md) | 진입점, builder, master URL |
| S02 | [DataFrame 생성](./spark02_create_df.md) | 4가지 생성 방법, StructType |
| S03 | [CSV 읽기](./spark03_csv_read.md) | header/inferSchema, mode 옵션 |
| S04 | [select / filter / where](./spark04_select_filter.md) | col 표현식, immutability |
| S05 | [withColumn / when / expr](./spark05_withcolumn.md) | 파생 컬럼, CASE WHEN |

### 2. 집계·조인·윈도우 (S06~S08)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| S06 | [groupBy + agg](./spark06_groupby_agg.md) | 다중 집계, pivot, shuffle.partitions |
| S07 | [Join](./spark07_join.md) | inner/left/anti, broadcast, skew |
| S08 | [Window 함수](./spark08_window_function.md) | rank/dense_rank/lag/lead, frame |

### 3. UDF / SQL (S09~S11)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| S09 | [Python UDF](./spark09_udf.md) | 직렬화 비용, 우선순위 |
| S10 | [Pandas UDF](./spark10_pandas_udf.md) | Arrow, 4가지 유형 |
| S11 | [Spark SQL](./spark11_spark_sql.md) | TempView, Global TempView, hint |

### 4. 성능 (S12~S14)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| S12 | [Partition / Repartition](./spark12_partition_repartition.md) | repartition vs coalesce |
| S13 | [Cache / Persist](./spark13_cache_persist.md) | StorageLevel, checkpoint |
| S14 | [Explain Plan](./spark14_explain_plan.md) | 4단계 plan, AQE |

### 5. 스트리밍 (S15)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| S15 | [Structured Streaming](./spark15_streaming_socket.md) | source/sink, output mode, watermark |

## 📖 활용 방법

1. **개념 학습**: `.md` 의 본문(표·다이어그램)으로 핵심 잡기
2. **코드 실습**: `python/spark/sparkNN_*.py` 를 직접 실행
3. **문제 풀이**: 각 노트 마지막의 연습 문제로 자가 점검
4. **약점 보강**: 틀린 문항 → 본문 정독 → 다시 실습

## 🛠 실행 환경

```bash
# Java 17 (Adoptium Temurin) 권장
pip install pyspark==3.5.0 pyarrow findspark
```

```python
from pyspark.sql import SparkSession
spark = (SparkSession.builder
         .appName("learning")
         .master("local[*]")
         .getOrCreate())
```

## 💡 학습 팁

- **lazy evaluation** 을 항상 의식 — `count()`/`show()` 같은 action 이 트리거
- **셔플(Exchange)** 이 가장 큰 성능 비용 → broadcast / partition 키로 회피
- **UDF 보다 내장 함수** — 안 되면 Pandas UDF, 그래도 안 되면 Python UDF
- 같은 데이터를 여러 번 쓸 땐 **`cache()`** + 첫 action 으로 적재
- `.explain("formatted")` 로 plan 확인하는 습관

## 🔗 관련 자료
- 공식 문서: https://spark.apache.org/docs/latest/api/python/
- 학습 노트는 시험용이 아니라 **실무 응용** 관점으로 작성됨
- 데이터레이크 응용은 [`docs/lakehouse/`](../lakehouse/README.md)
