# S02. DataFrame 생성

> 실습 코드: [`python/spark/spark02_create_df.py`](../../python/spark/spark02_create_df.py)

## 1. 핵심 개념

**Spark DataFrame** = 분산 환경의 행/열 구조 + **스키마(schema)**.
Pandas DataFrame 과 API 가 비슷하지만 내부적으로는 **lazy evaluation** 으로 동작한다.

## 2. 생성 방법 4가지

### 2.1 리스트 + 컬럼 이름 (스키마 추론)
```python
df = spark.createDataFrame(
    [(1, "Alice", 5500.0), (2, "Bob", 6200.0)],
    schema=["id", "name", "salary"],
)
```

### 2.2 명시적 StructType 스키마
```python
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

schema = StructType([
    StructField("id",   IntegerType(), nullable=False),
    StructField("name", StringType(),  nullable=True),
])
df = spark.createDataFrame([(1, "A")], schema)
```

### 2.3 Pandas DataFrame 변환
```python
import pandas as pd
df = spark.createDataFrame(pd.DataFrame({"x": [1, 2, 3]}))
```

### 2.4 RDD → DataFrame
```python
rdd = spark.sparkContext.parallelize([(1, "A")])
df = rdd.toDF(["id", "name"])
```

## 3. 주요 데이터 타입

| Spark 타입 | Python | SQL |
|-----------|--------|-----|
| IntegerType | int | INT |
| LongType | int | BIGINT |
| DoubleType | float | DOUBLE |
| StringType | str | STRING |
| BooleanType | bool | BOOLEAN |
| DateType | datetime.date | DATE |
| TimestampType | datetime.datetime | TIMESTAMP |
| ArrayType(T) | list | ARRAY<T> |
| MapType(K, V) | dict | MAP<K, V> |
| StructType | tuple/Row | STRUCT |

## 4. 자주 쓰는 메서드

```python
df.printSchema()    # 스키마 출력
df.show(n=5)        # 처음 n 행
df.dtypes           # [(컬럼명, 타입)] 리스트
df.columns          # 컬럼 이름 리스트
df.count()          # 행 개수 (액션 — 셔플 발생 가능)
```

## 5. 학습 포인트

- 스키마 추론은 **샘플링 비용**이 들고 타입을 잘못 잡을 수도 있음 → 운영에서는 명시 권장
- `createDataFrame(pd.DataFrame)` 은 Arrow 활성화로 빠르게 가능 (`spark.sql.execution.arrow.pyspark.enabled=true`)
- `printSchema()` 와 `show()` 가 가장 빈번한 디버깅 도구

## 6. 연습 문제

### Q1. Spark DataFrame 과 Pandas DataFrame 의 가장 큰 차이는?
① Spark 는 행 단위, Pandas 는 컬럼 단위 처리
② Spark 는 분산 처리·lazy evaluation, Pandas 는 단일 머신·즉시 실행
③ Pandas 는 SQL 을 지원하지 않는다
④ Spark 는 스키마가 없고 Pandas 는 있다

<details><summary>정답</summary>

**②** — Spark 는 분산·lazy, Pandas 는 단일 머신·eager.

</details>

### Q2. 다음 코드의 결과는?
```python
df = spark.createDataFrame([(1, "A"), (2, "B")], ["id", "name"])
df.printSchema()
```
① 컬럼 두 개의 스키마가 출력된다
② 데이터가 출력된다
③ 컴파일 에러가 난다
④ 빈 결과가 나온다

<details><summary>정답</summary>

**①** — `printSchema()` 는 컬럼명·타입·nullable 정보를 트리 형태로 출력.

</details>

### Q3. 명시적 StructType 스키마를 사용해야 하는 이유로 가장 적절한 것은?
① 코드가 짧아진다
② 데이터 읽기 속도가 빠르다
③ 추론 비용이 없고 타입 일관성이 보장된다
④ 작은 데이터에 적합하다

<details><summary>정답</summary>

**③** — `inferSchema` 는 한 번 더 데이터를 스캔해야 하고, 잘못된 타입을 잡을 위험이 있다.

</details>

### Q4. Pandas DataFrame 을 Spark DataFrame 으로 빠르게 변환하기 위해 활성화하는 옵션은?
① `spark.sql.shuffle.partitions`
② `spark.sql.execution.arrow.pyspark.enabled`
③ `spark.sql.adaptive.enabled`
④ `spark.serializer`

<details><summary>정답</summary>

**②** — Apache Arrow 를 통해 zero-copy 에 가까운 성능으로 변환.

</details>

### Q5. `df.count()` 는 transformation 인가 action 인가?
① transformation
② action
③ 둘 다 아니다
④ DataFrame 에는 없는 메서드

<details><summary>정답</summary>

**② action** — 실제 계산을 트리거하고 결과(정수)를 반환한다.

</details>
