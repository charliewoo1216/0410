# S04. select / filter / where

> 실습 코드: [`python/spark/spark04_select_filter.py`](../../python/spark/spark04_select_filter.py)

## 1. 핵심 개념

DataFrame 은 **불변(immutable)** — 모든 변환은 새 DataFrame 을 반환한다.

| 연산 | SQL 대응 | 비고 |
|------|---------|------|
| `df.select(...)` | SELECT | 컬럼 선택·계산 |
| `df.filter(...)` / `df.where(...)` | WHERE | 행 필터 (둘은 동일) |
| `df.drop(...)` | – | 컬럼 제거 |
| `df.distinct()` | SELECT DISTINCT | 중복 제거 |
| `df.limit(n)` | LIMIT | 상위 n 행 |

## 2. 컬럼 표현 방법

```python
from pyspark.sql.functions import col
df.select("name")            # 문자열로
df.select(df["name"])         # 인덱싱
df.select(df.name)            # 어트리뷰트
df.select(col("name"))        # F.col() 가장 권장
```

> 컬럼명에 공백·점 등이 있을 때는 `col()` 또는 `df["x.y"]` 만 안전.

## 3. 필터 조건 표현

```python
from pyspark.sql.functions import col
df.filter(col("salary") > 5000)
df.filter((col("dept") == "dev") & (col("salary") >= 6000))   # AND
df.filter((col("dept") == "dev") | (col("dept") == "mkt"))    # OR
df.filter(~col("dept").isin(["mkt"]))                         # NOT
df.filter("salary > 5000 AND dept != 'mkt'")                  # SQL 문자열도 가능
df.filter(col("name").like("A%"))                             # LIKE
df.filter(col("salary").isNull())                             # NULL 체크
df.filter(col("salary").between(5000, 7000))                  # BETWEEN
```

⚠️ `&`, `|` 는 비트 연산자라 **반드시 괄호**로 감싸야 한다.

## 4. select 에서 표현식 사용

```python
from pyspark.sql.functions import col, lit, expr

df.select(
    col("name"),
    (col("salary") * 1.1).alias("new_salary"),
    lit("KRW").alias("currency"),
    expr("salary + 100 AS bonus_salary"),
)
```

## 5. 학습 포인트

- `filter` 와 `where` 는 100% 동일 — 취향껏 선택
- `&`, `|` 사용 시 **괄호 필수** — 흔한 함정
- 새 DataFrame 을 변수에 할당하지 않으면 변경 사항이 사라짐
- `select` 는 transformation (lazy)

## 6. 연습 문제

### Q1. 다음 두 코드는 동일한 결과를 낼까?
```python
df.filter(col("salary") > 5000)
df.where(col("salary") > 5000)
```
① 다르다
② 동일하다
③ 첫 번째만 동작한다
④ 두 번째만 동작한다

<details><summary>정답</summary>

**②** — `filter` 와 `where` 는 별칭(alias) 관계로 완전히 동일.

</details>

### Q2. 다음 코드에서 잘못된 부분은?
```python
df.filter(col("dept") == "dev" & col("salary") >= 5000)
```
① `==` 가 잘못됨
② 비교 연산자 우선순위 때문에 괄호가 필요함
③ `col` 함수 호출이 누락됨
④ 정상 코드이다

<details><summary>정답</summary>

**②** — `&` 가 비교보다 우선순위가 높아 의도와 다르게 평가됨.
올바른 코드: `(col("dept") == "dev") & (col("salary") >= 5000)`

</details>

### Q3. 컬럼 이름에 공백이나 점이 포함된 경우 가장 안전한 컬럼 참조 방법은?
① `df.col_name`
② `df["col name"]` 또는 `col("col name")`
③ 모든 방법이 동일하게 동작한다
④ 컬럼 이름을 미리 변경해야만 참조 가능

<details><summary>정답</summary>

**②** — 어트리뷰트 접근(`df.col`)은 특수문자 포함 시 동작하지 않음.

</details>

### Q4. DataFrame 이 immutable 이라는 것은 무슨 의미인가?
① 한 번 만들면 절대 가비지컬렉션되지 않는다
② 변환 메서드는 원본을 바꾸지 않고 새 DataFrame 을 반환한다
③ 데이터 자체를 수정할 수 없다는 의미일 뿐이다
④ Pandas 와 동일하게 in-place 수정도 가능하다

<details><summary>정답</summary>

**②** — 모든 transformation 은 새 DataFrame 을 반환. 원본은 변하지 않는다.

</details>

### Q5. `df.select(col("name"), col("salary") * 1.1)` 의 동작은?
① 즉시 새 컬럼이 계산되어 디스크에 저장된다
② transformation 만 정의되고 action 시 실행된다
③ 에러가 발생한다 (alias 필요)
④ 원본 df 가 변경된다

<details><summary>정답</summary>

**②** — Lazy evaluation. action 호출 시 실행. (alias 가 없어도 동작은 하나 컬럼명이 자동 생성됨)

</details>
