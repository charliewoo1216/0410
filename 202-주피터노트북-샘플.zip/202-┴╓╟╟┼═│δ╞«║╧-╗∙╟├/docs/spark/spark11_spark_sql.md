# S11. Spark SQL — DataFrame ↔ TempView ↔ SQL

> 실습 코드: [`python/spark/spark11_spark_sql.py`](../../python/spark/spark11_spark_sql.py)

## 1. 핵심 개념

DataFrame API 와 SQL 은 **동일한 Catalyst 옵티마이저**를 통과해 같은 물리 계획이 된다.
취향·가독성에 따라 자유롭게 섞어 쓸 수 있다.

```python
df.createOrReplaceTempView("emp")
spark.sql("SELECT dept, AVG(salary) FROM emp GROUP BY dept").show()
```

## 2. View 종류

| 종류 | 생명주기 | 사용 |
|------|---------|------|
| **Temp View** | 현재 SparkSession | `createOrReplaceTempView` |
| **Global Temp View** | Spark 애플리케이션 전체 (다른 세션 공유) | `createOrReplaceGlobalTempView` |
| **Persistent Table** | 영구 (Hive/Catalog) | `df.write.saveAsTable("name")` |

> Global Temp View 는 `global_temp.view_name` 으로 접근.

## 3. SQL 에서만 가능한 것

- 복잡한 CTE (`WITH x AS (...)`)
- 가독성 좋은 윈도우 함수 표현
- 여러 hint 지정 (`/*+ BROADCAST(b) */`)
- 사용자가 SQL 만 익숙한 경우의 협업

## 4. DataFrame API 에서만 자연스러운 것

- 조건부 체이닝 (`if cond: df = df.filter(...)`)
- 함수 리팩터링 (DataFrame 을 인자로 받는 함수)
- 파이썬 변수와의 통합

## 5. Catalog API

```python
spark.catalog.listTables()                  # 등록된 테이블 목록
spark.catalog.listColumns("emp")            # 컬럼 정보
spark.catalog.dropTempView("emp")           # 뷰 삭제
spark.catalog.cacheTable("emp")             # 메모리에 캐시
```

## 6. 자주 쓰는 SQL 패턴

```sql
-- CTE + 윈도우
WITH ranked AS (
    SELECT *, RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS r
    FROM emp
)
SELECT * FROM ranked WHERE r = 1;

-- BROADCAST 힌트
SELECT /*+ BROADCAST(d) */ e.*, d.dept_name
FROM employees e JOIN dept d ON e.dept_id = d.id;

-- LATERAL VIEW EXPLODE (배열 펼치기)
SELECT id, t
FROM events LATERAL VIEW EXPLODE(tags) AS t;
```

## 7. 학습 포인트

- DataFrame API 와 SQL 은 **성능 동일** — 옵티마이저 같음
- `createOrReplaceTempView` 는 자주 사용 (멱등성)
- SQL 에서 **분포가 한쪽으로 치우친 조인**일 땐 hint 로 broadcast 강제
- 등록된 영구 테이블이 충돌하면 `DROP TABLE IF EXISTS` 로 정리

## 8. 연습 문제

### Q1. DataFrame API 와 Spark SQL 의 성능 차이는?
① DataFrame API 가 더 빠르다
② SQL 이 더 빠르다
③ 두 방식 모두 같은 옵티마이저를 통과해 동일하다
④ DataFrame 은 분산되지만 SQL 은 단일 노드에서 실행된다

<details><summary>정답</summary>

**③** — Catalyst 옵티마이저가 둘을 같은 논리/물리 계획으로 변환.

</details>

### Q2. Temp View 와 Global Temp View 의 차이는?
① Global 은 영구 저장된다
② Temp 는 현재 세션에서만, Global 은 SparkApplication 전체에서 접근 가능
③ Temp 만 SQL 에서 조회 가능
④ Global 은 캐싱이 된다

<details><summary>정답</summary>

**②** — Global Temp View 는 `global_temp` 데이터베이스 아래 등록되어 같은 애플리케이션 내 다른 세션에서도 접근 가능.

</details>

### Q3. SQL 에서 작은 테이블 d 를 broadcast 시키는 hint 는?
① `/*+ JOIN(d) */`
② `/*+ BROADCAST(d) */`
③ `/*+ SHUFFLE(d) */`
④ `/*+ COALESCE(d) */`

<details><summary>정답</summary>

**②** — `SELECT /*+ BROADCAST(d) */ ...` 형태로 사용.

</details>

### Q4. 다음 코드를 두 번 실행하면?
```python
df.createOrReplaceTempView("emp")
df.createOrReplaceTempView("emp")
```
① 두 번째 호출에서 에러
② 두 번째 호출이 무시됨
③ 두 번 모두 성공 (멱등)
④ 두 개의 view 가 동시에 존재

<details><summary>정답</summary>

**③** — `OrReplace` 가 붙어 있으므로 동일 이름이 있어도 덮어쓰며 성공.

</details>

### Q5. `createTempView` 와 `createOrReplaceTempView` 의 차이는?
① 동일하다
② 전자는 동일 이름 view 가 있으면 에러, 후자는 덮어씀
③ 후자는 영구 저장
④ 전자는 캐싱이 자동

<details><summary>정답</summary>

**②** — `createTempView` 는 이름 충돌 시 `AnalysisException`.

</details>
