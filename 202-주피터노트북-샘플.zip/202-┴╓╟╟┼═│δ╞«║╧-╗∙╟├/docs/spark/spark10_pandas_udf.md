# S10. Pandas UDF (벡터화 UDF)

> 실습 코드: [`python/spark/spark10_pandas_udf.py`](../../python/spark/spark10_pandas_udf.py)

## 1. 핵심 개념

**Pandas UDF** = Apache Arrow 기반의 **배치 단위 UDF**. 일반 UDF 가 행 단위 직렬화인 반면, Pandas UDF 는 묶음을 한 번에 Pandas Series 로 받아 처리한다.

```
일반 UDF:  [row1] → py → [row1] [row2] → py → [row2] ...   (행 단위 왕복)
Pandas UDF: [row1, row2, ..., rowN] → py(Series) → [...]    (배치 단위 1번)
```

→ 직렬화 오버헤드를 N분의 1 로 감소.

## 2. 사용 예

```python
import pandas as pd
from pyspark.sql.functions import pandas_udf, col

@pandas_udf("double")
def normalize(s: pd.Series) -> pd.Series:
    return (s - s.mean()) / s.std()

df.withColumn("z", normalize(col("value")))
```

핵심 차이: 함수 시그니처가 `pd.Series → pd.Series`.

## 3. Pandas UDF 의 4가지 유형

| 유형 | 시그니처 | 용도 |
|------|---------|------|
| **Series → Series** | `(s: Series) -> Series` | 동일한 행 수, 컬럼 변환 |
| **Iterator of Series → Iterator of Series** | `(it: Iterator[Series]) -> Iterator[Series]` | 큰 메모리, 모델 로드 1회 |
| **Series → scalar** | `(s: Series) -> float` | 그룹 내 집계 |
| **DataFrame → DataFrame** | `(pdf: DataFrame) -> DataFrame` | 그룹별 일괄 처리 |

### 3.1 Iterator 유형 — 모델 로드 비용 절감
```python
from typing import Iterator

@pandas_udf("double")
def predict(it: Iterator[pd.Series]) -> Iterator[pd.Series]:
    model = load_model()                # 한 번만 로드
    for s in it:
        yield pd.Series(model.predict(s.values))
```

### 3.2 GroupedData 와 결합 — `applyInPandas`
```python
def normalize_group(pdf: pd.DataFrame) -> pd.DataFrame:
    pdf["z"] = (pdf["v"] - pdf["v"].mean()) / pdf["v"].std()
    return pdf

df.groupBy("dept").applyInPandas(
    normalize_group,
    schema="dept string, v double, z double"
)
```

## 4. 활성화 옵션

```python
spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
```
대부분의 환경에서 기본 활성화. 비활성 상태면 일반 UDF 와 동일한 속도가 됨.

## 5. 학습 포인트

- 단순 변환은 항상 **내장 함수 → expr → Pandas UDF → Python UDF** 순으로 시도
- 모델 inference, 통계 계산 등 무거운 연산에 Pandas UDF 가 적합
- **타입 힌트가 필수** (Spark 가 시그니처로 유형 결정)
- batch size 조절: `spark.sql.execution.arrow.maxRecordsPerBatch` (기본 10000)

## 6. 연습 문제

### Q1. Pandas UDF 가 일반 UDF 보다 빠른 핵심 이유는?
① Python 인터프리터를 사용하지 않아서
② Arrow 로 배치 단위 직렬화하여 왕복 비용을 줄이기 때문
③ JVM 위에서 직접 실행되어서
④ 자동으로 캐싱되어서

<details><summary>정답</summary>

**②** — Arrow 의 zero-copy 형식으로 배치 단위 전송. 직렬화 비용이 행 수가 아닌 배치 수에 비례.

</details>

### Q2. 다음 함수의 Pandas UDF 유형은?
```python
@pandas_udf("double")
def f(s: pd.Series) -> pd.Series:
    return s * 2
```
① Series → scalar
② Series → Series
③ DataFrame → DataFrame
④ Iterator → Iterator

<details><summary>정답</summary>

**②** — 입력·출력 모두 Series. 동일한 행 수.

</details>

### Q3. ML 모델을 매 배치마다 로드하지 않고 한 번만 로드하려면?
① Series → Series 유형
② Iterator of Series → Iterator of Series 유형
③ Series → scalar 유형
④ 일반 UDF 사용

<details><summary>정답</summary>

**②** — 함수 호출이 한 executor 에서 한 번이고, 그 안에서 yield 로 배치를 처리.

</details>

### Q4. groupBy 후 그룹별로 DataFrame 단위 처리를 하려면?
① `groupBy(...).agg(pandas_udf...)`
② `groupBy(...).applyInPandas(fn, schema=...)`
③ `groupBy(...).pandas()`
④ `groupBy(...).map(fn)`

<details><summary>정답</summary>

**② `applyInPandas`** — Spark 3.0 이상. 출력 schema 를 명시해야 한다.

</details>

### Q5. Pandas UDF 가 일반 UDF 와 동일한 속도가 되어버리는 흔한 원인은?
① 데이터가 작아서
② Arrow 가 비활성화되었거나 PyArrow 가 설치되지 않은 경우
③ Java 17 사용
④ 항상 동일한 속도이다

<details><summary>정답</summary>

**②** — `spark.sql.execution.arrow.pyspark.enabled=false` 또는 PyArrow 미설치 시 일반 직렬화 fallback.

</details>
