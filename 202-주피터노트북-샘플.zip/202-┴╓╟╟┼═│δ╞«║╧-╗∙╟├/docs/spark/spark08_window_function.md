# S08. 윈도우 함수 — rank / lag / lead

> 실습 코드: [`python/spark/spark08_window_function.py`](../../python/spark/spark08_window_function.py)

## 1. 핵심 개념

**윈도우 함수**: 행을 묶지 않고(=`groupBy` 와 달리), 각 행에 대해 "관련 행 그룹(window)" 의 계산값을 추가한다.

```python
from pyspark.sql.window import Window
from pyspark.sql.functions import col, rank, lag, sum as ssum

w = Window.partitionBy("dept").orderBy(col("salary").desc())
df.withColumn("rank", rank().over(w))
```

## 2. Window 정의 3요소

| 메서드 | 역할 | SQL |
|--------|------|-----|
| `partitionBy(...)` | 그룹 분할 | `PARTITION BY` |
| `orderBy(...)` | 정렬 | `ORDER BY` |
| `rowsBetween(s, e)` / `rangeBetween` | 프레임 | `ROWS BETWEEN ... AND ...` |

## 3. 윈도우 함수 분류

### 3.1 Ranking
| 함수 | 동작 | 동점 처리 |
|------|------|----------|
| `row_number()` | 1, 2, 3, 4 | 동점도 다른 번호 |
| `rank()` | 1, 1, 3, 4 | 동점은 같은 번호, **다음 번호 건너뜀** |
| `dense_rank()` | 1, 1, 2, 3 | 동점은 같은 번호, 다음 번호 안 건너뜀 |
| `ntile(n)` | n분위 분할 | – |

### 3.2 Analytic
| 함수 | 동작 |
|------|------|
| `lag(col, n)` | n행 앞(이전) 값 |
| `lead(col, n)` | n행 뒤(이후) 값 |
| `first_value(col)` | 윈도우 첫 값 |
| `last_value(col)` | 윈도우 마지막 값 |

### 3.3 Aggregate (window 위에서)
`sum`, `avg`, `count`, `max`, `min` 등을 `.over(w)` 로 사용 → 누적합·이동평균 등.

```python
running = Window.partitionBy("dept").orderBy("ts") \
                .rowsBetween(Window.unboundedPreceding, Window.currentRow)
df.withColumn("cum_sum", ssum("amount").over(running))
```

## 4. 프레임(Frame) 종류

| 종류 | 의미 |
|------|------|
| `Window.unboundedPreceding` | 시작부터 |
| `Window.currentRow` | 현재 행 |
| `Window.unboundedFollowing` | 끝까지 |
| 정수 (예: -3, +3) | 상대적 행 수 |

```python
# 직전 3행 + 현재 + 이후 3행 의 평균 (이동평균)
w = Window.orderBy("ts").rowsBetween(-3, 3)
df.withColumn("ma7", avg("value").over(w))
```

## 5. 학습 포인트

- `partitionBy` 가 없으면 **단일 파티션** 으로 모이므로(주의 메시지 발생) 큰 데이터에서는 위험
- ranking 함수는 항상 `orderBy` 가 필요
- `rank` vs `dense_rank` 의 차이를 정확히 외워둘 것
- 윈도우 함수도 셔플을 유발 (partitionBy 키 기준)

## 6. 연습 문제

### Q1. 다음 점수에 대해 `rank()`, `dense_rank()`, `row_number()` 의 결과를 비교하라.
점수: [90, 90, 85, 80]

<details><summary>정답</summary>

| 점수 | row_number | rank | dense_rank |
|------|-----------|------|------------|
| 90 | 1 | 1 | 1 |
| 90 | 2 | 1 | 1 |
| 85 | 3 | 3 | 2 |
| 80 | 4 | 4 | 3 |

- `row_number`: 동점도 별도 번호
- `rank`: 동점은 같지만 다음 순위가 건너뜀
- `dense_rank`: 동점은 같고 다음 순위가 안 건너뜀

</details>

### Q2. 각 부서 내 연봉 1위 직원만 추출하려면?
① `groupBy("dept").max("salary")`
② `Window.partitionBy("dept").orderBy("salary".desc())` + `rank()` 로 1위만 필터
③ `df.distinct()`
④ `orderBy("salary").limit(1)`

<details><summary>정답</summary>

**②** — 윈도우 + rank=1 필터. ① 은 행이 줄어들고 다른 컬럼이 사라진다.

</details>

### Q3. 직전 행의 값을 가져오는 함수는?
① `prev`   ② `lag`   ③ `lead`   ④ `before`

<details><summary>정답</summary>

**② `lag`** — 직전(앞) 행 값. `lead` 는 다음(뒤) 행.

</details>

### Q4. 누적 합(running total) 을 구하기 위한 윈도우 정의로 옳은 것은?
① `Window.partitionBy("g").orderBy("t").rowsBetween(0, 0)`
② `Window.partitionBy("g").orderBy("t").rowsBetween(-1, 1)`
③ `Window.partitionBy("g").orderBy("t").rowsBetween(Window.unboundedPreceding, Window.currentRow)`
④ `Window.partitionBy("g")` (정렬·프레임 없음)

<details><summary>정답</summary>

**③** — 시작부터 현재 행까지 누적.

</details>

### Q5. 윈도우 함수에서 `partitionBy` 를 생략하면?
① 자동으로 모든 컬럼이 partition 키가 된다
② 모든 데이터가 단일 파티션으로 모이며 경고가 발생한다
③ Spark 가 자동으로 효율적인 파티션을 정한다
④ 에러가 발생한다

<details><summary>정답</summary>

**②** — 단일 노드로 데이터가 몰리므로 큰 데이터에선 위험.
`WARN WindowExec: No Partition Defined for Window operation!` 메시지가 뜬다.

</details>
