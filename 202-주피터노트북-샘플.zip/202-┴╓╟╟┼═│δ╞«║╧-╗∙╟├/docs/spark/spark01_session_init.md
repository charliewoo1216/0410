# S01. SparkSession 시작·종료

> 실습 코드: [`python/spark/spark01_session_init.py`](../../python/spark/spark01_session_init.py)

## 1. 핵심 개념

**SparkSession** 은 PySpark 의 **단일 진입점(entry point)**.
DataFrame · SQL · Catalog · Streaming 등 모든 기능을 한 객체로 다룬다.

```
┌──────────────────────────────────────────┐
│            SparkSession                  │
│  ┌──────────┐ ┌────────┐ ┌────────────┐  │
│  │SparkContext│ │SQLCtx │ │HiveCatalog │  │
│  └──────────┘ └────────┘ └────────────┘  │
└──────────────────────────────────────────┘
              │
              ▼
       Driver  ◀──────►  Executor 1, 2, …, N
```

## 2. 빌더 패턴

```python
spark = (SparkSession.builder
         .appName("learning")        # Web UI 에 표시되는 앱 이름
         .master("local[*]")         # 클러스터 매니저
         .config("k", "v")           # 임의 설정 추가
         .getOrCreate())             # 이미 있으면 재사용
```

### `master` URL 의 의미

| URL | 의미 |
|-----|------|
| `local` | 단일 스레드 |
| `local[4]` | 4개 코어 사용 |
| `local[*]` | 모든 코어 사용 |
| `spark://host:7077` | Standalone 클러스터 |
| `yarn` | YARN |
| `k8s://...` | Kubernetes |

## 3. SparkSession vs SparkContext

| 항목 | SparkContext (구) | SparkSession (신, 2.0+) |
|------|------------------|------------------------|
| 역할 | RDD 진입점 | DataFrame/SQL 통합 진입점 |
| 사용 | `sc = SparkContext(...)` | `spark = SparkSession.builder...` |
| 내장 | – | `spark.sparkContext` 로 접근 가능 |

## 4. 학습 포인트

- `getOrCreate()` 는 **싱글턴 패턴** — 동일 JVM 에 두 개를 만들지 않음
- 종료는 **반드시** `spark.stop()` (또는 `with` 컨텍스트)
- 노트북에서 자주 빠뜨리는 함정: 셀을 다시 실행해도 새 세션이 안 만들어짐
- Java 17 환경이라면 `--add-opens` JVM 옵션 필요할 수 있음

## 5. 연습 문제

### Q1. `master("local[*]")` 의 의미는?
① 단일 스레드 실행
② 4개 코어로 실행
③ 사용 가능한 모든 코어로 실행
④ 원격 클러스터에 접속

<details><summary>정답</summary>

**③** — `*` 는 호스트의 모든 가용 코어를 의미한다.

</details>

### Q2. SparkSession 과 SparkContext 의 관계로 옳은 것은?
① 둘은 완전히 별개의 객체이다
② SparkSession 은 SparkContext 를 내부에 포함하고 있다
③ SparkContext 가 SparkSession 보다 새로운 API 이다
④ SparkSession 은 RDD 만 다룬다

<details><summary>정답</summary>

**②** — `spark.sparkContext` 로 접근 가능. SparkSession 이 통합 진입점이며 더 새로운 API.

</details>

### Q3. 다음 코드의 동작으로 올바른 것은?
```python
spark1 = SparkSession.builder.appName("a").master("local[*]").getOrCreate()
spark2 = SparkSession.builder.appName("b").master("local[2]").getOrCreate()
```
① 두 개의 독립된 세션이 생성된다
② `spark2` 는 새 설정으로 덮어씌워진다
③ `spark2` 는 `spark1` 과 동일한 세션을 반환한다 (appName/master 무시)
④ 두 번째 호출은 에러가 난다

<details><summary>정답</summary>

**③** — `getOrCreate()` 는 기존 세션이 있으면 그것을 반환. 새 설정은 무시된다.
설정을 바꾸려면 먼저 `spark1.stop()` 후 새로 빌드해야 한다.

</details>

### Q4. SparkSession 을 종료하는 가장 권장되는 방법은?
① 프로그램이 그냥 끝나길 기다린다
② `spark.close()` 호출
③ `spark.stop()` 호출
④ JVM 을 강제 종료

<details><summary>정답</summary>

**③ `spark.stop()`** — 자원·포트를 정리해 다음 실행에서 충돌하지 않도록 함.

</details>
