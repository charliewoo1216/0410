# S05. 파생 컬럼 — withColumn / when / expr

> 실습 코드: [`python/spark/spark05_withcolumn.py`](../../python/spark/spark05_withcolumn.py)

## 1. 핵심 개념

| 메서드 | 용도 |
|--------|------|
| `withColumn(name, expr)` | 새 컬럼 추가 또는 기존 컬럼 덮어쓰기 |
| `withColumnRenamed(old, new)` | 컬럼 이름 변경 |
| `drop(*cols)` | 컬럼 제거 |
| `selectExpr("...")` | SQL 표현식으로 select |

```python
from pyspark.sql.functions import col, when, expr, lit

df = (df
      .withColumn("salary_k", col("salary") / 1000)
      .withColumn("doubled",  col("salary") * 2)
      .withColumn("country",  lit("KR")))
```

## 2. when().otherwise() — 조건부 컬럼

```python
df.withColumn(
    "grade",
    when(col("salary") >= 7000, "A")
    .when(col("salary") >= 5000, "B")
    .otherwise("C")
)
```

SQL 의 `CASE WHEN ... THEN ... ELSE ... END` 와 1:1 대응.

## 3. expr() — 문자열 SQL 표현식

```python
df.withColumn("note", expr("CASE WHEN salary >= 7000 THEN '우수' ELSE '평균' END"))
df.selectExpr("name", "salary * 1.1 AS new_salary")
```

`expr()` 은 컬럼처럼 어디서든 사용 가능. 가독성이 좋다면 SQL 그대로 적는 것도 OK.

## 4. 자주 쓰는 함수 (`pyspark.sql.functions`)

| 함수 | 용도 |
|------|------|
| `lit(v)` | 상수 컬럼 |
| `col("x")` | 컬럼 참조 |
| `when` / `otherwise` | 조건 |
| `cast("type")` | 타입 변환 |
| `concat`, `concat_ws` | 문자열 연결 |
| `upper`, `lower`, `trim` | 문자열 처리 |
| `to_date`, `to_timestamp` | 날짜 파싱 |
| `coalesce` | 첫 NULL 아닌 값 |
| `round`, `floor`, `ceil` | 수치 |

## 5. 성능 팁

- 같은 변환을 반복하면 **`select` 에 한 번에** 묶는 것이 더 효율적
  ```python
  df.select(col("a"), (col("b") * 2).alias("b2"), (col("c") + 1).alias("c1"))
  # 보다 빠를 수 있음
  df.withColumn("b2", col("b") * 2).withColumn("c1", col("c") + 1)
  ```
- `withColumn` 을 **수십 번 체이닝하면 plan 이 복잡해짐** → 큰 변환은 select 권장
- UDF 보다는 내장 `functions` 우선 (S09 참조)

## 6. 연습 문제

### Q1. 기존 컬럼 `salary` 를 두 배로 덮어쓰는 코드는?
```python
df.withColumn(?)
```
① `"salary_new", col("salary") * 2`
② `"salary", col("salary") * 2`
③ `col("salary"), col("salary") * 2`
④ `"salary", "salary * 2"`

<details><summary>정답</summary>

**②** — 동일한 컬럼명을 주면 덮어쓰기 동작.

</details>

### Q2. SQL 의 `CASE WHEN` 에 해당하는 PySpark API 는?
① `if-elif-else`   ② `when().otherwise()`   ③ `case()`   ④ `match()`

<details><summary>정답</summary>

**② `when().otherwise()`** — `from pyspark.sql.functions import when`.

</details>

### Q3. 모든 행에 상수 컬럼을 추가하려면?
① `df.withColumn("const", "fixed")`
② `df.withColumn("const", col("fixed"))`
③ `df.withColumn("const", lit("fixed"))`
④ `df.add_const("fixed")`

<details><summary>정답</summary>

**③ `lit("fixed")`** — 문자열을 그대로 넘기면 컬럼 이름으로 해석되어 에러.

</details>

### Q4. `withColumn` 에 대한 설명으로 옳지 않은 것은?
① 새 컬럼을 추가할 수 있다
② 기존 컬럼을 덮어쓸 수 있다
③ 원본 DataFrame 을 직접 수정한다
④ 새로운 DataFrame 을 반환한다

<details><summary>정답</summary>

**③** — DataFrame 은 immutable. `withColumn` 도 새 DataFrame 을 반환할 뿐 원본은 그대로.

</details>

### Q5. SQL 문법을 그대로 사용해 새 컬럼을 만들고 싶을 때 가장 적절한 함수는?
① `col`   ② `lit`   ③ `expr`   ④ `cast`

<details><summary>정답</summary>

**③ `expr`** — 문자열 SQL 표현식을 컬럼으로 변환.

</details>
