# S15. Structured Streaming — 단어 카운트

> 실습 코드: [`python/spark/spark15_streaming_socket.py`](../../python/spark/spark15_streaming_socket.py)

## 1. 핵심 개념

**Structured Streaming**: DataFrame API 그대로 무한히 들어오는 스트림을 처리한다.
배치(`spark.read`) 와 스트림(`spark.readStream`) 의 코드가 거의 동일.

```python
lines = spark.readStream.format("socket")...load()
counts = lines.groupBy("word").count()
counts.writeStream.outputMode("complete").format("console").start()
```

## 2. 처리 모델

| 모델 | 설명 |
|------|------|
| **Micro-batch** (기본) | 일정 주기로 작은 배치 처리 (수백 ms ~ 수십 초) |
| **Continuous** | 실험적, ms 단위 latency |

## 3. Source 종류

| Source | 비고 |
|--------|------|
| `socket` | 학습용 (TCP 소켓) |
| `rate` | 자동 발생 (테스트) |
| `kafka` | 가장 흔한 운영 source |
| `file` | 디렉토리 모니터링 |
| `delta` (Delta Lake) | Delta 테이블 변경 추적 |

## 4. Sink 종류 (출력)

| Sink | 비고 |
|------|------|
| `console` | 디버깅 |
| `memory` | 인메모리 테이블 (테스트) |
| `kafka` | 프로듀스 |
| `file` (parquet/csv/json/orc) | 파일 시스템 |
| `delta` | Delta Lake (LH09 참조) |
| `foreach` / `foreachBatch` | 임의 sink (DB 등) |

## 5. Output Mode

| 모드 | 의미 | 사용 가능 sink |
|------|------|----------------|
| `append` | 새로 추가된 행만 | 모든 sink |
| `complete` | 전체 결과 매번 | 집계 결과 (메모리·콘솔) |
| `update` | 변경된 행만 | 일부 sink |

## 6. Trigger

```python
.trigger(processingTime="5 seconds")  # 5초 간격
.trigger(once=True)                    # 한 번만 실행 (마지막 데이터 처리)
.trigger(availableNow=True)            # 현재까지의 모든 데이터를 일괄 처리
.trigger(continuous="1 second")        # 연속 처리
```

## 7. 보장 (Exactly-once)

```
Source → checkpoint → Stateful op → checkpoint → Sink
```
- **체크포인트** 가 모든 진행 상태를 저장 (offset, state)
- Source 가 replay 가능 + Sink 가 idempotent 면 **exactly-once** 보장

```python
.option("checkpointLocation", "/path/to/checkpoint")
```

## 8. Watermark — 늦게 도착하는 데이터 처리

```python
events.withWatermark("event_time", "10 minutes") \
      .groupBy(window("event_time", "1 hour")).count()
```
→ 10분 늦게 도착하는 이벤트까지는 받고, 그보다 더 늦으면 버림.

## 9. 학습 포인트

- 스트리밍 쿼리도 lazy → `start()` 호출 시 시작
- `awaitTermination()` 또는 `awaitTermination(timeout)` 으로 대기
- 운영에서는 반드시 `checkpointLocation` 설정
- Kafka 가 가장 흔한 source/sink

## 10. 연습 문제

### Q1. 배치 API (`spark.read`) 와 스트리밍 API (`spark.readStream`) 의 가장 큰 차이는?
① DataFrame 변환 코드가 다르다
② 데이터 소스만 다르고 변환·집계 코드는 거의 동일
③ 스트리밍은 SQL 사용 불가
④ 배치는 분산되지 않는다

<details><summary>정답</summary>

**②** — DataFrame API 가 통일되어 있어 변환·SQL 거의 그대로 사용.

</details>

### Q2. 집계 결과를 매번 전체 출력하는 output mode 는?
① append   ② complete   ③ update   ④ overwrite

<details><summary>정답</summary>

**② complete** — 매 트리거마다 누적 결과 전체 출력.

</details>

### Q3. exactly-once 보장을 위해 필수적인 옵션은?
① `outputMode`
② `checkpointLocation`
③ `triggerOnce`
④ `numPartitions`

<details><summary>정답</summary>

**② `checkpointLocation`** — offset / state 보존이 되어야 정확히 한 번 보장 가능.

</details>

### Q4. `withWatermark("event_time", "10 minutes")` 의 의미는?
① 10분마다 트리거를 발사
② 10분 이상 늦게 도착하는 이벤트는 폐기
③ 10분간 데이터를 버퍼링
④ 결과를 10분간 캐싱

<details><summary>정답</summary>

**②** — watermark 보다 더 늦은 이벤트는 stale 로 간주하고 폐기. State 메모리 유지를 위해 필수.

</details>

### Q5. 다음 trigger 중 "현재까지의 모든 미처리 데이터를 일괄 처리하고 종료"하는 것은?
① `processingTime="0"`
② `once=True`
③ `availableNow=True`
④ `continuous="1 second"`

<details><summary>정답</summary>

**③ `availableNow=True`** — 현재 lag 만큼을 일괄 처리하고 종료. ETL 배치형 사용에 적합.
(`once=True` 도 비슷하나 한 번만 처리하고 끝남)

</details>
