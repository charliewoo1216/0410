# S07. Join — inner / left / broadcast

> 실습 코드: [`python/spark/spark07_join.py`](../../python/spark/spark07_join.py)

## 1. 핵심 개념

```python
df1.join(df2, on="key", how="inner")
df1.join(df2, df1.id == df2.user_id, "left")
```

| `how` | 의미 |
|-------|------|
| `inner` (기본) | 양쪽 모두 매칭되는 행 |
| `left` (left_outer) | 왼쪽 전체 + 매칭되는 오른쪽 |
| `right` | 오른쪽 전체 + 매칭되는 왼쪽 |
| `outer` (full) | 양쪽 모두 |
| `left_semi` | 왼쪽에서 오른쪽과 매칭되는 행만 (오른쪽 컬럼은 미포함) |
| `left_anti` | 왼쪽에서 오른쪽과 매칭 **안 되는** 행 |
| `cross` | 카르테시안 곱 |

## 2. 조인 전략 (Spark 가 자동 선택)

| 전략 | 조건 | 동작 |
|------|------|------|
| **Broadcast Hash Join** | 한쪽이 작음 (~10MB 이하) | 작은 쪽을 모든 executor 로 복제 → **셔플 없음** |
| **Sort Merge Join** | 양쪽 큼 | 양쪽을 키로 정렬·병합 |
| **Shuffle Hash Join** | 일부 조건 | 키로 셔플 후 해시 조인 |

`spark.sql.autoBroadcastJoinThreshold` (기본 10MB) 이하인 테이블은 자동 broadcast.

## 3. broadcast() 명시 사용

```python
from pyspark.sql.functions import broadcast
employees.join(broadcast(depts), "dept_code", "inner")
```

→ Spark 가 자동 감지하지 못하는 경우 강제로 broadcast 시킨다.
조인 키가 한쪽으로 치우쳐(skew) 있으면 broadcast 가 큰 도움.

## 4. Skew Join 문제

특정 키 하나에 데이터가 몰리면(예: 90% 가 user_id=NULL) 한 executor 만 일을 함.

해결 방법:
- AQE (Adaptive Query Execution) `spark.sql.adaptive.enabled=true` 활성화
- Salting: skew 키에 무작위 접미사 추가 후 조인
- Broadcast (작은 테이블이 있을 때)

## 5. 자기 조인(Self join) 시 컬럼 모호성

```python
df.join(df, df.id == df.parent_id)   # 모호한 컬럼 에러
# → alias 로 구분
a, b = df.alias("a"), df.alias("b")
a.join(b, col("a.id") == col("b.parent_id"))
```

## 6. 학습 포인트

- 가능하면 **broadcast join** 으로 셔플을 피해라
- 조인 키 컬럼명이 양쪽 같으면 `on="key"` (문자열) — 자동으로 한 컬럼만 남음
- 다른 이름이면 `df1.col1 == df2.col2` 로 표현 — 두 컬럼 모두 결과에 남음
- left_anti / left_semi 는 EXISTS / NOT EXISTS 에 대응

## 7. 연습 문제

### Q1. 한쪽 테이블이 매우 작을 때(예: 차원 테이블) 가장 적절한 조인 전략은?
① Sort Merge Join   ② Broadcast Join   ③ Shuffle Hash Join   ④ Cross Join

<details><summary>정답</summary>

**② Broadcast Join** — 셔플 없이 모든 executor 가 작은 테이블을 메모리에 보유.

</details>

### Q2. `left_anti` 조인의 결과로 옳은 것은?
① 양쪽 매칭되는 행만
② 왼쪽에서 오른쪽과 매칭 안 되는 행
③ 오른쪽 전체
④ 모든 가능한 조합

<details><summary>정답</summary>

**②** — SQL 의 `NOT EXISTS` / `LEFT JOIN ... WHERE right IS NULL` 에 해당.

</details>

### Q3. Spark 가 자동으로 broadcast 를 선택하는 기준 설정은?
① `spark.sql.shuffle.partitions`
② `spark.sql.autoBroadcastJoinThreshold`
③ `spark.executor.memory`
④ `spark.sql.adaptive.enabled`

<details><summary>정답</summary>

**②** — 기본 10MB. 이보다 작은 테이블은 자동 broadcast.

</details>

### Q4. 조인 키가 한 값에 몰린(skew) 경우의 대응이 아닌 것은?
① AQE 활성화
② Salting 으로 키 분산
③ broadcast 가능하면 broadcast
④ shuffle.partitions 를 1 로 설정

<details><summary>정답</summary>

**④** — partition=1 은 모든 데이터를 한 곳에 모아 더 악화시킨다.

</details>

### Q5. 다음 두 결과의 차이는?
```python
A = df1.join(df2, "key", "inner")
B = df1.join(df2, df1.key == df2.key, "inner")
```
① 결과가 동일
② A 는 key 컬럼이 1개, B 는 양쪽의 key 컬럼이 모두 남아 2개
③ B 가 빠르다
④ A 는 broadcast, B 는 shuffle 만 사용한다

<details><summary>정답</summary>

**②** — 문자열로 키를 주면 자동으로 한 컬럼만 남고, 표현식이면 양쪽 모두 결과에 남는다.

</details>
