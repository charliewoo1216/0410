# A10. 단순 선형 회귀 + 가정 진단

> 실습 코드: [`python/adsp/adsp10_simple_regression.py`](../../python/adsp/adsp10_simple_regression.py)

## 1. 핵심 개념

**단순선형회귀**: 한 개의 독립변수 $x$ 로 종속변수 $y$ 를 예측하는 모형.

$$y = \beta_0 + \beta_1 x + \epsilon$$

| 기호 | 의미 |
|------|------|
| $\beta_0$ | 절편(intercept) |
| $\beta_1$ | 기울기(slope), 회귀계수 |
| $\epsilon$ | 오차(error term) |

추정 방법: **최소제곱법(OLS)** — 잔차 제곱합 $\sum(y_i - \hat{y}_i)^2$ 을 최소화.

## 2. 회귀 가정 (4가지)

| 가정 | 의미 | 위반 시 진단 |
|------|------|-------------|
| **선형성** (Linearity) | x와 y가 선형 관계 | 잔차 vs 적합값 산점도 |
| **독립성** (Independence) | 잔차들이 서로 독립 | Durbin-Watson 통계량 |
| **등분산성** (Homoscedasticity) | 잔차의 분산이 일정 | 잔차 vs 적합값에서 깔때기형 의심 |
| **정규성** (Normality) | 잔차가 정규분포 | Q-Q 플롯, Shapiro-Wilk |

> 약자 **LINE** (Linearity, Independence, Normality, Equal variance).

## 3. 회귀 평가 지표

| 지표 | 공식 | 의미 |
|------|------|------|
| **R²** | $1 - \frac{SS_{res}}{SS_{tot}}$ | 설명 분산 비율 (0~1) |
| **수정 R²** | R² 에 변수 수 패널티 | 다중회귀 비교에 사용 |
| **MSE** | $\frac{1}{n}\sum(y - \hat{y})^2$ | 평균 제곱 오차 |
| **RMSE** | $\sqrt{MSE}$ | 원자료와 동일 단위 |
| **MAE** | $\frac{1}{n}\sum|y - \hat{y}|$ | 평균 절대 오차 |

## 4. 회귀계수 검정

각 $\beta_i$ 가 0 인지(즉, 의미가 있는지)를 t-검정으로 확인.
- $H_0: \beta_i = 0$ vs $H_1: \beta_i \neq 0$
- p < 0.05 → 해당 변수는 통계적으로 유의

## 5. 기출 유형 문제

### Q1. 단순선형회귀의 4가지 기본 가정이 아닌 것은?
① 선형성   ② 독립성   ③ 정규성   ④ 다중공선성

<details><summary>정답</summary>

**④ 다중공선성** — 다중회귀에서 다루는 개념(변수 간 강한 상관). 단순회귀와는 무관.

</details>

### Q2. 잔차 vs 적합값 산점도가 "깔때기 모양(분산이 점점 커짐)"으로 나타날 때 의심되는 가정 위반은?
① 선형성   ② 등분산성   ③ 독립성   ④ 정규성

<details><summary>정답</summary>

**② 등분산성(Homoscedasticity)** 위반.

</details>

### Q3. 결정계수 R² 에 대한 설명으로 옳지 않은 것은?
① 0 ~ 1 사이의 값을 갖는다
② 클수록 모델 설명력이 좋다
③ 변수를 추가하면 항상 값이 증가하거나 같다
④ 모형의 잔차가 정규분포임을 보장한다

<details><summary>정답</summary>

**④** — R² 는 설명력 지표일 뿐 잔차 정규성과 무관.

</details>

### Q4. 회귀모형에서 다음과 같은 결과를 얻었다.
> $\hat{y} = 5 + 2x$, R² = 0.8

x 가 1 증가하면 y 의 예측값은 어떻게 변하는가?
① 1 증가   ② 2 증가   ③ 5 증가   ④ 0.8 증가

<details><summary>정답</summary>

**② 2 증가** — 기울기 = 2.

</details>

### Q5. 회귀계수의 유의성 검정에 사용되는 통계량은?
① 카이제곱   ② F-통계량   ③ t-통계량   ④ z-통계량

<details><summary>정답</summary>

**③ t-통계량** — $H_0: \beta_i = 0$ 에 대한 t-검정.
참고로 회귀모형 전체의 유의성 검정에는 F-통계량이 쓰임.

</details>
