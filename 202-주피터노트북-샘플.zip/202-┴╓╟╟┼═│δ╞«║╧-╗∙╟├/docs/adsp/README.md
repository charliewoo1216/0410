# ADsP 학습 노트 색인

ADsP(데이터분석 준전문가) 시험 대비를 위한 **개념 정리 + 기출 유형 문제** 모음.
각 문서는 동일한 번호의 실습 코드(`python/adsp/adspNN_*.py`)와 1:1 매칭된다.

## 📚 학습 노트

### 1과목 — 데이터의 이해
| No | 제목 | 핵심 개념 |
|----|------|----------|
| A01 | [DIKW 피라미드](./adsp01_dikw.md) | 데이터→정보→지식→지혜 위계 |
| A02 | [OLTP vs OLAP](./adsp02_db_vs_dw.md) | DW 4가지 특성 |
| A03 | [빅데이터 3V/5V](./adsp03_3v_5v.md) | Volume/Velocity/Variety, Veracity/Value |

### 2과목 — 데이터 분석 기획
| No | 제목 | 핵심 개념 |
|----|------|----------|
| A04 | [CRISP-DM](./adsp04_crisp_dm.md) | 6단계 반복 프로세스 |
| A05 | [KDD 프로세스](./adsp05_kdd.md) | 5단계, CRISP-DM/SEMMA 비교 |
| A06 | [데이터 거버넌스/품질](./adsp06_data_governance.md) | 6가지 품질 차원, 메타데이터 |

### 3과목 — 데이터 분석 (출제 빈도 高)
| No | 제목 | 핵심 개념 |
|----|------|----------|
| A07 | [기술통계량](./adsp07_descriptive_stats.md) | 평균/분산/왜도/첨도 |
| A08 | [상관계수](./adsp08_correlation.md) | 피어슨/스피어만/켄달 |
| A09 | [가설 검정](./adsp09_hypothesis_test.md) | t/카이제곱/ANOVA, 1·2종 오류 |
| A10 | [단순 선형 회귀](./adsp10_simple_regression.md) | LINE 가정, R² |
| A11 | [다중 회귀 + VIF](./adsp11_multiple_regression.md) | 다중공선성, 변수 선택 |
| A12 | [로지스틱 회귀](./adsp12_logistic_regression.md) | 로짓, Odds Ratio |
| A13 | [의사결정나무](./adsp13_decision_tree.md) | 지니/엔트로피, CART |
| A14 | [랜덤 포레스트](./adsp14_random_forest.md) | Bagging, OOB, 변수 중요도 |
| A15 | [K-means 군집](./adsp15_kmeans.md) | WCSS, 엘보우, 실루엣 |
| A16 | [계층적 군집](./adsp16_hierarchical.md) | 5가지 연결법, 덴드로그램 |
| A17 | [연관 규칙 (Apriori)](./adsp17_apriori.md) | 지지도/신뢰도/향상도 |
| A18 | [주성분분석 (PCA)](./adsp18_pca.md) | 분산 보존, 누적 설명분산 |
| A19 | [ARIMA 시계열](./adsp19_time_series_arima.md) | 정상성, p/d/q, ACF/PACF |
| A20 | [분류 평가 지표](./adsp20_confusion_matrix.md) | Confusion Matrix, F1, ROC-AUC |

## 📖 활용 방법

1. **개념 학습**: 각 `.md` 파일의 본문을 읽고 표·공식·핵심 키워드를 정리
2. **코드 실습**: `python/adsp/adspNN_*.py` 또는 `notebook/adsp/adspNN_*.ipynb` 실행
3. **문제 풀이**: 각 노트 마지막의 "기출 유형 문제" 풀어보고 `<details>` 로 정답 확인
4. **약점 보강**: 틀린 문항의 개념 섹션을 다시 정독

## 🔗 다른 학습 노트
- [PySpark 학습 노트](../spark/README.md) — 분산 처리·DataFrame API
- [데이터레이크/Lakehouse 학습 노트](../lakehouse/README.md) — Delta/Iceberg/DuckDB

## 🎯 시험 정보

| 항목 | 내용 |
|------|------|
| 주관 | 한국데이터산업진흥원 (K-DATA) |
| 형식 | 객관식 50문항 |
| 시간 | 90분 |
| 총점 | 100점 (과목별 40% / 총점 60% 이상 합격) |
| 출제 영역 | 데이터 이해 / 분석 기획 / 데이터 분석 |

## 💡 학습 팁

- **3과목(A07~A20)** 의 출제 비중이 가장 높다. 통계와 머신러닝 기본 알고리즘을 우선 학습.
- **기출 키워드** (DIKW, CRISP-DM, 3V, 다중공선성, 향상도 등) 는 매 회 반복 출제.
- **함정 문항** 주의:
  - 정확도 vs 정밀도 vs 재현율 혼동
  - 정보(Information) vs 지식(Knowledge) 사례 구분
  - KDD vs CRISP-DM 의 단계 수 / 시작점 차이
