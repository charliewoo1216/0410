# A05. KDD 프로세스

> 실습 코드: [`python/adsp/adsp05_kdd.py`](../../python/adsp/adsp05_kdd.py)

## 1. 핵심 개념

**KDD** (Knowledge Discovery in Databases): 데이터베이스로부터 유용한 지식을 추출하는 일련의 과정. Fayyad et al. (1996) 가 정립한 **5단계** 프로세스.

```
[원본 DB] → Selection → Preprocessing → Transformation → Data Mining → Interpretation/Evaluation → [Knowledge]
```

## 2. 단계별 활동

| 단계 | 주요 활동 |
|------|----------|
| **1. Selection (선택)** | 분석 목적에 맞는 데이터 부분집합 선택 |
| **2. Preprocessing (전처리)** | 결측치·이상치·노이즈 제거 |
| **3. Transformation (변환)** | 정규화, 차원 축소, 파생변수 생성 |
| **4. Data Mining (데이터마이닝)** | 알고리즘 적용 (분류/군집/연관규칙 등) |
| **5. Interpretation/Evaluation (해석·평가)** | 패턴 해석, 비즈니스 가치 평가 |

## 3. CRISP-DM 과의 차이

| 항목 | KDD | CRISP-DM |
|------|-----|----------|
| 단계 수 | 5 | 6 |
| 시작점 | DB(데이터) | 비즈니스 |
| 비즈니스 이해 | ❌ | ⭕ |
| 배포 단계 | ❌ | ⭕ |
| 학술/실무 | 학계 발 | 업계 표준 |
| 주체 | Fayyad 등 | SPSS·DaimlerChrysler·NCR |

> KDD는 "DB → Knowledge"의 학술적 접근, CRISP-DM은 "Biz → Deploy"의 실무 표준.

## 4. KDD vs SEMMA

**SEMMA** (SAS): Sample → Explore → Modify → Model → Assess.

| KDD | SEMMA | 비고 |
|-----|-------|------|
| Selection | Sample | 분석 대상 추출 |
| Preprocessing | Explore | 데이터 탐색·전처리 |
| Transformation | Modify | 변환·재구성 |
| Data Mining | Model | 모델링 |
| Evaluation | Assess | 평가 |

## 5. 기출 유형 문제

### Q1. KDD 프로세스의 5단계 순서가 올바른 것은?
① 선택 → 변환 → 전처리 → 데이터마이닝 → 평가
② 선택 → 전처리 → 변환 → 데이터마이닝 → 평가
③ 전처리 → 선택 → 변환 → 데이터마이닝 → 평가
④ 데이터마이닝 → 선택 → 전처리 → 변환 → 평가

<details><summary>정답</summary>

**②** 선택 → 전처리 → 변환 → 데이터마이닝 → 평가

</details>

### Q2. KDD 와 CRISP-DM 을 비교한 설명으로 옳지 않은 것은?
① CRISP-DM 은 6단계, KDD 는 5단계이다
② CRISP-DM 은 비즈니스 이해 단계가 있지만, KDD 에는 없다
③ CRISP-DM 은 배포 단계까지 포함한다
④ KDD 는 비즈니스 목표 정의에서 시작한다

<details><summary>정답</summary>

**④** — KDD 는 데이터베이스(데이터)에서 시작한다. 비즈니스 목표는 CRISP-DM 의 출발점이다.

</details>

### Q3. KDD 의 "Transformation(변환)" 단계에서 수행하는 작업으로 가장 적절한 것은?
① 결측치 대체   ② 모델 학습   ③ 차원 축소·정규화   ④ 비즈니스 목표 설정

<details><summary>정답</summary>

**③** — 정규화·차원 축소·파생변수 생성은 변환(Transformation) 단계에 해당.
- ① Preprocessing, ② Data Mining, ④ KDD 에는 없는 단계

</details>

### Q4. SAS 사가 정립한 데이터마이닝 프로세스로, KDD 와 유사하지만 비즈니스 이해 단계 대신 Sample 부터 시작하는 것은?
① CRISP-DM   ② SEMMA   ③ ETL   ④ KDD

<details><summary>정답</summary>

**② SEMMA** (Sample → Explore → Modify → Model → Assess)

</details>
