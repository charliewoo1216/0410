# A19. 시계열 — ARIMA 모형

> 실습 코드: [`python/adsp/adsp19_time_series_arima.py`](../../python/adsp/adsp19_time_series_arima.py)

## 1. 핵심 개념

**시계열**(Time Series): 시간 순서대로 관측된 데이터.
구성 요소: **추세(Trend) + 계절성(Seasonality) + 순환(Cycle) + 불규칙(Irregular/Noise)**.

## 2. 정상성 (Stationarity)

ARIMA 의 핵심 가정: **약정상성(weak stationarity)**.

| 조건 | 의미 |
|------|------|
| 평균 일정 | 시간에 따라 평균이 변하지 않음 |
| 분산 일정 | 분산이 시간 무관 |
| 자기공분산 일정 | 시차에만 의존, 시점 무관 |

### 정상성 만들기
- **차분(differencing)** $\Delta y_t = y_t - y_{t-1}$ → 추세 제거
- **로그 변환** → 분산 안정화
- **계절 차분** $\Delta_s y_t = y_t - y_{t-s}$ → 계절성 제거

### 정상성 검정
- **ADF 검정** (Augmented Dickey-Fuller)
- **KPSS 검정**

## 3. ARIMA(p, d, q)

| 기호 | 의미 |
|------|------|
| **AR(p)** | 자기회귀 차수 — 자기 자신의 과거 p개 값으로 설명 |
| **I(d)** | 차분 차수 — 정상성 확보까지 차분한 횟수 |
| **MA(q)** | 이동평균 차수 — 과거 q개 오차의 가중합 |

수식:
$$\phi(B)(1 - B)^d y_t = \theta(B) \epsilon_t$$

### SARIMA(p, d, q)(P, D, Q)ₛ
계절성 항을 추가한 확장 모형. s = 계절 주기 (월별=12, 일별=7 등).

## 4. ACF / PACF 로 차수 결정

| 모형 | ACF 패턴 | PACF 패턴 |
|------|----------|----------|
| **AR(p)** | 점진적으로 감소 | **시차 p 이후 절단** |
| **MA(q)** | **시차 q 이후 절단** | 점진적으로 감소 |
| **ARMA(p, q)** | 점진적 감소 | 점진적 감소 |

## 5. 모형 평가

| 지표 | 의미 |
|------|------|
| **AIC / BIC** | 적합도 + 복잡도 패널티 |
| **Ljung-Box** | 잔차의 자기상관 검정 (잔차가 백색잡음인지) |
| **MAE / RMSE / MAPE** | 예측 오차 |

## 6. 기타 시계열 기법

| 기법 | 특징 |
|------|------|
| **지수평활법** (Exponential Smoothing) | Simple/Holt/Holt-Winters |
| **Prophet** (Facebook) | 추세·계절·휴일 분해 |
| **VAR** | 다변량 시계열 |
| **LSTM, Transformer** | 딥러닝 기반 |

## 7. 기출 유형 문제

### Q1. ARIMA(1, 1, 1) 모형에서 각 숫자의 의미는?
① AR=1, MA=1, 차분=1
② AR=1, 차분=1, MA=1
③ MA=1, 차분=1, AR=1
④ AR=1, MA=1, 차분=2

<details><summary>정답</summary>

**②** — 순서는 (p, d, q) = (AR 차수, 차분 차수, MA 차수).

</details>

### Q2. 시계열의 정상성(stationarity) 조건이 아닌 것은?
① 평균이 시간에 따라 일정
② 분산이 시간에 따라 일정
③ 자기공분산이 시간에 따라 일정
④ 추세가 일정한 기울기로 증가

<details><summary>정답</summary>

**④** — 추세가 있다는 것은 평균이 시간에 따라 변한다는 뜻이므로 **비정상**.

</details>

### Q3. 시계열에 추세가 있을 때 정상성을 확보하기 위한 일반적인 방법은?
① 표준화   ② 차분(differencing)   ③ 정규화   ④ Box-Cox 변환

<details><summary>정답</summary>

**② 차분** — $\Delta y_t = y_t - y_{t-1}$ 로 추세 제거.

</details>

### Q4. AR(2) 모형의 PACF 의 일반적인 패턴은?
① 시차 1 에서 절단(cut-off)
② 시차 2 에서 절단(cut-off)
③ 점진적으로 감소
④ 무작위로 진동

<details><summary>정답</summary>

**②** — AR(p) 의 PACF 는 시차 p 까지 의미 있고 그 이후 0 에 가까움(절단).

</details>

### Q5. 시계열 분해의 4가지 구성 요소가 아닌 것은?
① 추세(Trend)   ② 계절성(Seasonality)   ③ 순환(Cycle)   ④ 결정계수(R²)

<details><summary>정답</summary>

**④** — 시계열 구성 요소는 추세·계절·순환·불규칙(Irregular).

</details>
