# A20. 분류 평가 — 혼동행렬 / Precision / Recall / F1 / ROC-AUC

> 실습 코드: [`python/adsp/adsp20_confusion_matrix.py`](../../python/adsp/adsp20_confusion_matrix.py)

## 1. 혼동 행렬 (Confusion Matrix)

이진 분류 결과를 4 가지 셀로 정리한 표.

|  | 예측: Positive | 예측: Negative |
|---|---|---|
| **실제: Positive** | TP (참 양성) | FN (거짓 음성) |
| **실제: Negative** | FP (거짓 양성) | TN (참 음성) |

## 2. 핵심 지표

### 2.1 정확도(Accuracy)
$$\text{Acc} = \frac{TP + TN}{TP + TN + FP + FN}$$
**전체 중 맞춘 비율**. 클래스 불균형이 심하면 오해 소지.

### 2.2 정밀도(Precision)
$$\text{Precision} = \frac{TP}{TP + FP}$$
**Positive 로 예측한 것 중 실제 Positive 비율**. (FP 줄이는 게 중요할 때)

### 2.3 재현율(Recall, 민감도)
$$\text{Recall} = \frac{TP}{TP + FN}$$
**실제 Positive 중 모델이 잡아낸 비율**. (FN 줄이는 게 중요할 때)

### 2.4 F1-score
$$\text{F1} = \frac{2 \cdot P \cdot R}{P + R}$$
정밀도와 재현율의 **조화평균**. 둘 다 중요할 때.

### 2.5 특이도(Specificity)
$$\text{Specificity} = \frac{TN}{TN + FP}$$

## 3. ROC 곡선과 AUC

분류 임계값(threshold) 을 0 ~ 1 로 변화시키며:
- **TPR** (= Recall, 민감도) vs
- **FPR** (= 1 − Specificity, 1종 오류율)

을 그린 곡선이 ROC.

**AUC** (Area Under Curve): 곡선 아래 면적.

| AUC | 해석 |
|-----|------|
| 1.0 | 완벽한 분류 |
| 0.9~ | 매우 우수 |
| 0.7~ | 양호 |
| 0.5 | 무작위 |
| < 0.5 | 무작위보다 못함 |

## 4. 어떤 지표를 봐야 하나?

| 상황 | 중요한 지표 | 이유 |
|------|-----------|------|
| 클래스 균형, 일반 | Accuracy | 직관적 |
| 클래스 불균형 | F1, AUC | Accuracy 가 왜곡됨 |
| 스팸 차단 (오차단↓) | Precision | FP(정상 메일을 스팸 처리) 최소화 |
| 암 진단 (놓침↓) | Recall | FN(암을 놓침) 최소화 |
| 임계값 자유롭게 비교 | AUC | threshold 무관 |

## 5. 다중 클래스 평균 방식

| 방식 | 설명 |
|------|------|
| **Macro** | 클래스별 지표의 단순 평균 (불균형 영향 큼) |
| **Weighted** | 클래스 빈도 가중 평균 |
| **Micro** | 모든 TP/FP/FN 합쳐서 계산 |

## 6. 기출 유형 문제

### Q1. 다음 혼동행렬에서 정밀도(Precision)는?

|  | 예측+ | 예측− |
|--|------|------|
| 실제+ | 80 | 20 |
| 실제− | 30 | 70 |

① 0.80   ② 0.73   ③ 0.70   ④ 0.50

<details><summary>정답</summary>

**②** Precision = TP / (TP + FP) = 80 / (80 + 30) = 80 / 110 ≈ **0.727**.

</details>

### Q2. 정밀도와 재현율의 조화평균을 의미하는 지표는?
① Accuracy   ② F1-score   ③ AUC   ④ Specificity

<details><summary>정답</summary>

**② F1-score** = 2 × P × R / (P + R).

</details>

### Q3. 클래스 불균형이 매우 심한 데이터에서 정확도(Accuracy) 만으로 모델을 평가하면 안 되는 이유는?
① 정확도는 항상 0 으로 나옴
② 다수 클래스만 예측해도 정확도가 매우 높게 나타남
③ 정확도는 회귀에서만 사용
④ 정확도는 음수 값을 가질 수 있음

<details><summary>정답</summary>

**②** — 예: 99% 음성 데이터에서 모두 음성으로 예측하면 정확도 99% 이지만 재현율 0%.

</details>

### Q4. ROC 곡선의 두 축은?
① Precision vs Recall
② TPR vs FPR
③ Accuracy vs Threshold
④ TP vs FP

<details><summary>정답</summary>

**②** — y축 TPR(=Recall, 민감도), x축 FPR(=1−특이도).

</details>

### Q5. 암 진단 모델에서 환자를 놓치지 않는 것이 가장 중요할 때, 가장 우선시해야 할 지표는?
① Precision   ② Recall   ③ Accuracy   ④ Specificity

<details><summary>정답</summary>

**② Recall (민감도)** — FN(놓침) 을 최소화해야 하므로 재현율 우선.

</details>

### Q6. AUC 가 0.5 라는 것의 의미는?
① 매우 좋은 모델   ② 무작위(동전 던지기) 수준의 모델   ③ 매우 나쁜 모델   ④ 모델 학습 실패

<details><summary>정답</summary>

**②** — AUC = 0.5 면 양·음성 구분 능력이 무작위 수준.

</details>
