# A14. 랜덤 포레스트 — 앙상블 / 변수 중요도

> 실습 코드: [`python/adsp/adsp14_random_forest.py`](../../python/adsp/adsp14_random_forest.py)

## 1. 핵심 개념

**랜덤 포레스트**(Random Forest): 여러 의사결정나무를 학습 후 예측을 다수결(분류) 또는 평균(회귀)으로 결합한 **배깅 기반 앙상블** 모델.

```
       [전체 학습 데이터]
            │
   ┌───┬────┼────┬───┐  ← bootstrap (복원 추출)
   ▼   ▼    ▼    ▼   ▼
 [Tree1][Tree2]…[TreeN]  ← 트리마다 무작위 변수 부분집합으로 분할
   │   │    │    │   │
   └───┴───┬┴────┴───┘
           ▼
      다수결 / 평균  → 최종 예측
```

## 2. 두 가지 무작위성

| 무작위성 | 설명 |
|---------|------|
| **Bootstrap** | 트리마다 학습 데이터를 복원 추출 (행 무작위) |
| **Random Subspace** | 분할 시 후보 변수도 무작위 부분집합 (열 무작위) |

→ 트리들 간 상관(corr)을 낮춰 앙상블 효과를 극대화.

## 3. 앙상블 종류

| 방법 | 핵심 아이디어 | 대표 모델 |
|------|--------------|----------|
| **Bagging** | 병렬, bootstrap 후 평균 | Random Forest |
| **Boosting** | 순차, 직전 모델의 오차 보정 | AdaBoost, XGBoost, LightGBM |
| **Stacking** | 여러 모델 출력을 메타 모델 입력 | (다양한 조합) |

## 4. OOB (Out-of-Bag) 평가

각 트리는 bootstrap 으로 약 63% 의 데이터만 사용 → 나머지 약 **37%** 가 OOB 샘플.
이 OOB 로 별도의 검증셋 없이 일반화 오차를 추정 가능.

## 5. 변수 중요도 (Feature Importance)

| 방법 | 계산 |
|------|------|
| **MDI** (Mean Decrease in Impurity) | 분할에서의 평균 불순도 감소량 (sklearn 기본) |
| **Permutation Importance** | 변수 값을 셔플 했을 때 성능 하락 정도 |

## 6. 장단점

| 장점 | 단점 |
|------|------|
| 단일 트리 대비 정확도 ↑ | 해석이 어려움(black-box 경향) |
| 과적합에 비교적 강건 | 학습/예측 시간 ↑ |
| 결측·이상치에 강함 | 메모리 사용량 ↑ |

## 7. 기출 유형 문제

### Q1. 랜덤 포레스트는 어떤 앙상블 기법에 해당하는가?
① Boosting   ② Bagging   ③ Stacking   ④ Voting

<details><summary>정답</summary>

**② Bagging** — Bootstrap Aggregating. 병렬로 학습 후 결합.

</details>

### Q2. 랜덤 포레스트가 단일 의사결정나무보다 성능이 좋은 핵심 이유는?
① 트리의 깊이를 무제한으로 키운다
② 여러 트리를 결합해 분산을 줄이고 일반화 성능을 높인다
③ 데이터를 정렬해서 학습한다
④ 회귀에서만 사용 가능하기 때문이다

<details><summary>정답</summary>

**②** — 다수의 트리를 결합해 variance 를 감소시키는 것이 핵심.

</details>

### Q3. OOB(Out-of-Bag) 에 대한 설명으로 옳은 것은?
① 학습에 사용된 데이터로만 평가한다
② Bootstrap 에 포함되지 않은 데이터로 검증한다
③ 부스팅에서 사용하는 평가 방법이다
④ 분할 기준의 한 종류이다

<details><summary>정답</summary>

**②** — 각 트리의 bootstrap 표본에 포함되지 않은 약 37% 의 데이터로 별도 검증셋 없이 추정.

</details>

### Q4. 랜덤 포레스트에서 트리 간 상관을 낮추기 위해 사용하는 두 가지 무작위성은?
① 데이터 무작위 + 변수 무작위
② 깊이 무작위 + 데이터 무작위
③ 모델 무작위 + 깊이 무작위
④ 가중치 무작위 + 변수 무작위

<details><summary>정답</summary>

**①** — Bootstrap(행) + Random Subspace(열).

</details>

### Q5. 부스팅(Boosting)과 배깅(Bagging)의 가장 큰 차이는?
① 배깅은 순차적, 부스팅은 병렬적이다
② 배깅은 병렬적, 부스팅은 순차적이다
③ 둘 다 순차적이지만 모델이 다르다
④ 둘 다 병렬이지만 데이터가 다르다

<details><summary>정답</summary>

**②** — 배깅은 트리 간 독립으로 병렬, 부스팅은 직전 트리의 오차를 보정하므로 순차.

</details>
