# A02. OLTP vs OLAP (운영DB vs 데이터웨어하우스)

> 실습 코드: [`python/adsp/adsp02_db_vs_dw.py`](../../python/adsp/adsp02_db_vs_dw.py)

## 1. 핵심 개념

**OLTP** (Online Transaction Processing): 실시간 트랜잭션 처리 시스템 (운영 DB)
**OLAP** (Online Analytical Processing): 분석을 위한 다차원 조회 시스템 (DW/Data Mart)

| 구분 | OLTP | OLAP |
|------|------|------|
| **목적** | 일상 업무 트랜잭션 | 분석·의사결정 |
| **데이터** | 현재 운영 데이터 | 과거 + 현재 통합 데이터 |
| **연산** | INSERT/UPDATE/DELETE 中心 | SELECT(집계) 중심 |
| **단위** | 행(Row) 단위 | 컬럼·집합 단위 |
| **스키마** | 정규화 (3NF) | 비정규화 (Star, Snowflake) |
| **응답시간** | ms 단위 | 초~분 단위 |
| **사용자** | 실무자 (수천명) | 분석가 (수십명) |

## 2. 데이터웨어하우스의 4가지 특성 (Inmon)

| 특성 | 의미 |
|------|------|
| **주제 지향성** (Subject-oriented) | 업무 기능이 아닌 분석 주제 중심 (예: 고객, 매출) |
| **통합성** (Integrated) | 여러 소스의 데이터를 일관된 형식으로 통합 |
| **시계열성** (Time-variant) | 과거 시점의 데이터를 보존 |
| **비휘발성** (Non-volatile) | 적재 후에는 갱신·삭제 거의 없음 |

## 3. 데이터 마트(Data Mart) vs DW

- **DW**: 전사(全社) 통합 저장소
- **Data Mart**: 특정 부서·주제용 부분집합 (DW에서 추출하여 구성)

## 4. 기출 유형 문제

### Q1. 데이터웨어하우스의 4가지 특성이 아닌 것은?
① 주제 지향성   ② 통합성   ③ 정규화   ④ 비휘발성

<details><summary>정답</summary>

**③ 정규화** — DW는 오히려 **비정규화**된 스타 스키마 등을 사용.

</details>

### Q2. OLTP와 OLAP의 비교로 옳지 않은 것은?
① OLTP는 트랜잭션 처리 중심이다
② OLAP는 의사결정 지원이 목적이다
③ OLTP는 비정규화된 스키마를 사용한다
④ OLAP는 대용량 집계 쿼리를 자주 수행한다

<details><summary>정답</summary>

**③** — OLTP는 일관성·중복 최소화를 위해 **정규화** 스키마를 사용한다.

</details>

### Q3. 다음 중 데이터마트(Data Mart)에 대한 설명으로 옳은 것은?
① 전사 데이터를 모두 보관한다
② 특정 부서·주제 영역에 특화된 소규모 DW이다
③ 운영 시스템의 데이터를 그대로 사용한다
④ 정규화 수준이 OLTP보다 높다

<details><summary>정답</summary>

**②** — 데이터마트는 부서·주제별 부분집합 형태의 DW이다.

</details>

### Q4. 데이터웨어하우스의 시계열성(Time-variant)이 의미하는 것은?
① 데이터가 실시간으로 업데이트된다
② 시간에 따라 변화한 이력을 보존한다
③ 시계열 분석 알고리즘을 내장한다
④ 데이터가 시간 순서로만 저장된다

<details><summary>정답</summary>

**②** — DW는 특정 시점의 스냅샷을 누적·보존하는 특성을 갖는다.

</details>
