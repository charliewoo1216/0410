# A03. 빅데이터 3V / 5V

> 실습 코드: [`python/adsp/adsp03_3v_5v.py`](../../python/adsp/adsp03_3v_5v.py)

## 1. 핵심 개념

**가트너(Gartner) 3V** — 빅데이터의 정의에 가장 많이 인용되는 특성 3가지.

| V | 의미 | 예시 |
|---|------|------|
| **Volume** (규모) | 테라바이트~페타바이트 이상의 대용량 | SNS 게시물, 센서 로그 |
| **Velocity** (속도) | 데이터의 생성·처리 속도 | IoT 스트림, 실시간 거래 |
| **Variety** (다양성) | 정형·반정형·비정형 혼재 | DB 레코드 + JSON + 텍스트 + 이미지 |

**5V** — 3V에 두 가지를 추가한 확장 모델.

| V | 의미 | 비고 |
|---|------|------|
| **Veracity** (신뢰성) | 데이터의 정확성·일관성 | 결측·노이즈·오류 관리 |
| **Value** (가치) | 분석을 통해 얻는 비즈니스 가치 | 의사결정 근거로서의 효용 |

## 2. 데이터 유형

| 유형 | 특징 | 예시 |
|------|------|------|
| **정형** (Structured) | 사전 정의된 스키마, 행·열 구조 | RDBMS 테이블 |
| **반정형** (Semi-structured) | 스키마는 데이터 안에 내장 | JSON, XML, HTML |
| **비정형** (Unstructured) | 스키마 없음 | 텍스트, 이미지, 동영상, 로그 |

## 3. 빅데이터 분석 기술

| 기술 | 역할 |
|------|------|
| **Hadoop / HDFS** | 분산 저장 |
| **MapReduce / Spark** | 분산 처리 |
| **Hive / Pig** | SQL 류 추상화 |
| **Kafka** | 메시지 큐(스트리밍) |
| **NoSQL** (HBase, Cassandra, MongoDB) | 비관계형 저장 |

## 4. 기출 유형 문제

### Q1. 가트너가 정의한 빅데이터의 3대 특성(3V)에 해당하지 않는 것은?
① Volume   ② Velocity   ③ Variety   ④ Value

<details><summary>정답</summary>

**④ Value** — Value 는 5V 의 확장 요소이며, 가트너 3V 에는 포함되지 않는다.

</details>

### Q2. 다음 중 비정형 데이터에 해당하지 않는 것은?
① 동영상   ② 이미지   ③ 자유 형식 텍스트   ④ JSON 문서

<details><summary>정답</summary>

**④ JSON** — JSON 은 키–값 구조를 가진 **반정형(semi-structured)** 데이터이다.

</details>

### Q3. 빅데이터 5V 중 "데이터의 정확성·신뢰성"에 해당하는 것은?
① Volume   ② Velocity   ③ Veracity   ④ Variety

<details><summary>정답</summary>

**③ Veracity** — 결측·노이즈·편향 등 데이터 품질 측면.

</details>

### Q4. 다음 설명에 해당하는 빅데이터 특성은?

> "온라인 쇼핑몰에서 1초당 수천 건의 클릭 이벤트가 생성되고, 이를 실시간으로 처리해야 한다."

① Volume   ② Velocity   ③ Variety   ④ Value

<details><summary>정답</summary>

**② Velocity** — 데이터 생성·처리 속도와 관련.

</details>
