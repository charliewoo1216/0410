# A13. 의사결정나무 — 지니계수 vs 엔트로피

> 실습 코드: [`python/adsp/adsp13_decision_tree.py`](../../python/adsp/adsp13_decision_tree.py)

## 1. 핵심 개념

**의사결정나무**(Decision Tree): 데이터를 재귀적으로 분할(split)하여 트리 구조의 규칙을 만드는 모델.

### 구조
```
        [Root]   ← 분기점(internal node)
        /    \
   조건참    조건거짓
      /        \
   [노드]     [Leaf]  ← 종단노드(예측 결과)
   /  \
  ...  ...
```

## 2. 분할 기준

### 2.1 분류 — Gini, Entropy
| 기준 | 정의 | 범위 |
|------|------|------|
| **지니계수** | $1 - \sum p_i^2$ | 0 (순수) ~ 0.5 (이진 50:50) |
| **엔트로피** | $-\sum p_i \log_2 p_i$ | 0 ~ log₂(클래스 수) |

**정보이득**(Information Gain) = 부모 불순도 − 자식들의 가중 불순도.
이득이 가장 큰 분할을 선택.

### 2.2 회귀 — 분산 / MSE 감소
$$\text{Reduction} = \text{Var(parent)} - \frac{n_L}{n}\text{Var}(L) - \frac{n_R}{n}\text{Var}(R)$$

## 3. 주요 알고리즘

| 알고리즘 | 분할 기준 | 트리 구조 |
|---------|----------|----------|
| **ID3** | 정보이득 (엔트로피) | 다지(multi-way) |
| **C4.5** | 정보이득비 | 다지 + 가지치기 |
| **CART** | 지니(분류), 분산(회귀) | **이진(binary)** |
| **CHAID** | 카이제곱 | 다지 (범주형) |

> scikit-learn 의 DecisionTree 는 CART 기반.

## 4. 가지치기(Pruning)

과적합 방지를 위해 트리 크기를 제한.

| 종류 | 설명 |
|------|------|
| **사전 가지치기** | max_depth, min_samples_split 등 사전 제한 |
| **사후 가지치기** | 최대 트리 후 비용복잡도(α) 로 가지 제거 |

## 5. 장단점

| 장점 | 단점 |
|------|------|
| 해석 쉬움 (white-box) | 과적합 경향 |
| 전처리 적음 (스케일 무관) | 작은 변화에도 트리가 크게 변함 |
| 비선형·상호작용 자동 학습 | 단일 트리는 정확도 한계 → 앙상블(RF) 필요 |

## 6. 기출 유형 문제

### Q1. 의사결정나무의 분할 기준이 아닌 것은?
① 지니계수   ② 엔트로피   ③ 분산   ④ 결정계수 R²

<details><summary>정답</summary>

**④ R²** — R² 는 회귀모형의 설명력 지표이지, 분할 기준이 아니다.

</details>

### Q2. CART 알고리즘의 특징으로 옳은 것은?
① 항상 다지(multi-way)로 분할
② 분류는 엔트로피, 회귀는 R² 사용
③ 항상 이진(binary)으로 분할
④ 가지치기를 지원하지 않음

<details><summary>정답</summary>

**③** — CART 는 항상 두 개의 자식 노드로 분할(이진 트리).

</details>

### Q3. 두 클래스가 50:50 으로 섞인 노드의 지니계수는?
① 0   ② 0.25   ③ 0.5   ④ 1.0

<details><summary>정답</summary>

**③ 0.5** — Gini = 1 − (0.5² + 0.5²) = 1 − 0.5 = **0.5**.

</details>

### Q4. 의사결정나무의 과적합을 방지하는 방법으로 적절하지 않은 것은?
① max_depth 제한
② min_samples_split 증가
③ 가지치기(pruning) 수행
④ 트리 깊이를 무제한으로 키움

<details><summary>정답</summary>

**④** — 깊이를 무제한으로 키우면 과적합이 심해진다.

</details>

### Q5. 정보이득(Information Gain) 의 정의로 옳은 것은?
① 부모 노드의 불순도와 자식 노드들의 가중 평균 불순도의 차이
② 부모 노드와 자식 노드 엔트로피의 합
③ 분할 후 정확도 증가량
④ 트리 깊이의 변화량

<details><summary>정답</summary>

**①** — IG = Impurity(parent) − Σ (n_child/n_parent) × Impurity(child).

</details>
