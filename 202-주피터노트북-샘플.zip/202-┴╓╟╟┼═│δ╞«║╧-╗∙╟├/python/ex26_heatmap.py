"""
예제 26. heatmap
DataFrame의 상관계수 행렬을 seaborn.heatmap으로 시각화한다.
"""
import seaborn as sns
import matplotlib.pyplot as plt

iris = sns.load_dataset("iris")
corr = iris.drop(columns="species").corr()

print("[상관계수 행렬]")
print(corr.round(3))

plt.figure(figsize=(7, 5))
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5)
plt.title("Iris Correlation Heatmap")
plt.tight_layout()
plt.show()
