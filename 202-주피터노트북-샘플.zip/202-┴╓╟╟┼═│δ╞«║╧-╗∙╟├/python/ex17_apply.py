"""
예제 17. 컬럼 추가/변환
apply()로 연봉을 기준으로 등급(A/B/C) 컬럼을 새로 추가한다.
"""
import pandas as pd

df = pd.DataFrame({
    "이름": ["김민준", "이서연", "박지호", "최수아", "정도윤", "한예준"],
    "연봉": [5500, 8000, 4500, 6500, 7300, 4800],
})


def grade(salary):
    if salary >= 7000:
        return "A"
    if salary >= 5000:
        return "B"
    return "C"


df["등급"] = df["연봉"].apply(grade)
print(df)
print("\n등급별 인원:")
print(df["등급"].value_counts())
