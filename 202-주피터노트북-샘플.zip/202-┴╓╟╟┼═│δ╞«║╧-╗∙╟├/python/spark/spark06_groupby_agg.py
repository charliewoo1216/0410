"""
S06. groupBy + 다중 집계
SQL GROUP BY 에 해당하는 핵심 패턴.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg, count, max as smax, min as smin, sum as ssum, round as rnd

spark = SparkSession.builder.appName("groupby").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [("dev", "A", 5500), ("dev", "B", 7200), ("dev", "C", 5800),
     ("mkt", "D", 4800), ("mkt", "E", 5200),
     ("ops", "F", 6300), ("ops", "G", 7100)],
    ["dept", "name", "salary"],
)

(df.groupBy("dept")
   .agg(
       count("*").alias("n"),
       rnd(avg("salary"), 1).alias("avg_salary"),
       smax("salary").alias("max_salary"),
       smin("salary").alias("min_salary"),
       ssum("salary").alias("total"),
   )
   .orderBy("dept")
   .show())

spark.stop()
