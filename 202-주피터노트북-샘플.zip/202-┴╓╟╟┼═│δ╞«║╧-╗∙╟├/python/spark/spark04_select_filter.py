"""
S04. select / filter / where
DataFrame 의 가장 기본 연산. SQL 의 SELECT / WHERE 와 동일.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder.appName("select").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [(1, "Alice", "dev", 5500),
     (2, "Bob",   "mkt", 4800),
     (3, "Carol", "dev", 7200),
     (4, "Dan",   "ops", 6100),
     (5, "Eve",   "dev", 8000)],
    ["id", "name", "dept", "salary"],
)

print("[name, salary 만 선택]")
df.select("name", "salary").show()

print("[dev 부서 + salary >= 6000]")
df.filter((col("dept") == "dev") & (col("salary") >= 6000)).show()

print("[where (filter 별칭)]")
df.where("salary > 5000 AND dept != 'mkt'").show()

spark.stop()
