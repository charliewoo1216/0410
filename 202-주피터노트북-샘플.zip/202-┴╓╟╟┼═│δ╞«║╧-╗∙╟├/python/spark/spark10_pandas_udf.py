"""
S10. Pandas UDF (벡터화 UDF)
- Apache Arrow 로 batch 단위 전달 → 일반 UDF 보다 10배 이상 빠름.
- pip install pyspark[pandas] pyarrow
"""
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf, col

spark = SparkSession.builder.appName("pudf").master("local[*]").getOrCreate()

df = spark.range(0, 10).withColumnRenamed("id", "value")


@pandas_udf("double")
def normalize(s: pd.Series) -> pd.Series:
    """그룹 전체 평균/표준편차로 z-score 변환."""
    return (s - s.mean()) / s.std()


@pandas_udf("long")
def double_it(s: pd.Series) -> pd.Series:
    return s * 2


(df.withColumn("doubled", double_it(col("value")))
   .withColumn("z", normalize(col("value")))
   .show())

spark.stop()
