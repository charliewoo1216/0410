"""
S12. partition 수 조절 — repartition / coalesce
- repartition(n): 셔플하며 n개로 늘리거나 줄이기 (모든 노드에 균등)
- coalesce(n): 셔플 없이 줄이기만 (writes 직전에 자주 사용)
"""
from pyspark.sql import SparkSession

spark = (
    SparkSession.builder.appName("part").master("local[*]")
    .config("spark.sql.shuffle.partitions", "8")
    .getOrCreate()
)

df = spark.range(0, 1_000_000)
print(f"기본 파티션 수      : {df.rdd.getNumPartitions()}")

df_50 = df.repartition(50)
print(f"repartition(50)     : {df_50.rdd.getNumPartitions()}")

df_2 = df_50.coalesce(2)
print(f"coalesce(2)         : {df_2.rdd.getNumPartitions()}")

# 컬럼 기반 repartition (조인 키로 미리 분할)
df_keyed = df.withColumnRenamed("id", "user_id").repartition(4, "user_id")
print(f"repartition(4, key) : {df_keyed.rdd.getNumPartitions()}")

spark.stop()
