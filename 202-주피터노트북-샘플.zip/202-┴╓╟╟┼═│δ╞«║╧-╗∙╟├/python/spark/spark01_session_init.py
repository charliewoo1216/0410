"""
S01. SparkSession 시작·종료
PySpark 의 진입점인 SparkSession 을 만들고 끝내는 가장 기본 코드.
- pip install pyspark==3.5.0 (Java 17 권장)
"""
from pyspark.sql import SparkSession

spark = (
    SparkSession.builder
    .appName("learning")
    .master("local[*]")           # 로컬에서 모든 코어 사용
    .config("spark.sql.shuffle.partitions", "4")
    .getOrCreate()
)

print(f"Spark version : {spark.version}")
print(f"App name      : {spark.sparkContext.appName}")
print(f"Master        : {spark.sparkContext.master}")
print(f"파티션 수     : {spark.conf.get('spark.sql.shuffle.partitions')}")

spark.stop()
print("\nSparkSession 종료 완료")
