"""
S09. Python UDF
- DataFrame API 에 없는 로직을 Python 함수로 등록해 컬럼에 적용.
- ⚠ 직렬화 비용 + Python 실행 비용 → 가능하면 내장 함수, Pandas UDF 우선 사용.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col
from pyspark.sql.types import StringType, IntegerType

spark = SparkSession.builder.appName("udf").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [("alice@example.com", 25), ("bob@gmail.com", 30), ("carol@x.io", 22)],
    ["email", "age"],
)


@udf(returnType=StringType())
def email_domain(email: str) -> str:
    return email.split("@", 1)[1] if email and "@" in email else None


@udf(returnType=IntegerType())
def age_bucket(age: int) -> int:
    return (age // 10) * 10


(df
 .withColumn("domain", email_domain(col("email")))
 .withColumn("age_bucket", age_bucket(col("age")))
 .show())

spark.stop()
