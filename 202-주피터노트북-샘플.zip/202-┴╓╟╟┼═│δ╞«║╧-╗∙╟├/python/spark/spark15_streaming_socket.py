"""
S15. Structured Streaming — 소켓 단어 카운트
- 별도 터미널에서 `ncat -lk 9999` 실행 후 단어 입력
- 본 스크립트는 5초마다 단어 카운트를 콘솔에 출력
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split

spark = (
    SparkSession.builder
    .appName("stream")
    .master("local[2]")
    .getOrCreate()
)

lines = (
    spark.readStream
    .format("socket")
    .option("host", "localhost")
    .option("port", 9999)
    .load()
)

words = lines.select(explode(split(lines.value, r"\s+")).alias("word"))
counts = words.groupBy("word").count()

query = (
    counts.writeStream
    .outputMode("complete")
    .format("console")
    .trigger(processingTime="5 seconds")
    .start()
)

# 60초 후 자동 중지
query.awaitTermination(timeout=60)
spark.stop()
