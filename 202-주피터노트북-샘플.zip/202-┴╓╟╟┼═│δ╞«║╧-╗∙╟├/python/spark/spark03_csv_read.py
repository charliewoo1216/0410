"""
S03. CSV 읽기 + 스키마 추론
- header / inferSchema / sep 옵션이 가장 자주 쓰는 3가지.
"""
import csv
from pyspark.sql import SparkSession

# 데모용 CSV 작성
with open("emp.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["id", "name", "dept", "salary"])
    for row in [(1, "A", "dev", 5500), (2, "B", "mkt", 4800), (3, "C", "dev", 7200)]:
        w.writerow(row)

spark = SparkSession.builder.appName("csv").master("local[*]").getOrCreate()

df = (
    spark.read
    .option("header", True)
    .option("inferSchema", True)
    .csv("emp.csv")
)

df.printSchema()
df.show()
print(f"행 수: {df.count()}")

spark.stop()
