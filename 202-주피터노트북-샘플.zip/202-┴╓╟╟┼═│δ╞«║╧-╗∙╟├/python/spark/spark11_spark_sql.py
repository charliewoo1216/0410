"""
S11. Spark SQL — DataFrame ↔ TempView ↔ SQL
DataFrame을 임시 뷰로 등록해 SQL 로 조회한다.
"""
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("sql").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [("dev", "A", 5500), ("dev", "B", 7200), ("mkt", "C", 4800),
     ("mkt", "D", 5200), ("ops", "E", 6300)],
    ["dept", "name", "salary"],
)
df.createOrReplaceTempView("emp")

print("[부서별 평균 연봉 — SQL]")
spark.sql("""
    SELECT dept,
           ROUND(AVG(salary), 1) AS avg_sal,
           COUNT(*) AS n
    FROM emp
    GROUP BY dept
    ORDER BY avg_sal DESC
""").show()

print("[CTE + 윈도우 함수]")
spark.sql("""
    WITH ranked AS (
        SELECT *, RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS r
        FROM emp
    )
    SELECT * FROM ranked WHERE r = 1
""").show()

spark.stop()
