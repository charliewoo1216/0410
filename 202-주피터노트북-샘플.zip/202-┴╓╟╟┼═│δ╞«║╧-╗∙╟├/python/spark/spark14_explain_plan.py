"""
S14. 실행 계획 보기 — explain()
- Logical Plan → Optimized Logical Plan → Physical Plan 순으로 출력.
- 'formatted' 모드는 노드별로 정리된 표 형식.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = (SparkSession.builder.appName("explain").master("local[*]")
         .config("spark.sql.shuffle.partitions", "4").getOrCreate())

a = spark.createDataFrame([(i, i % 10) for i in range(1000)], ["id", "g"])
b = spark.createDataFrame([(i, f"u{i}") for i in range(1000)], ["id", "name"])

q = (a.join(b, "id")
       .groupBy("g")
       .count()
       .filter(col("count") > 90))

print("[기본 Physical Plan]")
q.explain()

print("\n[전체 4단계 plan]")
q.explain(True)

print("\n[formatted]")
q.explain("formatted")

spark.stop()
