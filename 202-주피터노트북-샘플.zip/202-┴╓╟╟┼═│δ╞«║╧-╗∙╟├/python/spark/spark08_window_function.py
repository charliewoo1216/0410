"""
S08. 윈도우 함수 — rank / dense_rank / lag / lead
부서별 연봉 순위, 직전 행과의 비교 등을 한 줄에 처리한다.
"""
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import col, rank, dense_rank, lag, lead

spark = SparkSession.builder.appName("window").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [("dev", "A", 5500), ("dev", "B", 7200), ("dev", "C", 5800),
     ("mkt", "D", 4800), ("mkt", "E", 5200), ("mkt", "F", 5200),
     ("ops", "G", 6300), ("ops", "H", 7100)],
    ["dept", "name", "salary"],
)

w = Window.partitionBy("dept").orderBy(col("salary").desc())

(df
 .withColumn("rank", rank().over(w))
 .withColumn("dense_rank", dense_rank().over(w))
 .withColumn("prev_salary", lag("salary").over(w))
 .withColumn("next_salary", lead("salary").over(w))
 .orderBy("dept", "rank")
 .show())

spark.stop()
