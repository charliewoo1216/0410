"""
S13. cache / persist — 반복 사용 DataFrame 캐싱
- cache()   = persist(MEMORY_AND_DISK)
- persist() = StorageLevel 직접 지정
"""
import time
from pyspark import StorageLevel
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("cache").master("local[*]").getOrCreate()

df = spark.range(0, 5_000_000)
heavy = df.selectExpr("id", "id % 7 AS bucket", "id * id AS sq")

# 캐싱 없이
t0 = time.time(); heavy.count();             t_no_1 = time.time() - t0
t0 = time.time(); heavy.groupBy("bucket").count().collect(); t_no_2 = time.time() - t0
print(f"[캐시 X]  count: {t_no_1:.3f}s, groupBy: {t_no_2:.3f}s")

# 캐싱
heavy.persist(StorageLevel.MEMORY_AND_DISK)
heavy.count()  # warm-up

t0 = time.time(); heavy.count();             t_yes_1 = time.time() - t0
t0 = time.time(); heavy.groupBy("bucket").count().collect(); t_yes_2 = time.time() - t0
print(f"[캐시 O]  count: {t_yes_1:.3f}s, groupBy: {t_yes_2:.3f}s")

heavy.unpersist()
spark.stop()
