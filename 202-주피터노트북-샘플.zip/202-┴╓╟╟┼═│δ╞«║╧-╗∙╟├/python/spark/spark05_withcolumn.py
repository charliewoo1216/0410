"""
S05. 파생 컬럼 — withColumn / expr / when
새 컬럼을 추가하거나 기존 컬럼을 가공한다.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, expr

spark = SparkSession.builder.appName("withcol").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [(1, "Alice", 5500), (2, "Bob", 8200), (3, "Carol", 4500), (4, "Dan", 6800)],
    ["id", "name", "salary"],
)

result = (
    df
    .withColumn("salary_k", col("salary") / 1000)
    .withColumn(
        "grade",
        when(col("salary") >= 7000, "A")
        .when(col("salary") >= 5000, "B")
        .otherwise("C")
    )
    .withColumn("note", expr("CASE WHEN salary >= 7000 THEN '우수' ELSE '평균' END"))
)

result.show()

spark.stop()
