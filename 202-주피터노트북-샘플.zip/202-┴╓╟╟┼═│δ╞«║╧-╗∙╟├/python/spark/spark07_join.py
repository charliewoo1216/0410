"""
S07. Join — inner / left / broadcast
broadcast() 는 한쪽 테이블이 작을 때 셔플 없이 모든 executor 로 복제.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast

spark = SparkSession.builder.appName("join").master("local[*]").getOrCreate()

employees = spark.createDataFrame(
    [(1, "A", "D01"), (2, "B", "D02"), (3, "C", "D01"), (4, "D", "D03")],
    ["id", "name", "dept_code"],
)
depts = spark.createDataFrame(
    [("D01", "dev"), ("D02", "mkt"), ("D04", "fin")],
    ["dept_code", "dept_name"],
)

print("[INNER JOIN]")
employees.join(depts, "dept_code", "inner").show()

print("[LEFT JOIN]")
employees.join(depts, "dept_code", "left").show()

print("[BROADCAST JOIN — 작은 테이블을 모든 노드에 복제]")
employees.join(broadcast(depts), "dept_code", "inner").show()

spark.stop()
