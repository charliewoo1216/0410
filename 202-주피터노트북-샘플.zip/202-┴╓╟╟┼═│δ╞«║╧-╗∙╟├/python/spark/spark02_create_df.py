"""
S02. DataFrame 생성 (리스트 / Pandas / 스키마 지정)
"""
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType
import pandas as pd

spark = SparkSession.builder.appName("create").master("local[*]").getOrCreate()

# 1) 리스트 → DataFrame (스키마 추론)
df1 = spark.createDataFrame(
    [(1, "Alice", 5500.0), (2, "Bob", 6200.0), (3, "Carol", 4800.0)],
    schema=["id", "name", "salary"],
)
df1.printSchema()
df1.show()

# 2) 명시적 스키마
schema = StructType([
    StructField("id",     IntegerType(), False),
    StructField("name",   StringType(),  True),
    StructField("salary", DoubleType(),  True),
])
df2 = spark.createDataFrame([(4, "Dan", 7100.0)], schema)
df2.show()

# 3) Pandas → Spark
pdf = pd.DataFrame({"x": range(5), "y": [i * 2 for i in range(5)]})
df3 = spark.createDataFrame(pdf)
df3.show()

spark.stop()
