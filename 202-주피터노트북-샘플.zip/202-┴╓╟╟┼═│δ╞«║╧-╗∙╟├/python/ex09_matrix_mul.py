"""
예제 9. 행렬 연산
2×3 행렬과 3×2 행렬을 곱하여 결과 행렬을 출력한다.
"""
import numpy as np

A = np.array([[1, 2, 3],
              [4, 5, 6]])
B = np.array([[7, 8],
              [9, 10],
              [11, 12]])

print(f"A shape : {A.shape}")
print(f"B shape : {B.shape}")
print("\n@ 연산자:")
print(A @ B)
print("\nnp.matmul:")
print(np.matmul(A, B))
print("\nnp.dot:")
print(np.dot(A, B))
