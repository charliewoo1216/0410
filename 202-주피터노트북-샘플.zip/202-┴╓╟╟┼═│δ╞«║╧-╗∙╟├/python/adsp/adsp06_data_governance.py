"""
A06. 데이터 품질 점검
중복 / 결측 / 이상치 / 범위 검증을 한 번에 수행한다.
"""
import pandas as pd
import numpy as np

df = pd.DataFrame({
    "id":    [1, 2, 2, 3, 4, 5, 6],
    "age":   [25, 30, 30, np.nan, 35, 200, -5],   # 200, -5는 이상치
    "score": [80, 85, 85, 90, 75, np.nan, 95],
})

print("[원본]")
print(df)

# 1) 중복
dup = df.duplicated()
print(f"\n중복 행 수: {dup.sum()}")
print(df[dup])

# 2) 결측
print(f"\n결측 합계:\n{df.isnull().sum()}")

# 3) 이상치 (age는 0~120 범위 가정)
out = df[(df["age"] < 0) | (df["age"] > 120)]
print(f"\n범위 이탈 (age):\n{out}")

# 4) 정제 후
clean = (
    df.drop_duplicates()
      .dropna()
      .query("0 <= age <= 120")
      .reset_index(drop=True)
)
print(f"\n[정제 후]")
print(clean)
print(f"\n원본 {len(df)}행 → 정제 {len(clean)}행")
