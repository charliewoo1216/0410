"""
A03. 빅데이터 3V / 5V
Volume / Velocity / Variety / Veracity / Value
"""
import time
import json
import random
import string

# Volume: 대용량
vol = list(range(1_000_000))
print(f"[Volume]   배열 크기: {len(vol):,}")

# Velocity: 초당 처리량
t0 = time.time()
events = [random.random() for _ in range(100_000)]
print(f"[Velocity] 10만건 생성 시간: {time.time() - t0:.3f}s")

# Variety: 다양한 형식
structured = {"id": 1, "v": 10}
semi = json.dumps({"id": 1, "tags": ["a", "b"]})
unstructured = "Free-form text log entry " + "".join(random.choices(string.ascii_letters, k=20))
print(f"[Variety]")
print(f"  structured  : {structured}")
print(f"  semi (json) : {semi}")
print(f"  unstructured: {unstructured[:50]}...")

# Veracity: 데이터 신뢰성 (결측/오류)
samples = [10, 12, None, "N/A", 11, -999, 14]
clean = [v for v in samples if isinstance(v, (int, float)) and v >= 0 and v < 100]
print(f"[Veracity] 원본 {len(samples)}건 → 정제 {len(clean)}건 ({clean})")

# Value: 최종 가치 (의사결정 근거)
print(f"[Value]    정제 후 평균: {sum(clean)/len(clean):.2f} → 의사결정 입력 가능")
