"""
A12. 로지스틱 회귀 + Odds Ratio
- Odds Ratio = exp(coef): 변수 1단위 증가 시 사건 확률 비
"""
import numpy as np
import pandas as pd
import statsmodels.api as sm

np.random.seed(0)
n = 500
age = np.random.randint(20, 70, n)
income = np.random.normal(5000, 1500, n)
logit = -3 + 0.05 * age + 0.0003 * income
prob = 1 / (1 + np.exp(-logit))
buy = np.random.binomial(1, prob)

X = sm.add_constant(pd.DataFrame({"age": age, "income": income}))
y = pd.Series(buy)

model = sm.Logit(y, X).fit(disp=False)
print(model.summary().tables[1])

print("\n[Odds Ratio]")
for col, coef in model.params.items():
    print(f"  {col}: OR = {np.exp(coef):.4f}")
