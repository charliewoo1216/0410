"""
A13. 의사결정나무 — 지니계수 vs 엔트로피
같은 데이터를 두 분할 기준으로 학습해 정확도와 트리 모양을 비교한다.
"""
from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

X, y = load_iris(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0)

for crit in ["gini", "entropy"]:
    tree = DecisionTreeClassifier(criterion=crit, max_depth=3, random_state=0).fit(X_tr, y_tr)
    acc = accuracy_score(y_te, tree.predict(X_te))
    print(f"\n[{crit.upper()}] accuracy = {acc:.4f}")
    print(export_text(tree, feature_names=load_iris().feature_names))
