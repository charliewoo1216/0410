"""
A20. 분류 성능 — 혼동행렬 / 정밀도 / 재현율 / F1 / ROC-AUC
- 정밀도 (Precision) = TP / (TP + FP)
- 재현율 (Recall)    = TP / (TP + FN)
- F1                = 정밀도와 재현율의 조화 평균
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    confusion_matrix, classification_report,
    roc_auc_score, roc_curve,
)

data = load_breast_cancer()
X_tr, X_te, y_tr, y_te = train_test_split(
    data.data, data.target, test_size=0.3, random_state=0, stratify=data.target
)

model = LogisticRegression(max_iter=2000).fit(X_tr, y_tr)
pred = model.predict(X_te)
prob = model.predict_proba(X_te)[:, 1]

print("[혼동 행렬]")
print(confusion_matrix(y_te, pred))
print("\n[분류 리포트]")
print(classification_report(y_te, pred, target_names=data.target_names))

auc = roc_auc_score(y_te, prob)
print(f"ROC-AUC: {auc:.4f}")

fpr, tpr, _ = roc_curve(y_te, prob)
plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
plt.plot([0, 1], [0, 1], "--", color="gray")
plt.xlabel("FPR"); plt.ylabel("TPR")
plt.title("ROC Curve")
plt.legend()
plt.tight_layout()
plt.show()
