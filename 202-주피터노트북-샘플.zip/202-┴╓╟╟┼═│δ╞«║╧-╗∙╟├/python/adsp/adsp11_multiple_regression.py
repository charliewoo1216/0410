"""
A11. 다중 회귀 + 다중공선성 (VIF)
- VIF > 10 이면 해당 변수가 다른 변수와 강한 선형 관계 (다중공선성 의심).
"""
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

np.random.seed(0)
n = 200
x1 = np.random.normal(0, 1, n)
x2 = np.random.normal(0, 1, n)
x3 = 0.95 * x1 + 0.1 * np.random.normal(0, 1, n)   # x1 과 강한 상관 → VIF 높음
y = 2 * x1 + 3 * x2 - x3 + np.random.normal(0, 1, n)

df = pd.DataFrame({"x1": x1, "x2": x2, "x3": x3})
X = sm.add_constant(df)
model = sm.OLS(y, X).fit()
print(model.summary().tables[1])

print("\n[VIF]")
for col in df.columns:
    vif = variance_inflation_factor(X.values, X.columns.get_loc(col))
    flag = "⚠ 다중공선성 의심" if vif > 10 else ""
    print(f"  {col}: VIF = {vif:.2f} {flag}")
