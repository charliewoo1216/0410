"""
A18. 주성분분석 (PCA) 차원 축소
iris 4차원 → 2차원으로 축소하고 누적 분산을 본다.
"""
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

data = load_iris()
X = StandardScaler().fit_transform(data.data)

pca = PCA(n_components=4).fit(X)
print("[설명 분산 비율]")
for i, ratio in enumerate(pca.explained_variance_ratio_, 1):
    print(f"  PC{i}: {ratio:.4f}")
print(f"  누적(2개): {pca.explained_variance_ratio_[:2].sum():.4f}")

X2 = PCA(n_components=2).fit_transform(X)
plt.figure(figsize=(7, 5))
for label in range(3):
    mask = data.target == label
    plt.scatter(X2[mask, 0], X2[mask, 1], label=data.target_names[label])
plt.xlabel("PC1"); plt.ylabel("PC2")
plt.title("Iris PCA Projection")
plt.legend()
plt.tight_layout()
plt.show()
