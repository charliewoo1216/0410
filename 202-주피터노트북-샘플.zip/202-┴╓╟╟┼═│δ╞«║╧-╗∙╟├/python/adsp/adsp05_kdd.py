"""
A05. KDD 프로세스
Selection → Preprocessing → Transformation → Data Mining → Evaluation
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

np.random.seed(0)
raw = pd.DataFrame({
    "id": range(200),
    "x": np.random.normal(0, 1, 200),
    "y": np.random.normal(0, 1, 200),
    "noise_col": np.random.choice(["A", "B", None], 200),
})

# 1) Selection: 분석 목적과 무관한 컬럼 제거, 분석 대상만 선택
sel = raw[["x", "y"]].copy()
print(f"[1] Selection: shape={sel.shape}")

# 2) Preprocessing: 결측·이상치 제거, 노이즈 제거
sel = sel.dropna()
print(f"[2] Preprocessing: dropna 후 shape={sel.shape}")

# 3) Transformation: 스케일링·차원 축소
scaled = StandardScaler().fit_transform(sel)
print(f"[3] Transformation: 표준화 완료, mean≈{scaled.mean():.2e}")

# 4) Data Mining: K-means 군집
km = KMeans(n_clusters=3, n_init=10, random_state=0).fit(scaled)
sel["cluster"] = km.labels_
print(f"[4] Data Mining: 군집 결과")
print(sel.groupby("cluster").size())

# 5) Evaluation: 실루엣
from sklearn.metrics import silhouette_score
score = silhouette_score(scaled, km.labels_)
print(f"[5] Evaluation: silhouette={score:.4f} (1에 가까울수록 좋음)")
