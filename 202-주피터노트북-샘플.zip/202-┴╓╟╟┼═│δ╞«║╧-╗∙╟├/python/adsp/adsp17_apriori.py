"""
A17. 연관 규칙 (Apriori)
지지도(support) / 신뢰도(confidence) / 향상도(lift) 계산
- pip install mlxtend
"""
import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules

# 거래 데이터: 각 행이 한 번의 구매
transactions = [
    ["빵", "우유"],
    ["빵", "기저귀", "맥주", "달걀"],
    ["우유", "기저귀", "맥주", "콜라"],
    ["빵", "우유", "기저귀", "맥주"],
    ["빵", "우유", "기저귀", "콜라"],
]

# one-hot 인코딩
items = sorted({i for tr in transactions for i in tr})
df = pd.DataFrame([[i in tr for i in items] for tr in transactions], columns=items)

freq = apriori(df, min_support=0.4, use_colnames=True)
rules = association_rules(freq, metric="confidence", min_threshold=0.6)

print("[빈발 항목 집합]")
print(freq)

print("\n[연관 규칙 — confidence ≥ 0.6, lift 기준 정렬]")
print(rules.sort_values("lift", ascending=False)
           [["antecedents", "consequents", "support", "confidence", "lift"]]
           .reset_index(drop=True))
