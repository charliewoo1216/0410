"""
A01. DIKW 피라미드 — Data → Information → Knowledge → Wisdom
센서가 측정한 온도 값을 단계별로 가공하며 의미가 어떻게 변하는지 본다.
"""
# Data: 가공되지 않은 원시값
data = ["20.5", "21.3", "19.8", "22.1", "20.9", "21.5"]
print(f"[Data]        {data}")

# Information: 데이터를 의미 있는 형태로 가공
info = [float(x) for x in data]
print(f"[Information] mean={sum(info)/len(info):.2f}, n={len(info)}")

# Knowledge: 패턴/규칙을 추출
mean_t = sum(info) / len(info)
knowledge = "온도가 정상 범위(18~22°C) 내" if 18 <= mean_t <= 22 else "비정상"
print(f"[Knowledge]   {knowledge}")

# Wisdom: 행동 결정
wisdom = "쾌적한 환경이므로 냉방 가동 불필요" if knowledge.startswith("온도가 정상") else "공조 시스템 점검 권고"
print(f"[Wisdom]      {wisdom}")
