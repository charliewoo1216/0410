"""
A04. CRISP-DM 6단계 워크플로우
Business → Data Understanding → Data Preparation → Modeling → Evaluation → Deployment
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 1. Business Understanding
print("[1] Business: 광고 클릭 여부 예측 모델 구축")

# 2. Data Understanding
np.random.seed(0)
df = pd.DataFrame({
    "age": np.random.randint(18, 65, 500),
    "income": np.random.normal(5000, 1500, 500),
    "click": np.random.binomial(1, 0.3, 500),
})
print(f"[2] Data Understanding: shape={df.shape}, click 비율={df['click'].mean():.2%}")

# 3. Data Preparation
df["age_bin"] = pd.cut(df["age"], bins=[0, 25, 45, 100], labels=["young", "mid", "senior"])
X = pd.get_dummies(df[["age", "income", "age_bin"]], drop_first=True)
y = df["click"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0)
print(f"[3] Preparation: train={X_tr.shape}, test={X_te.shape}")

# 4. Modeling
model = LogisticRegression(max_iter=200).fit(X_tr, y_tr)
print(f"[4] Modeling: LogisticRegression 학습 완료")

# 5. Evaluation
acc = accuracy_score(y_te, model.predict(X_te))
print(f"[5] Evaluation: accuracy = {acc:.4f}")

# 6. Deployment
import joblib  # noqa
print("[6] Deployment: joblib.dump(model, 'model.pkl') 후 API 배포 (생략)")
