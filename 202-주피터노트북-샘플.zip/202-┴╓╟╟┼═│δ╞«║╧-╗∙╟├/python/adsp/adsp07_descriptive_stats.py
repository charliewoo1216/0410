"""
A07. 기술통계량 (평균/분산/표준편차/왜도/첨도)
- 왜도(skewness): 좌우 비대칭 정도 (양수: 우측꼬리 김)
- 첨도(kurtosis): 뾰족함 정도 (정규분포=0, 양수: 정규보다 뾰족)
"""
import numpy as np
from scipy import stats

np.random.seed(0)
normal = np.random.normal(0, 1, 1000)
right_skew = np.random.exponential(1, 1000)   # 양의 왜도
heavy_tail = np.random.standard_t(df=3, size=1000)  # 양의 첨도


def summarize(name, x):
    print(f"[{name}]")
    print(f"  평균   : {np.mean(x):>7.4f}")
    print(f"  분산   : {np.var(x, ddof=1):>7.4f}")
    print(f"  표준편차: {np.std(x, ddof=1):>7.4f}")
    print(f"  왜도   : {stats.skew(x):>7.4f}")
    print(f"  첨도   : {stats.kurtosis(x):>7.4f}")
    print()


summarize("정규분포 (정상)", normal)
summarize("지수분포 (우측 꼬리)", right_skew)
summarize("t분포 df=3 (두꺼운 꼬리)", heavy_tail)
