"""
A08. 상관계수 — 피어슨 / 스피어만 / 켄달
- 피어슨 : 선형 관계, 정규성 가정
- 스피어만: 순위 기반, 단조 관계
- 켄달   : 순위 기반, 작은 표본에 강건
"""
import pandas as pd
import numpy as np

np.random.seed(0)
n = 200
x = np.random.uniform(0, 10, n)
y_lin = 2 * x + np.random.normal(0, 1, n)         # 선형
y_log = np.log(x + 1) + np.random.normal(0, 0.1, n)  # 단조 비선형
y_rand = np.random.normal(0, 1, n)                # 무관

df = pd.DataFrame({"x": x, "linear": y_lin, "log_like": y_log, "random": y_rand})

for method in ["pearson", "spearman", "kendall"]:
    print(f"\n[{method.upper()}]")
    print(df.corr(method=method).round(3))
