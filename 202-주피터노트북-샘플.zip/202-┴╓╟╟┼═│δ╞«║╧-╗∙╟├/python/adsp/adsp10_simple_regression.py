"""
A10. 단순 선형 회귀 + 가정 진단
statsmodels OLS 의 summary 와 잔차 진단 플롯을 본다.
"""
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt

np.random.seed(0)
x = np.linspace(0, 10, 100)
y = 3 * x + 5 + np.random.normal(0, 2, 100)

X = sm.add_constant(x)
model = sm.OLS(y, X).fit()
print(model.summary())

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
axes[0].scatter(x, y); axes[0].plot(x, model.fittedvalues, "r-"); axes[0].set_title("Fit")
axes[1].scatter(model.fittedvalues, model.resid)
axes[1].axhline(0, color="red")
axes[1].set_title("Residual vs Fitted")
plt.tight_layout()
plt.show()

print(f"\n결정계수 R² = {model.rsquared:.4f}")
