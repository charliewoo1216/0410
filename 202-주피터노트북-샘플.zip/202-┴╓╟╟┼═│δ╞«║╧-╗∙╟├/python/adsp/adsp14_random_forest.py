"""
A14. 랜덤포레스트 변수 중요도
앙상블 모델로 학습 후 각 feature 의 중요도를 출력한다.
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = load_breast_cancer()
X, y = data.data, data.target
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)

rf = RandomForestClassifier(n_estimators=200, random_state=0, n_jobs=-1).fit(X_tr, y_tr)
print(f"accuracy = {accuracy_score(y_te, rf.predict(X_te)):.4f}")

idx = np.argsort(rf.feature_importances_)[::-1][:10]
top_names = [data.feature_names[i] for i in idx]
top_imp = rf.feature_importances_[idx]

print("\n[중요도 Top 10]")
for n, imp in zip(top_names, top_imp):
    print(f"  {n:<30} {imp:.4f}")

plt.figure(figsize=(8, 4))
plt.barh(top_names[::-1], top_imp[::-1])
plt.title("Random Forest Feature Importance (Top 10)")
plt.tight_layout()
plt.show()
