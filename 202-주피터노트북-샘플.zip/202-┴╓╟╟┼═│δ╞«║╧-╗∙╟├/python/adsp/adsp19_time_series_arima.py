"""
A19. ARIMA 모형 적합
- ARIMA(p, d, q): AR차수 / 차분차수 / MA차수
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA

np.random.seed(0)
ts = pd.date_range("2025-01-01", periods=120, freq="D")
trend = np.linspace(10, 30, 120)
season = 5 * np.sin(np.arange(120) * 2 * np.pi / 30)
noise = np.random.normal(0, 1, 120)
y = pd.Series(trend + season + noise, index=ts, name="value")

model = ARIMA(y, order=(1, 1, 1)).fit()
print(model.summary().tables[1])

forecast = model.forecast(steps=20)

plt.figure(figsize=(10, 4))
y.plot(label="observed")
forecast.plot(label="forecast (20)", color="red")
plt.title("ARIMA(1,1,1) forecast")
plt.legend()
plt.tight_layout()
plt.show()
