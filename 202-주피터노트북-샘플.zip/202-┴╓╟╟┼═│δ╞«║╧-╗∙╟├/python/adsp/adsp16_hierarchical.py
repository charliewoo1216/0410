"""
A16. 계층적 군집 (덴드로그램)
ward 연결법으로 거리 행렬을 만든 뒤 덴드로그램을 그린다.
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from sklearn.datasets import make_blobs

X, _ = make_blobs(n_samples=30, centers=3, cluster_std=1.0, random_state=0)

Z = linkage(X, method="ward")

plt.figure(figsize=(10, 5))
dendrogram(Z)
plt.title("Hierarchical Clustering Dendrogram (ward)")
plt.xlabel("sample index")
plt.ylabel("distance")
plt.tight_layout()
plt.show()

# 거리 임계값을 정해 군집 자르기
labels = fcluster(Z, t=10, criterion="distance")
print(f"\n임계 거리 10 기준 군집 수: {len(set(labels))}")
print(f"각 군집 크기: {np.bincount(labels)[1:]}")
