"""
A15. K-means + 엘보우 / 실루엣
적정 K 를 결정하기 위한 두 가지 지표를 함께 본다.
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

X, _ = make_blobs(n_samples=400, centers=4, cluster_std=1.0, random_state=0)

ks = range(2, 9)
inertias, silhouettes = [], []
for k in ks:
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X)
    inertias.append(km.inertia_)
    silhouettes.append(silhouette_score(X, km.labels_))

print(f"{'k':>3} {'inertia':>12} {'silhouette':>12}")
for k, i, s in zip(ks, inertias, silhouettes):
    print(f"{k:>3} {i:>12.2f} {s:>12.4f}")

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
axes[0].plot(ks, inertias, "o-"); axes[0].set_title("Elbow"); axes[0].set_xlabel("k")
axes[1].plot(ks, silhouettes, "o-"); axes[1].set_title("Silhouette"); axes[1].set_xlabel("k")
plt.tight_layout()
plt.show()
