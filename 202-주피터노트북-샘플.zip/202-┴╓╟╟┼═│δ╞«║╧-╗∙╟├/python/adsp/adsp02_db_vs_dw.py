"""
A02. OLTP vs OLAP
- OLTP: 짧고 잦은 트랜잭션 (주문 입력, 회원 가입)
- OLAP: 큰 범위의 집계 분석 (월별 매출, 코호트 분석)
"""
import sqlite3
import time

con = sqlite3.connect(":memory:")
cur = con.cursor()
cur.execute("CREATE TABLE orders(id INTEGER, user TEXT, amount REAL, ts TEXT)")

# --- OLTP 시뮬레이션: 1만 건의 짧은 INSERT ---
t0 = time.time()
for i in range(10_000):
    cur.execute("INSERT INTO orders VALUES (?, ?, ?, ?)",
                (i, f"u{i % 100}", (i % 50) * 1.5, "2025-10-10"))
con.commit()
print(f"[OLTP] 1만건 INSERT  : {time.time() - t0:.3f}s")

# --- OLAP 시뮬레이션: 사용자별 매출 합계 ---
t0 = time.time()
rows = cur.execute("SELECT user, SUM(amount), COUNT(*) FROM orders GROUP BY user").fetchall()
print(f"[OLAP] GROUP BY 집계 : {time.time() - t0:.3f}s")
print(f"  상위 3명: {sorted(rows, key=lambda r: -r[1])[:3]}")

print("\n특성 비교:")
print(f"  OLTP: 행 단위 처리, 정규화, 짧은 트랜잭션 (응답시간 ms)")
print(f"  OLAP: 컬럼 단위 처리, 비정규화, 대량 스캔 (응답시간 s~min)")
