"""
A09. 가설 검정 — t / 카이제곱 / ANOVA
- 두 집단 평균 차이      → t-test
- 범주형 변수 독립성     → chi-square
- 세 집단 이상 평균 비교 → ANOVA
"""
import numpy as np
from scipy import stats

np.random.seed(0)

# 1) 독립표본 t-검정
a = np.random.normal(50, 10, 100)
b = np.random.normal(55, 10, 100)
t, p = stats.ttest_ind(a, b)
print(f"[t-test]   t={t:.4f}, p={p:.4f}  → {'유의 (H0 기각)' if p < 0.05 else '유의x'}")

# 2) 카이제곱 (성별 × 흡연 여부)
table = np.array([[30, 10], [20, 40]])  # 행: 남/여, 열: 흡연/비흡연
chi2, p, dof, exp = stats.chi2_contingency(table)
print(f"[chi2]     chi2={chi2:.4f}, dof={dof}, p={p:.4f}")

# 3) ANOVA (세 그룹의 평균 비교)
g1 = np.random.normal(50, 5, 30)
g2 = np.random.normal(55, 5, 30)
g3 = np.random.normal(60, 5, 30)
f, p = stats.f_oneway(g1, g2, g3)
print(f"[ANOVA]    F={f:.4f}, p={p:.4f}")
