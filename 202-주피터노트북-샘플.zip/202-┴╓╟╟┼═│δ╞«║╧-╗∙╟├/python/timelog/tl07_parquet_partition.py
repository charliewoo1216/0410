"""
T07. Parquet 파티션 쓰기 (year/month/day)
시간 컬럼을 키로 디렉토리를 분할해 쿼리 시 partition pruning 이 가능하도록 한다.
"""
import pandas as pd
import numpy as np
from pathlib import Path

np.random.seed(0)
ts = pd.date_range("2025-09-28", "2025-10-03", freq="1H")
df = pd.DataFrame({
    "ts": ts,
    "value": np.random.randn(len(ts)),
})
df["year"] = df["ts"].dt.year
df["month"] = df["ts"].dt.month
df["day"] = df["ts"].dt.day

OUT = Path("logs_partitioned")
df.to_parquet(OUT, partition_cols=["year", "month", "day"], index=False)

print(f"파티션 디렉토리 구조:")
for p in sorted(OUT.rglob("*.parquet")):
    print(f"  {p.relative_to(OUT)}")

print("\n[10/01 데이터만 읽기]")
filt = pd.read_parquet(OUT, filters=[("year", "=", 2025), ("month", "=", 10), ("day", "=", 1)])
print(filt.head())
print(f"행수: {len(filt)}")
