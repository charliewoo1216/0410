"""
T01. Drain3 로 첫 템플릿 추출
파스 트리를 이용해 가변 토큰을 와일드카드(<*>)로 치환한 템플릿을 추출한다.
- pip install drain3
"""
from drain3 import TemplateMiner

LOGS = [
    "User alice logged in from 192.168.1.5",
    "User bob   logged in from 10.0.0.7",
    "User carol logged in from 172.16.0.3",
    "Disk usage 78% on /dev/sda1",
    "Disk usage 92% on /dev/sda2",
    "Connection refused at host db01:5432",
    "Connection refused at host db02:5432",
]

tm = TemplateMiner()
for log in LOGS:
    res = tm.add_log_message(log)
    print(f"id={res['cluster_id']:>2} | {res['template_mined']}")

print("\n[추출된 템플릿 목록]")
for cluster in tm.drain.clusters:
    print(f"  cluster #{cluster.cluster_id} (size={cluster.size}): {cluster.get_template()}")
