"""
T06. DataFrame → Parquet 저장 (Snappy 압축)
- pip install pyarrow
"""
import pandas as pd
import numpy as np
import os

np.random.seed(0)
df = pd.DataFrame({
    "ts": pd.date_range("2025-10-10", periods=10_000, freq="1s"),
    "level": np.random.choice(["INFO", "WARN", "ERROR"], 10_000, p=[0.85, 0.1, 0.05]),
    "service": np.random.choice(["api", "db", "cache", "auth"], 10_000),
    "duration_ms": np.random.lognormal(mean=4, sigma=0.5, size=10_000),
})

df.to_parquet("logs.parquet", compression="snappy", index=False)
size_kb = os.path.getsize("logs.parquet") / 1024
print(f"저장 완료: logs.parquet  ({size_kb:.1f} KB)")

loaded = pd.read_parquet("logs.parquet")
print(f"\n불러온 shape: {loaded.shape}")
print(loaded.head())
print(f"\ndtypes:\n{loaded.dtypes}")
