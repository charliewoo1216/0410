"""
예제 23. 히스토그램과 KDE
정규분포 샘플에 대해 seaborn.histplot(kde=True)로 분포를 시각화한다.
"""
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

np.random.seed(42)
samples = np.random.normal(loc=0, scale=1, size=1000)

plt.figure(figsize=(8, 5))
sns.histplot(samples, bins=30, kde=True, color="steelblue")
plt.title("Normal Distribution with KDE (n=1000)")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()
