"""
L14. 사용자 퍼널 분석
view → add_cart → checkout → pay 단계별 전환율을 계산한다.
"""
import pandas as pd
import numpy as np

np.random.seed(0)
USERS = 10_000

# 단계별 도달 확률 모델
view = np.arange(USERS)
add_cart = view[np.random.rand(USERS) < 0.45]
checkout = add_cart[np.random.rand(len(add_cart)) < 0.50]
pay = checkout[np.random.rand(len(checkout)) < 0.70]

stages = [
    ("view", len(view)),
    ("add_cart", len(add_cart)),
    ("checkout", len(checkout)),
    ("pay", len(pay)),
]

df = pd.DataFrame(stages, columns=["stage", "users"])
df["abs_pct"] = df["users"] / df["users"].iloc[0] * 100
df["step_pct"] = df["users"].pct_change().fillna(0).mul(100).add(100)

print(df.round(2))

print(f"\n전체 전환율(view→pay): {df['abs_pct'].iloc[-1]:.2f}%")
