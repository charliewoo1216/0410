"""
L12. 변경점 탐지 (PELT 알고리즘)
- 시계열의 평균/분산이 갑자기 바뀌는 시점을 자동으로 찾는다.
- pip install ruptures
"""
import numpy as np
import matplotlib.pyplot as plt
import ruptures as rpt

np.random.seed(0)
# 3개 구간을 가진 가짜 신호 (각 구간 평균 다름)
seg = [np.random.normal(loc=mu, scale=1, size=100) for mu in (5, 10, 3)]
signal = np.concatenate(seg)

algo = rpt.Pelt(model="rbf").fit(signal)
breakpoints = algo.predict(pen=10)
print(f"탐지된 변경점 인덱스: {breakpoints}")

plt.figure(figsize=(10, 4))
plt.plot(signal)
for bp in breakpoints[:-1]:
    plt.axvline(bp, color="red", linestyle="--", label=f"bp={bp}")
plt.title("Change-point detection (PELT, RBF cost)")
plt.legend()
plt.tight_layout()
plt.show()
