"""
L04. URL Top-N 과 Pareto(80/20) 분석
요청량 상위 엔드포인트를 식별하고 누적 비율로 핵심 URL을 가려낸다.
"""
import pandas as pd
import numpy as np

np.random.seed(0)
urls = (
    ["/api/users"] * 500
    + ["/api/orders"] * 300
    + ["/api/products"] * 200
    + ["/api/login"] * 150
    + ["/static/css"] * 80
    + ["/static/js"] * 60
    + ["/api/admin"] * 30
    + ["/api/health"] * 10
)
np.random.shuffle(urls)

s = pd.Series(urls)
top = s.value_counts()
cum_pct = top.cumsum() / top.sum() * 100

result = pd.DataFrame({"count": top, "cum_pct": cum_pct.round(2)})
print(result)

over80 = result[result["cum_pct"] <= 80]
print(f"\n전체 트래픽의 80%를 차지하는 URL 수: {len(over80) + 1}개")
