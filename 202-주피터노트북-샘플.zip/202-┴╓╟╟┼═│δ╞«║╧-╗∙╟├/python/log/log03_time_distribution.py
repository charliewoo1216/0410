"""
L03. 시간대별 요청량 분포
타임스탬프 컬럼을 인덱스로 둔 뒤 1시간 단위로 resample 하여 트래픽 분포를 본다.
"""
import pandas as pd
import numpy as np

np.random.seed(0)
ts = pd.date_range("2025-10-10 00:00", "2025-10-11 00:00", freq="2min")
# 낮 시간대(9~18시)에 더 많은 트래픽이 발생하도록 가중
weights = np.where((ts.hour >= 9) & (ts.hour <= 18), 4, 1)
counts = np.random.poisson(lam=weights * 5, size=len(ts))

df = pd.DataFrame({"ts": ts, "requests": counts}).set_index("ts")

hourly = df.resample("1H").sum()
print("[시간대별 합계]")
print(hourly)
print(f"\n피크 시간: {hourly.idxmax().iloc[0]}  ({hourly.max().iloc[0]} req/h)")
