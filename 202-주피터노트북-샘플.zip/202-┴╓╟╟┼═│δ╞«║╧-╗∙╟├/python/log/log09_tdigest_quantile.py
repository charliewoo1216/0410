"""
L09. t-Digest 로 응답시간 P50 / P95 / P99 추정
- 큰 데이터셋에서도 메모리 일정으로 분위수를 정확히 추정.
- pip install tdigest
"""
import numpy as np
from tdigest import TDigest

np.random.seed(0)
# log-normal 분포 응답시간 (꼬리가 긴 분포)
rt = np.random.lognormal(mean=4.5, sigma=0.6, size=100_000)

td = TDigest()
for v in rt:
    td.update(v)

print(f"표본 수: {len(rt):,}")
print(f"{'분위수':<6} {'정확':>10} {'t-Digest':>10}")
for p in [50, 90, 95, 99]:
    exact = np.percentile(rt, p)
    estim = td.percentile(p)
    print(f"P{p:<5} {exact:>10.2f} {estim:>10.2f}")
