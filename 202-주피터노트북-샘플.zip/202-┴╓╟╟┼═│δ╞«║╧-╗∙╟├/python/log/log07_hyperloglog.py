"""
L07. HyperLogLog 로 unique IP 근사 카운트
- 정확 카운트 대비 메모리를 1/1000 수준으로 줄이면서 1~2% 오차로 근사한다.
- pip install datasketch
"""
import numpy as np
from datasketch import HyperLogLog

np.random.seed(0)
TRUE_UNIQUE = 5000
TOTAL_EVENTS = 200_000

unique_pool = [f"10.0.{i//256}.{i%256}" for i in range(TRUE_UNIQUE)]
events = np.random.choice(unique_pool, TOTAL_EVENTS)

# 정확 카운트
exact = len(set(events))

# HLL 근사
hll = HyperLogLog(p=12)  # p=12 → 약 4KB
for ip in events:
    hll.update(ip.encode())
estimated = int(hll.count())

print(f"이벤트 수      : {TOTAL_EVENTS:,}")
print(f"정확 unique    : {exact:,}")
print(f"HLL 추정       : {estimated:,}")
print(f"오차           : {abs(exact - estimated) / exact:.2%}")
