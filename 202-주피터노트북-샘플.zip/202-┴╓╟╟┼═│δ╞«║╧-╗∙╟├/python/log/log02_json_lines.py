"""
L02. JSON-lines 로그를 DataFrame 으로 변환
한 줄 당 한 개의 JSON 객체로 구성된 jsonl 포맷을 처리한다.
"""
import json
import pandas as pd
from io import StringIO

JSONL = """\
{"ts":"2025-10-10T10:00:00","level":"INFO","service":"api","msg":"start"}
{"ts":"2025-10-10T10:00:01","level":"ERROR","service":"db","msg":"connection refused","code":500}
{"ts":"2025-10-10T10:00:02","level":"WARN","service":"api","msg":"slow query","duration_ms":1280}
{"ts":"2025-10-10T10:00:03","level":"INFO","service":"api","msg":"request ok","duration_ms":35}
{"ts":"2025-10-10T10:00:04","level":"ERROR","service":"db","msg":"timeout","code":504}
"""

records = [json.loads(line) for line in StringIO(JSONL) if line.strip()]
df = pd.json_normalize(records)
df["ts"] = pd.to_datetime(df["ts"])

print(df)
print("\n[레벨별 카운트]")
print(df["level"].value_counts())
print("\n[서비스별 평균 duration_ms]")
print(df.groupby("service")["duration_ms"].mean(numeric_only=True))
