"""
L11. IQR 기반 이상치 탐지
분포 가정 없이 사분위수 범위를 이용해 이상치를 식별한다 (Tukey's fences).
"""
import numpy as np
import pandas as pd

np.random.seed(0)
data = np.concatenate([
    np.random.normal(50, 5, size=200),
    [120, 130, -20, -30, 110],  # 명확한 이상치
])
df = pd.DataFrame({"value": data})

q1, q3 = df["value"].quantile([0.25, 0.75])
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr

df["outlier"] = (df["value"] < lower) | (df["value"] > upper)

print(f"Q1 = {q1:.2f},  Q3 = {q3:.2f},  IQR = {iqr:.2f}")
print(f"허용 범위: [{lower:.2f}, {upper:.2f}]")
print(f"\n이상치 {df['outlier'].sum()}건:")
print(df[df["outlier"]])
