"""
L13. 세션 재구성 (idle timeout 30분)
사용자별 이벤트 사이의 간격이 30분을 넘으면 새 세션으로 분리한다.
"""
import pandas as pd

events = pd.DataFrame({
    "user": ["A", "A", "A", "A", "B", "B", "B", "A"],
    "ts":   pd.to_datetime([
        "2025-10-10 09:00", "2025-10-10 09:05", "2025-10-10 09:25",
        "2025-10-10 11:00",  # 이전과 95분 간격 → 새 세션
        "2025-10-10 09:10", "2025-10-10 09:12", "2025-10-10 10:30",
        "2025-10-10 11:10",  # A의 두 번째 세션 이어서
    ]),
})

events = events.sort_values(["user", "ts"]).reset_index(drop=True)
events["gap_min"] = events.groupby("user")["ts"].diff().dt.total_seconds() / 60
events["new_session"] = events["gap_min"].isna() | (events["gap_min"] > 30)
events["session_id"] = events.groupby("user")["new_session"].cumsum()
events["session_key"] = events["user"] + "-" + events["session_id"].astype(str)

print(events)

print("\n[세션별 이벤트 수]")
print(events.groupby("session_key").size())
