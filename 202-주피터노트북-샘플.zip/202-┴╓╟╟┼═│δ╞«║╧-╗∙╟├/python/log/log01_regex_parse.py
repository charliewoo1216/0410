"""
L01. 정규식으로 Apache access log 파싱
Combined Log Format 을 정규식으로 분해하여 DataFrame으로 변환한다.
"""
import re
import pandas as pd

LOGS = [
    '127.0.0.1 - - [10/Oct/2025:13:55:36 +0900] "GET /api/users HTTP/1.1" 200 1024',
    '192.168.0.5 - alice [10/Oct/2025:13:55:40 +0900] "POST /api/login HTTP/1.1" 401 256',
    '10.0.0.7  - bob   [10/Oct/2025:13:56:01 +0900] "GET /static/main.css HTTP/1.1" 200 8821',
    '10.0.0.7  - bob   [10/Oct/2025:13:56:02 +0900] "GET /api/orders HTTP/1.1" 500 64',
    '127.0.0.1 - -     [10/Oct/2025:13:56:10 +0900] "GET /api/users HTTP/1.1" 200 1100',
]

PATTERN = re.compile(
    r'(?P<ip>\S+)\s+\S+\s+(?P<user>\S+)\s+'
    r'\[(?P<time>[^\]]+)\]\s+'
    r'"(?P<method>\S+)\s+(?P<url>\S+)\s+\S+"\s+'
    r'(?P<status>\d+)\s+(?P<size>\d+)'
)

records = [m.groupdict() for line in LOGS if (m := PATTERN.match(line))]
df = pd.DataFrame(records)
df["time"] = pd.to_datetime(df["time"], format="%d/%b/%Y:%H:%M:%S %z")
df["status"] = df["status"].astype(int)
df["size"] = df["size"].astype(int)

print(df)
print(f"\nshape: {df.shape}")
print(f"dtypes:\n{df.dtypes}")
