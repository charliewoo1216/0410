"""
L06. 로그 레벨 × 시간 pivot heatmap
시간×레벨 매트릭스로 변환해 시간대별 이상 신호를 한눈에 본다.
"""
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

np.random.seed(0)
n = 5000
ts = pd.to_datetime("2025-10-10") + pd.to_timedelta(np.random.rand(n) * 24, unit="h")
levels = np.random.choice(["INFO", "WARN", "ERROR"], n, p=[0.85, 0.10, 0.05])
df = pd.DataFrame({"ts": ts, "level": levels})
df["hour"] = df["ts"].dt.hour

pivot = df.pivot_table(index="level", columns="hour", values="ts", aggfunc="count", fill_value=0)
print(pivot)

plt.figure(figsize=(12, 3))
sns.heatmap(pivot, cmap="YlOrRd", annot=True, fmt="d", cbar=True)
plt.title("Hour x Log-level heatmap")
plt.tight_layout()
plt.show()
