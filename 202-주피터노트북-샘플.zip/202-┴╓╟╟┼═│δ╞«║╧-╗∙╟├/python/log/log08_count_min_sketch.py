"""
L08. Count-Min Sketch 로 메모리 절약형 빈도 추정
- 해시 함수 d개 × 카운터 w개의 2D 배열을 사용한 확률적 자료구조.
- 항상 실제 빈도 이상으로 추정 (overestimate).
"""
import hashlib
import numpy as np
from collections import Counter


class CountMinSketch:
    def __init__(self, w: int = 1024, d: int = 5):
        self.w, self.d = w, d
        self.table = np.zeros((d, w), dtype=np.int64)

    def _h(self, x: str, i: int) -> int:
        return int(hashlib.md5(f"{i}:{x}".encode()).hexdigest(), 16) % self.w

    def add(self, x: str):
        for i in range(self.d):
            self.table[i, self._h(x, i)] += 1

    def estimate(self, x: str) -> int:
        return int(min(self.table[i, self._h(x, i)] for i in range(self.d)))


np.random.seed(0)
items = np.random.choice([f"key{i}" for i in range(1000)], 50_000, p=None)

cms = CountMinSketch(w=512, d=5)
for it in items:
    cms.add(it)

exact = Counter(items)
top = exact.most_common(10)

print(f"{'key':<10} {'exact':>8} {'cms':>8} {'err':>5}")
for k, c in top:
    e = cms.estimate(k)
    print(f"{k:<10} {c:>8} {e:>8} {(e - c):>5}")
