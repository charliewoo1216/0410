"""
L05. 5xx 에러율 추이와 이동평균
HTTP 상태 코드를 분 단위로 묶어 에러율을 산출하고 10분 이동평균으로 추세를 본다.
"""
import pandas as pd
import numpy as np

np.random.seed(0)
ts = pd.date_range("2025-10-10 00:00", periods=600, freq="1min")
# 평소엔 1%, 200~250분 구간에 장애 발생 (20% 에러율)
err_prob = np.where((np.arange(600) > 200) & (np.arange(600) < 250), 0.2, 0.01)
status = np.where(np.random.rand(600) < err_prob, 500, 200)

df = pd.DataFrame({"ts": ts, "status": status}).set_index("ts")
df["is_err"] = df["status"] >= 500

err_rate = df["is_err"].astype(int).resample("1min").mean()
ma10 = err_rate.rolling(10, min_periods=1).mean()

result = pd.concat([err_rate.rename("err_rate"), ma10.rename("ma10")], axis=1)
print(result.head(20))
print(f"\n최대 에러율 시각: {err_rate.idxmax()}  ({err_rate.max():.2%})")
