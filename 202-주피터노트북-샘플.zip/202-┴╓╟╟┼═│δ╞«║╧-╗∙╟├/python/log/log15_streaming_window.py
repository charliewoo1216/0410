"""
L15. 슬라이딩 윈도우 실시간 통계 시뮬레이션
deque 기반 60초 슬라이딩 윈도우로 RPS를 계산한다.
"""
import time
from collections import deque

WINDOW_SEC = 60


class SlidingWindow:
    def __init__(self, window_sec: int):
        self.window = window_sec
        self.events: deque = deque()

    def add(self, ts: float):
        self.events.append(ts)
        self._evict(ts)

    def _evict(self, now: float):
        while self.events and self.events[0] < now - self.window:
            self.events.popleft()

    def rps(self, now: float) -> float:
        self._evict(now)
        return len(self.events) / self.window


# 시뮬레이션: 0~120초 사이에 2초 간격으로 이벤트 발생, 60~80초 구간 밀집
sw = SlidingWindow(WINDOW_SEC)
fake_now = 0
for sec in range(0, 121):
    burst = 10 if 60 <= sec <= 80 else 1
    for _ in range(burst):
        sw.add(sec)
    if sec % 10 == 0:
        print(f"t={sec:>3}s | events_in_window={len(sw.events):>4} | rps={sw.rps(sec):.2f}")
