"""
L10. z-score 기반 트래픽 이상치 탐지
정상 분포로 가정하고 |z| > 3 인 점을 이상치로 판정한다.
"""
import numpy as np
import pandas as pd
from scipy.stats import zscore

np.random.seed(0)
ts = pd.date_range("2025-10-10 00:00", periods=120, freq="1min")
traffic = np.random.normal(loc=200, scale=20, size=120)
# 일부 시점에 스파이크 주입
traffic[40] = 350
traffic[75] = 80
traffic[100] = 400

df = pd.DataFrame({"ts": ts, "rps": traffic})
df["z"] = zscore(df["rps"])
df["outlier"] = df["z"].abs() > 3

print("[이상치 후보]")
print(df[df["outlier"]])
