"""
예제 4. 배열 연산
두 개의 1차원 배열에 대해 element-wise 합/차/곱/나눗셈, 내적(dot product)을 계산한다.
"""
import numpy as np

a = np.array([1, 2, 3, 4, 5])
b = np.array([10, 20, 30, 40, 50])

print(f"a = {a}")
print(f"b = {b}")
print(f"a + b = {a + b}")
print(f"a - b = {a - b}")
print(f"a * b = {a * b}")
print(f"b / a = {b / a}")
print(f"내적   = {np.dot(a, b)}")
