"""
예제 24. 산점도와 상관관계
iris 데이터셋에서 꽃잎 길이와 너비의 산점도를 그리고 피어슨 상관계수를 계산한다.
"""
import seaborn as sns
import matplotlib.pyplot as plt

iris = sns.load_dataset("iris")
corr = iris["petal_length"].corr(iris["petal_width"])
print(f"피어슨 상관계수 (petal_length vs petal_width): {corr:.4f}")

plt.figure(figsize=(8, 5))
sns.scatterplot(data=iris, x="petal_length", y="petal_width", hue="species", s=60)
plt.title(f"Iris petal length vs width (r = {corr:.3f})")
plt.tight_layout()
plt.show()
