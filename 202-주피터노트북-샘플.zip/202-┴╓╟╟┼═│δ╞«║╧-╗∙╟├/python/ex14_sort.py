"""
예제 14. 정렬과 인덱싱
연봉 기준 내림차순 정렬 후 상위 5명을 head()로 출력한다.
"""
import pandas as pd

df = pd.DataFrame({
    "이름": ["김민준", "이서연", "박지호", "최수아", "정도윤",
             "한예준", "강하은", "조시우", "윤지유", "임건우"],
    "연봉": [5200, 4800, 7200, 4500, 6300, 5500, 8000, 4200, 4900, 5900],
})

sorted_df = df.sort_values("연봉", ascending=False).reset_index(drop=True)

print("[연봉 내림차순 정렬]")
print(sorted_df)

print("\n[상위 5명]")
print(sorted_df.head(5))
