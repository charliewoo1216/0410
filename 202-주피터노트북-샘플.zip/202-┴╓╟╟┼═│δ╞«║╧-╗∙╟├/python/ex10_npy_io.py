"""
예제 10. 파일 입출력
NumPy 배열을 .npy 파일로 저장하고 다시 불러와 동일한지 검증한다.
"""
import numpy as np

arr = np.arange(20).reshape(4, 5)
np.save("array_sample.npy", arr)

loaded = np.load("array_sample.npy")

print("저장 배열:")
print(arr)
print("\n불러온 배열:")
print(loaded)
print(f"\n동일 여부: {np.array_equal(arr, loaded)}")
