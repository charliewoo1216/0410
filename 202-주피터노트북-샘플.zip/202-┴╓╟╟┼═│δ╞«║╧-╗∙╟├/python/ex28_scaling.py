"""
예제 28. 스케일링
StandardScaler와 MinMaxScaler를 적용한 결과를 원본과 함께 비교 시각화한다.
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, MinMaxScaler

np.random.seed(0)
data = np.random.randn(100, 1) * 20 + 50

std = StandardScaler().fit_transform(data)
mm = MinMaxScaler().fit_transform(data)

print(f"원본       mean={data.mean():.3f},  std={data.std():.3f}")
print(f"Standard   mean={std.mean():.3f},  std={std.std():.3f}")
print(f"MinMax     min ={mm.min():.3f},  max={mm.max():.3f}")

fig, axes = plt.subplots(1, 3, figsize=(12, 4))
axes[0].hist(data, bins=20, color="gray"); axes[0].set_title("Original")
axes[1].hist(std, bins=20, color="steelblue"); axes[1].set_title("StandardScaler")
axes[2].hist(mm, bins=20, color="orange"); axes[2].set_title("MinMaxScaler")
plt.tight_layout()
plt.show()
