"""
예제 8. 난수 시드 고정
np.random.seed(42)를 적용하여 재현 가능한 난수 배열을 만들고, 시드 미적용 결과와 비교한다.
"""
import numpy as np

np.random.seed(42)
fixed_a = np.random.rand(5)

np.random.seed(42)
fixed_b = np.random.rand(5)

free_a = np.random.rand(5)
free_b = np.random.rand(5)

print("[Seed 42 고정]")
print(f"fixed_a = {fixed_a}")
print(f"fixed_b = {fixed_b}")
print(f"동일?    {np.array_equal(fixed_a, fixed_b)}")

print("\n[Seed 미고정 (이전 상태 이어감)]")
print(f"free_a  = {free_a}")
print(f"free_b  = {free_b}")
print(f"동일?    {np.array_equal(free_a, free_b)}")
