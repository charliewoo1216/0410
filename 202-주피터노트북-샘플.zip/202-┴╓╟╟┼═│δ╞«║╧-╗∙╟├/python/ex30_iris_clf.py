"""
예제 30. 분류 모델 기초
iris 데이터셋을 train/test로 나눈 뒤 LogisticRegression으로 분류하고 정확도를 평가한다.
"""
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

iris = load_iris()
X, y = iris.data, iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)
print(f"학습셋: {X_train.shape}, 테스트셋: {X_test.shape}")

model = LogisticRegression(max_iter=200).fit(X_train, y_train)
pred = model.predict(X_test)

print(f"\n정확도(accuracy): {accuracy_score(y_test, pred):.4f}")
print("\n[분류 리포트]")
print(classification_report(y_test, pred, target_names=iris.target_names))

print("[혼동 행렬]")
print(confusion_matrix(y_test, pred))
