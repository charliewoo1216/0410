"""
예제 16. 결측치 처리
일부 셀을 NaN으로 만든 뒤 fillna(평균/0)와 dropna() 결과를 비교한다.
"""
import pandas as pd
import numpy as np

df = pd.DataFrame({
    "name": ["A", "B", "C", "D", "E"],
    "score": [80, np.nan, 75, np.nan, 90],
    "age":   [25, 30, np.nan, 28, 35],
})

print("[원본]")
print(df)
print(f"\n결측치 수:\n{df.isnull().sum()}")

print("\n[평균으로 채움]")
print(df.fillna(df[["score", "age"]].mean()))

print("\n[0으로 채움]")
print(df.fillna(0))

print("\n[결측 행 제거]")
print(df.dropna())
