"""
예제 27. subplot 구성
2×2 서브플롯에 라인/막대/히스토그램/산점도를 한 캔버스에 배치한다.
"""
import matplotlib.pyplot as plt
import numpy as np

np.random.seed(0)
x = np.arange(10)
y = np.random.rand(10)

fig, axes = plt.subplots(2, 2, figsize=(10, 8))

axes[0, 0].plot(x, y, marker="o")
axes[0, 0].set_title("Line")

axes[0, 1].bar(x, y, color="orange")
axes[0, 1].set_title("Bar")

axes[1, 0].hist(np.random.randn(500), bins=20, color="steelblue", edgecolor="black")
axes[1, 0].set_title("Histogram")

axes[1, 1].scatter(np.random.rand(50), np.random.rand(50), c="green", alpha=0.6)
axes[1, 1].set_title("Scatter")

plt.tight_layout()
plt.show()
