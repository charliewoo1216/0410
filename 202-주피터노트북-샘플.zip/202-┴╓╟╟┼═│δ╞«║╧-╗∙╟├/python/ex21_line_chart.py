"""
예제 21. 라인 차트
시계열 매출 데이터를 라인 차트로 그리고, 제목/축 레이블/범례를 한글로 표시한다.
"""
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

matplotlib.rcParams["font.family"] = "Malgun Gothic"
matplotlib.rcParams["axes.unicode_minus"] = False

np.random.seed(0)
months = pd.date_range("2025-01", periods=12, freq="M")
sales = np.random.randint(1000, 5000, size=12)

plt.figure(figsize=(10, 5))
plt.plot(months, sales, marker="o", linewidth=2, label="월별 매출")
plt.title("2025년 월별 매출 추이")
plt.xlabel("월")
plt.ylabel("매출 (만원)")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
