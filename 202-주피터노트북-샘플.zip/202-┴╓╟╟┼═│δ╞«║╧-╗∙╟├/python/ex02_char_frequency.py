"""
예제 2. 딕셔너리로 빈도수 계산
문자열에 등장하는 각 알파벳의 빈도수를 딕셔너리로 계산하여 내림차순 정렬한다.
"""

text = "Data analysis with Python is fun and powerful"

freq = {}
for ch in text.lower():
    if ch.isalpha():
        freq[ch] = freq.get(ch, 0) + 1

sorted_freq = sorted(freq.items(), key=lambda x: x[1], reverse=True)

print(f"입력 문자열: {text}")
print(f"고유 알파벳 수: {len(freq)}")
print("\n빈도수 (내림차순):")
for ch, count in sorted_freq:
    print(f"  {ch}: {count}")
