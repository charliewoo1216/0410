"""
예제 22. 막대 차트
부서별 평균 연봉을 막대 차트로 시각화하고 값 레이블을 막대 위에 표기한다.
"""
import matplotlib
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = "Malgun Gothic"
matplotlib.rcParams["axes.unicode_minus"] = False

depts = ["개발팀", "마케팅팀", "디자인팀", "영업팀"]
salaries = [6500, 5000, 4500, 7000]
colors = ["#4C72B0", "#DD8452", "#55A467", "#C44E52"]

plt.figure(figsize=(8, 5))
bars = plt.bar(depts, salaries, color=colors)
plt.title("부서별 평균 연봉")
plt.ylabel("연봉 (만원)")
plt.ylim(0, max(salaries) * 1.15)

for bar in bars:
    h = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, h + 100,
             f"{h:,}", ha="center", va="bottom", fontweight="bold")

plt.tight_layout()
plt.show()
