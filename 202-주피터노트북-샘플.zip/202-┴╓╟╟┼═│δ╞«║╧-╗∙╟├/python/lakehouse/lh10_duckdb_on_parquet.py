"""
LH10. DuckDB 로 Parquet 직접 쿼리
- Spark 없이도 단일 프로세스에서 Parquet 위에 SQL 가능.
- pip install duckdb pandas pyarrow
"""
import duckdb
import pandas as pd
import numpy as np
from pathlib import Path

# 0) 데모용 Parquet 생성
np.random.seed(0)
N = 100_000
df = pd.DataFrame({
    "ts": pd.date_range("2025-10-01", periods=N, freq="1min"),
    "level": np.random.choice(["INFO", "WARN", "ERROR"], N, p=[0.85, 0.10, 0.05]),
    "service": np.random.choice(["api", "db", "auth", "cache"], N),
    "duration_ms": np.random.lognormal(4, 0.5, N),
})
Path("logs").mkdir(exist_ok=True)
df.to_parquet("logs/data.parquet", compression="snappy", index=False)

con = duckdb.connect()

print("[1] 단순 카운트")
print(con.sql("SELECT COUNT(*) FROM 'logs/*.parquet'").fetchone())

print("\n[2] 레벨별 분포")
con.sql("""
    SELECT level, COUNT(*) AS n
    FROM 'logs/*.parquet'
    GROUP BY level
    ORDER BY n DESC
""").show()

print("[3] ERROR 만 추출 + 응답시간 P95")
con.sql("""
    SELECT service,
           COUNT(*)               AS errors,
           ROUND(AVG(duration_ms), 1)        AS avg_ms,
           ROUND(QUANTILE_CONT(duration_ms, 0.95), 1) AS p95_ms
    FROM 'logs/*.parquet'
    WHERE level = 'ERROR'
    GROUP BY service
    ORDER BY errors DESC
""").show()
