"""
LH07. Apache Iceberg 테이블 + Schema Evolution
- packages: org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.0
- catalog 는 hadoop catalog 로 로컬 디렉토리 사용.
"""
from pyspark.sql import SparkSession

spark = (
    SparkSession.builder.appName("iceberg").master("local[*]")
    .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.0")
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
    .config("spark.sql.catalog.local.type", "hadoop")
    .config("spark.sql.catalog.local.warehouse", "file:///tmp/iceberg-warehouse")
    .getOrCreate()
)

spark.sql("CREATE NAMESPACE IF NOT EXISTS local.demo")
spark.sql("DROP TABLE IF EXISTS local.demo.events")
spark.sql("""
    CREATE TABLE local.demo.events (
        id BIGINT,
        ts TIMESTAMP,
        kind STRING
    ) USING iceberg
""")

spark.sql("INSERT INTO local.demo.events VALUES (1, current_timestamp(), 'click')")
spark.sql("INSERT INTO local.demo.events VALUES (2, current_timestamp(), 'view')")
spark.sql("SELECT * FROM local.demo.events").show()

# Schema evolution: 컬럼 추가
spark.sql("ALTER TABLE local.demo.events ADD COLUMN user_id STRING")
spark.sql("INSERT INTO local.demo.events VALUES (3, current_timestamp(), 'pay', 'u123')")
spark.sql("SELECT * FROM local.demo.events").show()

print("[스냅샷 히스토리]")
spark.sql("SELECT * FROM local.demo.events.history").show(truncate=False)

spark.stop()
