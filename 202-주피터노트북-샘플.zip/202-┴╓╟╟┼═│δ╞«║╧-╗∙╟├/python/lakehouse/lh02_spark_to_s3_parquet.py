"""
LH02. Spark → MinIO(S3) Parquet 쓰기
- s3a 커넥터(hadoop-aws)와 aws-java-sdk JAR 가 필요.
- packages 옵션으로 자동 다운로드.
"""
from pyspark.sql import SparkSession

spark = (
    SparkSession.builder
    .appName("spark-s3")
    .master("local[*]")
    .config("spark.jars.packages",
            "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262")
    .config("spark.hadoop.fs.s3a.endpoint", "http://localhost:9000")
    .config("spark.hadoop.fs.s3a.access.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.secret.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.path.style.access", "true")
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    .getOrCreate()
)

df = spark.createDataFrame(
    [(1, "Alice", 5500), (2, "Bob", 6200), (3, "Carol", 4800)],
    ["id", "name", "salary"],
)

PATH = "s3a://warehouse/employees/"
df.write.mode("overwrite").parquet(PATH)
print(f"쓰기 완료: {PATH}")

loaded = spark.read.parquet(PATH)
loaded.show()
print(f"행 수: {loaded.count()}")

spark.stop()
