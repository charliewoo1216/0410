"""
LH01. 로컬 MinIO 컨테이너로 S3 호환 환경 구성
1) Docker 로 MinIO 실행:
     docker run -d -p 9000:9000 -p 9001:9001 \
       -e "MINIO_ROOT_USER=minioadmin" \
       -e "MINIO_ROOT_PASSWORD=minioadmin" \
       --name minio quay.io/minio/minio server /data --console-address ":9001"
2) 콘솔 접속: http://localhost:9001  (minioadmin / minioadmin)
3) 본 스크립트로 버킷 생성·파일 업로드 검증
- pip install minio
"""
from minio import Minio
from minio.error import S3Error
from io import BytesIO

client = Minio(
    "localhost:9000",
    access_key="minioadmin",
    secret_key="minioadmin",
    secure=False,
)

BUCKET = "warehouse"

if not client.bucket_exists(BUCKET):
    client.make_bucket(BUCKET)
    print(f"버킷 생성: {BUCKET}")
else:
    print(f"버킷 이미 존재: {BUCKET}")

# 텍스트 객체 업로드
data = b"hello, lakehouse!\n"
client.put_object(BUCKET, "hello.txt", BytesIO(data), length=len(data))
print(f"업로드: s3a://{BUCKET}/hello.txt ({len(data)} bytes)")

print("\n[버킷 내 객체 목록]")
for obj in client.list_objects(BUCKET, recursive=True):
    print(f"  {obj.object_name}  ({obj.size}B)")
