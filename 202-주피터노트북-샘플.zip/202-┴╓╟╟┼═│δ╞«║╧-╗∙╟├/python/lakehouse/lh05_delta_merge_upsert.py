"""
LH05. Delta Lake MERGE INTO — Upsert (SCD Type 1)
존재하는 키는 UPDATE, 없는 키는 INSERT.
"""
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip
from delta.tables import DeltaTable

builder = (
    SparkSession.builder.appName("delta-merge").master("local[*]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)
spark = configure_spark_with_delta_pip(builder).getOrCreate()

PATH = "/tmp/delta-merge"

base = spark.createDataFrame([(1, "A", 100), (2, "B", 200)], ["id", "name", "v"])
base.write.format("delta").mode("overwrite").save(PATH)
print("[초기]")
spark.read.format("delta").load(PATH).orderBy("id").show()

updates = spark.createDataFrame(
    [(2, "B", 999),  # 기존 키: UPDATE
     (3, "C", 300)], # 신규 키: INSERT
    ["id", "name", "v"],
)

(DeltaTable.forPath(spark, PATH).alias("t")
   .merge(updates.alias("u"), "t.id = u.id")
   .whenMatchedUpdate(set={"v": "u.v"})
   .whenNotMatchedInsertAll()
   .execute())

print("\n[MERGE 후]")
spark.read.format("delta").load(PATH).orderBy("id").show()

spark.stop()
