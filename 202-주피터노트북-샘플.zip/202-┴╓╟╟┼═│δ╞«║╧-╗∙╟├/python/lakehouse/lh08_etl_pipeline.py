"""
LH08. 메달리온 아키텍처 — Bronze → Silver → Gold 파이프라인
- Bronze: 원본 그대로 적재
- Silver: 정제·중복 제거·타입 변환
- Gold:   비즈니스 메트릭 집계
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_timestamp, sum as ssum, count, when
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("medallion").master("local[*]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)
spark = configure_spark_with_delta_pip(builder).getOrCreate()

# ---------- Bronze: raw 텍스트 적재 ----------
raw = spark.createDataFrame(
    [
        ("2025-10-10 10:00:00", "u1", "view",  "p100"),
        ("2025-10-10 10:00:00", "u1", "view",  "p100"),  # 중복
        ("2025-10-10 10:05:00", "u1", "buy",   "p100"),
        ("2025-10-10 10:10:00", "u2", "view",  "p200"),
        ("2025-10-10 10:11:00", "u2", "buy",   "p200"),
        ("2025-10-10 10:30:00", None, "view",  "p100"),  # 결측
    ],
    ["ts_str", "user", "event", "product"],
)
raw.write.format("delta").mode("overwrite").save("/tmp/lh/bronze")

# ---------- Silver: 정제 ----------
silver = (
    spark.read.format("delta").load("/tmp/lh/bronze")
    .dropna(subset=["user"])
    .dropDuplicates()
    .withColumn("ts", to_timestamp("ts_str"))
    .drop("ts_str")
)
silver.write.format("delta").mode("overwrite").save("/tmp/lh/silver")
print("[Silver]")
silver.orderBy("ts").show()

# ---------- Gold: 사용자별 구매 메트릭 ----------
gold = (
    spark.read.format("delta").load("/tmp/lh/silver")
    .groupBy("user")
    .agg(
        count(when(col("event") == "view", 1)).alias("views"),
        count(when(col("event") == "buy",  1)).alias("buys"),
    )
    .withColumn("conv_rate", col("buys") / col("views"))
)
gold.write.format("delta").mode("overwrite").save("/tmp/lh/gold")
print("[Gold]")
gold.show()

spark.stop()
