"""
LH03. 파티션 키 설계 — date / region
시간·지역 기반 파티션은 쿼리 시 partition pruning 효과가 크다.
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_date

spark = SparkSession.builder.appName("partition").master("local[*]").getOrCreate()

df = spark.createDataFrame(
    [
        ("2025-10-08", "KR", 1, 1200),
        ("2025-10-08", "US", 2, 800),
        ("2025-10-09", "KR", 3, 1500),
        ("2025-10-09", "US", 4, 950),
        ("2025-10-10", "KR", 5, 1700),
        ("2025-10-10", "JP", 6, 600),
    ],
    ["date_str", "region", "order_id", "amount"],
).withColumn("order_date", to_date("date_str"))

OUT = "sales_partitioned/"
(df.write.mode("overwrite")
   .partitionBy("region", "order_date")
   .parquet(OUT))

print(f"쓰기 완료: {OUT}")

# 한 지역만 읽으면 다른 지역 디렉토리는 스캔하지 않음
kr = spark.read.parquet(OUT).filter("region = 'KR'")
print(f"\nKR 레코드: {kr.count()}건")
kr.show()

spark.stop()
