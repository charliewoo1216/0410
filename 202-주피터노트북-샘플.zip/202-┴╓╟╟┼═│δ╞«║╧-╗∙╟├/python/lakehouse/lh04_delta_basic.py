"""
LH04. Delta Lake 테이블 생성·읽기
- pip install delta-spark==3.2.0
- Spark 3.5 + Java 17 환경 권장
"""
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("delta-basic").master("local[*]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)
spark = configure_spark_with_delta_pip(builder).getOrCreate()

df = spark.createDataFrame(
    [(1, "A", 100), (2, "B", 200), (3, "C", 300)],
    ["id", "name", "amount"],
)

PATH = "/tmp/delta-employees"

# 1) 쓰기
df.write.format("delta").mode("overwrite").save(PATH)

# 2) 읽기
spark.read.format("delta").load(PATH).show()

# 3) DeltaTable 객체로도 접근 가능
from delta.tables import DeltaTable
dt = DeltaTable.forPath(spark, PATH)
print("\n[히스토리]")
dt.history().select("version", "timestamp", "operation").show(truncate=False)

spark.stop()
