"""
LH06. Delta Time Travel — 버전·타임스탬프 기반 조회
versionAsOf / timestampAsOf 옵션으로 과거 시점의 테이블을 조회한다.
"""
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("delta-tt").master("local[*]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)
spark = configure_spark_with_delta_pip(builder).getOrCreate()

PATH = "/tmp/delta-tt"

# v0
spark.createDataFrame([(1, 10), (2, 20)], ["id", "v"]) \
     .write.format("delta").mode("overwrite").save(PATH)

# v1
spark.createDataFrame([(3, 30)], ["id", "v"]) \
     .write.format("delta").mode("append").save(PATH)

# v2
spark.createDataFrame([(4, 40)], ["id", "v"]) \
     .write.format("delta").mode("append").save(PATH)

print("[현재 (v2)]")
spark.read.format("delta").load(PATH).orderBy("id").show()

print("[v0 시점]")
spark.read.format("delta").option("versionAsOf", 0).load(PATH).orderBy("id").show()

print("[v1 시점]")
spark.read.format("delta").option("versionAsOf", 1).load(PATH).orderBy("id").show()

spark.stop()
