"""
LH09. Structured Streaming → Delta Lake
Rate source 로 초당 N행을 생성해 Delta 테이블에 append 한다 (Kafka 대체 데모).
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("stream-to-delta").master("local[2]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)
spark = configure_spark_with_delta_pip(builder).getOrCreate()

DELTA_PATH = "/tmp/lh/streaming-delta"
CHECKPOINT = "/tmp/lh/streaming-checkpoint"

stream = (
    spark.readStream
    .format("rate")          # 매 초 N행 생성
    .option("rowsPerSecond", 100)
    .load()
    .withColumn("category", (col("value") % 5).cast("string"))
)

query = (
    stream.writeStream
    .format("delta")
    .outputMode("append")
    .option("checkpointLocation", CHECKPOINT)
    .trigger(processingTime="3 seconds")
    .start(DELTA_PATH)
)

# 15초간 실행 후 종료
query.awaitTermination(timeout=15)
query.stop()

print("\n[적재된 Delta 테이블]")
spark.read.format("delta").load(DELTA_PATH).groupBy("category").count().orderBy("category").show()

spark.stop()
