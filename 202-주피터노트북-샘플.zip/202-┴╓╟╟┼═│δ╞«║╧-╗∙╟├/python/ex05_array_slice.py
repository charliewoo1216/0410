"""
예제 5. 다차원 배열 슬라이싱
5×5 랜덤 행렬에서 대각선 원소를 추출하고, 2~4번째 행의 전체 컬럼을 슬라이싱한다.
"""
import numpy as np

np.random.seed(0)
mat = np.random.randint(0, 100, (5, 5))

print("원본 행렬:")
print(mat)

print("\n대각선:", np.diag(mat))
print("\n2~4번째 행 (인덱스 1~3):")
print(mat[1:4, :])

print("\n3번째 컬럼 (인덱스 2):")
print(mat[:, 2])
