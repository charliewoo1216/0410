"""
예제 18. 두 DataFrame 병합
직원 DataFrame과 부서 정보 DataFrame을 merge로 결합한다 (inner/left/right 비교).
"""
import pandas as pd

employees = pd.DataFrame({
    "id": [1, 2, 3, 4],
    "이름": ["김민준", "이서연", "박지호", "최수아"],
    "부서코드": ["D01", "D02", "D01", "D03"],
})

depts = pd.DataFrame({
    "부서코드": ["D01", "D02", "D04"],
    "부서명": ["개발팀", "마케팅팀", "재무팀"],
})

print("[employees]")
print(employees)
print("\n[depts]")
print(depts)

print("\n[INNER JOIN]")
print(employees.merge(depts, on="부서코드", how="inner"))

print("\n[LEFT JOIN]")
print(employees.merge(depts, on="부서코드", how="left"))

print("\n[RIGHT JOIN]")
print(employees.merge(depts, on="부서코드", how="right"))
