"""
예제 1. 리스트와 통계
주어진 정수 리스트의 평균, 중앙값, 표준편차를 직접 구현하고 statistics 모듈과 비교한다.
"""
import statistics

data = [12, 15, 18, 21, 25, 30, 33, 35, 40, 45]


def my_mean(values):
    return sum(values) / len(values)


def my_median(values):
    s = sorted(values)
    n = len(s)
    mid = n // 2
    if n % 2 == 0:
        return (s[mid - 1] + s[mid]) / 2
    return s[mid]


def my_stdev(values):
    m = my_mean(values)
    var = sum((x - m) ** 2 for x in values) / (len(values) - 1)
    return var ** 0.5


print("[직접 구현]")
print(f"평균   : {my_mean(data):.4f}")
print(f"중앙값 : {my_median(data):.4f}")
print(f"표준편차: {my_stdev(data):.4f}")

print("\n[statistics 모듈]")
print(f"평균   : {statistics.mean(data):.4f}")
print(f"중앙값 : {statistics.median(data):.4f}")
print(f"표준편차: {statistics.stdev(data):.4f}")
