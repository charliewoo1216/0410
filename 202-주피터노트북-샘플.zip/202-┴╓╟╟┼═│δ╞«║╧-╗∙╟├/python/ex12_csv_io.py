"""
예제 12. CSV 읽기/쓰기
DataFrame을 CSV로 저장하고, 다시 읽어와 컬럼 타입과 결측치를 확인한다.
"""
import pandas as pd

df = pd.DataFrame({
    "이름": ["김민준", "이서연", "박지호"],
    "나이": [29, 34, 41],
    "부서": ["개발팀", "마케팅팀", "개발팀"],
    "연봉": [5200, 4800, 7200],
})

df.to_csv("employees.csv", index=False, encoding="utf-8-sig")
print("CSV 저장 완료: employees.csv")

loaded = pd.read_csv("employees.csv")
print("\n[불러온 DataFrame]")
print(loaded)

print("\n[컬럼 타입]")
print(loaded.dtypes)

print("\n[결측치 수]")
print(loaded.isnull().sum())
