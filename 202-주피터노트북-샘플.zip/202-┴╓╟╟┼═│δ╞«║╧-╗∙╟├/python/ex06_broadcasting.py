"""
예제 6. 브로드캐스팅
3×3 행렬의 각 행에서 행 평균을 빼는 연산을 브로드캐스팅으로 구현한다.
"""
import numpy as np

mat = np.array([[1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]], dtype=float)

row_means = mat.mean(axis=1, keepdims=True)
centered = mat - row_means

print("원본:")
print(mat)
print(f"\n행 평균 shape: {row_means.shape}")
print(row_means)
print("\n중심화 결과 (각 행 평균이 0):")
print(centered)
print("\n각 행의 합:", centered.sum(axis=1))
