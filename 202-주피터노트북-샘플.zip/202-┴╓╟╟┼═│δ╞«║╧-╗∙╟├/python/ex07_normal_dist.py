"""
예제 7. 정규분포 샘플링
평균 0, 표준편차 1의 정규분포에서 1000개의 표본을 추출한 뒤 히스토그램을 그린다.
"""
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)
samples = np.random.normal(loc=0, scale=1, size=1000)

print(f"표본 수      : {len(samples)}")
print(f"표본 평균    : {samples.mean():.4f}")
print(f"표본 표준편차: {samples.std():.4f}")

plt.figure(figsize=(8, 5))
plt.hist(samples, bins=30, edgecolor='black', alpha=0.75)
plt.title("Normal Distribution Samples (n=1000)")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True, alpha=0.3)
plt.show()
