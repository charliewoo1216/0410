"""
예제 20. 시계열 데이터
일자별 매출 데이터를 만들어 월별 합계로 리샘플링한다.
"""
import pandas as pd
import numpy as np

np.random.seed(0)
dates = pd.date_range("2025-01-01", "2025-12-31", freq="D")
sales = np.random.randint(100, 1000, size=len(dates))

df = pd.DataFrame({"date": dates, "sales": sales}).set_index("date")
print(f"일자별 데이터 수: {len(df)}")
print(df.head())

monthly = df.resample("M").sum()
print("\n[월별 매출 합계]")
print(monthly)
