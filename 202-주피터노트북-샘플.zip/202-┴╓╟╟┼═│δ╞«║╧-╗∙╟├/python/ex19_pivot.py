"""
예제 19. pivot_table
부서×성별로 평균 연봉을 보여주는 피벗 테이블을 만든다.
"""
import pandas as pd

df = pd.DataFrame({
    "부서": ["개발팀", "개발팀", "마케팅팀", "마케팅팀", "영업팀", "영업팀",
             "개발팀", "영업팀"],
    "성별": ["M", "F", "M", "F", "M", "F", "F", "M"],
    "연봉": [5500, 6000, 4800, 5200, 7000, 6500, 5800, 7200],
})

pt = df.pivot_table(index="부서", columns="성별", values="연봉", aggfunc="mean")
print("[부서 × 성별 평균 연봉]")
print(pt)

print("\n[행/열 합계 추가]")
pt2 = df.pivot_table(index="부서", columns="성별", values="연봉",
                     aggfunc="mean", margins=True, margins_name="전체")
print(pt2)
