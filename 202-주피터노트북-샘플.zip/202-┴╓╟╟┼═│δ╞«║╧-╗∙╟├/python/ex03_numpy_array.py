"""
예제 3. NumPy 배열 생성
1부터 100까지의 정수를 담은 배열을 만들고, 짝수만 추출하여 새 배열을 생성한다.
"""
import numpy as np

arr = np.arange(1, 101)
even = arr[arr % 2 == 0]

print(f"원본 배열 shape : {arr.shape}")
print(f"짝수 배열 shape : {even.shape}")
print(f"짝수 처음 10개  : {even[:10]}")
print(f"짝수 합계       : {even.sum()}")
print(f"짝수 평균       : {even.mean():.2f}")
