"""
예제 25. 박스플롯
부서별 연봉 분포를 박스플롯으로 그리고 이상치를 식별한다.
"""
import matplotlib
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

matplotlib.rcParams["font.family"] = "Malgun Gothic"
matplotlib.rcParams["axes.unicode_minus"] = False

df = pd.DataFrame({
    "부서": ["개발팀"] * 5 + ["마케팅팀"] * 5 + ["영업팀"] * 5,
    "연봉": [5200, 7200, 5500, 5900, 9500,
             4800, 4900, 5200, 4500, 5100,
             6300, 8000, 6500, 7100, 6800],
})

plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x="부서", y="연봉", palette="pastel")
sns.stripplot(data=df, x="부서", y="연봉", color="black", size=4, alpha=0.6)
plt.title("부서별 연봉 분포 (박스플롯)")
plt.tight_layout()
plt.show()
