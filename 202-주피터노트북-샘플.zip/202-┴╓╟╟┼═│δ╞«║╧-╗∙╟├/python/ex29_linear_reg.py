"""
예제 29. 단순 선형 회귀
scikit-learn의 LinearRegression으로 (광고비, 매출) 가상 데이터를 학습하고 회귀선을 그린다.
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

np.random.seed(0)
ad = np.random.uniform(10, 100, 50).reshape(-1, 1)
sales = 3 * ad.flatten() + 50 + np.random.randn(50) * 20

model = LinearRegression().fit(ad, sales)
print(f"기울기: {model.coef_[0]:.4f}")
print(f"절편  : {model.intercept_:.4f}")
print(f"R²    : {model.score(ad, sales):.4f}")

xs = np.linspace(ad.min(), ad.max(), 100).reshape(-1, 1)

plt.figure(figsize=(8, 5))
plt.scatter(ad, sales, alpha=0.6, label="data")
plt.plot(xs, model.predict(xs), color="red", linewidth=2, label="regression")
plt.xlabel("Ad spend")
plt.ylabel("Sales")
plt.title("Simple Linear Regression: Ad spend vs Sales")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
