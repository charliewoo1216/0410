"""
.py 파일을 동일한 구조의 .ipynb로 일괄 변환한다.

- 입력 : python/<sub>/exXX_*.py
- 출력 : notebook/<sub>/exXX_*.ipynb
- 모듈 docstring(첫 줄)을 제목으로 추출하여 markdown 셀 1개,
  나머지 코드를 하나의 code 셀로 작성한다.
- 이미 존재하는 .ipynb 는 덮어쓰지 않는다(--force 옵션 시 덮어씀).

사용법:
    python _gen_notebooks.py
    python _gen_notebooks.py --force
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent
PY_ROOT = ROOT / "python"
NB_ROOT = ROOT / "notebook"
FORCE = "--force" in sys.argv


def split_docstring(code: str):
    """모듈 docstring을 추출. (title, desc, body) 반환."""
    src = code.lstrip()
    if not src.startswith('"""'):
        return "", "", code
    end = src.find('"""', 3)
    if end < 0:
        return "", "", code
    doc = src[3:end].strip()
    body = src[end + 3:].lstrip("\n")
    lines = [l.strip() for l in doc.split("\n") if l.strip()]
    title = lines[0] if lines else ""
    desc = "\n".join(lines[1:]) if len(lines) > 1 else ""
    return title, desc, body


def py_to_nb(py_path: Path, nb_path: Path):
    code = py_path.read_text(encoding="utf-8")
    title, desc, body = split_docstring(code)

    cells = []
    if title:
        md = f"# {title}\n\n{desc}" if desc else f"# {title}"
        cells.append({"cell_type": "markdown", "metadata": {}, "source": md})
    cells.append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": body.rstrip(),
    })

    nb = {
        "cells": cells,
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3.10"},
        },
        "nbformat": 4,
        "nbformat_minor": 4,
    }

    nb_path.parent.mkdir(parents=True, exist_ok=True)
    nb_path.write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")


def main():
    if not PY_ROOT.exists():
        print(f"[ERR] {PY_ROOT} 가 없습니다.")
        sys.exit(1)

    created, skipped = 0, 0
    for py in PY_ROOT.rglob("*.py"):
        rel = py.relative_to(PY_ROOT)
        nb = NB_ROOT / rel.with_suffix(".ipynb")
        if nb.exists() and not FORCE:
            skipped += 1
            continue
        py_to_nb(py, nb)
        created += 1
        print(f"  + {nb.relative_to(ROOT)}")

    print(f"\n생성: {created}개, 건너뜀: {skipped}개")


if __name__ == "__main__":
    main()
