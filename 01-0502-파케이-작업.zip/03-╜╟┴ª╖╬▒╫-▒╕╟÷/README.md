# 03-실제로그-구현

ASML 실제 공정을 최대한 반영한 **재현 가능한 합성 로그 세트**.
앞 폴더(`02-asml-xml-분석`)에서 정의한 XSD 골격과 `Event_log.old` 형식을 그대로 따르되, **lot 8개 / wafer 200장 / 약 830 이벤트** 규모로 키웠다.

> ⚠️ ASML 사내 실제 로그 포맷이 아니라 우리가 설계한 합성 데이터다. 단지 *현장에서 자주 보이는 비율과 패턴*(throughput, retry율, recal율 등)을 흉내 냈다.

---

## 1. 폴더 구성

```
03-실제로그-구현/
├── README.md             ← 이 파일
├── 실제로그규칙.md       ← 단일 진실원 (스펙)
├── generator.py          ← 모든 데이터를 만드는 단일 스크립트 (재현용)
├── Event_log.old         ← 2487 라인, 829 이벤트 × (2줄 + 빈 줄)
└── xml/                  ← XML 10개 (in-range 7 + out-of-range 3) — 모두 distinct ASML 공정
    │
    │── 7 in-range (Event_log 시간 범위 안, lot/eqp 모두 lot_01·eqp_01로 통일):
    ├── lot_01_eqp_01_euv_2026-04-30T06-00-00+09-00.xml      ← EUV (NXE:3600D)
    ├── lot_01_eqp_01_arf_imm_2026-04-30T06-02-00+09-00.xml  ← ArF immersion (NXT:2050i)
    ├── lot_01_eqp_01_krf_2026-04-30T06-06-00+09-00.xml      ← KrF (XT:860N)
    ├── lot_01_eqp_01_hna_euv_2026-04-30T06-11-00+09-00.xml  ← High-NA EUV (EXE:5200)
    ├── lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml  ← ArF dry (XT:1900i)
    ├── lot_01_eqp_01_ovl_2026-04-30T06-48-00+09-00.xml      ← YS overlay (S385)
    ├── lot_01_eqp_01_defect_2026-04-30T06-53-00+09-00.xml   ← e-beam Defect (eP5)
    │
    │── 3 out-of-range (Event_log에 라인 없음 — eqp/lot 그대로 유지):
    ├── lot_07_eqp_08_iline_2026-04-29T23-30-00+09-00.xml    ← 전날 i-line
    ├── lot_08_eqp_09_focus_2026-05-01T02-30-00+09-00.xml    ← 다음날 YS Focus
    └── lot_09_eqp_10_cdsem_2026-05-01T04-00-00+09-00.xml    ← 다음날 CD-SEM (eP6)
```

Event_log.old 시간 범위 (고정): **`2026-04-30 06:00:00.000` ~ `06:59:59.000` (정확히 1시간)**.
첫·마지막 이벤트 timestamp는 `generator.py`에서 명시적으로 클램프 → 시드 무관 고정.
1시간 안에 8 lot 처리를 위해 `TIME_SCALE = 0.2` (5배 압축) 적용. 자세한 사양은 `실제로그규칙.md` § 1-1, § 6-1 참조.

---

## 2. 시뮬레이션 스케줄 (2026-04-30 하루)

| 시각 | 장비 | 모델 | Lot | wafers | 종류 |
|---|---|---|---|---|---|
| 06:00 | eqp_01 | NXE:3600D | lot_04 | 25 | EUV 노광 |
| 09:11 | eqp_03 | XT:860N | lot_03 | 25 | KrF 노광 |
| 14:02 | eqp_03 | XT:860N | lot_06 | 25 | KrF 노광 |
| 18:02 | eqp_02 | NXT:2050i | lot_02 | 25 | ArF 노광 |
| 19:21 | eqp_04 | YieldStar S385 | lot_02 | 25 | overlay 검증 |
| 20:11 | eqp_05 | eP5 | lot_02 | 25 | 결함·CD 검사 |
| 21:30 | eqp_02 | NXT:2050i | lot_05 | 25 | ArF 노광 |
| 22:14 | eqp_01 | NXE:3600D | lot_01 | 25 | EUV 노광 |

같은 `lot_02`(`ARF007788.03`)가 ArF 노광 → YS overlay → eP5 검사로 **lot 라이프사이클을 횡단**한다 — 노광 ↔ 사후 검증 조인이 그대로 동작.

---

## 3. 실제 공정 반영 포인트

| 면 | 반영한 값 | 출처/근거 |
|---|---|---|
| EUV throughput | ~140 wph (wafer당 ~26 sec) | NXE:3600D 공식 사양 |
| ArF immersion throughput | ~295 wph (wafer당 ~12 sec) | NXT:2050i 공식 사양 |
| KrF throughput | 비슷한 자릿수 | XT:860N |
| 1 lot = 25 wafers | 표준 FOUP 단위 |  |
| EUV 노광 단계 | LOAD → STAGE_CALIB(μm) → ALIGN_COARSE(첫 wafer만) → ALIGN_FINE → EXPOSURE(필드 12개) → UNLOAD |  |
| Stage calibration recal율 | ~4% | 운영 통계 평균치 |
| Alignment retry율 | ~2.5% (EUV), ~2% (DUV) |  |
| Reticle stage WARN | ~2% per wafer |  |
| Z축 tolerance | 5 μm (recal 트리거 임계값) |  |

이번 시드(20260430)로 만든 이상 이벤트:
- **fail 2회** (ALIGN_FAIL → 재시도 후 RECOVERED)
- **recal 4회** (STAGE_CALIB Z축 초과)
- **warn 4회** (reticle stage 온도 등)

다른 시드로 재실행하면 분포가 달라진다.

---

## 4. Event_log.old 형식 (재확인)

```
<date> <time> <process> <event> <eqpid> <lotid> <waferid>
<phase> <result>
                                         ← blank line
<date> <time> <process> ...
<phase> <result>
```

- **1 이벤트 = 2 컨텐츠 줄 + 1 빈 줄**
- result: `success` / `fail` / `warn` / `recal`
- waferid: `wafer<slot>.<retry-pass>` (`wafer14.02` = 슬롯 14의 2회차 시도)

자세한 사양과 파서 코드는 `../02-asml-xml-분석/이벤트로그-특징.md` 참조.

---

## 5. 재실행

```bash
cd 03-실제로그-구현
python generator.py
```

- 시드는 `random.seed(20260430)` 으로 고정 → 항상 같은 결과
- 다른 시드를 원하면 `generator.py` 상단 `random.seed(...)` 값만 바꾸면 됨
- `SCHEDULE` 리스트를 늘리면 더 많은 lot 생성 가능 (20개 lot이면 ~5000라인)

---

## 6. 빠른 동작 확인 (Python)

```python
import pandas as pd
import xml.etree.ElementTree as ET

# 1) Event_log 적재
def load_event_log(path):
    with open(path, encoding="utf-8") as f:
        lines = [ln.rstrip() for ln in f if ln.strip()]
    rows = []
    for h, t in zip(lines[0::2], lines[1::2]):
        hp, tp = h.split(), t.split()
        rows.append(dict(timestamp=pd.to_datetime(f"{hp[0]} {hp[1]}"),
                         process=hp[2], event=hp[3], eqpid=hp[4],
                         lotid=hp[5], waferid=hp[6],
                         phase=tp[0], result=tp[1]))
    return pd.DataFrame(rows)

df = load_event_log("Event_log.old")
print(df["result"].value_counts())          # success/recal/warn/fail 빈도
print(df.groupby("eqpid").size())            # 장비별 이벤트 수

# 2) XML 적재 (EUV)
ns = {"e": "EUV3600"}
tree = ET.parse("xml/lot_01_eqp_01_euv.xml")
for w in tree.iterfind("e:Wafers/e:Wafer", ns):
    wid = w.findtext("e:WaferId", namespaces=ns)
    res = w.findtext("e:Alignment[e:Stage='FINE']/e:GridModel/e:Residual3Sigma_nm", namespaces=ns)
    print(wid, res)

# 3) Event_log + XML 조인 (recal 이벤트의 정밀 측정값 추적)
recal_df = df[df.result == "recal"]
print(recal_df[["timestamp","eqpid","lotid","waferid"]])
# → 각 recal 라인의 (eqpid, lotid, waferid)로 해당 XML의 StageCalibration.Axis[Z]를 직접 조회
```

---

## 7. 한계와 다음 단계

- 본 합성 로그는 **수치적 패턴**(빈도, throughput)은 그럴듯하지만, **원인 상관관계**(예: stage z-drift → CD 변동)는 들어 있지 않다. ML/이상 탐지 데모용으로 쓰려면 generator에 **상관 노이즈** 주입이 필요.
- XML은 5종 중 1 lot씩만 출력했다. 다른 lot에 대해서도 XML을 쓰고 싶으면 `generator.py` 하단 `write_*_xml(...)` 호출을 추가하면 된다.
- 현재 모든 이벤트가 같은 파일로 모이지만, 실제 팹에서는 **장비별 / 일자별 분할**이 일반적. 분할 출력이 필요하면 `EVENTS`를 `(eqpid, date)`로 group by 하여 파일을 나누면 된다.
