"""
ASML 실제 공정 반영 로그 생성기.

출력:
  - xml/<lotid>_<eqpid>.xml : 5종 장비별 1개씩
  - Event_log.old           : 약 2000라인 (이벤트 ~666개 × 3줄)

재현성을 위해 random.seed 고정.
실행:  python generator.py
"""

import random
from datetime import datetime, timedelta
from pathlib import Path

random.seed(20260430)

OUT = Path(__file__).parent
(OUT / "xml").mkdir(exist_ok=True)

# ──────────────────────────────────────────────────────────────────
# 장비 / 공정 / 일정
# ──────────────────────────────────────────────────────────────────
# in-range 7개 lot은 모두 eqp_01 단일 ID로 노출 (anonymization 또는 단일 통합 장비 가정).
# 내부 EQUIPMENT 룩업(model/recipe/ns)은 internal key로 그대로 진행.
# out-of-range 3개는 별개 ID(eqp_08/09/10) 유지 → Event_log 와 분리됨이 자연스럽게 보임.
OUTPUT_EQPID = {
    "eqp_01": "eqp_01", "eqp_02": "eqp_01", "eqp_03": "eqp_01",
    "eqp_04": "eqp_01", "eqp_05": "eqp_01", "eqp_06": "eqp_01", "eqp_07": "eqp_01",
    "eqp_08": "eqp_08", "eqp_09": "eqp_09", "eqp_10": "eqp_10",
}
def out_eqp(e): return OUTPUT_EQPID.get(e, e)

# in-range 7개 lot도 모두 lot_01로 통일.
# 내부 XML_DATA 키는 (internal_eqpid, internal_lotid)로 유지되어 lot별 데이터 분리는 보존됨.
OUTPUT_LOTID = {
    "lot_01": "lot_01", "lot_02": "lot_01", "lot_03": "lot_01",
    "lot_04": "lot_01", "lot_05": "lot_01", "lot_06": "lot_01",
    "lot_07": "lot_07", "lot_08": "lot_08", "lot_09": "lot_09",
}
def out_lot(l): return OUTPUT_LOTID.get(l, l)


EQUIPMENT = {
    "eqp_01": dict(model="NXE:3600D",       process="LITHO_EUV",     ns="EUV3600",
                   layer="METAL2",   recipe="5nm_BEOL_M2_v17",      software="TWINSCAN-EUV-2024.05",     reticle="RTC-EUV-9921A"),
    "eqp_02": dict(model="NXT:2050i",       process="LITHO_ARF_IMM", ns="NXT2050i",
                   layer="METAL3",   recipe="7nm_M3_overlay_v8",    software="TWINSCAN-ARF-IMM-2024.03", reticle="RTC-ARF-7733B"),
    "eqp_03": dict(model="XT:860N",         process="LITHO_KRF",     ns="XT860",
                   layer="VIA1",     recipe="40nm_VIA1_v5",         software="TWINSCAN-KRF-2023.09",     reticle="RTC-KRF-3344C"),
    "eqp_04": dict(model="YieldStar S385",  process="INSP_OVL",      ns="YS385",
                   layer="OVL_M3",   recipe="post_overlay_M3_v3",   software="YS-METRO-2024.02",         reticle=None),
    "eqp_05": dict(model="HMI eP5",         process="INSP_DEFECT",   ns="EBEAM",
                   layer="DEF_M3",   recipe="M3_post_overlay_v3",   software="HMI-EBEAM-2024.04",        reticle=None),
    "eqp_06": dict(model="EXE:5200",        process="LITHO_HNA_EUV", ns="EXE5200",
                   layer="METAL0",   recipe="2nm_BEOL_M0_v3",       software="TWINSCAN-HNA-EUV-2025.01", reticle="RTC-HNA-EUV-1100A"),
    "eqp_07": dict(model="XT:1900i",        process="LITHO_ARF_DRY", ns="XT1900",
                   layer="METAL5",   recipe="28nm_M5_dry_v2",       software="TWINSCAN-ARF-DRY-2023.11", reticle="RTC-ARF-DRY-5511D"),
    "eqp_08": dict(model="XT:400L",         process="LITHO_ILINE",   ns="XT400",
                   layer="IMPLANT1", recipe="130nm_IMP1_v1",        software="PAS-ILINE-2022.07",        reticle="RTC-ILINE-1101E"),
    "eqp_09": dict(model="YieldStar S250F", process="INSP_FOCUS",    ns="YS250F",
                   layer="FOC_M2",   recipe="focus_qual_M2_v2",     software="YS-FOCUS-2024.01",         reticle=None),
    "eqp_10": dict(model="HMI eP6",         process="METRO_CDSEM",   ns="EP6",
                   layer="CD_M1",    recipe="CD_M1_critical_v2",    software="HMI-CDSEM-2024.06",        reticle=None),
}

B = datetime(2026, 4, 30, 0, 0, 0)
def H(h, m=0): return B + timedelta(hours=h, minutes=m)

# (eqpid, lotid, start, kind, n_wafers)
# 모든 lot이 06:00:00 ~ 06:59:59 1시간 윈도우 안에서 시작·종료.
# 7개 lot ↔ 7 in-range XML ↔ Event_log: (lotid, eqpid) 1:1 매핑.
# lot_02는 ArF→OVL→Defect 3 공정 횡단 (eqpid 다름, lotid 동일).
SCHEDULE = [
    ("eqp_01", "lot_01", H(6,  0), "euv",     25),  # 06:00 EUV (첫 이벤트)
    ("eqp_02", "lot_02", H(6,  2), "arf_imm", 25),  # 06:02 ArF immersion (lot_02 시작)
    ("eqp_03", "lot_03", H(6,  6), "krf",     25),  # 06:06 KrF
    ("eqp_06", "lot_04", H(6, 11), "hna_euv", 25),  # 06:11 High-NA EUV (0.55 NA)
    ("eqp_07", "lot_05", H(6, 18), "arf_dry", 25),  # 06:18 ArF dry
    ("eqp_04", "lot_02", H(6, 48), "ovl",     25),  # 06:48 lot_02 → YS overlay
    ("eqp_05", "lot_02", H(6, 53), "defect",  25),  # 06:53 lot_02 → Defect (마지막, 06:59:59 종료)
]

# ──────────────────────────────────────────────────────────────────
# 보조 함수
# ──────────────────────────────────────────────────────────────────
# Event_log을 1시간 윈도우(06:00:00.000 ~ 06:59:59.000)에 맞추기 위한 시간 압축율.
# 1.0 = 실제 throughput(EUV ~26s/wafer 등) / 0.2 = 5배 빠르게 진행.
TIME_SCALE = 0.2

def jt(s, rel=0.06): return s * TIME_SCALE * (1 + random.uniform(-rel, rel))
def fmt_log(t):  return t.strftime("%Y-%m-%d %H:%M:%S.") + f"{t.microsecond//1000:03d}"
def fmt_iso(t):  return t.strftime("%Y-%m-%dT%H:%M:%S+09:00")

EVENTS = []  # 이벤트 누적 — eqpid·lotid 모두 out_* 매핑 후 저장 (Event_log·XML 출력 일관)
def E(t, process, ev, eq, lot, wid, ph, rs):
    EVENTS.append((t, process, ev, out_eqp(eq), out_lot(lot), wid, ph, rs))

# 각 lot에서 모은 XML용 데이터 (eqpid, lotid 별로)
XML_DATA = {}
def xml_init(eqpid, lotid, start_dt):
    XML_DATA[(eqpid, lotid)] = dict(
        eqpid=eqpid, lotid=lotid, start=start_dt, wafers=[]
    )
def xml_add_wafer(eqpid, lotid, w): XML_DATA[(eqpid, lotid)]["wafers"].append(w)
def xml_set_end(eqpid, lotid, end_dt): XML_DATA[(eqpid, lotid)]["end"] = end_dt

# ──────────────────────────────────────────────────────────────────
# Lot 생성기 — 장비 종류별
# ──────────────────────────────────────────────────────────────────
def gen_euv_lot(eqpid, lotid, start_dt, nw):
    P = EQUIPMENT[eqpid]["process"]
    xml_init(eqpid, lotid, start_dt)
    E(start_dt, P, "LOT_START", eqpid, lotid, "wafer01.01", "start", "success")
    t = start_dt + timedelta(seconds=jt(2))

    for slot in range(1, nw+1):
        wid = f"wafer{slot:02d}.01"
        wafer_start = t
        E(t, P, "WAFER_LOAD", eqpid, lotid, wid, "start", "success")
        t += timedelta(seconds=jt(3))

        # ── Stage calibration (μm)
        recal = random.random() < 0.04
        cal_start = t
        t += timedelta(seconds=jt(2))
        x_off = random.uniform(-3, 3)
        y_off = random.uniform(-3, 3)
        z_off = random.uniform(5.5, 8.0) if recal else random.uniform(-2, 2)
        if recal:
            t += timedelta(seconds=jt(2))  # 재교정 추가시간
            E(t, P, "STAGE_CALIB_RECAL", eqpid, lotid, wid, "end", "recal")
            cal_result = "RECALIBRATED"
        else:
            E(t, P, "STAGE_CALIB_OK", eqpid, lotid, wid, "end", "success")
            cal_result = "OK"
        cal_end = t
        calib = dict(start=cal_start, end=cal_end,
                     x=x_off, y=y_off, z=z_off, result=cal_result)

        # ── Coarse alignment (only first wafer / after recal)
        aligns = []
        if slot == 1 or recal:
            cs = t
            t += timedelta(seconds=jt(4))
            E(t, P, "ALIGN_COARSE_DONE", eqpid, lotid, wid, "end", "success")
            aligns.append(dict(stage="COARSE", start=cs, end=t,
                               n_marks=4, res3s=random.uniform(60, 90)))

        # ── Fine alignment (가끔 retry)
        retried = False
        fs = t
        t += timedelta(seconds=jt(17))
        if random.random() < 0.025:
            retried = True
            E(t, P, "ALIGN_FAIL", eqpid, lotid, wid, "end", "fail")
            t += timedelta(seconds=jt(2))
            wid = f"wafer{slot:02d}.02"
            E(t, P, "ALIGN_RETRY", eqpid, lotid, wid, "start", "success")
            t += timedelta(seconds=jt(17))
            E(t, P, "RECOVERED", eqpid, lotid, wid, "end", "success")
        else:
            E(t, P, "ALIGN_FINE_DONE", eqpid, lotid, wid, "end", "success")
        aligns.append(dict(stage="FINE", start=fs, end=t,
                           n_marks=8, res3s=random.uniform(3, 8), retried=retried))

        # 가끔 WARN (reticle stage 온도 등)
        if random.random() < 0.02:
            t += timedelta(seconds=jt(0.5))
            E(t, P, "WARN", eqpid, lotid, wid, "end", "warn")

        # ── Exposure
        es = t
        n_fields = 12
        t += timedelta(seconds=jt(34))
        E(t, P, "EXPOSURE_DONE", eqpid, lotid, wid, "end", "success")

        # ── Unload
        t += timedelta(seconds=jt(1))
        E(t, P, "WAFER_UNLOAD", eqpid, lotid, wid, "end", "success")
        wafer_end = t
        t += timedelta(seconds=0.3)

        xml_add_wafer(eqpid, lotid, dict(
            slot=slot, wid=wid, start=wafer_start, end=wafer_end,
            calib=calib, aligns=aligns,
            expose=dict(start=es, end=wafer_end, n_fields=n_fields)
        ))

    E(t, P, "LOT_END", eqpid, lotid, f"wafer{nw:02d}.01", "end", "success")
    xml_set_end(eqpid, lotid, t)


def gen_duv_lot(eqpid, lotid, start_dt, nw, expose_sec=5):
    """ArF / KrF 공통 — 단순화된 단일 정렬 + 노광"""
    P = EQUIPMENT[eqpid]["process"]
    xml_init(eqpid, lotid, start_dt)
    E(start_dt, P, "LOT_START", eqpid, lotid, "wafer01.01", "start", "success")
    t = start_dt + timedelta(seconds=jt(2))
    for slot in range(1, nw+1):
        wid = f"wafer{slot:02d}.01"
        ws = t
        E(t, P, "WAFER_LOAD", eqpid, lotid, wid, "start", "success")
        t += timedelta(seconds=jt(3))
        # 통합된 stage calib
        if random.random() < 0.025:
            t += timedelta(seconds=jt(2))
            E(t, P, "STAGE_CALIB_RECAL", eqpid, lotid, wid, "end", "recal")
        else:
            t += timedelta(seconds=jt(1))
            E(t, P, "STAGE_CALIB_OK", eqpid, lotid, wid, "end", "success")
        # 정렬
        t += timedelta(seconds=jt(8))
        if random.random() < 0.02:
            E(t, P, "ALIGN_FAIL", eqpid, lotid, wid, "end", "fail")
            t += timedelta(seconds=2)
            wid = f"wafer{slot:02d}.02"
            E(t, P, "ALIGN_RETRY", eqpid, lotid, wid, "start", "success")
            t += timedelta(seconds=jt(8))
            E(t, P, "RECOVERED", eqpid, lotid, wid, "end", "success")
        else:
            E(t, P, "ALIGN_FINE_DONE", eqpid, lotid, wid, "end", "success")
        # 가끔 WARN
        if random.random() < 0.015:
            t += timedelta(seconds=jt(0.3))
            E(t, P, "WARN", eqpid, lotid, wid, "end", "warn")
        # 노광
        t += timedelta(seconds=jt(expose_sec))
        E(t, P, "EXPOSURE_DONE", eqpid, lotid, wid, "end", "success")
        t += timedelta(seconds=jt(1))
        E(t, P, "WAFER_UNLOAD", eqpid, lotid, wid, "end", "success")
        we = t
        t += timedelta(seconds=0.3)
        xml_add_wafer(eqpid, lotid, dict(
            slot=slot, wid=wid, start=ws, end=we,
            ovl_x=random.gauss(1.2, 0.3), ovl_y=random.gauss(-0.7, 0.3),
            level_z=random.gauss(0.04, 0.01),
        ))
    E(t, P, "LOT_END", eqpid, lotid, f"wafer{nw:02d}.01", "end", "success")
    xml_set_end(eqpid, lotid, t)


def gen_ovl_lot(eqpid, lotid, start_dt, nw):
    P = EQUIPMENT[eqpid]["process"]
    xml_init(eqpid, lotid, start_dt)
    E(start_dt, P, "LOT_START", eqpid, lotid, "wafer01.01", "start", "success")
    t = start_dt + timedelta(seconds=2)
    for slot in range(1, nw+1):
        wid = f"wafer{slot:02d}.01"
        t += timedelta(seconds=jt(35))
        E(t, P, "OVL_MEASURE_DONE", eqpid, lotid, wid, "end", "success")
        xml_add_wafer(eqpid, lotid, dict(
            slot=slot, wid=wid, scan=t,
            sites=[dict(x=x, y=0, ovl_x=random.gauss(1.2, 0.4),
                        ovl_y=random.gauss(-0.8, 0.4),
                        res=random.uniform(0.2, 0.6))
                   for x in (-100, 0, 100)]
        ))
    t += timedelta(seconds=2)
    E(t, P, "LOT_END", eqpid, lotid, f"wafer{nw:02d}.01", "end", "success")
    xml_set_end(eqpid, lotid, t)


def gen_defect_lot(eqpid, lotid, start_dt, nw):
    P = EQUIPMENT[eqpid]["process"]
    xml_init(eqpid, lotid, start_dt)
    E(start_dt, P, "LOT_START", eqpid, lotid, "wafer01.01", "start", "success")
    t = start_dt + timedelta(seconds=5)
    classes = ["BRIDGE", "PARTICLE", "BREAK", "MISSING", "NUISANCE"]
    for slot in range(1, nw+1):
        wid = f"wafer{slot:02d}.01"
        t += timedelta(seconds=jt(80))
        E(t, P, "DEFECT_SCAN_DONE", eqpid, lotid, wid, "end", "success")
        n = max(0, int(random.gauss(2, 2)))
        xml_add_wafer(eqpid, lotid, dict(
            slot=slot, wid=wid, scan=t,
            defects=[dict(id=f"D-{slot:02d}{i:02d}",
                          cls=random.choice(classes),
                          x=random.uniform(-140, 140),
                          y=random.uniform(-140, 140),
                          size=random.uniform(15, 60))
                     for i in range(n)],
            cd_sites=[dict(id=f"S{j:02d}",
                           x=random.uniform(-100, 100),
                           y=random.uniform(-100, 100),
                           cd=random.gauss(13.2, 0.3))
                      for j in range(2)],
        ))
    t += timedelta(seconds=2)
    E(t, P, "LOT_END", eqpid, lotid, f"wafer{nw:02d}.01", "end", "success")
    xml_set_end(eqpid, lotid, t)


def gen_focus_lot(eqpid, lotid, start_dt, nw):
    """YS S250F focus 측정 — overlay와 유사한 wafer-level 측정"""
    P = EQUIPMENT[eqpid]["process"]
    xml_init(eqpid, lotid, start_dt)
    E(start_dt, P, "LOT_START", eqpid, lotid, "wafer01.01", "start", "success")
    t = start_dt + timedelta(seconds=2)
    for slot in range(1, nw+1):
        wid = f"wafer{slot:02d}.01"
        t += timedelta(seconds=jt(40))
        E(t, P, "OVL_MEASURE_DONE", eqpid, lotid, wid, "end", "success")  # event 이름은 통일
        xml_add_wafer(eqpid, lotid, dict(
            slot=slot, wid=wid, scan=t,
            sites=[dict(x=x, y=0,
                        focus_z=random.gauss(0, 8.0),       # focus offset (nm)
                        tilt_x=random.gauss(0, 0.3),        # μrad
                        tilt_y=random.gauss(0, 0.3))
                   for x in (-100, -50, 0, 50, 100)]
        ))
    t += timedelta(seconds=2)
    E(t, P, "LOT_END", eqpid, lotid, f"wafer{nw:02d}.01", "end", "success")
    xml_set_end(eqpid, lotid, t)


def gen_cdsem_lot(eqpid, lotid, start_dt, nw):
    """HMI eP6 CD-SEM — 결함 대신 CD/LER 측정 위주"""
    P = EQUIPMENT[eqpid]["process"]
    xml_init(eqpid, lotid, start_dt)
    E(start_dt, P, "LOT_START", eqpid, lotid, "wafer01.01", "start", "success")
    t = start_dt + timedelta(seconds=5)
    for slot in range(1, nw+1):
        wid = f"wafer{slot:02d}.01"
        t += timedelta(seconds=jt(95))
        E(t, P, "DEFECT_SCAN_DONE", eqpid, lotid, wid, "end", "success")  # 같은 통일 event 명
        xml_add_wafer(eqpid, lotid, dict(
            slot=slot, wid=wid, scan=t,
            cd_sites=[dict(id=f"CD{j:02d}",
                           x=random.uniform(-100, 100),
                           y=random.uniform(-100, 100),
                           cd=random.gauss(13.2, 0.25),
                           pitch=random.gauss(28.0, 0.2),
                           ler=random.uniform(0.8, 1.6))   # line edge roughness
                      for j in range(5)],
        ))
    t += timedelta(seconds=2)
    E(t, P, "LOT_END", eqpid, lotid, f"wafer{nw:02d}.01", "end", "success")
    xml_set_end(eqpid, lotid, t)


GENERATORS = {
    "euv":     gen_euv_lot,                                       # NXE:3600D
    "hna_euv": gen_euv_lot,                                       # EXE:5200 (구조 동일, 장비만 다름)
    "arf_imm": lambda *a: gen_duv_lot(*a, expose_sec=5),          # NXT:2050i
    "arf_dry": lambda *a: gen_duv_lot(*a, expose_sec=6),          # XT:1900i (immersion 없어 다소 느림)
    "krf":     lambda *a: gen_duv_lot(*a, expose_sec=4),          # XT:860N
    "iline":   lambda *a: gen_duv_lot(*a, expose_sec=8),          # XT:400L (i-line 더 느림)
    "ovl":     gen_ovl_lot,                                       # YieldStar S385
    "focus":   gen_focus_lot,                                     # YieldStar S250F
    "defect":  gen_defect_lot,                                    # HMI eP5
    "cdsem":   gen_cdsem_lot,                                     # HMI eP6
}

# ──────────────────────────────────────────────────────────────────
# 1) Event_log 범위 안의 lot 시뮬레이션 → EVENTS, XML_DATA
# ──────────────────────────────────────────────────────────────────
for eqpid, lotid, start, kind, nw in SCHEDULE:
    GENERATORS[kind](eqpid, lotid, start, nw)

# 1-b) XML 전용 lot — Event_log 시간 범위 *밖*에 위치
#      이 lot들의 이벤트는 EVENTS에 들어가긴 하지만, Event_log.old 파일에는
#      포함되지 않음(KrF XML 내부 <Events> 임베딩에는 사용).
XML_ONLY_SCHEDULE = [
    ("eqp_08", "lot_07", datetime(2026, 4, 29, 23, 30), "iline", 25),  # i-line (전날)
    ("eqp_09", "lot_08", datetime(2026, 5,  1,  2, 30), "focus", 25),  # YS Focus (다음날)
    ("eqp_10", "lot_09", datetime(2026, 5,  1,  4,  0), "cdsem", 25),  # CD-SEM (다음날)
]
xml_only_keys = set()
for eqpid, lotid, start, kind, nw in XML_ONLY_SCHEDULE:
    GENERATORS[kind](eqpid, lotid, start, nw)
    xml_only_keys.add((out_eqp(eqpid), out_lot(lotid)))   # EVENTS도 display 값으로 저장됨

EVENTS.sort(key=lambda e: e[0])

# ──────────────────────────────────────────────────────────────────
# 2) Event_log.old 작성 (XML 전용 lot은 제외)
# ──────────────────────────────────────────────────────────────────
events_for_log = [e for e in EVENTS if (e[3], e[4]) not in xml_only_keys]

# 첫/마지막 이벤트 timestamp을 1시간 윈도우 양 끝에 정확히 맞춤.
# (lot_04 LOT_START는 이미 06:00:00.000이지만 안전을 위해 명시적 override.
#  lot_01 LOT_END는 시뮬레이션 결과 ±10초 정도 흔들리므로 06:59:59.000으로 클램프.)
WINDOW_START = datetime(2026, 4, 30, 6, 0, 0)
WINDOW_END   = datetime(2026, 4, 30, 6, 59, 59)
if events_for_log:
    events_for_log[0]  = (WINDOW_START,) + events_for_log[0][1:]
    events_for_log[-1] = (WINDOW_END,)   + events_for_log[-1][1:]

event_path = OUT / "Event_log.old"
with event_path.open("w", encoding="utf-8") as f:
    for ts, p, ev, eq, lot, wid, ph, rs in events_for_log:
        f.write(f"{fmt_log(ts)} {p} {ev} {eq} {lot} {wid}\n")
        f.write(f"{ph} {rs}\n\n")
print(f"Event_log.old: {len(events_for_log)} events  ({event_path.stat().st_size} bytes)")
if events_for_log:
    print(f"  첫 이벤트:  {fmt_log(events_for_log[0][0])}  {events_for_log[0][2]}")
    print(f"  마지막:     {fmt_log(events_for_log[-1][0])}  {events_for_log[-1][2]}")

# ──────────────────────────────────────────────────────────────────
# 3) XML 작성 — 5종 장비 대표 lot 한 개씩
# ──────────────────────────────────────────────────────────────────
def write_euv_xml(d, path):
    eq = EQUIPMENT[d["eqpid"]]
    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} euv_exposure_log.xsd">')
    lines.append("  <Header>")
    lines.append(f'    <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'    <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'    <SoftwareVer>{eq["software"]}</SoftwareVer>')
    lines.append(f'    <StartTime>{fmt_iso(d["start"])}</StartTime>')
    lines.append(f'    <OperatorId>op_park</OperatorId>')
    lines.append("  </Header>")
    lines.append("  <Lot>")
    lines.append(f'    <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'    <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'    <ReticleId>{eq["reticle"]}</ReticleId>')
    lines.append(f'    <Recipe>{eq["recipe"]}</Recipe>')
    lines.append(f'    <Layer>{eq["layer"]}</Layer>')
    lines.append(f'    <WaferCount>{len(d["wafers"])}</WaferCount>')
    lines.append("  </Lot>")
    lines.append("  <Wafers>")
    for w in d["wafers"]:
        lines.append("    <Wafer>")
        lines.append(f'      <WaferId>{w["wid"]}</WaferId>')
        lines.append(f'      <StartTime>{fmt_iso(w["start"])}</StartTime>')
        c = w["calib"]
        lines.append("      <StageCalibration>")
        lines.append(f'        <ChuckId>CHK-A</ChuckId>')
        lines.append(f'        <StartTime>{fmt_iso(c["start"])}</StartTime>')
        lines.append(f'        <EndTime>{fmt_iso(c["end"])}</EndTime>')
        for ax, off, tol in (("X", c["x"], 10.0), ("Y", c["y"], 10.0), ("Z", c["z"], 5.0)):
            within = "true" if abs(off) <= tol else "false"
            lines.append("        <Axis>")
            lines.append(f'          <Axis>{ax}</Axis>')
            lines.append(f'          <NominalOrigin_um>0.0</NominalOrigin_um>')
            lines.append(f'          <MeasuredOrigin_um>{off:.3f}</MeasuredOrigin_um>')
            lines.append(f'          <Offset_um>{off:.3f}</Offset_um>')
            lines.append(f'          <Tolerance_um>{tol:.1f}</Tolerance_um>')
            lines.append(f'          <WithinTolerance>{within}</WithinTolerance>')
            lines.append("        </Axis>")
        lines.append(f'        <NotchAngle_deg>{random.uniform(-0.02, 0.02):.4f}</NotchAngle_deg>')
        lines.append(f'        <WaferTilt_urad>{random.uniform(2.5, 5.5):.2f}</WaferTilt_urad>')
        lines.append(f'        <Result>{c["result"]}</Result>')
        lines.append("      </StageCalibration>")
        for a in w["aligns"]:
            lines.append("      <Alignment>")
            lines.append(f'        <Stage>{a["stage"]}</Stage>')
            lines.append(f'        <Sensor>SMASH</Sensor>')
            lines.append(f'        <StartTime>{fmt_iso(a["start"])}</StartTime>')
            lines.append(f'        <EndTime>{fmt_iso(a["end"])}</EndTime>')
            for i in range(a["n_marks"]):
                mid = ("GA" if a["stage"] == "COARSE" else "FA") + f"_{i+1:02d}"
                nx = (-95 + i*60) if a["stage"] == "COARSE" else (-90 + i*30)
                ny = 95 if a["stage"] == "COARSE" else 90
                rx = random.gauss(0, 4 if a["stage"] == "FINE" else 80)
                ry = random.gauss(0, 4 if a["stage"] == "FINE" else 80)
                sq = random.uniform(0.85, 0.98)
                used = "false" if sq < 0.5 else "true"
                lines.append("        <Mark>")
                lines.append(f'          <MarkId>{mid}</MarkId>')
                lines.append(f'          <NominalX_mm>{nx:.3f}</NominalX_mm><NominalY_mm>{ny:.3f}</NominalY_mm>')
                lines.append(f'          <MeasuredX_mm>{nx + rx*1e-6:.6f}</MeasuredX_mm><MeasuredY_mm>{ny + ry*1e-6:.6f}</MeasuredY_mm>')
                lines.append(f'          <ResidualX_nm>{rx:.1f}</ResidualX_nm><ResidualY_nm>{ry:.1f}</ResidualY_nm>')
                lines.append(f'          <SignalQuality>{sq:.2f}</SignalQuality><Used>{used}</Used>')
                lines.append("        </Mark>")
            lines.append("        <GridModel>")
            lines.append(f'          <TranslationX_nm>{random.gauss(0,1):.2f}</TranslationX_nm>')
            lines.append(f'          <TranslationY_nm>{random.gauss(0,1):.2f}</TranslationY_nm>')
            lines.append(f'          <RotationX_urad>{random.gauss(0,0.05):.3f}</RotationX_urad>')
            lines.append(f'          <RotationY_urad>{random.gauss(0,0.05):.3f}</RotationY_urad>')
            lines.append(f'          <MagnificationX_ppm>{random.gauss(0,0.05):.3f}</MagnificationX_ppm>')
            lines.append(f'          <MagnificationY_ppm>{random.gauss(0,0.05):.3f}</MagnificationY_ppm>')
            lines.append(f'          <Residual3Sigma_nm>{a["res3s"]:.2f}</Residual3Sigma_nm>')
            lines.append("        </GridModel>")
            lines.append("      </Alignment>")
        # Fields
        for fi in range(w["expose"]["n_fields"]):
            fx = (fi % 4) - 1
            fy = (fi // 4) - 1
            lines.append("      <Field>")
            lines.append(f'        <FieldX>{fx}</FieldX><FieldY>{fy}</FieldY>')
            lines.append(f'        <Dose>{random.gauss(52.3, 0.05):.3f}</Dose>'
                         f'<Focus>{random.gauss(-3.2, 0.4):.2f}</Focus>'
                         f'<PulseCnt>{random.randint(1020, 1030)}</PulseCnt>')
            lines.append("      </Field>")
        lines.append(f'      <EndTime>{fmt_iso(w["end"])}</EndTime>')
        lines.append("    </Wafer>")
    lines.append("  </Wafers>")
    lines.append(f'  <EndTime>{fmt_iso(d["end"])}</EndTime>')
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


def write_duv_xml(d, path):
    """DUV scanner (ArF imm/dry, KrF, i-line) 공통 writer"""
    eq = EQUIPMENT[d["eqpid"]]
    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} duv_overlay_log.xsd">')
    lines.append("  <Header>")
    lines.append(f'    <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'    <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'    <SoftwareVer>{eq["software"]}</SoftwareVer>')
    lines.append(f'    <StartTime>{fmt_iso(d["start"])}</StartTime>')
    lines.append(f'    <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'    <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'    <ReticleId>{eq["reticle"]}</ReticleId>')
    lines.append(f'    <Recipe>{eq["recipe"]}</Recipe>')
    lines.append(f'    <LayerName>{eq["layer"]}</LayerName>')
    lines.append("  </Header>")
    for w in d["wafers"]:
        lines.append("  <Wafer>")
        lines.append(f'    <WaferId>{w["wid"]}</WaferId>')
        lines.append(f'    <Slot>{w["slot"]}</Slot>')
        lines.append(f'    <ScanTime>{fmt_iso(w["start"])}</ScanTime>')
        for fx in range(-1, 2):
            for fy in range(-1, 2):
                lines.append("    <Field>")
                lines.append(f'      <FieldX>{fx}</FieldX><FieldY>{fy}</FieldY>')
                lines.append(f'      <OverlayX>{random.gauss(w["ovl_x"], 0.2):.2f}</OverlayX>'
                             f'<OverlayY>{random.gauss(w["ovl_y"], 0.2):.2f}</OverlayY>')
                lines.append(f'      <LevelingZ>{random.gauss(w["level_z"], 0.005):.3f}</LevelingZ>')
                lines.append("    </Field>")
        lines.append("  </Wafer>")
    lines.append(f'  <EndTime>{fmt_iso(d["end"])}</EndTime>')
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


def write_krf_xml(d, path):
    """KrF는 event-style 로그"""
    eq = EQUIPMENT[d["eqpid"]]
    # 해당 lot의 이벤트만 필터.
    # display eqpid·lotid가 통합된 후에도 자기 lot 만 골라내려면 process 이름 + 시간창 추가.
    lot_events = [e for e in EVENTS
                  if e[1] == eq["process"]
                  and e[3] == out_eqp(d["eqpid"])
                  and e[4] == out_lot(d["lotid"])
                  and d["start"] <= e[0] <= d["end"]]
    n_wafers = len(d["wafers"])
    lot_sec = (d["end"] - d["start"]).total_seconds()
    wph = 3600 * n_wafers / lot_sec if lot_sec else 0

    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} xt860_event_log.xsd">')
    lines.append(f'  <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'  <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'  <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'  <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'  <StartTime>{fmt_iso(d["start"])}</StartTime>')
    lines.append(f'  <EndTime>{fmt_iso(d["end"])}</EndTime>')
    lines.append("  <Throughput>")
    lines.append(f'    <WafersPerHour>{wph:.1f}</WafersPerHour>')
    lines.append(f'    <LotProcessSec>{int(lot_sec)}</LotProcessSec>')
    lines.append("  </Throughput>")
    lines.append("  <Events>")
    code_map = {"LOT_START": ("E0001", "INFO"), "LOT_END": ("E0002", "INFO"),
                "WAFER_LOAD": ("E0010", "INFO"), "WAFER_UNLOAD": ("E0011", "INFO"),
                "STAGE_CALIB_OK": ("E0020", "INFO"), "STAGE_CALIB_RECAL": ("E0021", "WARN"),
                "ALIGN_FINE_DONE": ("E0030", "INFO"), "ALIGN_FAIL": ("E0501", "ERROR"),
                "ALIGN_RETRY": ("E0502", "WARN"), "RECOVERED": ("E0503", "INFO"),
                "EXPOSURE_DONE": ("E0040", "INFO"), "WARN": ("E0312", "WARN")}
    msgs = {"LOT_START": "Lot start", "LOT_END": "Lot end",
            "WAFER_LOAD": "Wafer loaded", "WAFER_UNLOAD": "Wafer unloaded",
            "STAGE_CALIB_OK": "Stage calibration passed",
            "STAGE_CALIB_RECAL": "Stage Z-axis recalibrated",
            "ALIGN_FINE_DONE": "Fine alignment completed",
            "ALIGN_FAIL": "Wafer alignment failed - retry triggered",
            "ALIGN_RETRY": "Alignment retry initiated",
            "RECOVERED": "Wafer alignment recovered",
            "EXPOSURE_DONE": "Field exposure completed",
            "WARN": "Reticle stage temperature out of nominal band, auto-recovered"}
    for ts, p, ev, eq_, lot, wid, ph, rs in lot_events:
        if ev not in code_map:
            continue
        code, sev = code_map[ev]
        lines.append("    <Event>")
        lines.append(f'      <Time>{fmt_iso(ts)}</Time>')
        lines.append(f'      <Code>{code}</Code><Severity>{sev}</Severity>')
        lines.append(f'      <Message>{msgs.get(ev, ev)}</Message>')
        if not wid.startswith("wafer25") and ev not in ("LOT_START", "LOT_END"):
            lines.append(f'      <WaferId>{wid}</WaferId>')
        lines.append("    </Event>")
    lines.append("  </Events>")
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


def write_ovl_xml(d, path):
    eq = EQUIPMENT[d["eqpid"]]
    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} yieldstar_overlay_log.xsd">')
    lines.append(f'  <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'  <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'  <SoftwareVer>{eq["software"]}</SoftwareVer>')
    lines.append(f'  <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'  <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'  <Recipe>{eq["recipe"]}</Recipe>')
    lines.append(f'  <Kind>OVL</Kind>')
    for w in d["wafers"]:
        lines.append("  <Wafer>")
        lines.append(f'    <WaferId>{w["wid"]}</WaferId>')
        lines.append(f'    <MeasureTime>{fmt_iso(w["scan"])}</MeasureTime>')
        lines.append(f'    <Wavelength>425.0</Wavelength>')
        for s in w["sites"]:
            lines.append("    <OverlaySite>")
            lines.append(f'      <WaferX_mm>{s["x"]:.1f}</WaferX_mm><WaferY_mm>{s["y"]:.1f}</WaferY_mm>')
            lines.append(f'      <OvlX_nm>{s["ovl_x"]:.2f}</OvlX_nm><OvlY_nm>{s["ovl_y"]:.2f}</OvlY_nm>'
                         f'<Residual_nm>{s["res"]:.2f}</Residual_nm>')
            lines.append("    </OverlaySite>")
        lines.append("  </Wafer>")
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


def write_focus_xml(d, path):
    """YieldStar S250F — 광학 focus 측정 (FocusSite 단위)"""
    eq = EQUIPMENT[d["eqpid"]]
    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} yieldstar_focus_log.xsd">')
    lines.append(f'  <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'  <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'  <SoftwareVer>{eq["software"]}</SoftwareVer>')
    lines.append(f'  <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'  <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'  <Recipe>{eq["recipe"]}</Recipe>')
    lines.append(f'  <Kind>FOCUS</Kind>')
    for w in d["wafers"]:
        lines.append("  <Wafer>")
        lines.append(f'    <WaferId>{w["wid"]}</WaferId>')
        lines.append(f'    <MeasureTime>{fmt_iso(w["scan"])}</MeasureTime>')
        for s in w["sites"]:
            lines.append("    <FocusSite>")
            lines.append(f'      <WaferX_mm>{s["x"]:.1f}</WaferX_mm><WaferY_mm>{s["y"]:.1f}</WaferY_mm>')
            lines.append(f'      <FocusOffset_nm>{s["focus_z"]:.2f}</FocusOffset_nm>')
            lines.append(f'      <TiltX_urad>{s["tilt_x"]:.3f}</TiltX_urad>'
                         f'<TiltY_urad>{s["tilt_y"]:.3f}</TiltY_urad>')
            lines.append("    </FocusSite>")
        lines.append("  </Wafer>")
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


def write_defect_xml(d, path):
    eq = EQUIPMENT[d["eqpid"]]
    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} ebeam_defect_log.xsd">')
    lines.append(f'  <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'  <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'  <SoftwareVer>{eq["software"]}</SoftwareVer>')
    lines.append(f'  <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'  <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'  <Recipe>{eq["recipe"]}</Recipe>')
    for w in d["wafers"]:
        lines.append("  <Wafer>")
        lines.append(f'    <WaferId>{w["wid"]}</WaferId>')
        lines.append(f'    <ScanTime>{fmt_iso(w["scan"])}</ScanTime>')
        lines.append(f'    <Beam_kV>1.0</Beam_kV>')
        if w["defects"]:
            lines.append("    <Defects>")
            for d_ in w["defects"]:
                lines.append("      <Defect>")
                lines.append(f'        <DefectId>{d_["id"]}</DefectId>')
                lines.append(f'        <Class>{d_["cls"]}</Class>')
                lines.append(f'        <X_um>{d_["x"]:.1f}</X_um><Y_um>{d_["y"]:.1f}</Y_um>')
                lines.append(f'        <Size_nm>{d_["size"]:.1f}</Size_nm>')
                lines.append(f'        <ImageRef>imgs/{w["wid"]}/{d_["id"]}.png</ImageRef>')
                lines.append("      </Defect>")
            lines.append("    </Defects>")
        else:
            lines.append("    <Defects/>")
        lines.append("    <CdMeasurements>")
        for s in w["cd_sites"]:
            lines.append("      <Cd>")
            lines.append(f'        <SiteId>{s["id"]}</SiteId>'
                         f'<X_um>{s["x"]:.1f}</X_um><Y_um>{s["y"]:.1f}</Y_um>'
                         f'<Cd_nm>{s["cd"]:.2f}</Cd_nm>')
            lines.append("      </Cd>")
        lines.append("    </CdMeasurements>")
        lines.append("  </Wafer>")
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


def write_cdsem_xml(d, path):
    """HMI eP6 CD-SEM — site별 CD/Pitch/LER"""
    eq = EQUIPMENT[d["eqpid"]]
    lines = ['<?xml version="1.0" encoding="utf-8"?>']
    lines.append(f'<{eq["ns"]}:Log xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
                 f'xmlns:{eq["ns"]}="{eq["ns"]}" '
                 f'xsi:schemaLocation="{eq["ns"]} ebeam_cdsem_log.xsd">')
    lines.append(f'  <ToolId>{out_eqp(d["eqpid"])}</ToolId>')
    lines.append(f'  <ToolModel>{eq["model"]}</ToolModel>')
    lines.append(f'  <SoftwareVer>{eq["software"]}</SoftwareVer>')
    lines.append(f'  <LotId>{out_lot(d["lotid"])}</LotId>')
    lines.append(f'  <LotStartTime>{fmt_iso(d["start"])}</LotStartTime>')
    lines.append(f'  <Recipe>{eq["recipe"]}</Recipe>')
    for w in d["wafers"]:
        lines.append("  <Wafer>")
        lines.append(f'    <WaferId>{w["wid"]}</WaferId>')
        lines.append(f'    <ScanTime>{fmt_iso(w["scan"])}</ScanTime>')
        lines.append(f'    <Beam_kV>0.8</Beam_kV>')
        lines.append("    <CdSites>")
        for s in w["cd_sites"]:
            lines.append("      <CdSite>")
            lines.append(f'        <SiteId>{s["id"]}</SiteId>')
            lines.append(f'        <X_um>{s["x"]:.1f}</X_um><Y_um>{s["y"]:.1f}</Y_um>')
            lines.append(f'        <Cd_nm>{s["cd"]:.2f}</Cd_nm>')
            lines.append(f'        <Pitch_nm>{s["pitch"]:.2f}</Pitch_nm>')
            lines.append(f'        <LineEdgeRoughness_nm>{s["ler"]:.2f}</LineEdgeRoughness_nm>')
            lines.append("      </CdSite>")
        lines.append("    </CdSites>")
        lines.append("  </Wafer>")
    lines.append(f'</{eq["ns"]}:Log>')
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  {path.name}: {len(lines)} lines")


# XML 출력 — 총 10개 (in-range 7 + out-of-range 3) — 모두 서로 다른 ASML 공정
# 파일명에 LotStartTime 포함, Windows 호환을 위해 ":" → "-" 치환.
# eqpid/lotid 모두 out_* 매핑 적용 (in-range는 모두 eqp_01·lot_01).
def fname(lotid, eqpid, kind, start_dt):
    iso = fmt_iso(start_dt).replace(":", "-")
    return f"{out_lot(lotid)}_{out_eqp(eqpid)}_{kind}_{iso}.xml"

# In-range — 7개 distinct 공정 (Event_log.old 안)
IN_RANGE_XMLS = [
    (("eqp_01", "lot_01"), "euv",     write_euv_xml),     # ① EUV (NXE:3600D, 0.33 NA)
    (("eqp_02", "lot_02"), "arf_imm", write_duv_xml),     # ② ArF immersion (NXT:2050i)
    (("eqp_03", "lot_03"), "krf",     write_krf_xml),     # ③ KrF (XT:860N, event-style)
    (("eqp_06", "lot_04"), "hna_euv", write_euv_xml),     # ④ High-NA EUV (EXE:5200, 0.55 NA)
    (("eqp_07", "lot_05"), "arf_dry", write_duv_xml),     # ⑤ ArF dry (XT:1900i)
    (("eqp_04", "lot_02"), "ovl",     write_ovl_xml),     # ⑥ 광학 Overlay (YS S385)
    (("eqp_05", "lot_02"), "defect",  write_defect_xml),  # ⑦ E-beam Defect (HMI eP5)
]
# Out-of-range — 3개 distinct 공정 (Event_log.old 밖)
OUT_OF_RANGE_XMLS = [
    (("eqp_08", "lot_07"), "iline",   write_duv_xml),     # ⑧ i-line (XT:400L, 전날 23:30)
    (("eqp_09", "lot_08"), "focus",   write_focus_xml),   # ⑨ 광학 Focus (YS S250F, 다음날 02:30)
    (("eqp_10", "lot_09"), "cdsem",   write_cdsem_xml),   # ⑩ CD-SEM (HMI eP6, 다음날 04:00)
]

print("\nIn-range XML files (Event_log.old 시간 범위 안):")
for key, kind, writer in IN_RANGE_XMLS:
    d = XML_DATA[key]
    writer(d, OUT / "xml" / fname(d["lotid"], d["eqpid"], kind, d["start"]))

print("\nOut-of-range XML files (Event_log.old 시간 범위 밖):")
for key, kind, writer in OUT_OF_RANGE_XMLS:
    d = XML_DATA[key]
    writer(d, OUT / "xml" / fname(d["lotid"], d["eqpid"], kind, d["start"]))

# ──────────────────────────────────────────────────────────────────
# 4) 통계 출력
# ──────────────────────────────────────────────────────────────────
from collections import Counter
print(f"\nIn-Event_log events: {len(events_for_log)}  (lines = {3 * len(events_for_log)})")
print(f"  Result counts:     {dict(Counter(e[7] for e in events_for_log))}")
print(f"XML-only events (제외됨): {len(EVENTS) - len(events_for_log)}")
print(f"  Result counts:     {dict(Counter(e[7] for e in EVENTS if (e[3], e[4]) in xml_only_keys))}")
print(f"\nTotal XMLs: {len(IN_RANGE_XMLS) + len(OUT_OF_RANGE_XMLS)} ({len(IN_RANGE_XMLS)} in-range + {len(OUT_OF_RANGE_XMLS)} out-of-range)")
