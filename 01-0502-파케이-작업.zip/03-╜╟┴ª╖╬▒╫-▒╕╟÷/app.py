"""
app.py — Streamlit으로 log_lake.db 의 log_files 레코드를 보여준다.

실행:
    streamlit run app.py

전제: 같은 폴더에 log_lake.db 가 있어야 함 (없으면 db_loader.py 먼저 실행).
"""

import sqlite3
from pathlib import Path

import pandas as pd
import streamlit as st

DB = Path(__file__).parent / "log_lake.db"

st.set_page_config(page_title="log_lake.db", layout="wide")
st.title("log_lake.db · log_files")

if not DB.exists():
    st.error(f"`{DB.name}` 가 없다. 먼저 `python db_loader.py` 를 실행하라.")
    st.stop()


@st.cache_data(show_spinner=False)
def load_df():
    con = sqlite3.connect(DB)
    try:
        df = pd.read_sql_query(
            "SELECT uid, lake_load_tm, file_nm, file_path, dt, eqp_id, lot_id "
            "FROM log_files ORDER BY uid",
            con,
        )
    finally:
        con.close()
    return df


df = load_df()

# 요약 메트릭
in_range  = ((df["eqp_id"] == "eqp_01") & (df["lot_id"] == "lot_01")).sum()
event_log = (df["file_nm"] == "Event_log.old").sum()
xml_total = df["file_nm"].str.endswith(".xml").sum()
out_range = xml_total - in_range

c1, c2, c3, c4 = st.columns(4)
c1.metric("총 rows", len(df))
c2.metric("in-range XML", int(in_range))
c3.metric("out-of-range XML", int(out_range))
c4.metric("Event_log", int(event_log))

# 사이드바 필터
st.sidebar.header("필터")
dt_opts  = ["(전체)"] + sorted(df["dt"].unique().tolist())
eqp_opts = ["(전체)"] + sorted(df["eqp_id"].dropna().unique().tolist()) + ["(NULL)"]
lot_opts = ["(전체)"] + sorted(df["lot_id"].dropna().unique().tolist()) + ["(NULL)"]

dt_sel  = st.sidebar.selectbox("dt", dt_opts)
eqp_sel = st.sidebar.selectbox("eqp_id", eqp_opts)
lot_sel = st.sidebar.selectbox("lot_id", lot_opts)
kw      = st.sidebar.text_input("file_nm 검색 (부분일치)")

view = df.copy()
if dt_sel != "(전체)":
    view = view[view["dt"] == dt_sel]
if eqp_sel != "(전체)":
    view = view[view["eqp_id"].isna()] if eqp_sel == "(NULL)" else view[view["eqp_id"] == eqp_sel]
if lot_sel != "(전체)":
    view = view[view["lot_id"].isna()] if lot_sel == "(NULL)" else view[view["lot_id"] == lot_sel]
if kw:
    view = view[view["file_nm"].str.contains(kw, case=False, na=False)]

# 메인 테이블
st.subheader(f"레코드 ({len(view)} / {len(df)})")
st.dataframe(view, use_container_width=True, hide_index=True)

# dt 분포
st.subheader("dt 별 row 수")
st.bar_chart(df.groupby("dt").size().rename("rows"))

# 선택한 row의 file_path
st.subheader("개별 row 상세")
if len(view):
    uid_pick = st.selectbox("uid 선택", view["uid"].tolist())
    row = df[df["uid"] == uid_pick].iloc[0].to_dict()
    st.json(row)
else:
    st.info("필터 결과가 없다.")

# 임의 SQL
with st.expander("커스텀 SQL"):
    sql = st.text_area(
        "SQL",
        value="SELECT eqp_id, COUNT(*) AS n FROM log_files GROUP BY eqp_id ORDER BY n DESC;",
        height=100,
    )
    if st.button("실행"):
        try:
            con = sqlite3.connect(DB)
            try:
                st.dataframe(pd.read_sql_query(sql, con), use_container_width=True, hide_index=True)
            finally:
                con.close()
        except Exception as e:
            st.error(str(e))
