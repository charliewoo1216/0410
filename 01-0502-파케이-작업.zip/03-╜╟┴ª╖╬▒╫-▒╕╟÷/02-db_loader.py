"""
db_loader.py — sql규칙.md 기반 SQLite log lake 생성 스크립트

산출물:
    log_lake.db  (이 스크립트와 같은 폴더)

입력:
    xml/*.xml         — 10개 ASML 공정 XML
    Event_log.old     — 평면 이벤트 로그 1개

스키마/규칙: sql규칙.md
    - 테이블: log_files (uid, lake_load_tm, file_nm, file_path, dt, eqp_id, lot_id)
    - 적재 순서: 각 파일의 lake_load_tm 오름차순 → uid 1~11

재실행:
    python db_loader.py     # log_lake.db 항상 새로 생성 (멱등)

note:
    실제 운영에서는 lake_load_tm = datetime.now() at insert time 이지만,
    본 데모는 재현성을 위해 파일명의 LotStartTime + 5분(작업 종료 직후 가정)을
    lake_load_tm으로 사용한다. Event_log.old은 1시간 윈도(06:00~06:59) 마감
    직후인 04-30 07:00:00.000으로 고정.
"""

import re
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

ROOT    = Path(__file__).parent
DB      = ROOT / "log_lake.db"
XML_DIR = ROOT / "xml"
ELOG    = ROOT / "Event_log.old"

# 파일명 prefix → (lot_id, eqp_id), 예: 'lot_01_eqp_01_euv_...' → ('lot_01', 'eqp_01')
FNAME_PREFIX = re.compile(r"^(lot_\d+)_(eqp_\d+)_")

# 파일명 끝의 LotStartTime 부분, 예: '..._2026-04-30T06-00-00+09-00.xml'
FNAME_TS = re.compile(r"_(\d{4}-\d{2}-\d{2})T(\d{2})-(\d{2})-(\d{2})\+09-00\.xml$")

# Event_log.old 적재 시각: 1시간 윈도(06:00~06:59) 마감 직후
EVENT_LOG_LOAD_TM = datetime(2026, 4, 30, 7, 0, 0)

# 각 lot이 lake에 도착하기까지의 지연(작업 시간 + 적재 지연)
ARRIVAL_DELAY = timedelta(minutes=5)


def parse_filename_ts(fname: str) -> datetime:
    """파일명의 LotStartTime 부분을 datetime으로."""
    m = FNAME_TS.search(fname)
    if not m:
        raise ValueError(f"timestamp not found in filename: {fname}")
    date, hh, mm, ss = m.group(1), m.group(2), m.group(3), m.group(4)
    return datetime.fromisoformat(f"{date}T{hh}:{mm}:{ss}")


def extract_ids(file_nm: str):
    """파일명 prefix에서 (lot_id, eqp_id). 매치 없으면 (None, None)."""
    m = FNAME_PREFIX.match(file_nm)
    return (m.group(1), m.group(2)) if m else (None, None)


def fmt_tm(dt: datetime) -> str:
    """YYYY-MM-DD HH:MM:SS.mmm (마지막 3자리 = 밀리초)."""
    return dt.strftime("%Y-%m-%d %H:%M:%S.") + f"{dt.microsecond // 1000:03d}"


def collect_records():
    """11개 파일을 도착 시각(lake_load_tm) 오름차순으로 반환."""
    rows = []

    # 1) xml/*.xml — 파일명 LotStartTime + ARRIVAL_DELAY = 도착 시각
    for xml in XML_DIR.glob("*.xml"):
        lake_tm = parse_filename_ts(xml.name) + ARRIVAL_DELAY
        lot_id, eqp_id = extract_ids(xml.name)
        rows.append({
            "lake_tm":   lake_tm,
            "file_nm":   xml.name,
            "file_path": f"xml/{xml.name}",
            "eqp_id":    eqp_id,
            "lot_id":    lot_id,
        })

    # 2) Event_log.old — 1시간 윈도 마감 직후, eqp/lot은 NULL (다중 lot 가정)
    if ELOG.exists():
        rows.append({
            "lake_tm":   EVENT_LOG_LOAD_TM,
            "file_nm":   ELOG.name,
            "file_path": ELOG.name,
            "eqp_id":    None,
            "lot_id":    None,
        })
    else:
        raise FileNotFoundError(f"{ELOG} not found")

    rows.sort(key=lambda r: r["lake_tm"])  # uid 부여 순서
    return rows


def create_schema(con: sqlite3.Connection):
    con.executescript("""
        CREATE TABLE IF NOT EXISTS log_files (
            uid           INTEGER PRIMARY KEY AUTOINCREMENT,
            lake_load_tm  TEXT    NOT NULL,
            file_nm       TEXT    NOT NULL,
            file_path     TEXT    NOT NULL UNIQUE,
            dt            TEXT    NOT NULL,
            eqp_id        TEXT,
            lot_id        TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_log_files_dt      ON log_files(dt);
        CREATE INDEX IF NOT EXISTS idx_log_files_eqp_id  ON log_files(eqp_id);
        CREATE INDEX IF NOT EXISTS idx_log_files_lot_id  ON log_files(lot_id);
        CREATE INDEX IF NOT EXISTS idx_log_files_load_tm ON log_files(lake_load_tm);
    """)


def insert_rows(con: sqlite3.Connection, rows):
    cur = con.cursor()
    for r in rows:
        tm = fmt_tm(r["lake_tm"])
        dt = tm[:10]
        cur.execute("""
            INSERT OR IGNORE INTO log_files
                (lake_load_tm, file_nm, file_path, dt, eqp_id, lot_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (tm, r["file_nm"], r["file_path"], dt, r["eqp_id"], r["lot_id"]))
    con.commit()


def show_summary(con: sqlite3.Connection):
    cur = con.cursor()
    cur.execute("""
        SELECT uid, lake_load_tm, file_nm, file_path, dt, eqp_id, lot_id
        FROM log_files ORDER BY uid
    """)
    rows = cur.fetchall()
    h = ("uid", "lake_load_tm", "file_nm", "dt", "eqp_id", "lot_id")
    print(f"\n{h[0]:>3} | {h[1]:<23} | {h[3]:<10} | {h[4]:<6} | {h[5]:<6} | {h[2]}")
    print("-" * 130)
    for uid, tm, nm, _path, dt, eqp, lot in rows:
        print(f"{uid:>3} | {tm:<23} | {dt:<10} | {eqp or '(NULL)':<6} | {lot or '(NULL)':<6} | {nm}")
    print("-" * 130)
    print(f"총 {len(rows)} rows  →  {DB}")


def main():
    if DB.exists():
        DB.unlink()  # 멱등성: 매 실행 시 새로 생성

    con = sqlite3.connect(DB)
    try:
        create_schema(con)
        insert_rows(con, collect_records())
        show_summary(con)
    finally:
        con.close()


if __name__ == "__main__":
    main()
