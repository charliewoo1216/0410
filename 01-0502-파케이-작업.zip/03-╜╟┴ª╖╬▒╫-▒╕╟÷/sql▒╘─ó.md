# SQL 규칙 (SQLite Log Lake)

> `03-실제로그-구현/`의 로그 산출물(XML 10개 + Event_log.old)을 SQLite DB에 인덱싱하기 위한 **테이블 설계와 적재 규칙**.
> 단일 진실원은 `실제로그규칙.md`이며, 본 문서는 그 위에 올라가는 **검색·조인 레이어** 스펙이다.

---

## ★ 한눈에 보기 (스키마 + 예시 레코드)

### 컬럼 7개

| # | 컬럼 | 타입 | 제약 | 한 줄 의미 |
|---|---|---|---|---|
| 1 | `uid` | INTEGER | PK · AUTOINCREMENT | 고유번호 (1부터 자동 증가) |
| 2 | `lake_load_tm` | TEXT | NOT NULL | 로그파일 적재 시각 (`YYYY-MM-DD HH:MM:SS.mmm`, KST) |
| 3 | `file_nm` | TEXT | NOT NULL | 로그파일 이름 (확장자 포함) |
| 4 | `file_path` | TEXT | NOT NULL · UNIQUE | 로그파일 적재 경로 (중복 적재 차단) |
| 5 | `dt` | TEXT | NOT NULL | 적재 날짜 (`YYYY-MM-DD` = `lake_load_tm[:10]`) |
| 6 | `eqp_id` | TEXT | nullable | display eqp_id (`eqp_01` / `eqp_08~10` / NULL) |
| 7 | `lot_id` | TEXT | nullable | display lot_id (`lot_01` / `lot_07~09` / NULL) |

### 예시 레코드 11개 (적재 정황 반영)

> **적재 정황** — 모든 파일은 도착 순서(= 각 파일의 lake_load_tm 오름차순)대로 INSERT되며 uid는 그 순서대로 1부터 부여된다.
> - `uid=1` → iline.xml (LotStartTime `2026-04-29 23:30` — 가장 이른 lot, 04-29 23:35 적재)
> - `uid=2~8` → 7개 in-range XML (LotStartTime `2026-04-30 06:00~06:53` — 각 lot 완료 즉시 적재, 06:01~06:58)
> - `uid=9` → **Event_log.old** (06:59:59.000 마지막 이벤트 직후, **2026-04-30 07:00** 적재)
> - `uid=10` → focus.xml (LotStartTime `2026-05-01 02:30` — 다음날 새벽 적재)
> - `uid=11` → cdsem.xml (LotStartTime `2026-05-01 04:00` — 다음날 새벽 적재)

| uid | lake_load_tm | file_nm | file_path | dt | eqp_id | lot_id |
|----:|---|---|---|---|---|---|
| 1 | 2026-04-29 23:35:00.105 | `lot_07_eqp_08_iline_2026-04-29T23-30-00+09-00.xml` | `xml/lot_07_eqp_08_iline_2026-04-29T23-30-00+09-00.xml` | 2026-04-29 | `eqp_08` | `lot_07` |
| 2 | 2026-04-30 06:01:30.412 | `lot_01_eqp_01_euv_2026-04-30T06-00-00+09-00.xml` | `xml/lot_01_eqp_01_euv_2026-04-30T06-00-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 3 | 2026-04-30 06:03:45.187 | `lot_01_eqp_01_arf_imm_2026-04-30T06-02-00+09-00.xml` | `xml/lot_01_eqp_01_arf_imm_2026-04-30T06-02-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 4 | 2026-04-30 06:11:12.903 | `lot_01_eqp_01_krf_2026-04-30T06-06-00+09-00.xml` | `xml/lot_01_eqp_01_krf_2026-04-30T06-06-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 5 | 2026-04-30 06:16:45.044 | `lot_01_eqp_01_hna_euv_2026-04-30T06-11-00+09-00.xml` | `xml/lot_01_eqp_01_hna_euv_2026-04-30T06-11-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 6 | 2026-04-30 06:23:11.220 | `lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml` | `xml/lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 7 | 2026-04-30 06:53:33.811 | `lot_01_eqp_01_ovl_2026-04-30T06-48-00+09-00.xml` | `xml/lot_01_eqp_01_ovl_2026-04-30T06-48-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 8 | 2026-04-30 06:58:40.502 | `lot_01_eqp_01_defect_2026-04-30T06-53-00+09-00.xml` | `xml/lot_01_eqp_01_defect_2026-04-30T06-53-00+09-00.xml` | 2026-04-30 | `eqp_01` | `lot_01` |
| 9 | 2026-04-30 07:00:00.000 | `Event_log.old` | `Event_log.old` | 2026-04-30 | *(NULL)* | *(NULL)* |
| 10 | 2026-05-01 02:35:14.730 | `lot_08_eqp_09_focus_2026-05-01T02-30-00+09-00.xml` | `xml/lot_08_eqp_09_focus_2026-05-01T02-30-00+09-00.xml` | 2026-05-01 | `eqp_09` | `lot_08` |
| 11 | 2026-05-01 04:05:01.418 | `lot_09_eqp_10_cdsem_2026-05-01T04-00-00+09-00.xml` | `xml/lot_09_eqp_10_cdsem_2026-05-01T04-00-00+09-00.xml` | 2026-05-01 | `eqp_10` | `lot_09` |

> `file_path`는 작업 디렉터리(`03-실제로그-구현/`) 기준 상대 경로로 표기. 실제 DB에는 절대경로(예: `C:/203-log-parcing/01-로그생성/03-실제로그-구현/xml/...`)를 저장해도 무방하며, **UNIQUE 제약만 충족하면 된다**.

### 11 rows의 분류

| 분류 | uid | rows | eqp_id | lot_id |
|---|---|---|---|---|
| out-of-range XML (전날 iline) | 1 | 1 | `eqp_08` | `lot_07` |
| in-range XML (7 distinct ASML 공정) | 2~8 | 7 | `eqp_01` | `lot_01` |
| Event_log.old (다중 이벤트 묶음) | 9 | 1 | *(NULL)* | *(NULL)* |
| out-of-range XML (다음날 focus, cdsem) | 10~11 | 2 | `eqp_09`/`eqp_10` | `lot_08`/`lot_09` |

> 자세한 정의·인덱스·쿼리 패턴은 아래 § 1 ~ § 9 참조.

---

## 1. 개요

| 항목 | 값 |
|---|---|
| DBMS | **SQLite 3.x** (단일 파일, 서버 불필요) |
| DB 파일 | `03-실제로그-구현/log_lake.db` |
| 테이블 | `log_files` (단일 테이블, 향후 확장 가능) |
| 1 row = 1 file | 각 XML 또는 평면 로그 파일이 한 행으로 인덱싱됨 |
| 포지션 | "포인터 인덱스" — 실제 측정값은 XML/Event_log를 직접 파싱 (DB는 *어떤 파일이 어디 있는지* 만 관리) |

---

## 2. 테이블 정의

### 2-1. `log_files` 스키마

```sql
CREATE TABLE IF NOT EXISTS log_files (
    uid           INTEGER PRIMARY KEY AUTOINCREMENT,
    lake_load_tm  TEXT    NOT NULL,
    file_nm       TEXT    NOT NULL,
    file_path     TEXT    NOT NULL UNIQUE,
    dt            TEXT    NOT NULL,
    eqp_id        TEXT,
    lot_id        TEXT
);
```

### 2-2. 컬럼 정의

| # | 컬럼 | 타입 | 제약 | 의미 / 형식 |
|---|---|---|---|---|
| 1 | `uid` | INTEGER | **PRIMARY KEY AUTOINCREMENT** | 고유번호. 1부터 시작하여 적재 순으로 1씩 증가 |
| 2 | `lake_load_tm` | TEXT | NOT NULL | 로그파일 **적재 시각** (`YYYY-MM-DD HH:MM:SS.mmm`, KST). DB에 row가 들어간 wall-clock 시각이지 로그 자체의 시각이 아님 |
| 3 | `file_nm` | TEXT | NOT NULL | 로그파일 **이름** (확장자 포함, 디렉터리 제외) |
| 4 | `file_path` | TEXT | NOT NULL **UNIQUE** | 로그파일 **경로** (프로젝트 루트 기준 상대 또는 절대). UNIQUE → 동일 파일 중복 적재 차단 |
| 5 | `dt` | TEXT | NOT NULL | **적재 날짜** (`YYYY-MM-DD`). `lake_load_tm[:10]`과 항상 동일하게 유지 |
| 6 | `eqp_id` | TEXT | nullable | 파일이 가리키는 **display eqp_id**. 단일 lot/eqp 파일이 아니면 NULL 가능 |
| 7 | `lot_id` | TEXT | nullable | 파일이 가리키는 **display lot_id**. 다중이면 NULL 가능 |

> SQLite는 native DATETIME이 없으므로 시각·날짜는 모두 TEXT(ISO 8601) 저장.
> KST(`+09:00`)는 명시하지 않고 **모든 시각은 KST 기준**이라는 규칙으로 약속 (실제로그규칙.md § 3-3과 일관).

### 2-3. 인덱스

```sql
CREATE INDEX IF NOT EXISTS idx_log_files_dt      ON log_files(dt);
CREATE INDEX IF NOT EXISTS idx_log_files_eqp_id  ON log_files(eqp_id);
CREATE INDEX IF NOT EXISTS idx_log_files_lot_id  ON log_files(lot_id);
CREATE INDEX IF NOT EXISTS idx_log_files_load_tm ON log_files(lake_load_tm);
```

`file_path`는 UNIQUE 제약으로 자동 인덱싱되므로 별도 추가 불필요.

---

## 3. 적재 규칙

### 3-1. 어떤 파일이 row가 되는가

| 대상 | row 수 | 비고 |
|---|---|---|
| `xml/*.xml` | 10 | 각 XML 1행 (in-range 7 + out-of-range 3) |
| `Event_log.old` | 1 | 평면 로그 1행 |
| (확장) 다른 로그 | per-file | 동일 규칙 |

### 3-2. eqp_id / lot_id 추출 규칙

**display id**(`실제로그규칙.md` § 2-4의 OUTPUT_* 매핑 적용 후 값)를 그대로 사용.

| 대상 | 추출 방법 | 결과 |
|---|---|---|
| in-range XML 7개 | 파일명 정규식 `^(lot_\d+)_(eqp_\d+)_` | `eqp_01` · `lot_01` (모두 통일) |
| out-of-range XML 3개 | 동일 정규식 | `eqp_08/09/10` · `lot_07/08/09` |
| `Event_log.old` | (단일 (eqp, lot) 파일이 아님) | **항상 NULL / NULL** |

> 파일명에서 추출하는 것이 우선. XML 내부 `<ToolId>` / `<LotId>`는 검증용 보조 키.
> `Event_log.old`은 여러 lot/eqp의 이벤트가 한 파일에 모이는 평면 로그이므로, 시드/스케줄에 따라 단일 값이 되더라도 **파일 자체는 다중 lot/eqp를 가정**한다 → `eqp_id`/`lot_id` 둘 다 NULL.

### 3-3. lake_load_tm / dt

- **`lake_load_tm`** = `datetime.now()` at insert time, `YYYY-MM-DD HH:MM:SS.mmm` 포맷, KST
- **`dt`** = `substr(lake_load_tm, 1, 10)` 즉 `YYYY-MM-DD`

두 값은 한 row 안에서 항상 일관 — 코드에서 같은 datetime 객체로부터 derive하므로 어긋나지 않는다.

### 3-4. 멱등성 (re-load 안전성)

- `file_path`가 UNIQUE이므로 동일 파일 재적재 시 INSERT 실패 (or constraint error).
- 강제 갱신이 필요하면 둘 중 하나:
  - `INSERT OR REPLACE` (uid 변경됨, 주의)
  - `DELETE FROM log_files WHERE file_path = ?` 후 재삽입
- 멱등성을 위해 적재 스크립트는 기본적으로 `INSERT OR IGNORE` 사용 권장.

---

## 4. 예시 데이터 (현재 시드 기준 11 rows)

적재 정황: 각 파일이 도착하는 시각(lake_load_tm) 순으로 INSERT → uid도 그 순서대로 1~11.

| uid | lake_load_tm | file_nm | file_path | dt | eqp_id | lot_id |
|---|---|---|---|---|---|---|
| 1 | 2026-04-29 23:35:00.105 | lot_07_eqp_08_iline_2026-04-29T23-30-00+09-00.xml | xml/lot_07_eqp_08_iline_2026-04-29T23-30-00+09-00.xml | 2026-04-29 | eqp_08 | lot_07 |
| 2 | 2026-04-30 06:01:30.412 | lot_01_eqp_01_euv_2026-04-30T06-00-00+09-00.xml | xml/lot_01_eqp_01_euv_2026-04-30T06-00-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 3 | 2026-04-30 06:03:45.187 | lot_01_eqp_01_arf_imm_2026-04-30T06-02-00+09-00.xml | xml/lot_01_eqp_01_arf_imm_2026-04-30T06-02-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 4 | 2026-04-30 06:11:12.903 | lot_01_eqp_01_krf_2026-04-30T06-06-00+09-00.xml | xml/lot_01_eqp_01_krf_2026-04-30T06-06-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 5 | 2026-04-30 06:16:45.044 | lot_01_eqp_01_hna_euv_2026-04-30T06-11-00+09-00.xml | xml/lot_01_eqp_01_hna_euv_2026-04-30T06-11-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 6 | 2026-04-30 06:23:11.220 | lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml | xml/lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 7 | 2026-04-30 06:53:33.811 | lot_01_eqp_01_ovl_2026-04-30T06-48-00+09-00.xml | xml/lot_01_eqp_01_ovl_2026-04-30T06-48-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 8 | 2026-04-30 06:58:40.502 | lot_01_eqp_01_defect_2026-04-30T06-53-00+09-00.xml | xml/lot_01_eqp_01_defect_2026-04-30T06-53-00+09-00.xml | 2026-04-30 | eqp_01 | lot_01 |
| 9 | 2026-04-30 07:00:00.000 | Event_log.old | Event_log.old | 2026-04-30 | *(NULL)* | *(NULL)* |
| 10 | 2026-05-01 02:35:14.730 | lot_08_eqp_09_focus_2026-05-01T02-30-00+09-00.xml | xml/lot_08_eqp_09_focus_2026-05-01T02-30-00+09-00.xml | 2026-05-01 | eqp_09 | lot_08 |
| 11 | 2026-05-01 04:05:01.418 | lot_09_eqp_10_cdsem_2026-05-01T04-00-00+09-00.xml | xml/lot_09_eqp_10_cdsem_2026-05-01T04-00-00+09-00.xml | 2026-05-01 | eqp_10 | lot_09 |

`file_path`는 작업 디렉터리(`03-실제로그-구현/`) 기준 상대 경로 표기 — 실제 DB에는 절대경로 저장도 무방.

---

## 5. 표준 쿼리 패턴

### 5-1. 적재된 모든 파일 보기
```sql
SELECT uid, file_nm, eqp_id, lot_id, lake_load_tm
FROM log_files
ORDER BY uid;
```

### 5-2. 오늘 적재 / 특정 날짜 적재
```sql
SELECT * FROM log_files WHERE dt = DATE('now');
SELECT * FROM log_files WHERE dt = '2026-05-01';
```

### 5-3. 특정 lot/eqp의 파일
```sql
SELECT file_nm, file_path FROM log_files
WHERE lot_id = 'lot_01' AND eqp_id = 'eqp_01';
-- → 7개 in-range XML (Event_log.old은 lot_id/eqp_id NULL이라 매치되지 않음)
```

### 5-4. in-range vs out-of-range 분류
```sql
SELECT
    CASE
        WHEN eqp_id = 'eqp_01' AND lot_id = 'lot_01' THEN 'in-range'
        WHEN file_nm = 'Event_log.old' THEN 'event-log'
        ELSE 'out-of-range'
    END AS bucket,
    COUNT(*) AS n
FROM log_files
GROUP BY bucket;
```

### 5-5. XML 파일만 / Event_log만
```sql
SELECT * FROM log_files WHERE file_nm LIKE '%.xml';
SELECT * FROM log_files WHERE file_nm = 'Event_log.old';
```

### 5-6. uid로 파일 위치 찾아 직접 파싱
```sql
SELECT file_path FROM log_files WHERE uid = 5;
-- → 결과로 받은 경로를 lxml.etree.parse(...) 로 로드
```

---

## 6. 다른 산출물과의 관계

```
[generator.py]
   ├──→ xml/*.xml             ─┐
   └──→ Event_log.old          ├──→  [db_loader.py]  ──→  log_lake.db.log_files
                               │                                  │
                                                                  ▼
                                                       SQL 쿼리로 후보 파일 선별
                                                                  │
                                                                  ▼
                                                lxml/pandas로 file_path 직접 파싱
                                                                  │
                                                                  ▼
                                                              실측값 분석
```

- log_files 테이블은 **검색 인덱스**일 뿐, 측정 데이터(예: overlay X, dose, alignment 잔차)는 저장하지 않는다.
- 측정 데이터까지 DB로 들이려면 별도 테이블 (`xml_wafers`, `xml_alignments` 등) 추가 필요 — 본 문서 범위 밖, 후속 단계에서 확장.

---

## 7. 적재 흐름 (Python 의사코드)

```python
import sqlite3, os, re, datetime
from pathlib import Path

OUT = Path(__file__).parent
DB  = OUT / "log_lake.db"

con = sqlite3.connect(DB)
cur = con.cursor()
cur.executescript("""
    CREATE TABLE IF NOT EXISTS log_files (
        uid          INTEGER PRIMARY KEY AUTOINCREMENT,
        lake_load_tm TEXT    NOT NULL,
        file_nm      TEXT    NOT NULL,
        file_path    TEXT    NOT NULL UNIQUE,
        dt           TEXT    NOT NULL,
        eqp_id       TEXT,
        lot_id       TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_log_files_dt     ON log_files(dt);
    CREATE INDEX IF NOT EXISTS idx_log_files_eqp_id ON log_files(eqp_id);
    CREATE INDEX IF NOT EXISTS idx_log_files_lot_id ON log_files(lot_id);
""")

FNAME_RE = re.compile(r"^(lot_\d+)_(eqp_\d+)_")

def extract_ids(file_nm):
    """파일명에서 (lot_id, eqp_id) 추출. XML 형식 외에는 (None, None)."""
    m = FNAME_RE.match(file_nm)
    return (m.group(1), m.group(2)) if m else (None, None)

def load_one(p: Path):
    now = datetime.datetime.now()
    tm  = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond//1000:03d}"
    dt  = tm[:10]
    if p.name == "Event_log.old":
        # Event_log은 다중 lot/eqp를 가정 (평면 로그) → NULL/NULL
        lot_id, eqp_id = None, None
    else:
        lot_id, eqp_id = extract_ids(p.name)
    cur.execute("""
        INSERT OR IGNORE INTO log_files
            (lake_load_tm, file_nm, file_path, dt, eqp_id, lot_id)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (tm, p.name, str(p), dt, eqp_id, lot_id))

# 파일 도착 순서대로 적재 — uid는 INSERT 순서대로 1~11이 자연스럽게 부여됨
#
#   uid=1   04-29 23:35   iline.xml      (LotStartTime 04-29 23:30, 가장 이른 lot)
#   uid=2~8 04-30 06:01~06:58  in-range 7개 (LotStartTime 04-30 06:00~06:53)
#   uid=9   04-30 07:00:00.000  Event_log.old (06:59:59 마지막 이벤트 직후)
#   uid=10  05-01 02:35   focus.xml      (LotStartTime 05-01 02:30)
#   uid=11  05-01 04:05   cdsem.xml      (LotStartTime 05-01 04:00)
#
# 실제 운영에서는 파일 watcher가 각 시점에 load_one()을 호출.
# 일괄 재현 시에는 도착 시각순 정렬 후 순차 적재:

import re
TS_RE = re.compile(r"_(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})\+09-00\.xml$")

def arrival_key(p: Path):
    if p.name == "Event_log.old":
        return ("2026-04-30T07-00-00",)         # Event_log 1시간 윈도 마감 직후
    m = TS_RE.search(p.name)
    return (m.group(1),) if m else (p.name,)    # XML은 파일명의 LotStartTime

paths = list((OUT / "xml").glob("*.xml")) + [OUT / "Event_log.old"]
for p in sorted(paths, key=arrival_key):
    load_one(p)

con.commit()
con.close()
```

---

## 8. 재현성 / 재생성

- DB 파일은 `generator.py`의 산출물이 아니라 **별도 단계** (`db_loader.py` 등)의 결과.
- 재생성: `rm log_lake.db && python db_loader.py`
- `lake_load_tm` / `dt`는 적재 시점에 따라 달라짐 (시드 무관). 같은 적재 시점에 다시 만들면 같은 값.
- DB 파일은 git에 commit하지 않는 것을 권장 (`.gitignore`).

---

## 9. 변경 원칙

| 변경 종류 | 영향 받는 곳 |
|---|---|
| 새 컬럼 추가 | § 2-1 CREATE TABLE + § 2-2 컬럼 표 + § 7 적재 코드 + 인덱스 검토 |
| 새 테이블 추가 (예: `xml_wafers`) | 본 문서에 새 섹션 + § 6 ERD 추가 |
| eqp_id/lot_id 매핑 변경 | 우선 `실제로그규칙.md` § 2-4 갱신 후 본 § 3-2 조정 |
| 파일명 규칙 변경 | `실제로그규칙.md` § 5-1 + 본 § 3-2 정규식 |

규칙과 코드가 어긋나면 **본 문서가 진실원** — 코드를 문서에 맞춘다.
