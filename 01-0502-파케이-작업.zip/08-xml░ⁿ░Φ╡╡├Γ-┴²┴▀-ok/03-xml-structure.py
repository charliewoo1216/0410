"""
04-xml-structure.py — XML 구조만 출력 (값 제외)

설계: 04-xml로그템플릿-v2.md
사용:
    python 04-xml-structure.py <xml_path>
    python 04-xml-structure.py selected-log-normalized/lot_01_eqp_01_euv_*.xml

    xml-log\lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml
    

    python 03-xml-structure.py xml-log\lot_01_eqp_01_arf_dry_2026-04-30T06-18-00+09-00.xml
"""

import sys
from collections import OrderedDict
from pathlib import Path
from lxml import etree


def localname(tag: str) -> str:
    """{namespace}Local → Local."""
    return tag.split("}", 1)[1] if "}" in tag else tag


def group_children(elem):
    """자식을 이름별로 묶고 [(name, 첫번째_elem, count), ...] 반환. 순서 보존."""
    od = OrderedDict()
    for c in elem:
        name = localname(c.tag)
        if name in od:
            od[name][1] += 1
        else:
            od[name] = [c, 1]
    return [(n, rep, cnt) for n, (rep, cnt) in od.items()]


def print_tree(elem, prefix: str = "", is_root: bool = True):
    if is_root:
        print(localname(elem.tag))
    children = group_children(elem)
    for i, (name, rep, cnt) in enumerate(children):
        is_last = (i == len(children) - 1)
        connector = "└── " if is_last else "├── "
        suffix = f"  (×{cnt})" if cnt > 1 else ""
        print(prefix + connector + name + suffix)
        new_prefix = prefix + ("    " if is_last else "│   ")
        print_tree(rep, new_prefix, is_root=False)


def main():
    # Windows 기본 stdout cp949 → UTF-8 강제 (박스문자 보존)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass

    if len(sys.argv) != 2:
        print("usage: python 03-xml-structure.py <xml_path>", file=sys.stderr)
        sys.exit(2)
    xml_path = Path(sys.argv[1])
    if not xml_path.exists():
        print(f"file not found: {xml_path}", file=sys.stderr)
        sys.exit(1)
    root = etree.parse(str(xml_path)).getroot()
    print(f"# {xml_path.name}\n")
    print_tree(root)


if __name__ == "__main__":
    main()
