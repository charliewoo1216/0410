"""
T40. xml-log/*.xml 을 event-log.log 의 실제 시간/이벤트로 정렬

[목적]
- event-log.log 가 가진 (장비, lot, wafer, sub-event) 별 실제 시각을 추출
- 각 XML 파일의 시간 태그 값을 그 시각으로 in-place 교체
- 결과: raw XML 만 봐도 event-log 와 시간 흐름이 자연스럽게 일치

[보존]
- 원본 xml-log/ 디렉터리는 첫 실행 시 xml-log-original/ 으로 백업 (있으면 그대로)
- 수정은 xml-log/ 안에서 in-place

[XML 별 처리 정책]
  EUV / HNA_EUV (NXE/EXE):
    Wafer/StartTime              ← log[WAFER_LOAD].start  (없으면 wafer 첫 활동)
    Wafer/EndTime                ← log[WAFER_UNLOAD].end  (없으면 wafer 마지막 활동)
    StageCalibration/StartTime   ← log[STAGE_CALIB].start
    StageCalibration/EndTime     ← log[STAGE_CALIB].end
    Alignment[Stage='COARSE']/StartTime/EndTime ← log[ALIGN_COARSE]
    Alignment[Stage='FINE']/StartTime/EndTime   ← log[ALIGN_FINE]
    root/EndTime                 ← lot 의 모든 wafer 마지막 활동 max

  ARF (XT1900 / NXT2050i):
    Header/StartTime             ← lot 의 첫 wafer 첫 활동
    Wafer/ScanTime               ← wafer 첫 활동 (WAFER_LOAD start)
    Wafer/EndTime (신규 추가)    ← wafer 마지막 활동 (WAFER_UNLOAD end)
    root/EndTime                 ← lot 마지막 활동

  DEFECT (EBEAM):
    Wafer/ScanTime               ← wafer 첫 활동
    Wafer/EndTime (신규 추가)    ← wafer 마지막 활동

  OVL (YS385):
    Wafer/MeasureTime            ← wafer 첫 활동
    Wafer/EndTime (신규 추가)    ← wafer 마지막 활동

  KRF (XT860):
    각 Events/Event/Time 을 Code 매핑에 따라 교체:
      E0001 Lot start            ← log LOT_START.start
      E0010 Wafer loaded         ← log WAFER_LOAD.end
      E0020 Stage calibration    ← log STAGE_CALIB.end
      E0030 Fine alignment       ← log ALIGN_FINE.end
      E0040 Field exposure       ← log EXPOSURE.end
      E0011 Wafer unloaded       ← log WAFER_UNLOAD.end
      E0002 Lot end              ← log LOT_END.end
    root/StartTime, EndTime, LotStartTime 도 갱신
"""
from pathlib import Path
import re
import shutil
import pandas as pd
from lxml import etree

APP_DIR = Path(__file__).parent
EVENT_LOG_PATH = APP_DIR / "event-log" / "event-log.log"
XML_DIR = APP_DIR / "xml-log"
BACKUP_DIR = APP_DIR / "xml-log-original"

# XML namespace ↔ event-log equipment 토큰
NS_TO_EQUIPMENT = {
    "EUV3600":  "LITHO_EUV",
    "EXE5200":  "LITHO_HNA_EUV",
    "NXT2050i": "LITHO_ARF_IMM",
    "XT1900":   "LITHO_ARF_DRY",
    "XT860":    "LITHO_KRF",
    "EBEAM":    "INSP_DEFECT",
    "YS385":    "INSP_OVL",
}

# KRF Event Code ↔ event-log (event_name, action) 매핑.
KRF_CODE_TO_LOG = {
    "E0001": ("LOT_START",    "start"),
    "E0010": ("WAFER_LOAD",   "end"),
    "E0020": ("STAGE_CALIB",  "end"),
    "E0030": ("ALIGN_FINE",   "end"),
    "E0040": ("EXPOSURE",     "end"),
    "E0011": ("WAFER_UNLOAD", "end"),
    "E0002": ("LOT_END",      "end"),
}


# ─────────────────────────────────────────────────────────────────────────
# 1) event-log 파싱 + 매핑 빌드
# ─────────────────────────────────────────────────────────────────────────
HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<equipment>\S+)\s+(?P<event>\S+)\s+"
    r"(?P<eqp_id>\S+)\s+(?P<lot_id>\S+)\s+(?P<wafer_id>\S+)\s*$"
)


def _parse_block(block):
    if len(block) < 2:
        return None
    m = HEADER_RE.match(block[0])
    if not m:
        return None
    status = block[1].split()
    if len(status) < 2:
        return None
    return {**m.groupdict(), "action": status[0], "result": status[1]}


def parse_event_log(path):
    block, records = [], []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                r = _parse_block(block)
                if r:
                    records.append(r)
                block = []
        if block:
            r = _parse_block(block)
            if r:
                records.append(r)
    df = pd.DataFrame.from_records(records)
    df["ts"] = pd.to_datetime(df["ts"])
    return df


def build_lookup(log_df):
    """이벤트 별 (start_ts, end_ts) + wafer 별 (first, last) 조회 구조."""
    log_events = {}    # (equipment, eqp_id, lot_id, wafer_id, event) → {start, end}
    grouped = log_df.groupby(["equipment", "eqp_id", "lot_id", "wafer_id", "event"], sort=False)
    for key, grp in grouped:
        d = {"start": pd.NaT, "end": pd.NaT}
        for _, r in grp.iterrows():
            if r["action"] == "start" and pd.isna(d["start"]):
                d["start"] = r["ts"]
            elif r["action"] == "end":
                d["end"] = r["ts"]
        log_events[key] = d

    wafer_window = {}  # (equipment, eqp_id, lot_id, wafer_id) → {first, last}
    base = log_df[~log_df["event"].isin(["LOT_START", "LOT_END"])]
    for key, grp in base.groupby(["equipment", "eqp_id", "lot_id", "wafer_id"], sort=False):
        wafer_window[key] = {
            "first": grp["ts"].min(),
            "last":  grp["ts"].max(),
        }

    lot_window = {}    # (equipment, eqp_id, lot_id) → {first, last}
    for key, grp in log_df.groupby(["equipment", "eqp_id", "lot_id"], sort=False):
        lot_window[key] = {
            "first": grp["ts"].min(),
            "last":  grp["ts"].max(),
        }
    return log_events, wafer_window, lot_window


# ─────────────────────────────────────────────────────────────────────────
# 2) XML 헬퍼
# ─────────────────────────────────────────────────────────────────────────
def localname(tag):
    return tag.split("}", 1)[1] if "}" in tag else tag


def get_ns(tag):
    if tag.startswith("{") and "}" in tag:
        return tag[1:].split("}", 1)[0]
    return ""


def find_first_direct(elem, tag):
    if elem is None:
        return None
    for c in elem:
        if localname(c.tag) == tag:
            return c
    return None


def find_first_deep(elem, tag):
    if elem is None:
        return None
    for c in elem.iter():
        if localname(c.tag) == tag:
            return c
    return None


def find_all_direct(elem, tag):
    if elem is None:
        return []
    return [c for c in elem if localname(c.tag) == tag]


def text_in(elem, tag):
    c = find_first_direct(elem, tag)
    return c.text if c is not None else None


def fmt_iso(ts):
    """pandas Timestamp / NaT → 2026-04-30T06:00:00+09:00 형식 (KST naive 가정)."""
    if pd.isna(ts):
        return None
    s = ts.strftime("%Y-%m-%dT%H:%M:%S")
    # 마이크로초 부분 0이 아닐 때만 추가 (XML 가독성)
    micro = ts.microsecond
    if micro:
        s += f".{micro:06d}"
    return s + "+09:00"


def set_text(elem, tag, value, ns):
    """직계 자식 tag 의 text 를 value 로 설정. 없으면 새 자식으로 추가."""
    if value is None:
        return
    c = find_first_direct(elem, tag)
    if c is None:
        c = etree.SubElement(elem, f"{{{ns}}}{tag}" if ns else tag)
    c.text = value


# ─────────────────────────────────────────────────────────────────────────
# 3) XML 파일별 정렬 함수
# ─────────────────────────────────────────────────────────────────────────
def align_euv(root, ns, equipment, log_events, wafer_window, lot_window):
    """EUV3600 / EXE5200 — Wafer + StageCalibration + Alignment 시간 갱신."""
    eqp_id = text_in(find_first_deep(root, "Header"), "ToolId")
    lot = find_first_deep(root, "Lot")
    lot_id = text_in(lot, "LotId")
    wafers = find_first_deep(root, "Wafers")
    n_changes = 0

    for wafer in find_all_direct(wafers, "Wafer"):
        wafer_id = text_in(wafer, "WaferId")
        key = (equipment, eqp_id, lot_id, wafer_id)
        win = wafer_window.get(key)
        if not win:
            continue

        # Wafer/StartTime ← WAFER_LOAD.start (없으면 wafer 첫 활동)
        wl = log_events.get(key + ("WAFER_LOAD",), {})
        set_text(wafer, "StartTime", fmt_iso(wl.get("start") or win["first"]), ns)

        # Wafer/EndTime ← WAFER_UNLOAD.end (없으면 wafer 마지막)
        wu = log_events.get(key + ("WAFER_UNLOAD",), {})
        set_text(wafer, "EndTime", fmt_iso(wu.get("end") or win["last"]), ns)

        # StageCalibration
        sc = find_first_direct(wafer, "StageCalibration")
        if sc is not None:
            stc = log_events.get(key + ("STAGE_CALIB",), {})
            set_text(sc, "StartTime", fmt_iso(stc.get("start")), ns)
            set_text(sc, "EndTime",   fmt_iso(stc.get("end")),   ns)

        # Alignment(s) — Stage 가 COARSE 인지 FINE 인지로 매핑
        for align in find_all_direct(wafer, "Alignment"):
            stage = text_in(align, "Stage")  # COARSE / FINE
            log_event_name = f"ALIGN_{stage}" if stage in ("COARSE", "FINE") else None
            if log_event_name:
                ae = log_events.get(key + (log_event_name,), {})
                set_text(align, "StartTime", fmt_iso(ae.get("start")), ns)
                set_text(align, "EndTime",   fmt_iso(ae.get("end")),   ns)
        n_changes += 1

    # Header/StartTime, root/EndTime
    header = find_first_deep(root, "Header")
    lw = lot_window.get((equipment, eqp_id, lot_id))
    if header is not None and lw:
        set_text(header, "StartTime", fmt_iso(lw["first"]), ns)
    set_text(root, "EndTime", fmt_iso(lw["last"]), ns) if lw else None
    if lot is not None and lw:
        set_text(lot, "LotStartTime", fmt_iso(lw["first"]), ns)
    return n_changes


def align_arf(root, ns, equipment, log_events, wafer_window, lot_window):
    """XT1900 / NXT2050i — Wafer/ScanTime + (신규)EndTime."""
    header = find_first_deep(root, "Header")
    eqp_id = text_in(header, "ToolId")
    lot_id = text_in(header, "LotId")
    n_changes = 0

    for wafer in find_all_direct(root, "Wafer"):
        wafer_id = text_in(wafer, "WaferId")
        key = (equipment, eqp_id, lot_id, wafer_id)
        win = wafer_window.get(key)
        if not win:
            continue
        wl = log_events.get(key + ("WAFER_LOAD",), {})
        wu = log_events.get(key + ("WAFER_UNLOAD",), {})
        # ScanTime ← WAFER_LOAD.start (없으면 wafer 첫 활동)
        set_text(wafer, "ScanTime", fmt_iso(wl.get("start") or win["first"]), ns)
        # EndTime 신규/갱신 ← WAFER_UNLOAD.end (없으면 wafer 마지막)
        set_text(wafer, "EndTime",  fmt_iso(wu.get("end") or win["last"]), ns)
        n_changes += 1

    lw = lot_window.get((equipment, eqp_id, lot_id))
    if header is not None and lw:
        set_text(header, "StartTime", fmt_iso(lw["first"]), ns)
        set_text(header, "LotStartTime", fmt_iso(lw["first"]), ns)
    if lw:
        set_text(root, "EndTime", fmt_iso(lw["last"]), ns)
    return n_changes


def align_inspection(root, ns, equipment, log_events, wafer_window, lot_window, time_tag):
    """EBEAM (ScanTime) / YS385 (MeasureTime) — Wafer 시간 + (신규)EndTime."""
    eqp_id = text_in(root, "ToolId")
    lot_id = text_in(root, "LotId")
    n_changes = 0

    for wafer in find_all_direct(root, "Wafer"):
        wafer_id = text_in(wafer, "WaferId")
        key = (equipment, eqp_id, lot_id, wafer_id)
        win = wafer_window.get(key)
        if not win:
            continue
        wl = log_events.get(key + ("WAFER_LOAD",), {})
        wu = log_events.get(key + ("WAFER_UNLOAD",), {})
        set_text(wafer, time_tag, fmt_iso(wl.get("start") or win["first"]), ns)
        set_text(wafer, "EndTime", fmt_iso(wu.get("end") or win["last"]),   ns)
        n_changes += 1

    lw = lot_window.get((equipment, eqp_id, lot_id))
    if lw:
        set_text(root, "LotStartTime", fmt_iso(lw["first"]), ns)
    return n_changes


def align_krf(root, ns, equipment, log_events, wafer_window, lot_window):
    """XT860 — Events/Event/Time 을 Code 매핑으로 교체."""
    eqp_id = text_in(root, "ToolId")
    lot_id = text_in(root, "LotId")
    n_changes = 0

    events_node = find_first_deep(root, "Events")
    for ev in find_all_direct(events_node, "Event"):
        code = text_in(ev, "Code")
        wafer_id = text_in(ev, "WaferId")
        mapping = KRF_CODE_TO_LOG.get(code)
        if not mapping:
            continue
        log_event_name, action = mapping

        # LOT_START / LOT_END 는 wafer_id 없음 → lot 단위에서 가져옴
        if log_event_name in ("LOT_START", "LOT_END"):
            # lot 의 어떤 wafer 가 LOT_START 가졌든 첫 ts 가 곧 LOT_START 시각
            # event-log 에는 LOT_START 가 wafer01.01 에 매달려 있으므로 그 ts 사용
            for k, v in log_events.items():
                if (k[0], k[1], k[2], k[4]) == (equipment, eqp_id, lot_id, log_event_name):
                    ts = v.get(action)
                    if not pd.isna(ts):
                        set_text(ev, "Time", fmt_iso(ts), ns)
                        n_changes += 1
                    break
        else:
            if not wafer_id:
                continue
            key = (equipment, eqp_id, lot_id, wafer_id, log_event_name)
            d = log_events.get(key, {})
            ts = d.get(action) or d.get("start") or d.get("end")
            if not pd.isna(ts):
                set_text(ev, "Time", fmt_iso(ts), ns)
                n_changes += 1

    lw = lot_window.get((equipment, eqp_id, lot_id))
    if lw:
        set_text(root, "StartTime",    fmt_iso(lw["first"]), ns)
        set_text(root, "LotStartTime", fmt_iso(lw["first"]), ns)
        set_text(root, "EndTime",      fmt_iso(lw["last"]),  ns)
    return n_changes


HANDLERS = {
    "EUV3600":  align_euv,
    "EXE5200":  align_euv,
    "XT1900":   align_arf,
    "NXT2050i": align_arf,
    "EBEAM":    lambda r, ns, eq, le, ww, lw:
                    align_inspection(r, ns, eq, le, ww, lw, "ScanTime"),
    "YS385":    lambda r, ns, eq, le, ww, lw:
                    align_inspection(r, ns, eq, le, ww, lw, "MeasureTime"),
    "XT860":    align_krf,
}


# ─────────────────────────────────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────────────────────────────────
def main():
    print(f"=== event-log 파싱 ===")
    log_df = parse_event_log(EVENT_LOG_PATH)
    print(f"  {EVENT_LOG_PATH.name}: {len(log_df):,}건")

    log_events, wafer_window, lot_window = build_lookup(log_df)
    print(f"  log_events: {len(log_events):,}  wafer_window: {len(wafer_window):,}  lot_window: {len(lot_window):,}")

    # 백업
    if not BACKUP_DIR.exists():
        print(f"\n=== 원본 백업: {BACKUP_DIR.name}/ ===")
        shutil.copytree(XML_DIR, BACKUP_DIR)
        print(f"  완료")
    else:
        print(f"\n[skip 백업] {BACKUP_DIR.name}/ 이미 존재")

    print(f"\n=== XML 정렬 (in-place) ===")
    for path in sorted(XML_DIR.iterdir()):
        if path.suffix.lower() != ".xml":
            continue
        # 원본을 다시 읽지 않고 이미 수정된 xml-log 에서 읽으면 누적 변경됨.
        # 백업본을 읽어 항상 같은 결과가 되게 한다.
        src = BACKUP_DIR / path.name
        tree = etree.parse(str(src))
        root = tree.getroot()
        ns = get_ns(root.tag)
        equipment = NS_TO_EQUIPMENT.get(ns)
        handler = HANDLERS.get(ns)
        if handler is None or equipment is None:
            print(f"  [skip] unknown namespace: {ns}  ({path.name})")
            continue
        n = handler(root, ns, equipment, log_events, wafer_window, lot_window)
        # pretty 출력 (들여쓰기 유지). lxml 의 pretty_print 옵션 사용.
        # 단, 부분 추가된 노드는 들여쓰기 안되므로 etree.indent() 호출.
        try:
            etree.indent(tree, space="  ")
        except AttributeError:
            pass  # lxml < 4.5
        tree.write(str(path), xml_declaration=True, encoding="utf-8", pretty_print=True)
        print(f"  {path.name:<60} {ns:<10} → wafer 변경 {n}건")

    print(f"\n완료 - 다음 단계: 기존 *.parquet 삭제 후 `python 20_parquet_duckdb.py` 재실행")


if __name__ == "__main__":
    main()
