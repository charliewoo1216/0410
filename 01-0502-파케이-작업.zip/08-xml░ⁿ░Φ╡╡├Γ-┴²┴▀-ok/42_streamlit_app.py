"""
T30. 인터랙티브 로그 분석 + 시간 매칭 — Streamlit 앱

[실행]
  pip install streamlit duckdb pyarrow pandas lxml
  streamlit run 30_streamlit_app.py

[좌측 메뉴]
  - 데이터 소스 선택  : event-log / xml-log / matching (둘의 시간 매칭)
  - 단계 1~4         : 입력 → 구조 → 컬럼 변경 → DuckDB 쿼리

[전제]
  20_parquet_duckdb.py 가 미리 실행되어 다음 3개 parquet 이 같은 폴더에 있어야 함:
    - event-log.parquet  (event-log.log 파싱본)
    - xml-logs.parquet   (XML 파싱 + event-log 시간 OVERRIDE 본)
    - matching.parquet   (시간 매칭 결과)
"""
from pathlib import Path
import re
import pandas as pd
import streamlit as st
import duckdb

APP_DIR = Path(__file__).parent
EVENT_LOG_PARQUET    = APP_DIR / "event-log.parquet"
LOG_PAIRED_PARQUET   = APP_DIR / "event-log-paired.parquet"
XML_PARQUET          = APP_DIR / "xml-logs.parquet"
MATCHING_PARQUET     = APP_DIR / "matching.parquet"

# 사이드바 셀렉트박스 라벨 → parquet 경로
SOURCES = {
    "event-log (원본 텍스트, action 분리)":     EVENT_LOG_PARQUET,
    "event-log-paired (sub-event start/end)":  LOG_PAIRED_PARQUET,
    "xml-log (XML, 시간 OVERRIDE 됨)":          XML_PARQUET,
    "matching (XML × event-log sub-event)":    MATCHING_PARQUET,
}


# ─────────────────────────────────────────────────────────────────────────
# 헬퍼
# ─────────────────────────────────────────────────────────────────────────
def safe_col(name: str) -> str:
    """SQL 안전 컬럼 표기 (특수문자 시 큰따옴표)."""
    if re.search(r"[^A-Za-z0-9_]", name):
        return f'"{name}"'
    return name


def load_df(parquet_path: Path) -> pd.DataFrame:
    if not parquet_path.exists():
        return pd.DataFrame()
    return pd.read_parquet(parquet_path)


def init_state():
    # 세션에 들어있던 라벨이 SOURCES 에 더 이상 없으면 (코드 갱신/리네임 후) 첫 번째로 복귀
    default_label = next(iter(SOURCES))
    if (
        "source_label" not in st.session_state
        or st.session_state.source_label not in SOURCES
    ):
        st.session_state.source_label = default_label
    if "column_map" not in st.session_state:
        st.session_state.column_map = {}
    if "sql_text" not in st.session_state:
        st.session_state.sql_text = ""


def current_path() -> Path:
    return SOURCES[st.session_state.source_label]


def current_df_original() -> pd.DataFrame:
    return load_df(current_path())


def current_df_renamed() -> pd.DataFrame:
    df = current_df_original()
    return df.rename(columns=st.session_state.column_map)


# ─────────────────────────────────────────────────────────────────────────
# Streamlit 앱
# ─────────────────────────────────────────────────────────────────────────
st.set_page_config(page_title="이벤트 로그 / XML 시간 매칭", layout="wide")
init_state()

# === 사이드바 ===
st.sidebar.title("📊 메뉴")
st.sidebar.markdown("**데이터 소스**")
new_source = st.sidebar.selectbox(
    "어떤 parquet 을 볼까요?",
    list(SOURCES.keys()),
    index=list(SOURCES.keys()).index(st.session_state.source_label),
)
if new_source != st.session_state.source_label:
    st.session_state.source_label = new_source
    st.session_state.column_map = {}      # 소스 변경 시 매핑 초기화
    st.session_state.sql_text = ""
    st.rerun()

section = st.sidebar.radio(
    "단계",
    [
        "1. 소스 정보",
        "2. 기본 구조 (Parquet)",
        "3. 컬럼 확인/변경",
        "4. DuckDB 쿼리",
    ],
)
st.sidebar.markdown("---")
df_orig = current_df_original()
st.sidebar.markdown(f"**현재 소스**\n\n`{current_path().name}`")
st.sidebar.markdown(f"**행 수**: {len(df_orig):,}")
st.sidebar.markdown(f"**컬럼 수**: {len(df_orig.columns)}")
n_renamed = sum(1 for k, v in st.session_state.column_map.items() if k != v)
st.sidebar.markdown(f"**리네이밍**: {n_renamed}개")

# 입력 파일 존재 검사
if not current_path().exists():
    st.error(
        f"`{current_path().name}` 가 없습니다. 먼저 터미널에서 "
        f"`python 20_parquet_duckdb.py` 를 실행해 parquet 들을 생성해 주세요."
    )
    st.stop()


# ─────────────────────────────────────────────────────────────────────────
# 1) 소스 정보
# ─────────────────────────────────────────────────────────────────────────
if section.startswith("1"):
    st.header("1. 데이터 소스 정보")

    info = {
        "event-log (원본 텍스트, action 분리)": (
            "**event-log/event-log.log** 의 파싱 결과 (원본 형태).\n\n"
            "장비 × wafer 단위 sub-event 들이 `action='start'` 와 `'end'` 두 줄로 분리된 채 "
            "그대로 들어 있음. 컬럼: ts, equipment, event, eqp_id, lot_id, wafer_id, action, result.\n"
            "한 wafer 가 여러 행을 차지함."
        ),
        "event-log-paired (sub-event start/end)": (
            "**event-log 를 sub-event 단위로 페어링한 결과**.\n\n"
            "ROW_NUMBER + FULL OUTER JOIN 으로 같은 (장비, lot, wafer, event) 의 N번째 start ↔ "
            "N번째 end 를 한 행으로 합침. 컬럼: equipment, log_event, log_start, log_end, "
            "log_duration_sec, eqp_id, lot_id, wafer_id."
        ),
        "xml-log (XML, 시간 OVERRIDE 됨)": (
            "**xml-log/*.xml** 의 파싱 결과 + event-log 시간 강제 정렬.\n\n"
            "한 wafer = 한 행. event = `<Recipe>` (KRF 는 `<ToolModel>`).\n"
            "`start_time / end_time` 은 event-log 의 wafer-level 윈도우로 **OVERRIDE** 되어 있고, "
            "XML 원본 시각은 `xml_orig_start / xml_orig_end` 에 보존."
        ),
        "matching (XML × event-log sub-event)": (
            "**시간 매칭 결과 — sub-event 단위**.\n\n"
            "한 XML wafer 행 × 그 wafer 의 모든 event-log sub-event 들의 cross-join. "
            "결과: `equipment | wafer_id | log_event (WAFER_LOAD/STAGE_CALIB/...) | log_start | "
            "log_end | xml_event (Recipe) | xml_start | xml_end | time_match`.\n\n"
            "`time_match` 가 `OK overlap` 인 행 = 시간상 같은 동작으로 판정."
        ),
    }
    st.markdown(info[st.session_state.source_label])

    st.subheader("미리보기 (처음 10건)")
    st.dataframe(current_df_renamed().head(10), width="stretch")

    st.caption(f"파일: `{current_path()}`")


# ─────────────────────────────────────────────────────────────────────────
# 2) 기본 구조 (Parquet)
# ─────────────────────────────────────────────────────────────────────────
elif section.startswith("2"):
    st.header("2. 로그 기본 구조 (Parquet 기준)")

    df = current_df_renamed()
    size_kb = current_path().stat().st_size / 1024

    c1, c2, c3 = st.columns(3)
    c1.metric("행 수", f"{len(df):,}")
    c2.metric("컬럼 수", len(df.columns))
    c3.metric("Parquet 크기", f"{size_kb:.1f} KB")

    st.subheader("스키마")
    schema_df = pd.DataFrame(
        {
            "컬럼명": df.columns,
            "dtype": df.dtypes.astype(str).values,
            "Null 수": df.isna().sum().values,
            "유니크 값": [df[c].nunique() for c in df.columns],
            "샘플": [
                str(df[c].dropna().iloc[0]) if len(df[c].dropna()) > 0 else ""
                for c in df.columns
            ],
        }
    )
    st.dataframe(schema_df, width="stretch")

    st.subheader("샘플 데이터 (처음 20행)")
    st.dataframe(df.head(20), width="stretch")


# ─────────────────────────────────────────────────────────────────────────
# 3) 컬럼 확인/변경
# ─────────────────────────────────────────────────────────────────────────
elif section.startswith("3"):
    st.header("3. 컬럼 명칭 확인 및 변경")
    st.markdown(
        "현재 소스의 컬럼 이름을 자유롭게 변경할 수 있습니다.\n"
        "- 영숫자/언더스코어 권장 (SQL 에서 따옴표 없이 사용)\n"
        "- 하이픈/공백도 가능 — 쿼리 시 자동으로 큰따옴표가 붙습니다."
    )

    columns = list(df_orig.columns)
    new_map: dict[str, str] = {}
    cols_layout = st.columns(2)
    for i, orig in enumerate(columns):
        with cols_layout[i % 2]:
            current = st.session_state.column_map.get(orig, orig)
            new_name = st.text_input(
                f"`{orig}` →",
                value=current,
                key=f"col_input_{orig}",
            )
            new_map[orig] = (new_name or "").strip() or orig

    bt1, bt2 = st.columns(2)
    if bt1.button("✅ 변경 적용", width="stretch"):
        if len(set(new_map.values())) != len(new_map):
            st.error("새 컬럼명에 중복이 있습니다.")
        else:
            st.session_state.column_map = new_map
            st.success("적용되었습니다 (현재 소스에만 적용)")
            st.rerun()

    if bt2.button("↩️ 원본으로 되돌리기", width="stretch"):
        st.session_state.column_map = {}
        st.rerun()

    st.subheader("적용 결과 미리보기 (처음 5행)")
    st.dataframe(current_df_renamed().head(5), width="stretch")


# ─────────────────────────────────────────────────────────────────────────
# 4) DuckDB 쿼리
# ─────────────────────────────────────────────────────────────────────────
elif section.startswith("4"):
    st.header("4. DuckDB 쿼리")

    p_log   = EVENT_LOG_PARQUET.as_posix()
    p_xml   = XML_PARQUET.as_posix()
    p_match = MATCHING_PARQUET.as_posix()
    p_curr  = current_path().as_posix()

    presets = {
        "① 현재 소스 — 전체": f"SELECT * FROM read_parquet('{p_curr}')",
        "② 매칭: 한 wafer 의 sub-event 별 (LITHO_EUV wafer01.01 예시)": (
            f"SELECT equipment, wafer_id, log_event, log_start, log_end,\n"
            f"       xml_event, xml_start, xml_end, time_match\n"
            f"FROM read_parquet('{p_match}')\n"
            f"WHERE equipment = 'LITHO_EUV' AND wafer_id = 'wafer01.01'\n"
            f"ORDER BY log_start"
        ),
        "③ 매칭 요약: equipment × log_event × time_match 카운트": (
            f"SELECT equipment, log_event, time_match, COUNT(*) AS n\n"
            f"FROM read_parquet('{p_match}')\n"
            f"GROUP BY equipment, log_event, time_match\n"
            f"ORDER BY equipment, log_event, time_match"
        ),
        "④ 매칭 실패 행만 (NO overlap / null)": (
            f"SELECT *\n"
            f"FROM read_parquet('{p_match}')\n"
            f"WHERE time_match <> 'OK overlap'"
        ),
        "⑤ event-log: wafer 단위 윈도우": (
            f"SELECT equipment, eqp_id, lot_id, wafer_id,\n"
            f"       MIN(ts) AS w_start, MAX(ts) AS w_end\n"
            f"FROM read_parquet('{p_log}')\n"
            f"WHERE event NOT IN ('LOT_START', 'LOT_END')\n"
            f"GROUP BY equipment, eqp_id, lot_id, wafer_id\n"
            f"ORDER BY equipment, w_start"
        ),
        "⑥ XML: 장비별 Recipe (event) 분포": (
            f"SELECT equipment, event, COUNT(*) AS n\n"
            f"FROM read_parquet('{p_xml}')\n"
            f"GROUP BY equipment, event ORDER BY equipment, n DESC"
        ),
        "⑦ XML 원본 vs event-log 시간 비교": (
            f"SELECT equipment, eqp_id, lot_id, wafer_id,\n"
            f"       xml_orig_start, xml_orig_end,\n"
            f"       start_time AS overridden_start, end_time AS overridden_end\n"
            f"FROM read_parquet('{p_xml}')\n"
            f"WHERE xml_orig_start IS NOT NULL\n"
            f"ORDER BY equipment, wafer_id LIMIT 30"
        ),
        "⑧ event-log sub-event 별 평균 소요시간": (
            f"SELECT equipment, log_event,\n"
            f"       COUNT(*) AS n,\n"
            f"       ROUND(AVG(log_duration_sec), 3) AS avg_sec,\n"
            f"       ROUND(MAX(log_duration_sec), 3) AS max_sec\n"
            f"FROM read_parquet('event-log-paired.parquet')\n"
            f"WHERE log_duration_sec IS NOT NULL\n"
            f"GROUP BY equipment, log_event\n"
            f"ORDER BY equipment, avg_sec DESC"
        ),
    }

    st.subheader("쿼리 예제")
    cols_p = st.columns([3, 1])
    preset_choice = cols_p[0].selectbox("예제 선택", list(presets.keys()))
    if cols_p[1].button("📋 예제 불러오기", width="stretch"):
        st.session_state.sql_text = presets[preset_choice]
        st.rerun()

    if not st.session_state.sql_text:
        st.session_state.sql_text = presets["① 현재 소스 — 전체"]

    sql = st.text_area(
        "SQL (자유롭게 수정/입력)",
        key="sql_text",
        height=320,
    )

    if st.button("▶️ 실행", type="primary"):
        try:
            with st.spinner("쿼리 실행 중..."):
                result = duckdb.sql(sql).df()
            st.success(f"✅ 결과: {len(result):,}행 × {len(result.columns)}열")
            st.dataframe(result, width="stretch")

            csv_bytes = result.to_csv(index=False).encode("utf-8")
            st.download_button(
                "💾 결과 CSV 다운로드",
                data=csv_bytes,
                file_name="query_result.csv",
                mime="text/csv",
            )
        except Exception as e:
            st.error(f"❌ 쿼리 오류:\n```\n{e}\n```")

    with st.expander("💡 사용 가능한 Parquet 파일"):
        st.code(
            f"event-log : {p_log}\n"
            f"xml-log   : {p_xml}\n"
            f"matching  : {p_match}",
            language=None,
        )
        st.markdown(
            "쿼리에서 `read_parquet('<경로>')` 형태로 자유롭게 JOIN 가능."
        )
