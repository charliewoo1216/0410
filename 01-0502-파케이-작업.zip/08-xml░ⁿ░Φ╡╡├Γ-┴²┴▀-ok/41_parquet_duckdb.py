"""
T20. event-log + xml-log → Parquet → DuckDB 시간 매칭

[목적]
  같은 wafer 의 같은 처리 동작이 두 로그에 다른 이름으로 기록되어 있음.
  이름 매칭은 불가 → (장비, lot, wafer) + 시간 윈도우 로 동일 이벤트 식별.

[코드 실행 순서]
  ① 모듈/경로/매핑 설정
  ② event-log.log 파싱 → 페어링된 wafer-level DataFrame → event-log.parquet
  ③ xml-log/*.xml 파싱
       - equipment 컬럼 추가 (XML namespace → event-log 표기)
       - start/end NULL 은 event-log 윈도우로 보충
       - xml-logs.parquet
  ④ DuckDB 매칭 SQL: 같은 wafer 의 두 윈도우가 시간상 겹치는지 판정 → matching.parquet
  ⑤ 결과 출력 (.show() 박스표)

[최종 출력 컬럼 — 매칭 표]
  equipment | eqp_id | lot_id | wafer_id |
  xml_event | xml_start | xml_end |
  log_start | log_end |
  time_match
"""
from pathlib import Path
import re
import pandas as pd
import duckdb
from lxml import etree

APP_DIR = Path(__file__).parent
EVENT_LOG_PATH = APP_DIR / "event-log" / "event-log.log"
XML_DIR = APP_DIR / "xml-log"

EVENT_LOG_PARQUET = APP_DIR / "event-log.parquet"
XML_PARQUET = APP_DIR / "xml-logs.parquet"
MATCHING_PARQUET = APP_DIR / "matching.parquet"

# XML namespace ↔ event-log equipment 토큰 매핑
NS_TO_EQUIPMENT = {
    "EUV3600":  "LITHO_EUV",
    "EXE5200":  "LITHO_HNA_EUV",
    "NXT2050i": "LITHO_ARF_IMM",
    "XT1900":   "LITHO_ARF_DRY",
    "XT860":    "LITHO_KRF",
    "EBEAM":    "INSP_DEFECT",
    "YS385":    "INSP_OVL",
}


# ─────────────────────────────────────────────────────────────────────────
# 1) event-log.log 파싱 — 텍스트 → DataFrame (action='start'/'end' 두 줄 페어 그대로 보존)
# ─────────────────────────────────────────────────────────────────────────
HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<equipment>\S+)\s+(?P<event>\S+)\s+"
    r"(?P<eqp_id>\S+)\s+(?P<lot_id>\S+)\s+(?P<wafer_id>\S+)\s*$"
)


def _parse_block(block: list[str]):
    if len(block) < 2:
        return None
    m = HEADER_RE.match(block[0])
    if not m:
        return None
    status = block[1].split()
    if len(status) < 2:
        return None
    return {**m.groupdict(), "action": status[0], "result": status[1]}


def parse_event_log(path: Path) -> pd.DataFrame:
    """이벤트 로그 텍스트 파일을 DataFrame 으로."""
    block, records = [], []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                r = _parse_block(block)
                if r:
                    records.append(r)
                block = []
        if block:
            r = _parse_block(block)
            if r:
                records.append(r)

    df = pd.DataFrame.from_records(records)
    df["ts"] = pd.to_datetime(df["ts"])
    return df


# ─────────────────────────────────────────────────────────────────────────
# 2) XML 파싱 헬퍼 + 핸들러
# ─────────────────────────────────────────────────────────────────────────
def localname(tag: str) -> str:
    return tag.split("}", 1)[1] if "}" in tag else tag


def get_ns(tag: str) -> str:
    if tag.startswith("{") and "}" in tag:
        return tag[1:].split("}", 1)[0]
    return ""


def text_in(elem, tag: str) -> str | None:
    if elem is None:
        return None
    for c in elem:
        if localname(c.tag) == tag:
            return c.text
    return None


def text_deep(elem, tag: str) -> str | None:
    if elem is None:
        return None
    for c in elem.iter():
        if localname(c.tag) == tag:
            return c.text
    return None


def find_deep(elem, tag: str):
    if elem is None:
        return None
    for c in elem.iter():
        if localname(c.tag) == tag:
            return c
    return None


def find_all_direct(elem, tag: str) -> list:
    if elem is None:
        return []
    return [c for c in elem if localname(c.tag) == tag]


def _parse_euv_style(root) -> list[dict]:
    eqp_id = text_deep(root, "ToolId")
    lot = find_deep(root, "Lot")
    lot_id = text_in(lot, "LotId")
    recipe = text_in(lot, "Recipe")
    wafers = find_deep(root, "Wafers")
    return [{
        "event":      recipe,
        "start_time": text_in(w, "StartTime"),
        "end_time":   text_in(w, "EndTime"),
        "eqp_id":     eqp_id,
        "lot_id":     lot_id,
        "wafer_id":   text_in(w, "WaferId"),
    } for w in find_all_direct(wafers, "Wafer")]


def _parse_arf_style(root) -> list[dict]:
    header = find_deep(root, "Header")
    eqp_id = text_in(header, "ToolId")
    lot_id = text_in(header, "LotId")
    recipe = text_in(header, "Recipe")
    return [{
        "event":      recipe,
        "start_time": text_in(w, "ScanTime"),
        "end_time":   None,
        "eqp_id":     eqp_id,
        "lot_id":     lot_id,
        "wafer_id":   text_in(w, "WaferId"),
    } for w in find_all_direct(root, "Wafer")]


def _parse_single_time_style(root, time_tag: str) -> list[dict]:
    eqp_id = text_in(root, "ToolId")
    lot_id = text_in(root, "LotId")
    recipe = text_in(root, "Recipe")
    return [{
        "event":      recipe,
        "start_time": text_in(w, time_tag),
        "end_time":   None,
        "eqp_id":     eqp_id,
        "lot_id":     lot_id,
        "wafer_id":   text_in(w, "WaferId"),
    } for w in find_all_direct(root, "Wafer")]


def _parse_krf_style(root) -> list[dict]:
    eqp_id     = text_in(root, "ToolId")
    lot_id     = text_in(root, "LotId")
    tool_model = text_in(root, "ToolModel")
    starts, ends = {}, {}
    for ev in find_all_direct(find_deep(root, "Events"), "Event"):
        wid = text_in(ev, "WaferId")
        if not wid:
            continue
        code = text_in(ev, "Code")
        time = text_in(ev, "Time")
        if code == "E0010" and wid not in starts:
            starts[wid] = time
        elif code == "E0011":
            ends[wid] = time
    return [{
        "event":      tool_model,
        "start_time": starts.get(wid),
        "end_time":   ends.get(wid),
        "eqp_id":     eqp_id,
        "lot_id":     lot_id,
        "wafer_id":   wid,
    } for wid in sorted(set(starts) | set(ends))]


HANDLERS = {
    "EUV3600":  _parse_euv_style,
    "EXE5200":  _parse_euv_style,
    "XT1900":   _parse_arf_style,
    "NXT2050i": _parse_arf_style,
    "EBEAM":    lambda r: _parse_single_time_style(r, "ScanTime"),
    "YS385":    lambda r: _parse_single_time_style(r, "MeasureTime"),
    "XT860":    _parse_krf_style,
}


def parse_xml_dir(xml_dir: Path) -> pd.DataFrame:
    records = []
    for path in sorted(xml_dir.iterdir()):
        if path.suffix.lower() != ".xml":
            continue
        root = etree.parse(str(path)).getroot()
        ns = get_ns(root.tag)
        handler = HANDLERS.get(ns)
        if handler is None:
            print(f"[skip] unknown namespace: {ns}  ({path.name})")
            continue
        equipment = NS_TO_EQUIPMENT.get(ns)
        rows = handler(root)
        for r in rows:
            r["equipment"] = equipment              # event-log 매칭용
            r["xml_namespace"] = ns
        print(f"  {path.name:<60} → {len(rows):>4}건  ({ns} → {equipment})")
        records.extend(rows)
    return pd.DataFrame(records)


def to_kst_naive(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, utc=True, errors="coerce") \
             .dt.tz_convert("Asia/Seoul").dt.tz_localize(None)


# ─────────────────────────────────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────────────────────────────────
print("=== 1) event-log.log 파싱 ===")
log_df = parse_event_log(EVENT_LOG_PATH)
print(f"  {EVENT_LOG_PATH.name}: {len(log_df):,}건")
log_df.to_parquet(EVENT_LOG_PARQUET, compression="snappy", index=False)
print(f"  저장: {EVENT_LOG_PARQUET.name}  ({EVENT_LOG_PARQUET.stat().st_size/1024:.1f} KB)")


print("\n=== 2) xml-log/*.xml 파싱 ===")
xml_df = parse_xml_dir(XML_DIR)
xml_df["start_time"] = to_kst_naive(xml_df["start_time"])
xml_df["end_time"]   = to_kst_naive(xml_df["end_time"])


print("\n=== 3) event-log 윈도우로 XML start/end 강제 정렬 (OVERRIDE) ===")
# 정책: XML 의 원본 시각은 event-log 와 시간축이 어긋나 있다 (서로 다른 생성기에서
# 만들어진 데이터). 사용자 요구 "강제적으로 변경" 에 따라, event-log 가 가진 wafer
# 처리 윈도우로 XML 의 start/end 를 **덮어쓴다**.
# - 같은 (장비, lot, wafer) 가 event-log 에 있으면: start = w_start, end = w_end
# - 없으면 XML 원본 값 그대로 유지 (XML-only wafer — 예: ARF_DRY 의 wafer01.02 재시도)
window = (
    log_df[~log_df["event"].isin(["LOT_START", "LOT_END"])]
        .groupby(["equipment", "eqp_id", "lot_id", "wafer_id"], as_index=False)
        .agg(w_start=("ts", "min"), w_end=("ts", "max"))
)
print(f"  event-log wafer 윈도우: {len(window):,}건")

# 보존: 비교/디버깅용으로 XML 원본 시각을 별도 컬럼에 저장
xml_df["xml_orig_start"] = xml_df["start_time"]
xml_df["xml_orig_end"]   = xml_df["end_time"]

xml_df = xml_df.merge(
    window, on=["equipment", "eqp_id", "lot_id", "wafer_id"], how="left"
)

# OVERRIDE: event-log 에 매칭되는 wafer 가 있으면 그 값으로 덮어쓴다.
matched = xml_df["w_start"].notna()
xml_df.loc[matched, "start_time"] = xml_df.loc[matched, "w_start"]
xml_df.loc[matched, "end_time"]   = xml_df.loc[matched, "w_end"]
print(f"  event-log 매칭되어 덮어쓴 행: {matched.sum()}건 / {len(xml_df)}건")
print(f"  매칭 실패(XML 원본 유지)   : {(~matched).sum()}건")

# duration_tm 재계산 (보충 후)
xml_df["duration_tm"] = (xml_df["end_time"] - xml_df["start_time"]).dt.total_seconds().round(3)

# 컬럼 정리해 저장 — XML 원본 시각도 보존 컬럼으로 함께 저장 (디버깅/비교용)
xml_out = xml_df[[
    "event", "start_time", "end_time", "duration_tm",
    "equipment", "eqp_id", "lot_id", "wafer_id", "xml_namespace",
    "xml_orig_start", "xml_orig_end",
]]
xml_out.to_parquet(XML_PARQUET, compression="snappy", index=False)
print(f"  저장: {XML_PARQUET.name}  ({XML_PARQUET.stat().st_size/1024:.1f} KB, {len(xml_out):,}건)")


print("\n=== 4) event-log sub-event 페어링 (start/end 한 행으로) ===")
# 13_parquet_partition-v2 와 같은 ROW_NUMBER + FULL OUTER JOIN 패턴
LOG_PAIRED_PARQUET = APP_DIR / "event-log-paired.parquet"
pair_sql = f"""
WITH ordered AS (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY equipment, eqp_id, lot_id, wafer_id, event, action
            ORDER BY ts
        ) AS rn
    FROM read_parquet('{EVENT_LOG_PARQUET.as_posix()}')
),
starts AS (SELECT * FROM ordered WHERE action = 'start'),
ends   AS (SELECT * FROM ordered WHERE action = 'end')
SELECT
    COALESCE(s.equipment, e.equipment) AS equipment,
    COALESCE(s.event,     e.event)     AS log_event,
    -- 단일 액션 이벤트(WARN/ALIGN_FAIL/RECOVERED 등)는 한쪽만 존재.
    -- COALESCE 로 instant 이벤트화: start=end=ts 로 만들어 시간 비교가 동작하게.
    COALESCE(s.ts, e.ts)                AS log_start,
    COALESCE(e.ts, s.ts)                AS log_end,
    -- 정상 페어는 양수 duration, 단일 이벤트는 0.0
    ROUND(epoch(COALESCE(e.ts, s.ts)) - epoch(COALESCE(s.ts, e.ts)), 3) AS log_duration_sec,
    COALESCE(s.eqp_id,    e.eqp_id)    AS eqp_id,
    COALESCE(s.lot_id,    e.lot_id)    AS lot_id,
    COALESCE(s.wafer_id,  e.wafer_id)  AS wafer_id,
    -- 어떤 형태인지 구분 라벨
    CASE
        WHEN s.ts IS NOT NULL AND e.ts IS NOT NULL THEN 'paired'
        WHEN s.ts IS NOT NULL AND e.ts IS NULL     THEN 'start-only'
        WHEN s.ts IS NULL     AND e.ts IS NOT NULL THEN 'end-only'
    END AS log_event_kind
FROM starts s
FULL OUTER JOIN ends e
  ON  s.equipment = e.equipment
 AND  s.eqp_id    = e.eqp_id
 AND  s.lot_id    = e.lot_id
 AND  s.wafer_id  = e.wafer_id
 AND  s.event     = e.event
 AND  s.rn        = e.rn
ORDER BY COALESCE(s.ts, e.ts)
"""
duckdb.sql(f"COPY ({pair_sql}) TO '{LOG_PAIRED_PARQUET.as_posix()}' (FORMAT PARQUET, COMPRESSION SNAPPY)")
n_paired = duckdb.sql(f"SELECT COUNT(*) FROM read_parquet('{LOG_PAIRED_PARQUET.as_posix()}')").fetchone()[0]
print(f"  저장: {LOG_PAIRED_PARQUET.name}  ({LOG_PAIRED_PARQUET.stat().st_size/1024:.1f} KB, {n_paired:,}건)")


print("\n=== 5) DuckDB 시간 매칭 (sub-event 단위) ===")
# 한 XML wafer 행 × 그 wafer 의 모든 event-log sub-event 들을 cross 매칭.
# 결과 컬럼: equipment, eqp_id, lot_id, wafer_id,
#           log_event (WAFER_LOAD/STAGE_CALIB/...),  log_start, log_end,
#           xml_event (Recipe / ToolModel),          xml_start, xml_end,
#           time_match
match_sql = f"""
WITH xml_rows AS (
    SELECT * FROM read_parquet('{XML_PARQUET.as_posix()}')
),
log_paired AS (
    SELECT * FROM read_parquet('{LOG_PAIRED_PARQUET.as_posix()}')
    WHERE log_event NOT IN ('LOT_START', 'LOT_END')   -- lot 경계 이벤트는 매칭에서 제외
)
SELECT
    x.equipment,
    x.eqp_id, x.lot_id, x.wafer_id,
    l.log_event,                                       -- WAFER_LOAD / STAGE_CALIB / ...
    l.log_start, l.log_end, l.log_duration_sec,
    x.event       AS xml_event,                        -- Recipe / ToolModel
    x.start_time  AS xml_start,
    x.end_time    AS xml_end,
    -- 시간 겹침: [xml_start, xml_end] ∩ [log_start, log_end] ≠ ∅ ?
    CASE
        WHEN x.start_time IS NULL OR x.end_time IS NULL
          OR l.log_start IS NULL OR l.log_end IS NULL
            THEN '-- null'
        WHEN x.start_time <= l.log_end AND l.log_start <= x.end_time
            THEN 'OK overlap'
        ELSE 'NO overlap'
    END AS time_match
FROM xml_rows x
LEFT JOIN log_paired l USING (equipment, eqp_id, lot_id, wafer_id)
ORDER BY x.equipment, x.wafer_id, l.log_start NULLS LAST
"""
duckdb.sql(f"COPY ({match_sql}) TO '{MATCHING_PARQUET.as_posix()}' (FORMAT PARQUET, COMPRESSION SNAPPY)")
n_match = duckdb.sql(f"SELECT COUNT(*) FROM read_parquet('{MATCHING_PARQUET.as_posix()}')").fetchone()[0]
print(f"  저장: {MATCHING_PARQUET.name}  ({MATCHING_PARQUET.stat().st_size/1024:.1f} KB, {n_match:,}건)")


print("\n[매칭 결과 - LITHO_EUV wafer01.01 만]")
duckdb.sql(f"""
    SELECT equipment, wafer_id, xml_event, log_event,
           xml_start, xml_end, log_start, log_end, time_match
    FROM read_parquet('{MATCHING_PARQUET.as_posix()}')
    WHERE equipment = 'LITHO_EUV' AND wafer_id = 'wafer01.01'
    ORDER BY log_start
""").show(max_rows=30)

print("\n[매칭 요약 - log_event 별 OK 카운트]")
duckdb.sql(f"""
    SELECT equipment, log_event, time_match, COUNT(*) AS n
    FROM read_parquet('{MATCHING_PARQUET.as_posix()}')
    GROUP BY equipment, log_event, time_match
    ORDER BY equipment, log_event, time_match
""").show(max_rows=100)

print(f"\n총 XML 이벤트: {len(xml_out):,}건  /  event-log sub-event 페어: {n_paired:,}건  /  매칭 행: {n_match:,}건")
