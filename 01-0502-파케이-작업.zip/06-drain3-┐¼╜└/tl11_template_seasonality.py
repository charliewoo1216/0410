"""
T11. 템플릿 발생량의 주기성(seasonality) 분해
statsmodels seasonal_decompose 로 trend / seasonal / resid 로 분리한다.
- pip install statsmodels
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose

np.random.seed(0)
hours = pd.date_range("2025-10-01", periods=24 * 14, freq="1H")
# 시간대 패턴(낮 많고 밤 적음) + 주간 트렌드 + 노이즈
hour_pat = np.tile([2, 1, 1, 1, 2, 4, 8, 12, 14, 14, 13, 11, 10, 11, 13, 15, 16, 14, 12, 10, 8, 6, 4, 3], 14)
trend = np.linspace(0, 5, len(hours))
noise = np.random.normal(0, 0.5, len(hours))
counts = hour_pat + trend + noise

s = pd.Series(counts, index=hours, name="template_count")
result = seasonal_decompose(s, model="additive", period=24)

fig, axes = plt.subplots(4, 1, figsize=(10, 8), sharex=True)
s.plot(ax=axes[0], title="Observed")
result.trend.plot(ax=axes[1], title="Trend")
result.seasonal.plot(ax=axes[2], title="Seasonal (24h)")
result.resid.plot(ax=axes[3], title="Residual")
plt.tight_layout()
plt.show()

print(f"24시간 주기 진폭: {result.seasonal.max() - result.seasonal.min():.2f}")
