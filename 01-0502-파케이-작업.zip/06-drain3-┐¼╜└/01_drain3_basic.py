"""
T01. Drain3 로 첫 템플릿 추출
파스 트리를 이용해 가변 토큰을 와일드카드(<*>)로 치환한 템플릿을 추출한다.
- pip install drain3

[Drain3 동작 원리 요약]
  1) 토큰화      : 로그 메시지를 공백 기준으로 토큰(단어)으로 자른다.
  2) 길이 분기   : 토큰 개수(=길이)가 같은 로그끼리 먼저 한 그룹으로 묶는다.
                   (길이가 다르면 다른 템플릿으로 본다 — 1차 분기 기준)
  3) 파스 트리   : 트리의 각 단계는 "토큰 위치"를 의미한다.
                   앞쪽 토큰부터 차례로 따라 내려가며 후보 클러스터를 좁힌다.
                   (앞쪽 단어는 보통 고정 키워드라는 휴리스틱)
  4) 유사도 비교 : 리프(leaf) 노드의 기존 템플릿들과 위치별 토큰 일치율을 계산.
                   임계값(sim_th, 기본 0.4)을 넘으면 같은 템플릿으로 판단.
  5) 병합/생성   : - 매칭 성공 → 위치별로 다른 토큰을 와일드카드 <*> 로 일반화.
                                   (예: alice / bob / carol → <*>)
                   - 매칭 실패 → 새 클러스터(=새 템플릿) 생성.
  ⇒ 결과적으로 가변 부분(사용자명, IP, 수치 등)은 <*> 로,
     반복되는 고정 문구는 그대로 남아 "로그의 골격"이 추출된다.
"""
from drain3 import TemplateMiner

# 샘플 로그: 형태가 비슷한 것들끼리 같은 클러스터로 묶일 것으로 기대
#   - "User ... logged in from ..."  (3건, 사용자명/IP만 다름)
#   - "Disk usage ...% on /dev/..."  (2건, 사용량/장치명만 다름)
#   - "Connection refused at host ...:5432" (2건, 호스트명만 다름)
LOGS = [
    "User alice logged in from 192.168.1.5",
    "User bob   logged in from 10.0.0.7",
    "User carol logged in from 172.16.0.3",
    "Disk usage 78% on /dev/sda1",
    "Disk usage 92% on /dev/sda2",
    "Connection refused at host db01:5432",
    "Connection refused at host db02:5432",
]

# TemplateMiner: Drain 알고리즘을 감싼 고수준 API.
# 내부에 파스 트리(self.drain)를 들고 있으며, add_log_message() 한 번에
# "토큰화 → 트리 탐색 → 유사도 비교 → 병합 또는 신규 클러스터 생성"이 모두 일어난다.
tm = TemplateMiner()
for log in LOGS:
    # 한 줄을 투입할 때마다 트리가 점진적(online)으로 학습된다.
    # 같은 클러스터에 두 번째 이상 매칭되는 순간, 위치별로 달라지는 토큰이
    # 자동으로 <*> 로 일반화되어 템플릿이 갱신된다.
    res = tm.add_log_message(log)
    # cluster_id     : 이 로그가 속한 템플릿 클러스터 번호
    # template_mined : 현재까지 학습된 그 클러스터의 템플릿 문자열
    print(f"id={res['cluster_id']:>2} | {res['template_mined']}")

# 모든 로그를 다 넣은 뒤, 최종적으로 만들어진 템플릿(클러스터) 목록을 출력.
# size 는 해당 템플릿에 매칭된 로그 건수 — 빈도 분석에도 그대로 활용 가능.
print("\n[추출된 템플릿 목록]")
for cluster in tm.drain.clusters:
    print(f"  cluster #{cluster.cluster_id} (size={cluster.size}): {cluster.get_template()}")
