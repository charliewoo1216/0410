"""
T06. DataFrame → Parquet 저장 (Snappy 압축)

[Parquet 이란?]
  Apache Parquet — Hadoop/Spark/DuckDB/Athena/BigQuery 등 빅데이터 생태계의
  사실상 표준 파일 포맷. CSV/JSON 같은 "행(row) 기반"이 아닌 **열(column) 기반**
  바이너리 포맷이며, 자체적으로 스키마(컬럼명/타입)와 통계(min/max/null count)를
  파일 안에 함께 보관한다.

[왜 로그 분석에 Parquet 인가? — 핵심 장점 5가지]

  1) 컬럼 기반 저장 (Columnar Layout)
     - CSV 는 한 행 전체를 디스크에 연속 저장 → "duration_ms 평균만 보고 싶다"
       해도 모든 컬럼을 다 읽어야 함.
     - Parquet 은 같은 컬럼의 값을 한군데에 모아 저장 → 필요한 컬럼만 골라서
       읽을 수 있음 (= projection pushdown). I/O 가 수~수십 배 줄어든다.

  2) 강력한 압축 (Snappy / Gzip / Zstd / LZ4)
     - 같은 컬럼 안의 값들은 타입과 분포가 비슷 → 압축률이 매우 높다.
       (예: level 컬럼의 INFO/WARN/ERROR 같은 반복 문자열은 dictionary encoding
       으로 정수 코드 + 사전으로 저장되어 사이즈가 극단적으로 줄어듦)
     - 본 스크립트의 Snappy 는 압축률보다 "압축/해제 속도" 를 우선한 옵션.
       장기 보관용은 zstd, 핫 데이터는 snappy 가 일반적인 선택.

  3) 스키마 보존 (Self-describing)
     - CSV 는 모든 값이 문자열, 다시 읽을 때마다 dtype 추론을 해야 함
       (날짜 파싱 실패, int64 가 float64 로 바뀌는 사고가 빈번).
     - Parquet 은 컬럼별 타입(timestamp[ns], float64, dictionary<string> …)을
       파일 헤더에 박아둔다 → 다시 읽으면 dtype 이 그대로 복원된다.

  4) Predicate Pushdown / Statistics
     - Parquet 은 파일을 row group(보통 수만 행 단위)으로 나누고, 각 row group
       마다 컬럼별 min/max/null 통계를 메타데이터에 저장.
     - 쿼리 엔진(DuckDB, pyarrow.dataset 등)이 "level == 'ERROR'" 같은 필터를
       만나면, 통계만 보고 "이 row group 엔 ERROR 값이 없다" 는 걸 알아내
       해당 블록 자체를 건너뜀 (= 디스크에서 안 읽음).
     - tl08_parquet_pushdown.py 에서 실측 비교가 이어진다.

  5) 빅데이터 생태계와 호환
     - pandas/polars/duckdb/spark/trino/athena 모두 동일 파일을 그대로 읽는다.
     - 파티셔닝(년/월/일 디렉터리 분할, tl07 참고)과 결합하면 페타바이트급
       로그도 SQL 한 줄로 다룰 수 있다.

[CSV 와의 정량 비교 (감잡기용 — tl09 에서 실측)]
  같은 1천만 행 로그 기준 대략:
    - 파일 크기   : Parquet ≈ CSV 의 1/5 ~ 1/15
    - 읽기 속도   : 컬럼 1개만 읽을 때 Parquet 이 10~50배 빠름
    - 타입 안정성 : Parquet O / CSV X (재추론 필요)

[본 스크립트가 하는 일]
  1) 합성 로그(10,000행) 를 pandas DataFrame 으로 만든다.
  2) snappy 압축으로 logs.parquet 에 저장한다.
  3) 파일 크기를 출력하고, 다시 읽어 shape/head/dtypes 가
     원본과 동일하게 복원되는지 확인한다.

- pip install pyarrow   # to_parquet 의 기본 엔진. 없으면 fastparquet 도 가능.
"""
import pandas as pd
import numpy as np
import os

# 재현 가능한 난수: 같은 seed → 매 실행마다 동일한 합성 로그가 만들어진다.
np.random.seed(0)

# 합성 로그 데이터 — 실제 운영 로그를 흉내 낸 4개 컬럼.
#   ts          : 1초 간격으로 2025-10-10 부터 10,000초 (약 2시간 47분)
#   level       : 로그 레벨. INFO 85% / WARN 10% / ERROR 5% 비율로 가중 추출
#                 → Parquet 의 dictionary encoding 효과를 실감하기 좋은 형태
#   service     : 마이크로서비스 이름 4종 중 균등 추출
#   duration_ms : 응답 지연(ms). 로그정규분포로 "대부분 짧고, 가끔 매우 김"
#                 형태를 만들어 실제 latency 분포를 흉내 냄
df = pd.DataFrame({
    "ts": pd.date_range("2025-10-10", periods=10_000, freq="1s"),
    "level": np.random.choice(["INFO", "WARN", "ERROR"], 10_000, p=[0.85, 0.1, 0.05]),
    "service": np.random.choice(["api", "db", "cache", "auth"], 10_000),
    "duration_ms": np.random.lognormal(mean=4, sigma=0.5, size=10_000),
})

# Parquet 으로 저장.
#   compression="snappy" : 빠른 압축/해제. 핫 데이터 표준.
#                          (압축률은 zstd > gzip > snappy, 속도는 반대)
#   index=False          : pandas RangeIndex 를 컬럼으로 보존하지 않음.
#                          (ts 같은 진짜 시간컬럼이 따로 있으면 인덱스는 불필요)
df.to_parquet("logs.parquet", compression="snappy", index=False)

# 파일 크기 확인 — 같은 데이터를 to_csv 로 쓰면 보통 5~10배는 큼.
size_kb = os.path.getsize("logs.parquet") / 1024
print(f"저장 완료: logs.parquet  ({size_kb:.1f} KB)")

# 다시 읽어 들이면 dtypes 까지 그대로 복원되는지 확인.
#   - ts      → datetime64[ns]    (CSV 였다면 object/string 으로 복원돼 재파싱 필요)
#   - level   → object (문자열)   (pyarrow backend 쓰면 dictionary 로도 가능)
#   - duration_ms → float64
loaded = pd.read_parquet("logs.parquet")
print(f"\n불러온 shape: {loaded.shape}")
print(loaded.head())
print(f"\ndtypes:\n{loaded.dtypes}")
