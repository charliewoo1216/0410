"""
T07. Parquet 파티션 쓰기 (year/month/day)
시간 컬럼을 키로 디렉토리를 분할해 쿼리 시 partition pruning 이 가능하도록 한다.

[쉽게 설명하면 — "도서관 책장 비유"]
  로그 파일 1개에 1년치 데이터를 다 때려 넣은 것은,
  도서관 책 수만 권을 한 책장에 무더기로 쌓아둔 것과 같다.
  "10월 1일 책 좀 줘" 하면 사서는 책장 전체를 뒤져야 한다.

  파티셔닝은 책장을 "년 → 월 → 일" 폴더로 미리 나눠 꽂아두는 것이다.
      logs/year=2025/month=10/day=01/part-0.parquet
      logs/year=2025/month=10/day=02/part-0.parquet
      ...
  "10월 1일" 을 찾으면 해당 폴더 1개만 열면 끝 — 나머지는 디스크에서 아예
  안 읽는다. 이 "필요 없는 폴더는 통째로 건너뛰기" 동작을 partition pruning
  이라고 부른다.

[핵심 포인트 3가지]
  1) 파티션 키는 디렉터리 이름에 박힌다 (year=2025/...).
     파일 본문엔 그 컬럼이 안 들어가서, 그만큼 파일도 더 작아진다.
  2) 자주 필터하는 컬럼을 파티션 키로 골라야 효과가 있다.
     (시간, 장비, 지역 같은 "쿼리 WHERE 절에 자주 나오는 것")
  3) 너무 잘게 쪼개면 안 된다 — 파일 수만 폭증해 오히려 느려짐
     ("초 단위 파티션" 같은 건 금물. 일/시간 단위가 보통 적당).

[본 스크립트가 하는 일]
  1) 시간 시리즈 데이터(시간당 1건, 약 6일치)를 합성한다.
  2) ts 에서 year/month/day 컬럼을 만들어 파티션 키로 쓴다.
  3) logs_partitioned/ 디렉터리 아래에 year/month/day 폴더 구조로 저장한다.
  4) 그중 "2025-10-01" 폴더만 골라 읽어 partition pruning 을 확인한다.
"""
import pandas as pd
import numpy as np
from pathlib import Path

np.random.seed(0)
ts = pd.date_range("2025-09-28", "2025-10-03", freq="1H")
df = pd.DataFrame({
    "ts": ts,
    "value": np.random.randn(len(ts)),
})
df["year"] = df["ts"].dt.year
df["month"] = df["ts"].dt.month
df["day"] = df["ts"].dt.day

OUT = Path("logs_partitioned")
df.to_parquet(OUT, partition_cols=["year", "month", "day"], index=False)

print(f"파티션 디렉토리 구조:")
for p in sorted(OUT.rglob("*.parquet")):
    print(f"  {p.relative_to(OUT)}")

print("\n[10/01 데이터만 읽기]")
filt = pd.read_parquet(OUT, filters=[("year", "=", 2025), ("month", "=", 10), ("day", "=", 1)])
print(filt.head())
print(f"행수: {len(filt)}")
