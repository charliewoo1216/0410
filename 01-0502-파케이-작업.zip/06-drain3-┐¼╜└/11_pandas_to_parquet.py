"""
T11. 실제 로그 파일 → DataFrame → Parquet 저장
- tl06 의 합성 데이터 대신, log-file/01-log.log 를 직접 파싱해서 사용한다.
- 비정형 텍스트 로그를 "컬럼 스키마를 가진 표 형태" 로 정규화한 뒤 Parquet 으로
  저장하는 전체 파이프라인의 1단계.

[입력 로그 형식]  (한 이벤트가 2줄, 이벤트 사이는 빈 줄)
  2026-04-30T06:00:00.000000 LITHO_EUV LOT_START eqp_01 lot_01 wafer01.01
  start success

[추출 스키마]
  ts          datetime64[ns]   타임스탬프
  equipment   string(dict)     장비 타입 (LITHO_EUV / LITHO_ARF_IMM / …)
  event       string(dict)     이벤트명 (LOT_START / WAFER_LOAD / EXPOSURE_DONE / …)
  eqp_id      string(dict)     장비 ID (eqp_01)
  lot_id      string(dict)     로트 ID (lot_01)
  wafer_id    string           웨이퍼 ID (wafer01.01)
  action      string(dict)     start / end
  result      string(dict)     success / fail / warn

[Parquet 으로 저장하는 이유 — 본 데이터 기준]
  - equipment/event/eqp_id/lot_id/action/result 는 카디널리티가 매우 낮은
    범주형 → dictionary encoding 으로 사이즈가 극단적으로 줄어든다.
    (CSV 라면 LITHO_HNA_EUV 라는 12바이트 문자열을 매 행마다 그대로 저장)
  - ts 는 컬럼 단위로 정렬돼 있어 row-group min/max 통계로 시간 범위 필터
    (predicate pushdown) 가 즉시 적용됨.
  - dtype 보존 — 다시 읽을 때 ts 가 datetime 으로 바로 복원되어 재파싱 불필요.

[본 스크립트가 하는 일]
  1) log-file/ 의 모든 *.log 파일을 읽어 이벤트 단위로 파싱
  2) pandas DataFrame 으로 모은다 (저카디널리티 컬럼은 category 로 캐스팅)
  3) Snappy 압축으로 logs.parquet 에 저장
  4) 같은 데이터를 logs.csv 로도 저장해 사이즈를 비교 출력
  5) Parquet 을 다시 읽어 shape/head/dtypes 가 그대로인지 확인
"""
from pathlib import Path
import os
import re
import pandas as pd

LOG_DIR = Path(__file__).parent / "log-file"
PARQUET_PATH = Path(__file__).parent / "logs.parquet"
CSV_PATH = Path(__file__).parent / "logs.csv"

# 헤더 줄 정규식 — 토큰 6개를 포지션으로 잡는다.
#   (.+?) 로 비탐욕 매칭하지 않고, 토큰 사이는 \s+ 로 두어 공백 개수 변동을 흡수.
HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+"          # 2026-04-30T06:00:00.000000
    r"(?P<equipment>\S+)\s+"    # LITHO_EUV
    r"(?P<event>\S+)\s+"        # LOT_START
    r"(?P<eqp_id>\S+)\s+"       # eqp_01
    r"(?P<lot_id>\S+)\s+"       # lot_01
    r"(?P<wafer_id>\S+)\s*$"    # wafer01.01
)


def parse_log_file(path: Path):
    """파일을 빈 줄 기준 블록으로 끊어, 각 블록(헤더+상태)을 dict 한 건으로 yield."""
    block: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                yield from _parse_block(block, path.name)
                block = []
        if block:
            yield from _parse_block(block, path.name)


def _parse_block(block: list[str], source: str):
    """[헤더줄, 상태줄] 2줄 블록을 한 행으로 변환."""
    if len(block) < 2:
        # 형식 어긋난 블록은 건너뛴다 (필요시 로그로 남길 수 있음).
        return
    m = HEADER_RE.match(block[0])
    if not m:
        return
    status_tokens = block[1].split()
    if len(status_tokens) < 2:
        return
    yield {
        **m.groupdict(),
        "action": status_tokens[0],
        "result": status_tokens[1],
        "source": source,
    }


# 1) 모든 로그 파일을 한 번에 파싱
log_files = sorted(p for p in LOG_DIR.iterdir() if p.is_file())
if not log_files:
    raise SystemExit(f"[!] 처리할 로그 파일이 없습니다: {LOG_DIR}")

records = [rec for path in log_files for rec in parse_log_file(path)]
print(f"파싱된 이벤트 수: {len(records)}건  (파일 {len(log_files)}개)")

# 2) DataFrame 으로 변환 + dtype 정리
df = pd.DataFrame.from_records(records)
df["ts"] = pd.to_datetime(df["ts"])  # ISO 8601 자동 인식
# 카디널리티가 낮은 컬럼은 category 로 → 메모리/Parquet 사이즈 모두 절감
for col in ["equipment", "event", "eqp_id", "lot_id", "action", "result", "source"]:
    df[col] = df[col].astype("category")

# 시간 정렬 — row-group min/max 통계가 의미 있게 작동하려면 정렬돼 있는 편이 유리
df = df.sort_values("ts").reset_index(drop=True)

print(f"\nDataFrame shape: {df.shape}")
print(df.head())
print(f"\ndtypes:\n{df.dtypes}")

# 3) Parquet 저장 (Snappy 압축, 인덱스 미저장)
df.to_parquet(PARQUET_PATH, compression="snappy", index=False)
parquet_kb = os.path.getsize(PARQUET_PATH) / 1024

# 4) CSV 로도 저장해서 사이즈 비교 (Parquet 의 압축 효과를 체감)
df.to_csv(CSV_PATH, index=False)
csv_kb = os.path.getsize(CSV_PATH) / 1024

print(f"\n[파일 크기 비교]")
print(f"  CSV     : {csv_kb:>8.1f} KB  ({CSV_PATH.name})")
print(f"  Parquet : {parquet_kb:>8.1f} KB  ({PARQUET_PATH.name})")
print(f"  비율    : Parquet 이 CSV 의 {parquet_kb / csv_kb * 100:.1f}%")

# 5) 다시 읽어 dtype 이 그대로 복원되는지 확인
loaded = pd.read_parquet(PARQUET_PATH)
print(f"\n[복원 확인]")
print(f"  shape  : {loaded.shape}")
print(f"  ts dtype : {loaded['ts'].dtype}   (CSV 였다면 object 로 복원됨)")
print(f"  equipment 분포:\n{loaded['equipment'].value_counts()}")
