"""
T03. Drain3 상태 영속화 (파일 기반)
파스 트리 상태를 파일로 저장해 재시작 후에도 학습 결과를 이어간다.
"""
from drain3 import TemplateMiner
from drain3.file_persistence import FilePersistence

STATE_FILE = "drain3_state.bin"

# 1차 실행: 템플릿을 학습하고 상태를 디스크에 저장
tm1 = TemplateMiner(persistence_handler=FilePersistence(STATE_FILE))
for log in [
    "Service api started on port 8080",
    "Service db  started on port 5432",
    "Service api stopped",
]:
    tm1.add_log_message(log)

print("[1차 학습 후] 클러스터 수:", len(tm1.drain.clusters))

# 2차 실행: 같은 파일을 로드 → 새 인스턴스가 기존 트리를 그대로 이어받음
tm2 = TemplateMiner(persistence_handler=FilePersistence(STATE_FILE))
print("[재로딩 후]   클러스터 수:", len(tm2.drain.clusters))

for cluster in tm2.drain.clusters:
    print(f"  - {cluster.get_template()}")
