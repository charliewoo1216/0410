"""
T02. Drain3 마스킹 정규식 커스터마이징
IP, UUID, 숫자 등을 사전에 마스킹해 템플릿 정확도를 높인다.
"""
from drain3 import TemplateMiner
from drain3.template_miner_config import TemplateMinerConfig
from drain3.masking import MaskingInstruction

config = TemplateMinerConfig()
config.masking_instructions = [
    MaskingInstruction(r"((?<=[^A-Za-z0-9])|^)(\d{1,3}\.){3}\d{1,3}((?=[^A-Za-z0-9])|$)", "IP"),
    MaskingInstruction(r"((?<=[^A-Za-z0-9])|^)([0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12})((?=[^A-Za-z0-9])|$)", "UUID"),
    MaskingInstruction(r"((?<=[^A-Za-z0-9])|^)\d+((?=[^A-Za-z0-9])|$)", "NUM"),
]

tm = TemplateMiner(config=config)

LOGS = [
    "User 12345 from 192.168.0.1 finished job a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "User 67890 from 10.0.0.1 finished job b2c3d4e5-f6a7-8901-bcde-f23456789012",
]
for log in LOGS:
    res = tm.add_log_message(log)
    print(f"original  : {log}")
    print(f"template  : {res['template_mined']}")
    print()
