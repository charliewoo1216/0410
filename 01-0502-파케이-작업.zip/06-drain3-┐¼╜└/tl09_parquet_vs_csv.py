"""
T09. Parquet vs CSV 용량/속도 벤치마크
같은 데이터프레임을 두 포맷으로 저장하고 크기 및 IO 속도를 비교한다.
"""
import pandas as pd
import numpy as np
import os
import time

np.random.seed(0)
N = 200_000
df = pd.DataFrame({
    "ts": pd.date_range("2025-01-01", periods=N, freq="1min"),
    "level": np.random.choice(["INFO", "WARN", "ERROR"], N, p=[0.85, 0.10, 0.05]),
    "service": np.random.choice(["api", "db", "auth", "cache"], N),
    "duration_ms": np.random.lognormal(4, 0.5, N),
})

# 쓰기 속도
t0 = time.time(); df.to_csv("bench.csv", index=False);          csv_w = time.time() - t0
t0 = time.time(); df.to_parquet("bench.parquet", index=False);  pq_w  = time.time() - t0

# 파일 크기
csv_sz = os.path.getsize("bench.csv") / 1024**2
pq_sz  = os.path.getsize("bench.parquet") / 1024**2

# 읽기 속도
t0 = time.time(); pd.read_csv("bench.csv");      csv_r = time.time() - t0
t0 = time.time(); pd.read_parquet("bench.parquet"); pq_r  = time.time() - t0

print(f"{'metric':<12} {'CSV':>10} {'Parquet':>10}")
print(f"{'size (MB)':<12} {csv_sz:>10.2f} {pq_sz:>10.2f}")
print(f"{'write (s)':<12} {csv_w:>10.3f} {pq_w:>10.3f}")
print(f"{'read  (s)':<12} {csv_r:>10.3f} {pq_r:>10.3f}")
print(f"\n압축률: CSV 대비 Parquet 은 {csv_sz / pq_sz:.1f}× 작음")
