"""
log-file/01-log.log 재생성기 — 약 10,000건의 일관된 이벤트 로그 생성.

[기존 로그의 결함]
  WAFER_LOAD 가 'start success' 로만 등장하고 'end' 가 누락되는 등,
  공정 단계가 시작/종료 쌍을 이루지 않는 경우가 있었다.

[새 규칙]
  - 시간이 걸리는 모든 공정 단계는 start/end 한 쌍으로 기록한다.
    (WAFER_LOAD, STAGE_CALIB, ALIGN_COARSE, ALIGN_FINE, EXPOSURE, WAFER_UNLOAD,
     OVL_MEASURE, DEFECT_SCAN)
  - 순간 이벤트는 단일 이벤트로 기록한다.
    (LOT_START start success / LOT_END end success / RECOVERED end success /
     ALIGN_FAIL end fail / WARN end warn)
  - 약 2% 확률로 ALIGN_FINE 이 실패 → ALIGN_FAIL → ALIGN_RETRY(start/end) →
    RECOVERED → 같은 웨이퍼에서 ALIGN_FINE 재시도 후 성공
  - 약 0.5% 확률로 임의 단계 종료 시 result='warn' 발생

[로그 형식]  (한 이벤트 = 2줄, 이벤트 사이는 빈 줄)
  2026-04-30T06:00:00.000000 LITHO_EUV LOT_START eqp_01 lot_01 wafer01.01
  start success
"""
from pathlib import Path
from datetime import datetime, timedelta
import random

random.seed(42)

OUT = Path(__file__).parent / "log-file" / "01-log.log"

# (장비 타입, 처리할 lot 수, lot 당 wafer 수, 파이프라인 종류)
EQUIPMENT_TYPES = [
    ("LITHO_EUV",     6, 25, "litho"),
    ("LITHO_ARF_IMM", 6, 25, "litho"),
    ("LITHO_ARF_DRY", 6, 25, "litho"),
    ("LITHO_KRF",     6, 25, "litho"),
    ("LITHO_HNA_EUV", 6, 25, "litho"),
    ("INSP_OVL",      3, 25, "insp_ovl"),
    ("INSP_DEFECT",   3, 25, "insp_defect"),
]

# 단계명, 소요시간 min/max(초)
LITHO_STEPS = [
    ("WAFER_LOAD",    0.3,  0.5),
    ("STAGE_CALIB",   0.8,  1.5),
    ("ALIGN_COARSE",  0.4,  0.9),
    ("ALIGN_FINE",    2.0,  4.0),
    ("EXPOSURE",      5.0,  8.0),
    ("WAFER_UNLOAD",  0.2,  0.4),
]
INSP_OVL_STEPS = [
    ("WAFER_LOAD",   0.3,  0.5),
    ("OVL_MEASURE",  10.0, 15.0),
    ("WAFER_UNLOAD", 0.2,  0.4),
]
INSP_DEFECT_STEPS = [
    ("WAFER_LOAD",   0.3,  0.5),
    ("DEFECT_SCAN",  12.0, 18.0),
    ("WAFER_UNLOAD", 0.2,  0.4),
]
PIPELINES = {
    "litho": LITHO_STEPS,
    "insp_ovl": INSP_OVL_STEPS,
    "insp_defect": INSP_DEFECT_STEPS,
}

ALIGN_FAIL_PROB = 0.02   # ALIGN_FINE 실패율
WARN_PROB = 0.005        # 단계 종료 시 warn 발생률


def fmt_ts(t: datetime) -> str:
    """2026-04-30T06:00:00.000000 형식."""
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond:06d}"


class LogWriter:
    def __init__(self):
        self.lines: list[str] = []
        self.event_count = 0

    def write(self, t, eq, event, eqp_id, lot_id, wafer_id, action, result):
        self.lines.append(f"{fmt_ts(t)} {eq} {event} {eqp_id} {lot_id} {wafer_id}")
        self.lines.append(f"{action} {result}")
        self.lines.append("")
        self.event_count += 1


def gen_wafer_pipeline(w: LogWriter, t: datetime, eq, eqp_id, lot_id, wafer_id, steps):
    """한 웨이퍼에 대해 파이프라인 step 들을 start/end 쌍으로 기록.
    이상 이벤트(ALIGN_FAIL → ALIGN_RETRY → RECOVERED) 가 발생하면 처리 후 진행.
    return: 마지막 시각."""
    for step_name, min_d, max_d in steps:
        # start
        w.write(t, eq, step_name, eqp_id, lot_id, wafer_id, "start", "success")
        t += timedelta(seconds=random.uniform(min_d, max_d))

        # ALIGN_FINE 은 가끔 실패한다
        if step_name == "ALIGN_FINE" and random.random() < ALIGN_FAIL_PROB:
            # 실패: ALIGN_FINE end fail
            w.write(t, eq, step_name, eqp_id, lot_id, wafer_id, "end", "fail")
            t += timedelta(milliseconds=random.randint(100, 300))
            # ALIGN_FAIL: 단일 이벤트
            w.write(t, eq, "ALIGN_FAIL", eqp_id, lot_id, wafer_id, "end", "fail")
            t += timedelta(milliseconds=random.randint(200, 500))
            # ALIGN_RETRY: start/end
            w.write(t, eq, "ALIGN_RETRY", eqp_id, lot_id, wafer_id, "start", "success")
            t += timedelta(seconds=random.uniform(2.0, 5.0))
            w.write(t, eq, "ALIGN_RETRY", eqp_id, lot_id, wafer_id, "end", "success")
            t += timedelta(milliseconds=200)
            # RECOVERED: 단일 이벤트
            w.write(t, eq, "RECOVERED", eqp_id, lot_id, wafer_id, "end", "success")
            t += timedelta(milliseconds=300)
            # 재시도된 ALIGN_FINE: start/end success
            w.write(t, eq, step_name, eqp_id, lot_id, wafer_id, "start", "success")
            t += timedelta(seconds=random.uniform(min_d, max_d))
            w.write(t, eq, step_name, eqp_id, lot_id, wafer_id, "end", "success")
        else:
            # 정상 종료 (가끔 warn)
            result = "warn" if random.random() < WARN_PROB else "success"
            w.write(t, eq, step_name, eqp_id, lot_id, wafer_id, "end", result)
            if result == "warn":
                # WARN 단일 이벤트도 함께 남김
                t += timedelta(milliseconds=200)
                w.write(t, eq, "WARN", eqp_id, lot_id, wafer_id, "end", "warn")

        t += timedelta(milliseconds=random.randint(50, 200))
    return t


def main():
    w = LogWriter()
    # 각 장비는 약간의 시작 오프셋만 두고 동시 가동
    base_t = datetime(2026, 4, 30, 6, 0, 0)

    for eq_idx, (eq, n_lots, wpl, pipeline_name) in enumerate(EQUIPMENT_TYPES):
        eqp_id = "eqp_01"
        steps = PIPELINES[pipeline_name]
        eq_start = base_t + timedelta(seconds=eq_idx * 5)

        for lot_n in range(1, n_lots + 1):
            lot_id = f"lot_{lot_n:02d}"
            # 각 lot 사이에 충분한 간격 (lot 간 stage 전환 시간)
            t = eq_start + timedelta(minutes=(lot_n - 1) * 60)

            # LOT_START (단일 이벤트)
            first_wafer = "wafer01.01"
            w.write(t, eq, "LOT_START", eqp_id, lot_id, first_wafer, "start", "success")
            t += timedelta(milliseconds=random.randint(200, 500))

            for wafer_n in range(1, wpl + 1):
                wafer_id = f"wafer{wafer_n:02d}.01"
                t = gen_wafer_pipeline(w, t, eq, eqp_id, lot_id, wafer_id, steps)

            last_wafer = f"wafer{wpl:02d}.01"
            w.write(t, eq, "LOT_END", eqp_id, lot_id, last_wafer, "end", "success")

    # 시각순으로 정렬 — 여러 장비가 동시에 가동되므로 헤더 1줄째(timestamp) 기준 정렬.
    # 블록 단위(헤더+상태+빈줄=3줄)로 묶어서 정렬해야 한다.
    blocks = []
    for i in range(0, len(w.lines), 3):
        blocks.append(w.lines[i:i + 3])
    blocks.sort(key=lambda b: b[0].split()[0])  # 헤더의 첫 토큰(timestamp)
    w.lines = [line for b in blocks for line in b]

    OUT.write_text("\n".join(w.lines), encoding="utf-8")
    print(f"생성 완료: {OUT}")
    print(f"  이벤트 수: {w.event_count:,}건")
    print(f"  파일 라인: {len(w.lines):,}줄")
    print(f"  파일 크기: {OUT.stat().st_size / 1024:.1f} KB")


if __name__ == "__main__":
    main()
