"""
T04. 템플릿 ID 별 발생 빈도와 추이
Drain3가 부여한 cluster_id를 시간축과 결합해 템플릿별 추이를 본다.
"""
import pandas as pd
import numpy as np
from drain3 import TemplateMiner

np.random.seed(0)
TEMPLATES = [
    "User {} logged in",
    "Order {} created",
    "Disk usage {}%",
    "Cache miss for key {}",
]
N = 2000

logs = []
ts_base = pd.Timestamp("2025-10-10 00:00")
for i in range(N):
    tpl = np.random.choice(TEMPLATES, p=[0.5, 0.3, 0.15, 0.05])
    logs.append((ts_base + pd.Timedelta(seconds=i * 30), tpl.format(np.random.randint(1, 1000))))

tm = TemplateMiner()
records = []
for ts, msg in logs:
    res = tm.add_log_message(msg)
    records.append({"ts": ts, "cid": res["cluster_id"], "template": res["template_mined"]})

df = pd.DataFrame(records).set_index("ts")

print("[템플릿별 누적 빈도]")
print(df.groupby(["cid", "template"]).size().sort_values(ascending=False))

print("\n[1시간 단위 cid별 카운트 (처음 5시간)]")
print(df.groupby([pd.Grouper(freq="1H"), "cid"]).size().unstack(fill_value=0).head())
