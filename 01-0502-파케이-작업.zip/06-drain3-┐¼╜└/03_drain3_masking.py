"""
T03. Drain3 마스킹 정규식 커스터마이징
- 02_drain3_basic.py 의 한계: 마스킹 규칙이 없으니 Drain3 가 "토큰 길이가 같고
  앞쪽이 같으면 비슷"이라는 휴리스틱만으로 묶어, 이벤트명(LOT_START, WAFER_LOAD,
  EXPOSURE_DONE 등)까지 <*> 로 일반화돼 한 줄에 6가지 이벤트가 뭉뚱그려졌다.
- 본 스크립트는 진짜 가변값(타임스탬프, 장비/로트/웨이퍼 ID)만 사전에 마스킹해
  Drain3 의 토큰 비교 단계에서 이미 동일한 토큰이 되도록 만든다.
  → 이벤트명은 문자 그대로 남아 (장비×이벤트) 단위로 깔끔하게 클러스터가 분리된다.

[입력 로그 예]
  2026-04-30T06:00:00.000000 LITHO_EUV LOT_START eqp_01 lot_01 wafer01.01
  start success
  → 두 줄을 합쳐 한 메시지로 투입.

[적용 마스킹]
  TIMESTAMP : 2026-04-30T06:00:00.000000  → <:TIMESTAMP:>
  EQP       : eqp_01                       → <:EQP:>
  LOT       : lot_01                       → <:LOT:>
  WAFER     : wafer01.01                   → <:WAFER:>
"""
from pathlib import Path
from drain3 import TemplateMiner
from drain3.template_miner_config import TemplateMinerConfig
from drain3.masking import MaskingInstruction

LOG_DIR = Path(__file__).parent / "log-file"

# 마스킹 규칙: 토큰화 직전에 정규식 매치 부분을 고정 토큰으로 치환한다.
# - 첫 번째 인자: 정규식
# - 두 번째 인자: 치환에 쓰일 라벨 (Drain3 가 <:LABEL:> 형태로 끼워 넣음)
# 순서가 중요: 더 구체적인 패턴(타임스탬프, wafer)을 먼저 두어, 일반 NUM 패턴이
# 그것을 잘게 부수지 않도록 한다.
config = TemplateMinerConfig()
config.masking_instructions = [
    # ISO 8601 타임스탬프 (마이크로초 포함)
    MaskingInstruction(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+", "TIMESTAMP"),
    # wafer ID: wafer01.01 형태 (점 포함이라 NUM 보다 먼저 잡아야 함)
    MaskingInstruction(r"wafer\d+\.\d+", "WAFER"),
    # 장비/로트 ID
    MaskingInstruction(r"eqp_\d+", "EQP"),
    MaskingInstruction(r"lot_\d+", "LOT"),
]
# Drain3 의 유사도 임계값.
# 마스킹 후 한 메시지는 8토큰 (<TIMESTAMP> 장비 이벤트 <EQP> <LOT> <WAFER> 동작 결과)
# 이 되는데, 사실상 변동 위치는 "이벤트"(2번)와 "동작/결과"(6,7번) 정도뿐이라
# 기본 0.4 로는 모든 게 한 클러스터로 합쳐진다.
# 0.9 로 올려야 8토큰 중 7개 이상 일치할 때만 같은 클러스터로 묶여,
# (장비 × 이벤트) 단위로 깔끔하게 분리된다.
config.drain_sim_th = 0.9

tm = TemplateMiner(config=config)


def iter_log_messages(path: Path):
    """빈 줄로 구분된 이벤트 블록(헤더+상태)을 한 메시지로 합쳐 yield."""
    block: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                yield " ".join(block)
                block = []
        if block:
            yield " ".join(block)


log_files = sorted(p for p in LOG_DIR.iterdir() if p.is_file())
if not log_files:
    raise SystemExit(f"[!] 처리할 로그 파일이 없습니다: {LOG_DIR}")

# 마스킹이 실제로 어떻게 동작하는지 보여주기 위해 처음 몇 줄은 원문/마스킹 결과를 비교 출력.
print("[마스킹 적용 샘플]")
sample_count = 0
for path in log_files:
    for msg in iter_log_messages(path):
        masked = tm.masker.mask(msg)
        print(f"  원문   : {msg}")
        print(f"  마스킹 : {masked}")
        sample_count += 1
        if sample_count >= 3:
            break
    if sample_count >= 3:
        break

# 본 처리: 모든 파일의 모든 메시지를 같은 TemplateMiner 에 누적 투입.
total = 0
print("\n[클러스터 변동 추적]")
for path in log_files:
    print(f"\n=== {path.name} ===")
    count = 0
    for msg in iter_log_messages(path):
        res = tm.add_log_message(msg)
        if res["change_type"] != "none":
            print(f"  [{res['change_type']:>24}] id={res['cluster_id']:>2} | {res['template_mined']}")
        count += 1
    print(f"  -> 처리 메시지 수: {count}")
    total += count

# 최종 클러스터 목록 (size 내림차순)
print(f"\n[추출된 템플릿 목록]  (총 입력 메시지 {total}건, 클러스터 {len(tm.drain.clusters)}개)")
for cluster in sorted(tm.drain.clusters, key=lambda c: -c.size):
    print(f"  cluster #{cluster.cluster_id} (size={cluster.size}): {cluster.get_template()}")
