"""
T12. Parquet 파티셔닝 — 실제 로그 기반 (장비별 / 날짜별)
- 11_pandas_to_parquet.py 가 단일 파일(logs.parquet)에 다 담았다면,
  이번 스크립트는 같은 데이터를 "디렉터리 구조" 로 쪼개 저장한다.
- 쿼리 시 필요한 파티션만 골라 읽으면 디스크 I/O 가 극단적으로 줄어든다.
  (= partition pruning)

[파티셔닝 키 선택]
  - equipment : 장비 타입은 카디널리티가 낮고(7종), 분석 시 자주 필터됨
                "LITHO_EUV 만 보고 싶다" → 1/7 파티션만 읽음
  - date      : 일자별 파티션. 본 샘플은 1일치라 디렉터리가 1개뿐이지만,
                실제 운영에선 "지난 7일" 같은 시간 범위 쿼리에 결정적
  ※ 너무 잘게 쪼개면 small file 문제(파일 수 폭증, 메타데이터 오버헤드)
     가 생기므로, 보통 (장비/일자) 또는 (서비스/시간대) 정도로 묶는다.

[디렉터리 구조 예]
  logs_partitioned/
    equipment=LITHO_EUV/
      date=2026-04-30/
        part-0.parquet
    equipment=LITHO_ARF_IMM/
      date=2026-04-30/
        part-0.parquet
    ...

[파티션 컬럼은 디렉터리 이름에 박힌다]
  → 파일 내용에는 equipment/date 가 저장되지 않는다 (디렉터리 경로 = 값).
     읽을 때 pyarrow 가 경로를 파싱해서 자동으로 컬럼으로 복원해 준다.
"""
from pathlib import Path
import re
import shutil
import pandas as pd

LOG_DIR = Path(__file__).parent / "log-file"
OUT_DIR = Path(__file__).parent / "logs_partitioned"

HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<equipment>\S+)\s+(?P<event>\S+)\s+"
    r"(?P<eqp_id>\S+)\s+(?P<lot_id>\S+)\s+(?P<wafer_id>\S+)\s*$"
)


def parse_log_file(path: Path):
    block: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                yield from _parse_block(block)
                block = []
        if block:
            yield from _parse_block(block)


def _parse_block(block: list[str]):
    if len(block) < 2:
        return
    m = HEADER_RE.match(block[0])
    if not m:
        return
    status = block[1].split()
    if len(status) < 2:
        return
    yield {**m.groupdict(), "action": status[0], "result": status[1]}


# 1) 모든 로그 파일 파싱 → DataFrame
log_files = sorted(p for p in LOG_DIR.iterdir() if p.is_file())
records = [r for p in log_files for r in parse_log_file(p)]
df = pd.DataFrame.from_records(records)
df["ts"] = pd.to_datetime(df["ts"])
# 파티셔닝 키로 쓸 date 컬럼 (datetime → 'YYYY-MM-DD' 문자열)
# date 컬럼 없이 ts.dt.date 를 직접 partition_cols 에 넣어도 되지만, 명시적으로
# 추출해 두면 디렉터리 이름이 깔끔(date=2026-04-30) 해진다.
df["date"] = df["ts"].dt.date.astype(str)

print(f"파싱된 이벤트 수: {len(df)}건")
print(f"장비 종류       : {df['equipment'].nunique()}종 → {sorted(df['equipment'].unique())}")
print(f"날짜 범위       : {df['date'].min()} ~ {df['date'].max()}")

# 2) 기존 파티션 디렉터리가 있으면 깨끗이 비우고 다시 쓴다
#    (to_parquet 은 partition 디렉터리에 append 동작이라 누적되어버린다)
if OUT_DIR.exists():
    shutil.rmtree(OUT_DIR)

# 3) 파티션 쓰기
#    partition_cols 에 지정한 컬럼은 파일 본문이 아닌 디렉터리 경로로 빠진다.
df.to_parquet(
    OUT_DIR,
    partition_cols=["equipment", "date"],
    compression="snappy",
    index=False,
)

# 4) 만들어진 디렉터리 구조 출력
print(f"\n[디렉터리 구조]  ({OUT_DIR.name}/)")
for p in sorted(OUT_DIR.rglob("*.parquet")):
    rel = p.relative_to(OUT_DIR)
    size_kb = p.stat().st_size / 1024
    print(f"  {rel}  ({size_kb:.1f} KB)")

# 5) Partition pruning 데모 — LITHO_EUV 만 읽기
#    내부적으로 logs_partitioned/equipment=LITHO_EUV/ 디렉터리만 스캔한다.
#    나머지 6개 장비 디렉터리는 디스크에서 아예 읽지 않음.
print(f"\n[LITHO_EUV 만 읽기] (다른 장비 파일은 디스크에서 안 읽힘)")
litho_euv = pd.read_parquet(OUT_DIR, filters=[("equipment", "=", "LITHO_EUV")])
print(f"  shape: {litho_euv.shape}")
print(f"  결과별 분포:\n{litho_euv['result'].value_counts()}")

# 6) Partition pruning 데모 — 특정 일자만 읽기
print(f"\n[2026-04-30 만 읽기]")
day = pd.read_parquet(OUT_DIR, filters=[("date", "=", "2026-04-30")])
print(f"  shape: {day.shape}")

# 7) 다중 조건: 특정 장비 + 특정 일자
print(f"\n[INSP_DEFECT + 2026-04-30 만 읽기]")
combo = pd.read_parquet(
    OUT_DIR,
    filters=[("equipment", "=", "INSP_DEFECT"), ("date", "=", "2026-04-30")],
)
print(f"  shape: {combo.shape}")
print(combo[["ts", "event", "wafer_id", "action", "result"]].head())


# ============================================================================
# 8) DuckDB 로 SQL 쿼리하기
# ----------------------------------------------------------------------------
# pandas filters 도 좋지만, 집계/JOIN/시간 윈도우가 끼면 SQL 이 훨씬 자연스럽다.
# DuckDB 는 Parquet 을 메모리에 로드하지 않고 디스크에서 컬럼/필터/파티션
# pushdown 을 모두 자동 적용한다. (pandas filters 와 동일 효과 + SQL 표현력)
#
# - pip install duckdb
# - 'logs_partitioned/**/*.parquet' 처럼 글롭으로 디렉터리 전체를 데이터셋처럼
#   다룰 수 있고, hive_partitioning=true 옵션으로 디렉터리명에 박힌
#   equipment / date 컬럼이 자동 복원된다.
# ============================================================================
import duckdb

GLOB = f"{OUT_DIR.as_posix()}/**/*.parquet"  # Windows 경로도 / 로 통일

print("\n[DuckDB] 장비 × 결과별 이벤트 수 (전체)")
duckdb.sql(f"""
    SELECT equipment, result, COUNT(*) AS n
    FROM read_parquet('{GLOB}', hive_partitioning=true)
    GROUP BY equipment, result
    ORDER BY equipment, n DESC
""").show()

print("\n[DuckDB] LITHO_EUV 만 - partition pruning 자동 적용")
# WHERE equipment='LITHO_EUV' 한 줄로 logs_partitioned/equipment=LITHO_EUV/ 만 스캔
duckdb.sql(f"""
    SELECT event, action, result, COUNT(*) AS n
    FROM read_parquet('{GLOB}', hive_partitioning=true)
    WHERE equipment = 'LITHO_EUV'
    GROUP BY event, action, result
    ORDER BY n DESC
""").show()

print("\n[DuckDB] 실패/경고 이벤트만 추려내기 (이상 이벤트 백로그)")
duckdb.sql(f"""
    SELECT ts, equipment, event, wafer_id, result
    FROM read_parquet('{GLOB}', hive_partitioning=true)
    WHERE result IN ('fail', 'warn')
    ORDER BY ts
""").show()

print("\n[DuckDB] 시간 윈도우 - 1분 단위 이벤트 카운트 상위 5분")
duckdb.sql(f"""
    SELECT date_trunc('minute', ts) AS minute,
           COUNT(*) AS events,
           SUM(CASE WHEN result <> 'success' THEN 1 ELSE 0 END) AS abnormal
    FROM read_parquet('{GLOB}', hive_partitioning=true)
    GROUP BY minute
    ORDER BY events DESC
    LIMIT 5
""").show()

print("\n[DuckDB -> pandas] .df() 로 결과를 DataFrame 으로 받기")
# 분석/시각화는 pandas 가 편하니, 집계는 DuckDB → 결과만 .df() 로 변환하는 게 정석.
fail_rate = duckdb.sql(f"""
    SELECT equipment,
           COUNT(*) AS total,
           SUM(CASE WHEN result = 'fail' THEN 1 ELSE 0 END) AS fails,
           ROUND(100.0 * SUM(CASE WHEN result = 'fail' THEN 1 ELSE 0 END) / COUNT(*), 2)
               AS fail_pct
    FROM read_parquet('{GLOB}', hive_partitioning=true)
    GROUP BY equipment
    ORDER BY fail_pct DESC
""").df()
print(fail_rate)
