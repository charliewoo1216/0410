"""
T08. Parquet 컬럼/필터 pushdown
필요한 컬럼·행만 디스크에서 읽어 I/O 를 줄인다.
"""
import pandas as pd
import numpy as np
import time
import os

np.random.seed(0)
N = 500_000
df = pd.DataFrame({
    "ts": pd.date_range("2025-10-10", periods=N, freq="1s"),
    "level": np.random.choice(["INFO", "WARN", "ERROR"], N, p=[0.85, 0.10, 0.05]),
    "service": np.random.choice(["api", "db", "auth", "cache"], N),
    "duration_ms": np.random.lognormal(4, 0.5, size=N),
    "msg": ["lorem ipsum dolor sit amet" * 3 for _ in range(N)],  # 일부러 큰 컬럼
})
df.to_parquet("big_logs.parquet", compression="snappy", index=False)
print(f"파일 크기: {os.path.getsize('big_logs.parquet') / 1024**2:.2f} MB")

# 1) 전체 읽기
t0 = time.time()
full = pd.read_parquet("big_logs.parquet")
print(f"\n[전체 읽기]    rows={len(full):,}, cols={full.shape[1]}, time={time.time()-t0:.3f}s")

# 2) 필요한 컬럼만
t0 = time.time()
two = pd.read_parquet("big_logs.parquet", columns=["ts", "level"])
print(f"[2개 컬럼만]   rows={len(two):,}, cols={two.shape[1]}, time={time.time()-t0:.3f}s")

# 3) 필터 + 컬럼 pushdown
t0 = time.time()
err = pd.read_parquet(
    "big_logs.parquet",
    columns=["ts", "service", "duration_ms"],
    filters=[("level", "==", "ERROR")],
)
print(f"[ERROR만]      rows={len(err):,}, cols={err.shape[1]}, time={time.time()-t0:.3f}s")
