"""
T12. 통합 파이프라인: Drain3 → Parquet → 알림
1) raw 로그를 Drain3 으로 파싱
2) DataFrame 으로 누적 후 Parquet 저장
3) ERROR 템플릿이 임계치를 초과하면 알림 출력
"""
import pandas as pd
from drain3 import TemplateMiner

LOGS = [
    "INFO  user alice login",
    "INFO  user bob   login",
    "ERROR db connection refused at db01",
    "ERROR db connection refused at db02",
    "ERROR db connection refused at db03",
    "ERROR db connection refused at db04",
    "INFO  cache hit key=a",
    "INFO  cache hit key=b",
    "ERROR null pointer in module x",
]

tm = TemplateMiner()
records = []
for i, log in enumerate(LOGS):
    res = tm.add_log_message(log)
    records.append({
        "ts": pd.Timestamp("2025-10-10 00:00") + pd.Timedelta(seconds=i),
        "level": log.split()[0],
        "cid": res["cluster_id"],
        "template": res["template_mined"],
    })

df = pd.DataFrame(records)
df.to_parquet("alert_pipeline.parquet", compression="snappy", index=False)
print("Parquet 저장 완료. 행수:", len(df))

THRESHOLD = 3
err = df[df["level"] == "ERROR"].groupby(["cid", "template"]).size()
print(f"\nERROR 템플릿별 빈도 (임계치={THRESHOLD}):")
for (cid, tpl), cnt in err.items():
    flag = "⚠ ALERT" if cnt >= THRESHOLD else "ok"
    print(f"  cid={cid} cnt={cnt:>3} [{flag}] {tpl}")
