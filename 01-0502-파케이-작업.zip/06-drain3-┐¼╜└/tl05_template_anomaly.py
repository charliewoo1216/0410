"""
T05. 신규 템플릿 등장 = 이상 신호
Drain3 result["change_type"] == "cluster_created" 가 발생하면 알림을 띄운다.
"""
from drain3 import TemplateMiner

NORMAL = [
    "User alice logged in",
    "User bob logged in",
    "Order 1 created",
    "Order 2 created",
    "Order 3 created",
] * 5

ANOMALOUS = [
    "Segmentation fault in module xyz at 0xdeadbeef",  # 신규 패턴
    "Kernel panic: not syncing",                        # 신규 패턴
]

tm = TemplateMiner()
print("[정상 학습 단계]")
for log in NORMAL:
    tm.add_log_message(log)
print(f"학습된 템플릿 수: {len(tm.drain.clusters)}")

print("\n[운영 단계 — 신규 템플릿 감지]")
for log in NORMAL[:3] + ANOMALOUS:
    res = tm.add_log_message(log)
    if res["change_type"] == "cluster_created":
        print(f"  ⚠ ALERT 신규 템플릿: {res['template_mined']}")
    else:
        print(f"  OK   기존 템플릿  : {res['template_mined']}")
