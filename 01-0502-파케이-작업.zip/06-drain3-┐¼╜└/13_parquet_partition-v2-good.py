"""
T13-v2. log-file/ → Parquet → DuckDB 페어링 쿼리

[하는 일]
  1) log-file/ 의 로그를 파싱해 Parquet 으로 저장
  2) DuckDB 로 같은 (equipment, eqp_id, lot_id, wafer_id, event) 안의
     start / end 두 줄을 ROW_NUMBER 로 짝지어 한 행으로 합침
  3) 다음 7컬럼만 출력:
        event | start_time | end_time | duration_tm | eqp_id | lot_id | wafer_id
"""
from pathlib import Path
import re
import pandas as pd
import duckdb

# 입출력 경로. __file__ 기준 상대 경로 → 어디서 실행해도 동일하게 동작.
LOG_DIR = Path(__file__).parent / "log-file"
PARQUET_PATH = Path(__file__).parent / "13-logs.parquet"

# 로그 헤더 줄(첫 번째 줄) 정규식.
#   예) "2026-04-30T06:00:00.000000 LITHO_EUV LOT_START eqp_01 lot_01 wafer01.01"
# - \S+ 는 "공백 아닌 토큰 1개 이상" — 공백 개수 변동을 흡수.
# - 명명 그룹 (?P<name>...) 으로 잡아두면 m.groupdict() 한 번에 dict 변환됨.
HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<equipment>\S+)\s+(?P<event>\S+)\s+"
    r"(?P<eqp_id>\S+)\s+(?P<lot_id>\S+)\s+(?P<wafer_id>\S+)\s*$"
)


def parse_log_file(path: Path):
    """한 로그 파일을 "이벤트 블록" 단위로 끊어 dict 한 건씩 yield 한다.

    파일 구조:
        <헤더 줄>          ← 토큰 6개
        <상태 줄>          ← "start success" / "end fail" 등
        <빈 줄>            ← 블록 구분자
        <헤더 줄>
        <상태 줄>
        <빈 줄>
        ...

    빈 줄을 만나면 누적된 block 을 _parse_block 에 넘겨 dict 로 변환한다.
    파일이 빈 줄 없이 끝나는 경우를 대비해 마지막에도 한 번 flush.
    """
    block: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()              # 줄 끝 \n / \r\n 제거
            if line:
                block.append(line)            # 내용 있는 줄: 블록에 누적
            elif block:
                yield from _parse_block(block)  # 빈 줄: 블록 종료 → 변환
                block = []
        if block:                              # EOF 시 마지막 블록 flush
            yield from _parse_block(block)


def _parse_block(block: list[str]):
    """[헤더 줄, 상태 줄] 2줄 블록을 한 행짜리 dict 로 변환해 yield.
    형식이 어긋난 블록은 조용히 스킵한다 (실제 운영에선 로깅하는 게 안전)."""
    if len(block) < 2:
        return                                  # 블록이 2줄 미만 → 스킵
    m = HEADER_RE.match(block[0])
    if not m:
        return                                  # 헤더 정규식 불일치 → 스킵
    status = block[1].split()
    if len(status) < 2:
        return                                  # 상태 줄 토큰 부족 → 스킵
    # 헤더의 6개 명명 그룹 + 상태의 action/result = 8개 컬럼 dict
    yield {**m.groupdict(), "action": status[0], "result": status[1]}


# ─────────────────────────────────────────────────────────────────────────
# 1) 파싱 → Parquet 저장
#    - log-file/ 의 모든 파일을 정렬 순으로 순회하며 한 번에 records 리스트로
#    - pandas DataFrame 으로 만들고 ts 만 datetime 으로 캐스팅
#    - snappy 압축 Parquet 으로 저장 (DuckDB 가 바로 읽을 입력)
# ─────────────────────────────────────────────────────────────────────────
records = [r for p in sorted(LOG_DIR.iterdir()) if p.is_file() for r in parse_log_file(p)]
df = pd.DataFrame.from_records(records)
df["ts"] = pd.to_datetime(df["ts"])             # ISO 8601 → datetime64[ns]
df.to_parquet(PARQUET_PATH, compression="snappy", index=False)

# ─────────────────────────────────────────────────────────────────────────
# 2) DuckDB: start/end 페어링 SQL
#    핵심 아이디어:
#      같은 (equipment, eqp_id, lot_id, wafer_id, event) 안에서 action='start'
#      들과 action='end' 들 각각에 ROW_NUMBER() 로 1, 2, 3… 번호를 매긴 뒤
#      "N번째 start" 와 "N번째 end" 를 FULL OUTER JOIN 으로 짝짓는다.
#    덕분에:
#      - ALIGN_FINE 이 fail → retry 되어 같은 wafer 에서 start/end 가 2쌍이어도
#        1번째끼리, 2번째끼리 정확히 매칭됨.
#      - 단일 이벤트(LOT_START / LOT_END / ALIGN_FAIL / RECOVERED / WARN)는
#        한쪽이 비어 있으므로 FULL OUTER JOIN 의 NULL 컬럼으로 그대로 노출됨.
# ─────────────────────────────────────────────────────────────────────────
PAIRED_SQL = f"""
    -- (a) 모든 행에 그룹별 순번(rn) 부여
    WITH ordered AS (
        SELECT
            ts, equipment, event, eqp_id, lot_id, wafer_id, action,
            ROW_NUMBER() OVER (
                -- 그룹 = 같은 장비/lot/wafer/event 의 같은 action
                PARTITION BY equipment, eqp_id, lot_id, wafer_id, event, action
                ORDER BY ts                       -- 시간순 1, 2, 3 …
            ) AS rn
        FROM read_parquet('{PARQUET_PATH.as_posix()}')
    ),
    -- (b) start 만 / end 만 분리해 두 가상 테이블로
    starts AS (SELECT * FROM ordered WHERE action = 'start'),
    ends   AS (SELECT * FROM ordered WHERE action = 'end')

    -- (c) 같은 그룹 + 같은 rn 끼리 FULL OUTER JOIN → 한 행으로 합치기
    SELECT
        COALESCE(s.event,    e.event)    AS event,        -- 둘 중 있는 쪽
        s.ts                              AS start_time,   -- 없으면 NULL
        e.ts                              AS end_time,     -- 없으면 NULL
        -- epoch() = unix timestamp(초). 차이를 소수점 3자리로 반올림.
        -- 한쪽이 NULL 이면 결과도 NULL (단일 이벤트는 duration 없음).
        ROUND(epoch(e.ts) - epoch(s.ts), 3) AS duration_tm,
        COALESCE(s.eqp_id,   e.eqp_id)   AS eqp_id,
        COALESCE(s.lot_id,   e.lot_id)   AS lot_id,
        COALESCE(s.wafer_id, e.wafer_id) AS wafer_id
    FROM starts s
    FULL OUTER JOIN ends e
      ON s.equipment = e.equipment
     AND s.eqp_id    = e.eqp_id
     AND s.lot_id    = e.lot_id
     AND s.wafer_id  = e.wafer_id
     AND s.event     = e.event
     AND s.rn        = e.rn                              -- ★ N번째끼리 매칭
    -- 시간순 정렬. start 가 없으면 end 시각으로 정렬 키를 보충.
    ORDER BY COALESCE(s.ts, e.ts)
"""

# ─────────────────────────────────────────────────────────────────────────
# 3) 출력 — DuckDB 의 box-drawing 표 형식 (12_ 와 동일 모양).
#    .show() 는 기본 max_rows=20 이라, 전부 보이도록 크게 지정.
# ─────────────────────────────────────────────────────────────────────────
print("\n[DuckDB] start/end 페어링 - event / start_time / end_time / duration_tm / eqp_id / lot_id / wafer_id")
duckdb.sql(PAIRED_SQL).show(max_rows=10000)

# 끝에 총 행 수 한 줄. fetchone()[0] 으로 스칼라만 꺼냄.
total = duckdb.sql(f"SELECT COUNT(*) FROM ({PAIRED_SQL})").fetchone()[0]
print(f"총 {total:,}건")
