"""
T10. PyArrow ParquetWriter 로 스트리밍 쓰기
배치 단위로 row group 을 추가해 메모리에 전체를 담지 않고 큰 파일을 쓴다.
"""
import pyarrow as pa
import pyarrow.parquet as pq
import numpy as np

np.random.seed(0)

schema = pa.schema([
    pa.field("ts", pa.timestamp("ms")),
    pa.field("level", pa.string()),
    pa.field("value", pa.float64()),
])

writer = pq.ParquetWriter("stream.parquet", schema, compression="snappy")
TOTAL = 100_000
BATCH = 10_000
import pandas as pd

for batch_idx in range(TOTAL // BATCH):
    df = pd.DataFrame({
        "ts": pd.date_range("2025-10-10", periods=BATCH, freq="100ms") + pd.Timedelta(seconds=batch_idx * 1000),
        "level": np.random.choice(["INFO", "ERROR"], BATCH, p=[0.95, 0.05]),
        "value": np.random.randn(BATCH),
    })
    table = pa.Table.from_pandas(df, schema=schema, preserve_index=False)
    writer.write_table(table)
    print(f"  배치 {batch_idx + 1}/{TOTAL // BATCH} 기록")

writer.close()
print("\n쓰기 완료. row groups 정보:")
meta = pq.read_metadata("stream.parquet")
print(f"  total rows = {meta.num_rows:,}")
print(f"  row groups = {meta.num_row_groups}")
