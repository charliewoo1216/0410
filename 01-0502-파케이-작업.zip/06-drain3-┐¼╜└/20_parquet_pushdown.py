"""
T13. Parquet 컬럼/필터 pushdown — 실제 로그 기반 실측
- 11_/12_ 가 "어떻게 저장하느냐" 였다면, 본 스크립트는 "어떻게 빨리 읽느냐" 다.
- 같은 파일을 (a) 전부 읽기  (b) 컬럼만 골라 읽기  (c) 필터까지 적용해서 읽기
  3가지로 비교해 시간/메모리 차이를 직접 확인한다.

[Pushdown 두 종류]
  1) Projection pushdown (컬럼)
     - read_parquet(columns=[...]) 로 필요한 컬럼만 지정.
     - Parquet 은 컬럼 기반이라 다른 컬럼 영역은 디스크에서 아예 안 읽음.
     - 효과는 "안 읽는 컬럼이 얼마나 큰가" 에 비례. 본 데모에선 일부러
       무거운 raw_msg 컬럼을 만들어 차이를 키운다.

  2) Predicate pushdown (필터)
     - read_parquet(filters=[("col", "==", val), ...])
     - row group 단위 min/max 통계로 "이 블록엔 해당 값이 없다" 를 판정해
       row group 자체를 건너뜀.
     - 효과는 "필터 셀렉티비티(걸러내고 남는 비율)" 와 "데이터가 그 컬럼으로
       정렬돼 있는지" 에 좌우된다. 정렬돼 있을수록 row group 단위 통계가
       선명해져 더 많이 스킵 가능.

[데이터 준비]
  - log-file/ 의 실제 로그(699건)는 timing 측정엔 너무 작아 차이가 ms 단위로
    묻힌다. 그래서 동일 데이터를 N배 복제해 의미 있는 크기로 키운다.
    (스키마와 분포는 실제 로그 그대로)
  - 추가로 raw_msg 컬럼을 합쳐 "원본 로그 한 줄을 통째로 들고 있는" 형태로 만든다.
    → 컬럼 pushdown 의 효과를 명확히 보여주기 위함.
"""
from pathlib import Path
import os
import re
import time
import pandas as pd

LOG_DIR = Path(__file__).parent / "log-file"
PARQUET_PATH = Path(__file__).parent / "big_logs.parquet"
REPLICATE = 1000  # 699 × 1000 = 699,000 행 정도면 timing 차이가 눈에 보인다

HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<equipment>\S+)\s+(?P<event>\S+)\s+"
    r"(?P<eqp_id>\S+)\s+(?P<lot_id>\S+)\s+(?P<wafer_id>\S+)\s*$"
)


def parse_log_file(path: Path):
    block: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                yield from _parse_block(block)
                block = []
        if block:
            yield from _parse_block(block)


def _parse_block(block: list[str]):
    if len(block) < 2:
        return
    m = HEADER_RE.match(block[0])
    if not m:
        return
    status = block[1].split()
    if len(status) < 2:
        return
    yield {
        **m.groupdict(),
        "action": status[0],
        "result": status[1],
        # 원본 두 줄을 통째로 보관 → 컬럼 pushdown 의 효과를 키우기 위한 "무거운 컬럼"
        "raw_msg": block[0] + " | " + block[1],
    }


# 1) 실제 로그 파싱
log_files = sorted(p for p in LOG_DIR.iterdir() if p.is_file())
records = [r for p in log_files for r in parse_log_file(p)]
base_df = pd.DataFrame.from_records(records)
base_df["ts"] = pd.to_datetime(base_df["ts"])
print(f"원본 파싱: {len(base_df)}건")

# 2) N배 복제로 데이터 부풀리기 (timing 측정용)
#    ts 는 그대로 두면 row-group 통계가 더 잘 작동(같은 시각이 뭉쳐 있음).
#    실측 의도가 "Parquet 의 통계가 얼마나 잘 먹는지" 를 보여주는 것이므로
#    여기서는 의도적으로 ts 정렬을 유지한다.
df = pd.concat([base_df] * REPLICATE, ignore_index=True)
df = df.sort_values("ts").reset_index(drop=True)
print(f"복제 후  : {len(df):,}건  ({REPLICATE}× 복제)")

# 3) Parquet 저장 — row_group_size 를 명시해 통계 단위를 분명히 함
#    (지정 안 하면 pyarrow 기본값 ~64K 행)
df.to_parquet(PARQUET_PATH, compression="snappy", index=False, row_group_size=50_000)
size_mb = os.path.getsize(PARQUET_PATH) / 1024**2
print(f"\n파일 크기: {size_mb:.2f} MB  ({PARQUET_PATH.name})")

# 4) 측정용 헬퍼
def measure(label: str, fn):
    """fn() 의 실행 시간과 결과 DataFrame 의 메모리 사용량을 출력."""
    t0 = time.perf_counter()
    result = fn()
    elapsed = time.perf_counter() - t0
    mem_mb = result.memory_usage(deep=True).sum() / 1024**2
    print(f"  {label:<28} rows={len(result):>9,}  cols={result.shape[1]:>2}  "
          f"time={elapsed*1000:>6.1f} ms  mem={mem_mb:>6.2f} MB")
    return result


print("\n[읽기 방식별 비교]")

# (a) 전체 읽기 — 가장 비싼 케이스
measure("(a) 전체 읽기", lambda: pd.read_parquet(PARQUET_PATH))

# (b) 가벼운 컬럼만 — raw_msg 같은 무거운 컬럼은 디스크에서 안 읽음
measure("(b) ts+equipment+result만",
        lambda: pd.read_parquet(PARQUET_PATH, columns=["ts", "equipment", "result"]))

# (c) 필터 pushdown — result == "fail" (전체의 매우 작은 비율)
measure("(c) result=='fail' 만",
        lambda: pd.read_parquet(PARQUET_PATH, filters=[("result", "==", "fail")]))

# (d) 컬럼 + 필터 동시 — 가장 빠른 케이스
measure("(d) (b) + (c) 동시",
        lambda: pd.read_parquet(
            PARQUET_PATH,
            columns=["ts", "equipment", "event", "result"],
            filters=[("result", "==", "fail")],
        ))

# (e) 시간 범위 필터 — ts 정렬 덕에 row-group 단위로 잘려나간다
mid_ts = base_df["ts"].quantile(0.5)
measure(f"(e) ts >= {mid_ts.time()} 만",
        lambda: pd.read_parquet(
            PARQUET_PATH,
            columns=["ts", "equipment", "event"],
            filters=[("ts", ">=", mid_ts)],
        ))

print("\n[해석]")
print("  (a) → (b): raw_msg 같은 무거운 컬럼을 빼면 시간/메모리 모두 급감")
print("  (a) → (c): fail 비율이 작을수록 더 많은 row group 이 스킵되어 빠름")
print("  (d)     : 두 효과가 곱해져 가장 작은 결과 + 가장 짧은 시간")
