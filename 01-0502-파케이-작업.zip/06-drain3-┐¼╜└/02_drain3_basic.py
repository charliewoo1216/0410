"""
T02. Drain3 로 로그 파일에서 템플릿 추출
- 01_drain3_basic.py 와 동일한 알고리즘이지만, 입력원이 하드코딩된 LOGS 가 아니라
  log-file/ 디렉터리의 실제 로그 파일들이다.
- 같은 TemplateMiner 인스턴스에 여러 파일의 로그를 순차 투입하여,
  파일 경계를 넘어 동일한 템플릿이 누적·일반화되도록 한다.

[입력 로그 형식]
  본 디렉터리의 로그는 "헤더 줄 + 상태 줄"이 한 이벤트를 이루고,
  이벤트 사이는 빈 줄로 구분된다. 예)
      2026-04-30T06:00:00.000000 LITHO_EUV LOT_START eqp_01 lot_01 wafer01.01
      start success
  → Drain3 입장에서는 "한 건의 로그 메시지"로 보는 게 자연스러우므로
     두 줄을 공백으로 이어 붙여 하나의 메시지로 투입한다.
"""
from pathlib import Path
from drain3 import TemplateMiner

LOG_DIR = Path(__file__).parent / "log-file"


def iter_log_messages(path: Path):
    """파일을 빈 줄 기준 블록으로 끊어 한 메시지씩 yield 한다.
    각 블록 내부의 줄바꿈은 공백으로 치환하여 Drain3 의 토큰화에 그대로 태운다."""
    block: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.rstrip()
            if line:
                block.append(line)
            elif block:
                yield " ".join(block)
                block = []
        if block:
            yield " ".join(block)


# TemplateMiner: Drain 알고리즘을 감싼 고수준 API.
# 파일 여러 개를 같은 인스턴스에 투입해야 클러스터가 누적된다.
tm = TemplateMiner()

log_files = sorted(p for p in LOG_DIR.iterdir() if p.is_file())
if not log_files:
    raise SystemExit(f"[!] 처리할 로그 파일이 없습니다: {LOG_DIR}")

total = 0
for path in log_files:
    print(f"\n=== {path.name} ===")
    count = 0
    for msg in iter_log_messages(path):
        # add_log_message: 토큰화 → 트리 탐색 → 유사도 비교 → 병합/신규 생성
        res = tm.add_log_message(msg)
        # change_type: cluster_created / cluster_template_changed / none
        # 변화가 있을 때만 찍어 출력 폭주를 막는다.
        if res["change_type"] != "none":
            print(f"  [{res['change_type']:>24}] id={res['cluster_id']:>2} | {res['template_mined']}")
        count += 1
    print(f"  -> 처리 메시지 수: {count}")
    total += count

# 최종 클러스터(템플릿) 목록과 각 템플릿의 매칭 건수.
print(f"\n[추출된 템플릿 목록]  (총 입력 메시지 {total}건)")
for cluster in sorted(tm.drain.clusters, key=lambda c: -c.size):
    print(f"  cluster #{cluster.cluster_id} (size={cluster.size}): {cluster.get_template()}")
