```@autodocs
Modules = [XmlStructLoader]
```