```@autodocs
Modules = [XmlStructWriter]
```