```@autodocs
Modules = [XsdToStruct]
```