# ASML 장비별 XML 로그 예시 (XmlStructTools 규격 기반)

> ⚠️ 면책: ASML 사내 정식 로그 스키마는 비공개이다. 본 문서의 XSD/XML은 `XmlStructTools.jl`이 지원하는 XSD 기능 범위 안에서 **공개된 ASML 장비 정보(장비명, 측정 항목, 일반적 로그 필드)** 만 재구성한 **교육용 예시**다. 실제 장비에서 출력되는 파일과 1:1 일치하지 않는다.
> 검증 도구: 모든 XSD/XML 예시는 `XsdToStruct.jl + XmlStructLoader.jl`이 처리할 수 있는 부분 집합(`simpleType`, `complexType`, `sequence`, `choice`, `extension`, `union`, `pattern`, `min/maxLength`, `min/maxInclusive`, `dateTime`, `default`)으로만 구성했다. `<include>` / `<import>`는 사용하지 않는다.

---

## 0. 공통 규약

모든 장비 로그는 다음 골격을 공유한다.

```
<{Namespace}:Log
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:{Namespace}="{Namespace}"
    xsi:schemaLocation="{Namespace} {File}.xsd">
    <Header>...</Header>
    <Lot>...</Lot>
    <Wafers>
        <Wafer>...</Wafer>
        ...
    </Wafers>
    <Footer>...</Footer>
</{Namespace}:Log>
```

- 네임스페이스는 장비 모델별로 다르게 둔다(예: `EUV3600`, `NXT2050i`, …). `XsdToStruct`는 `targetNamespace` → 모듈명을 그대로 매핑하므로 **모델별 스키마를 분리**하는 것이 호환성에 유리하다.
- 시간은 모두 `xs:dateTime`(ISO 8601, 타임존 포함). `XmlStructTools`에서 `Union{ZonedDateTime, DateTime}`으로 디코딩된다.
- 식별자는 모두 `pattern` 제약으로 형식을 강제한다.

---

## 1. EUV Scanner — TWINSCAN NXE:3600D (Exposure Log)

ASML의 EUV 노광기. 13.5 nm 광원, dual-stage, immersion 없음. 주요 로그 항목: 펄스(dose) 안정성, 포커스, **alignment(웨이퍼 정렬)**, reticle stage 데이터.

> **정렬(Alignment) 모델 메모.** ASML 스캐너는 새 웨이퍼가 척(chuck)에 로드되면 다음 단계를 거쳐 좌표계를 잡는다(스케일이 단계마다 다르다는 점에 유의):
>
> | 단계 | 측정 수단 | 좌표계 매핑 | 단위 |
> |---|---|---|---|
> | **0. Stage origin calibration** | 스테이지 인코더 + 노치 센서 | 척 ↔ 스테이지 X/Y/Z 원점 | **μm** |
> | **1. Coarse alignment** | 광학 정렬 센서 + 글로벌 마크 2~3개 | 스테이지 ↔ 웨이퍼 (대략) | nm |
> | **2. Fine alignment** | 다수 마크 + 6-파라미터(Tx, Ty, Rx, Ry, Mx, My) 최소제곱 | 스테이지 ↔ 웨이퍼 (정밀) | nm |
>
> 단계 0(`StageCalibration`)은 **인코더 기반 기계적 측정**이라 분해능이 ~μm이며, 이 단계가 통과해야 단계 1·2의 광학 정렬(`Alignment`, nm)이 의미 있는 잔차를 낼 수 있다. EUV는 주로 **SMASH** 계열 정렬 센서를 사용한다.

### 1.1 XSD 발췌 (`euv_exposure_log.xsd`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
        xmlns:EUV3600="EUV3600"
        targetNamespace="EUV3600">

  <element name="Log" type="EUV3600:LogType"/>

  <!-- 식별자 -->
  <simpleType name="LotIdType">
    <restriction base="string">
      <pattern value="[A-Z]{3}[0-9]{6}\.[0-9]{2}"/>
    </restriction>
  </simpleType>

  <simpleType name="WaferIdType">
    <restriction base="string">
      <pattern value="W[0-9]{2}"/>
    </restriction>
  </simpleType>

  <simpleType name="ReticleIdType">
    <restriction base="string">
      <minLength value="6"/>
      <maxLength value="20"/>
    </restriction>
  </simpleType>

  <!-- 측정값 -->
  <simpleType name="DoseMjcm2">
    <restriction base="double">
      <minInclusive value="0"/>
      <maxInclusive value="100"/>
    </restriction>
  </simpleType>

  <simpleType name="FocusNm">
    <restriction base="double">
      <minInclusive value="-200"/>
      <maxInclusive value="200"/>
    </restriction>
  </simpleType>

  <!-- 0) Stage origin calibration (μm 단위) -->
  <simpleType name="AxisName">
    <restriction base="string">
      <pattern value="X|Y|Z"/>
    </restriction>
  </simpleType>

  <simpleType name="StageOffsetUm">
    <!-- 척 원점 대비 오차 허용 범위(±500 μm, 그 이상은 척 안착 오류로 간주) -->
    <restriction base="double">
      <minInclusive value="-500"/>
      <maxInclusive value="500"/>
    </restriction>
  </simpleType>

  <simpleType name="StageCalibResult">
    <restriction base="string">
      <pattern value="OK|RECALIBRATED|FAIL"/>
    </restriction>
  </simpleType>

  <complexType name="AxisCalibrationType">
    <sequence>
      <element name="Axis"              type="EUV3600:AxisName"/>
      <element name="NominalOrigin_um"  type="double"/>
      <element name="MeasuredOrigin_um" type="double"/>
      <element name="Offset_um"         type="EUV3600:StageOffsetUm"/>
      <element name="Tolerance_um"      type="double"/>
      <element name="WithinTolerance"   type="boolean"/>
    </sequence>
  </complexType>

  <complexType name="StageCalibrationType">
    <sequence>
      <element name="ChuckId"        type="string"/>
      <element name="StartTime"      type="dateTime"/>
      <element name="EndTime"        type="dateTime"/>
      <!-- X, Y, Z 3축 -->
      <element name="Axis"           type="EUV3600:AxisCalibrationType" maxOccurs="3"/>
      <element name="NotchAngle_deg" type="double"/>
      <element name="WaferTilt_urad" type="double" minOccurs="0"/>
      <element name="Result"         type="EUV3600:StageCalibResult"/>
    </sequence>
  </complexType>

  <!-- 1·2) Alignment(광학 마크 정렬, nm 단위) -->
  <simpleType name="AlignStageType">
    <!-- Coarse: 거친 정렬, Fine: 정밀 정렬 -->
    <restriction base="string">
      <pattern value="COARSE|FINE"/>
    </restriction>
  </simpleType>

  <simpleType name="AlignSensorType">
    <!-- ASML 정렬 센서 종류 (EUV는 보통 SMASH 계열) -->
    <restriction base="string">
      <pattern value="SMASH|ATHENA|ORION|TIS"/>
    </restriction>
  </simpleType>

  <simpleType name="ResidualNm">
    <restriction base="double">
      <minInclusive value="-100"/>
      <maxInclusive value="100"/>
    </restriction>
  </simpleType>

  <complexType name="AlignmentMarkType">
    <sequence>
      <element name="MarkId"        type="string"/>
      <element name="NominalX_mm"   type="double"/>
      <element name="NominalY_mm"   type="double"/>
      <element name="MeasuredX_mm"  type="double"/>
      <element name="MeasuredY_mm"  type="double"/>
      <element name="ResidualX_nm" type="EUV3600:ResidualNm"/>
      <element name="ResidualY_nm" type="EUV3600:ResidualNm"/>
      <element name="SignalQuality" type="double"/>
      <element name="Used"          type="boolean" default="true"/>
    </sequence>
  </complexType>

  <!-- 6-parameter wafer grid model (Tx, Ty, Rx, Ry, Mx, My) -->
  <complexType name="WaferGridModelType">
    <sequence>
      <element name="TranslationX_nm"   type="double"/>
      <element name="TranslationY_nm"   type="double"/>
      <element name="RotationX_urad"    type="double"/>
      <element name="RotationY_urad"    type="double"/>
      <element name="MagnificationX_ppm" type="double"/>
      <element name="MagnificationY_ppm" type="double"/>
      <element name="Residual3Sigma_nm" type="double"/>
    </sequence>
  </complexType>

  <complexType name="AlignmentResultType">
    <sequence>
      <element name="Stage"      type="EUV3600:AlignStageType"/>
      <element name="Sensor"     type="EUV3600:AlignSensorType"/>
      <element name="StartTime"  type="dateTime"/>
      <element name="EndTime"    type="dateTime"/>
      <element name="Mark"       type="EUV3600:AlignmentMarkType" maxOccurs="unbounded"/>
      <element name="GridModel"  type="EUV3600:WaferGridModelType"/>
    </sequence>
  </complexType>

  <!-- 헤더 -->
  <complexType name="HeaderType">
    <sequence>
      <element name="ToolId"        type="string"/>
      <element name="ToolModel"     type="string" default="NXE:3600D"/>
      <element name="SoftwareVer"   type="string"/>
      <element name="StartTime"     type="dateTime"/>
      <element name="OperatorId"    type="string"/>
    </sequence>
  </complexType>

  <!-- 노광 필드 단위 데이터 -->
  <complexType name="FieldExposureType">
    <sequence>
      <element name="FieldX"   type="int"/>
      <element name="FieldY"   type="int"/>
      <element name="Dose"     type="EUV3600:DoseMjcm2"/>
      <element name="Focus"    type="EUV3600:FocusNm"/>
      <element name="PulseCnt" type="nonNegativeInteger"/>
    </sequence>
  </complexType>

  <complexType name="WaferType">
    <sequence>
      <element name="WaferId"          type="EUV3600:WaferIdType"/>
      <element name="StartTime"        type="dateTime"/>
      <!-- 0) 척-스테이지 원점 교정 (μm) - 새 wafer 로드 직후 -->
      <element name="StageCalibration" type="EUV3600:StageCalibrationType"/>
      <!-- 1·2) Coarse + Fine 광학 정렬 (nm) - 1~2회 -->
      <element name="Alignment"        type="EUV3600:AlignmentResultType" maxOccurs="2"/>
      <element name="Field"            type="EUV3600:FieldExposureType" maxOccurs="unbounded"/>
      <element name="EndTime"          type="dateTime"/>
    </sequence>
  </complexType>

  <complexType name="LotType">
    <sequence>
      <element name="LotId"      type="EUV3600:LotIdType"/>
      <element name="ReticleId"  type="EUV3600:ReticleIdType"/>
      <element name="Recipe"     type="string"/>
      <element name="WaferCount" type="positiveInteger"/>
    </sequence>
  </complexType>

  <complexType name="WafersType">
    <sequence>
      <element name="Wafer" type="EUV3600:WaferType" maxOccurs="unbounded"/>
    </sequence>
  </complexType>

  <complexType name="LogType">
    <sequence>
      <element name="Header" type="EUV3600:HeaderType"/>
      <element name="Lot"    type="EUV3600:LotType"/>
      <element name="Wafers" type="EUV3600:WafersType"/>
      <element name="EndTime" type="dateTime"/>
    </sequence>
  </complexType>

</schema>
```

### 1.2 XML 예시 (`euv_exposure_log_lot42.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<EUV3600:Log
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:EUV3600="EUV3600"
    xsi:schemaLocation="EUV3600 euv_exposure_log.xsd">

  <Header>
    <ToolId>NXE3600-K7</ToolId>
    <ToolModel>NXE:3600D</ToolModel>
    <SoftwareVer>TWINSCAN-EUV-2024.05</SoftwareVer>
    <StartTime>2026-04-30T22:14:03+09:00</StartTime>
    <OperatorId>op_park</OperatorId>
  </Header>

  <Lot>
    <LotId>LOT123456.01</LotId>
    <ReticleId>RTC-EUV-9921A</ReticleId>
    <Recipe>5nm_BEOL_M2_v17</Recipe>
    <WaferCount>25</WaferCount>
  </Lot>

  <Wafers>
    <Wafer>
      <WaferId>W01</WaferId>
      <StartTime>2026-04-30T22:14:08+09:00</StartTime>

      <!-- 0) Stage origin calibration: 척-스테이지 X/Y/Z 원점 교정 (μm) -->
      <StageCalibration>
        <ChuckId>CHK-A</ChuckId>
        <StartTime>2026-04-30T22:14:08+09:00</StartTime>
        <EndTime>2026-04-30T22:14:09+09:00</EndTime>
        <Axis>
          <Axis>X</Axis>
          <NominalOrigin_um>0.0</NominalOrigin_um>
          <MeasuredOrigin_um>2.4</MeasuredOrigin_um>
          <Offset_um>2.4</Offset_um>
          <Tolerance_um>10.0</Tolerance_um>
          <WithinTolerance>true</WithinTolerance>
        </Axis>
        <Axis>
          <Axis>Y</Axis>
          <NominalOrigin_um>0.0</NominalOrigin_um>
          <MeasuredOrigin_um>-1.8</MeasuredOrigin_um>
          <Offset_um>-1.8</Offset_um>
          <Tolerance_um>10.0</Tolerance_um>
          <WithinTolerance>true</WithinTolerance>
        </Axis>
        <Axis>
          <Axis>Z</Axis>
          <NominalOrigin_um>0.0</NominalOrigin_um>
          <MeasuredOrigin_um>0.7</MeasuredOrigin_um>
          <Offset_um>0.7</Offset_um>
          <Tolerance_um>5.0</Tolerance_um>
          <WithinTolerance>true</WithinTolerance>
        </Axis>
        <NotchAngle_deg>0.012</NotchAngle_deg>
        <WaferTilt_urad>3.4</WaferTilt_urad>
        <Result>OK</Result>
      </StageCalibration>

      <!-- 1) Coarse alignment: 마크 3개로 거친 정렬 -->
      <Alignment>
        <Stage>COARSE</Stage>
        <Sensor>SMASH</Sensor>
        <StartTime>2026-04-30T22:14:09+09:00</StartTime>
        <EndTime>2026-04-30T22:14:13+09:00</EndTime>
        <Mark>
          <MarkId>GA_TL</MarkId>
          <NominalX_mm>-95.000</NominalX_mm><NominalY_mm>95.000</NominalY_mm>
          <MeasuredX_mm>-94.99988</MeasuredX_mm><MeasuredY_mm>95.00007</MeasuredY_mm>
          <ResidualX_nm>120.0</ResidualX_nm><ResidualY_nm>-70.0</ResidualY_nm>
          <SignalQuality>0.91</SignalQuality><Used>true</Used>
        </Mark>
        <Mark>
          <MarkId>GA_TR</MarkId>
          <NominalX_mm>95.000</NominalX_mm><NominalY_mm>95.000</NominalY_mm>
          <MeasuredX_mm>95.00009</MeasuredX_mm><MeasuredY_mm>95.00004</MeasuredY_mm>
          <ResidualX_nm>-90.0</ResidualX_nm><ResidualY_nm>-40.0</ResidualY_nm>
          <SignalQuality>0.93</SignalQuality><Used>true</Used>
        </Mark>
        <Mark>
          <MarkId>GA_BC</MarkId>
          <NominalX_mm>0.000</NominalX_mm><NominalY_mm>-95.000</NominalY_mm>
          <MeasuredX_mm>0.00002</MeasuredX_mm><MeasuredY_mm>-94.99996</MeasuredY_mm>
          <ResidualX_nm>-20.0</ResidualX_nm><ResidualY_nm>40.0</ResidualY_nm>
          <SignalQuality>0.88</SignalQuality><Used>true</Used>
        </Mark>
        <GridModel>
          <TranslationX_nm>3.2</TranslationX_nm>
          <TranslationY_nm>-1.1</TranslationY_nm>
          <RotationX_urad>0.42</RotationX_urad>
          <RotationY_urad>0.39</RotationY_urad>
          <MagnificationX_ppm>0.18</MagnificationX_ppm>
          <MagnificationY_ppm>0.17</MagnificationY_ppm>
          <Residual3Sigma_nm>78.4</Residual3Sigma_nm>
        </GridModel>
      </Alignment>

      <!-- 2) Fine alignment: 16개 마크로 6-파라미터 피팅 -->
      <Alignment>
        <Stage>FINE</Stage>
        <Sensor>SMASH</Sensor>
        <StartTime>2026-04-30T22:14:14+09:00</StartTime>
        <EndTime>2026-04-30T22:14:31+09:00</EndTime>
        <Mark>
          <MarkId>FA_01</MarkId>
          <NominalX_mm>-90.000</NominalX_mm><NominalY_mm>90.000</NominalY_mm>
          <MeasuredX_mm>-89.999996</MeasuredX_mm><MeasuredY_mm>90.000003</MeasuredY_mm>
          <ResidualX_nm>4.0</ResidualX_nm><ResidualY_nm>-3.0</ResidualY_nm>
          <SignalQuality>0.96</SignalQuality><Used>true</Used>
        </Mark>
        <Mark>
          <MarkId>FA_02</MarkId>
          <NominalX_mm>0.000</NominalX_mm><NominalY_mm>90.000</NominalY_mm>
          <MeasuredX_mm>0.000002</MeasuredX_mm><MeasuredY_mm>89.999997</MeasuredY_mm>
          <ResidualX_nm>-2.0</ResidualX_nm><ResidualY_nm>3.0</ResidualY_nm>
          <SignalQuality>0.94</SignalQuality><Used>true</Used>
        </Mark>
        <Mark>
          <MarkId>FA_03</MarkId>
          <NominalX_mm>90.000</NominalX_mm><NominalY_mm>90.000</NominalY_mm>
          <MeasuredX_mm>89.999995</MeasuredX_mm><MeasuredY_mm>89.999996</MeasuredY_mm>
          <ResidualX_nm>5.0</ResidualX_nm><ResidualY_nm>4.0</ResidualY_nm>
          <SignalQuality>0.92</SignalQuality><Used>true</Used>
        </Mark>
        <Mark>
          <!-- 신호 품질 낮아 모델 피팅에서 제외된 예시 -->
          <MarkId>FA_07</MarkId>
          <NominalX_mm>-45.000</NominalX_mm><NominalY_mm>0.000</NominalY_mm>
          <MeasuredX_mm>-44.999932</MeasuredX_mm><MeasuredY_mm>0.000058</MeasuredY_mm>
          <ResidualX_nm>68.0</ResidualX_nm><ResidualY_nm>-58.0</ResidualY_nm>
          <SignalQuality>0.41</SignalQuality><Used>false</Used>
        </Mark>
        <GridModel>
          <TranslationX_nm>0.4</TranslationX_nm>
          <TranslationY_nm>-0.2</TranslationY_nm>
          <RotationX_urad>0.011</RotationX_urad>
          <RotationY_urad>0.010</RotationY_urad>
          <MagnificationX_ppm>0.01</MagnificationX_ppm>
          <MagnificationY_ppm>0.01</MagnificationY_ppm>
          <Residual3Sigma_nm>5.7</Residual3Sigma_nm>
        </GridModel>
      </Alignment>

      <Field>
        <FieldX>-3</FieldX><FieldY>-2</FieldY>
        <Dose>52.31</Dose><Focus>-3.4</Focus><PulseCnt>1024</PulseCnt>
      </Field>
      <Field>
        <FieldX>-2</FieldX><FieldY>-2</FieldY>
        <Dose>52.27</Dose><Focus>-2.9</Focus><PulseCnt>1024</PulseCnt>
      </Field>
      <Field>
        <FieldX>-1</FieldX><FieldY>-2</FieldY>
        <Dose>52.34</Dose><Focus>-3.1</Focus><PulseCnt>1024</PulseCnt>
      </Field>
      <EndTime>2026-04-30T22:15:42+09:00</EndTime>
    </Wafer>

    <Wafer>
      <WaferId>W02</WaferId>
      <StartTime>2026-04-30T22:15:50+09:00</StartTime>

      <!-- 0) Stage origin calibration: Z축 허용 범위 초과 → 자동 재교정 후 OK -->
      <StageCalibration>
        <ChuckId>CHK-A</ChuckId>
        <StartTime>2026-04-30T22:15:50+09:00</StartTime>
        <EndTime>2026-04-30T22:15:53+09:00</EndTime>
        <Axis>
          <Axis>X</Axis>
          <NominalOrigin_um>0.0</NominalOrigin_um>
          <MeasuredOrigin_um>1.9</MeasuredOrigin_um>
          <Offset_um>1.9</Offset_um>
          <Tolerance_um>10.0</Tolerance_um>
          <WithinTolerance>true</WithinTolerance>
        </Axis>
        <Axis>
          <Axis>Y</Axis>
          <NominalOrigin_um>0.0</NominalOrigin_um>
          <MeasuredOrigin_um>-2.1</MeasuredOrigin_um>
          <Offset_um>-2.1</Offset_um>
          <Tolerance_um>10.0</Tolerance_um>
          <WithinTolerance>true</WithinTolerance>
        </Axis>
        <Axis>
          <Axis>Z</Axis>
          <NominalOrigin_um>0.0</NominalOrigin_um>
          <MeasuredOrigin_um>6.2</MeasuredOrigin_um>
          <Offset_um>6.2</Offset_um>
          <Tolerance_um>5.0</Tolerance_um>
          <WithinTolerance>false</WithinTolerance>
        </Axis>
        <NotchAngle_deg>-0.008</NotchAngle_deg>
        <WaferTilt_urad>5.1</WaferTilt_urad>
        <Result>RECALIBRATED</Result>
      </StageCalibration>

      <!-- W02는 Coarse 결과가 충분히 좋아 Fine 한 단계만 기록된 예시 -->
      <Alignment>
        <Stage>FINE</Stage>
        <Sensor>SMASH</Sensor>
        <StartTime>2026-04-30T22:15:51+09:00</StartTime>
        <EndTime>2026-04-30T22:16:08+09:00</EndTime>
        <Mark>
          <MarkId>FA_01</MarkId>
          <NominalX_mm>-90.000</NominalX_mm><NominalY_mm>90.000</NominalY_mm>
          <MeasuredX_mm>-89.999998</MeasuredX_mm><MeasuredY_mm>90.000001</MeasuredY_mm>
          <ResidualX_nm>2.0</ResidualX_nm><ResidualY_nm>-1.0</ResidualY_nm>
          <SignalQuality>0.97</SignalQuality><Used>true</Used>
        </Mark>
        <Mark>
          <MarkId>FA_03</MarkId>
          <NominalX_mm>90.000</NominalX_mm><NominalY_mm>90.000</NominalY_mm>
          <MeasuredX_mm>89.999997</MeasuredX_mm><MeasuredY_mm>89.999998</MeasuredY_mm>
          <ResidualX_nm>3.0</ResidualX_nm><ResidualY_nm>2.0</ResidualY_nm>
          <SignalQuality>0.95</SignalQuality><Used>true</Used>
        </Mark>
        <GridModel>
          <TranslationX_nm>0.6</TranslationX_nm>
          <TranslationY_nm>-0.3</TranslationY_nm>
          <RotationX_urad>0.014</RotationX_urad>
          <RotationY_urad>0.012</RotationY_urad>
          <MagnificationX_ppm>0.02</MagnificationX_ppm>
          <MagnificationY_ppm>0.02</MagnificationY_ppm>
          <Residual3Sigma_nm>4.8</Residual3Sigma_nm>
        </GridModel>
      </Alignment>

      <Field>
        <FieldX>-3</FieldX><FieldY>-2</FieldY>
        <Dose>52.29</Dose><Focus>-3.6</Focus><PulseCnt>1024</PulseCnt>
      </Field>
      <EndTime>2026-04-30T22:17:24+09:00</EndTime>
    </Wafer>
  </Wafers>

  <EndTime>2026-04-30T23:02:11+09:00</EndTime>
</EUV3600:Log>
```

핵심 활용:
- 필드 단위 dose/focus 시계열 → 공정 안정성 모니터링.
- **StageCalibration.Result = `RECALIBRATED`/`FAIL`** 빈도 → 척 안착·노치 검출 문제 추적 (μm 단위 기계적 이상).
- **StageCalibration.Axis[Z].Offset_um** 시계열 → 척 thermal drift / 웨이퍼 백사이드 오염 조기 감지.
- **Alignment.GridModel.Residual3Sigma_nm** → wafer별 정렬 품질 게이팅 (예: 7 nm 초과 시 자동 rework 큐로 분기).
- **Mark.Used = false** 표본 비율 → 정렬 마크 손상/오염 추적 (마크별 시계열 집계).
- **GridModel.MagnificationX/Y_ppm**, **RotationX/Y_urad** → wafer 변형(reticle stage drift, chuck thermal expansion 등) 원인 회귀 분석.
- §4 YieldStar overlay 결과와 같은 LotId/WaferId로 조인 → 노광 시 정렬 잔차 ↔ 사후 측정 overlay의 상관 분석.

---

## 2. ArF Immersion Scanner — TWINSCAN NXT:2050i (Overlay & Leveling Log)

193 nm ArF + 물 침수, 현재 7 nm급 BEOL과 5 nm급 non-critical 레이어 주력. 로그는 overlay(정렬 오차)·leveling(웨이퍼 평탄도) 측정 결과.

### 2.1 XSD 발췌 (`nxt_overlay_log.xsd`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
        xmlns:NXT2050i="NXT2050i"
        targetNamespace="NXT2050i">

  <element name="Log" type="NXT2050i:LogType"/>

  <simpleType name="LotIdType">
    <restriction base="string">
      <pattern value="[A-Z]{3}[0-9]{6}\.[0-9]{2}"/>
    </restriction>
  </simpleType>

  <simpleType name="OverlayNm">
    <restriction base="double">
      <minInclusive value="-50"/>
      <maxInclusive value="50"/>
    </restriction>
  </simpleType>

  <!-- AlignmentSource: choice 예시 (TIS 마크 또는 SMASH 마크) -->
  <complexType name="MarkPositionType">
    <sequence>
      <element name="X" type="double"/>
      <element name="Y" type="double"/>
      <choice>
        <element name="TIS_Mark"   type="string"/>
        <element name="SMASH_Mark" type="string"/>
      </choice>
    </sequence>
  </complexType>

  <!-- Overlay/Leveling 모두 같은 필드 단위에 매달리므로 union 사용 예시 -->
  <simpleType name="MeasurementValue">
    <union memberTypes="NXT2050i:OverlayNm double"/>
  </simpleType>

  <complexType name="FieldMeasurementType">
    <sequence>
      <element name="FieldX"     type="int"/>
      <element name="FieldY"     type="int"/>
      <element name="OverlayX"   type="NXT2050i:OverlayNm"/>
      <element name="OverlayY"   type="NXT2050i:OverlayNm"/>
      <element name="LevelingZ"  type="double"/>
      <element name="Mark"       type="NXT2050i:MarkPositionType" minOccurs="0"/>
    </sequence>
  </complexType>

  <complexType name="WaferType">
    <sequence>
      <element name="WaferId"   type="string"/>
      <element name="Slot"      type="positiveInteger"/>
      <element name="ScanTime"  type="dateTime"/>
      <element name="Field"     type="NXT2050i:FieldMeasurementType" maxOccurs="unbounded"/>
    </sequence>
  </complexType>

  <complexType name="HeaderType">
    <sequence>
      <element name="ToolId"      type="string"/>
      <element name="ToolModel"   type="string" default="NXT:2050i"/>
      <element name="StartTime"   type="dateTime"/>
      <element name="LotId"       type="NXT2050i:LotIdType"/>
      <element name="Recipe"      type="string"/>
      <element name="LayerName"   type="string"/>
    </sequence>
  </complexType>

  <complexType name="LogType">
    <sequence>
      <element name="Header" type="NXT2050i:HeaderType"/>
      <element name="Wafer"  type="NXT2050i:WaferType" maxOccurs="unbounded"/>
      <element name="EndTime" type="dateTime"/>
    </sequence>
  </complexType>

</schema>
```

### 2.2 XML 예시 (`nxt2050i_overlay_lot7788.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<NXT2050i:Log
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:NXT2050i="NXT2050i"
    xsi:schemaLocation="NXT2050i nxt_overlay_log.xsd">

  <Header>
    <ToolId>NXT2050i-FAB3-12</ToolId>
    <ToolModel>NXT:2050i</ToolModel>
    <StartTime>2026-04-30T18:02:00+09:00</StartTime>
    <LotId>ARF007788.03</LotId>
    <Recipe>7nm_M3_overlay_v8</Recipe>
    <LayerName>METAL3</LayerName>
  </Header>

  <Wafer>
    <WaferId>WAF-7788-W01</WaferId>
    <Slot>1</Slot>
    <ScanTime>2026-04-30T18:02:14+09:00</ScanTime>
    <Field>
      <FieldX>0</FieldX><FieldY>0</FieldY>
      <OverlayX>1.2</OverlayX><OverlayY>-0.8</OverlayY>
      <LevelingZ>0.04</LevelingZ>
      <Mark>
        <X>0.0</X><Y>0.0</Y>
        <SMASH_Mark>SM-A-001</SMASH_Mark>
      </Mark>
    </Field>
    <Field>
      <FieldX>1</FieldX><FieldY>0</FieldY>
      <OverlayX>1.7</OverlayX><OverlayY>-0.4</OverlayY>
      <LevelingZ>0.05</LevelingZ>
    </Field>
  </Wafer>

  <Wafer>
    <WaferId>WAF-7788-W02</WaferId>
    <Slot>2</Slot>
    <ScanTime>2026-04-30T18:04:01+09:00</ScanTime>
    <Field>
      <FieldX>0</FieldX><FieldY>0</FieldY>
      <OverlayX>1.0</OverlayX><OverlayY>-1.1</OverlayY>
      <LevelingZ>0.03</LevelingZ>
      <Mark>
        <X>0.0</X><Y>0.0</Y>
        <TIS_Mark>TIS-Q-77</TIS_Mark>
      </Mark>
    </Field>
  </Wafer>

  <EndTime>2026-04-30T18:38:55+09:00</EndTime>
</NXT2050i:Log>
```

핵심 활용: `<choice>`로 정렬 마크 종류(TIS / SMASH) 분기, overlay 평균/표준편차 통계 추출.

---

## 3. KrF DUV Scanner — TWINSCAN XT:860N (Lot Throughput / Event Log)

248 nm KrF, 비핵심 레이어용. 로그 성격: 단위 시간당 wafer 처리, 알람/이벤트 시퀀스.

### 3.1 XSD 발췌 (`xt860_event_log.xsd`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
        xmlns:XT860="XT860"
        targetNamespace="XT860">

  <element name="Log" type="XT860:LogType"/>

  <simpleType name="SeverityType">
    <restriction base="string">
      <pattern value="INFO|WARN|ERROR|FATAL"/>
    </restriction>
  </simpleType>

  <simpleType name="EventCodeType">
    <restriction base="string">
      <pattern value="E[0-9]{4}"/>
    </restriction>
  </simpleType>

  <complexType name="EventType">
    <sequence>
      <element name="Time"     type="dateTime"/>
      <element name="Code"     type="XT860:EventCodeType"/>
      <element name="Severity" type="XT860:SeverityType"/>
      <element name="Message"  type="string"/>
      <element name="WaferId"  type="string" minOccurs="0"/>
    </sequence>
  </complexType>

  <complexType name="ThroughputType">
    <sequence>
      <element name="WafersPerHour" type="double"/>
      <element name="LotProcessSec" type="nonNegativeInteger"/>
    </sequence>
  </complexType>

  <complexType name="LogType">
    <sequence>
      <element name="ToolId"     type="string"/>
      <element name="ToolModel"  type="string" default="XT:860N"/>
      <element name="LotId"      type="string"/>
      <element name="StartTime"  type="dateTime"/>
      <element name="EndTime"    type="dateTime"/>
      <element name="Throughput" type="XT860:ThroughputType"/>
      <element name="Events">
        <complexType>
          <sequence>
            <element name="Event" type="XT860:EventType" maxOccurs="unbounded"/>
          </sequence>
        </complexType>
      </element>
    </sequence>
  </complexType>

</schema>
```

### 3.2 XML 예시 (`xt860_lot_event_20260430.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<XT860:Log
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:XT860="XT860"
    xsi:schemaLocation="XT860 xt860_event_log.xsd">

  <ToolId>XT860-FAB1-04</ToolId>
  <ToolModel>XT:860N</ToolModel>
  <LotId>KRF003344.05</LotId>
  <StartTime>2026-04-30T09:11:00+09:00</StartTime>
  <EndTime>2026-04-30T09:38:42+09:00</EndTime>

  <Throughput>
    <WafersPerHour>148.3</WafersPerHour>
    <LotProcessSec>1662</LotProcessSec>
  </Throughput>

  <Events>
    <Event>
      <Time>2026-04-30T09:11:02+09:00</Time>
      <Code>E0001</Code><Severity>INFO</Severity>
      <Message>Lot start</Message>
    </Event>
    <Event>
      <Time>2026-04-30T09:18:45+09:00</Time>
      <Code>E0312</Code><Severity>WARN</Severity>
      <Message>Reticle stage temperature out of nominal band, auto-recovered</Message>
      <WaferId>W08</WaferId>
    </Event>
    <Event>
      <Time>2026-04-30T09:25:11+09:00</Time>
      <Code>E0501</Code><Severity>ERROR</Severity>
      <Message>Wafer alignment failed - retry 1</Message>
      <WaferId>W14</WaferId>
    </Event>
    <Event>
      <Time>2026-04-30T09:25:33+09:00</Time>
      <Code>E0001</Code><Severity>INFO</Severity>
      <Message>Wafer alignment recovered</Message>
      <WaferId>W14</WaferId>
    </Event>
    <Event>
      <Time>2026-04-30T09:38:40+09:00</Time>
      <Code>E0002</Code><Severity>INFO</Severity>
      <Message>Lot end</Message>
    </Event>
  </Events>

</XT860:Log>
```

핵심 활용: `Severity = ERROR/FATAL` 필터링 → MTBF 계산 / 장애 패턴 학습. Drain3로 `Message` 필드를 클러스터링하면 자유 텍스트와 구조화 데이터의 결합이 가능.

---

## 4. YieldStar S385 — Optical Overlay/CD Metrology

ASML의 광학 메트롤로지(스캔 후 검증). overlay·CD(Critical Dimension) 측정 결과를 wafer × site 단위로 보고.

### 4.1 XSD 발췌 (`yieldstar_metrology_log.xsd`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
        xmlns:YS385="YS385"
        targetNamespace="YS385">

  <element name="Log" type="YS385:LogType"/>

  <simpleType name="MeasurementKind">
    <restriction base="string">
      <pattern value="OVL|CD|FOCUS"/>
    </restriction>
  </simpleType>

  <simpleType name="WavelengthNm">
    <restriction base="double">
      <minInclusive value="200"/>
      <maxInclusive value="800"/>
    </restriction>
  </simpleType>

  <!-- extension 예시: 모든 측정점이 공유하는 좌표를 베이스로 두고 측정값 추가 -->
  <complexType name="SiteCoordType">
    <sequence>
      <element name="WaferX_mm" type="double"/>
      <element name="WaferY_mm" type="double"/>
    </sequence>
  </complexType>

  <complexType name="OverlaySiteType">
    <complexContent>
      <extension base="YS385:SiteCoordType">
        <sequence>
          <element name="OvlX_nm" type="double"/>
          <element name="OvlY_nm" type="double"/>
          <element name="Residual_nm" type="double"/>
        </sequence>
      </extension>
    </complexContent>
  </complexType>

  <complexType name="CdSiteType">
    <complexContent>
      <extension base="YS385:SiteCoordType">
        <sequence>
          <element name="Cd_nm"       type="double"/>
          <element name="LineEdgeRoughness_nm" type="double"/>
        </sequence>
      </extension>
    </complexContent>
  </complexType>

  <complexType name="WaferMeasurementType">
    <sequence>
      <element name="WaferId" type="string"/>
      <element name="MeasureTime" type="dateTime"/>
      <element name="Wavelength"  type="YS385:WavelengthNm"/>
      <choice maxOccurs="unbounded">
        <element name="OverlaySite" type="YS385:OverlaySiteType"/>
        <element name="CdSite"      type="YS385:CdSiteType"/>
      </choice>
    </sequence>
  </complexType>

  <complexType name="LogType">
    <sequence>
      <element name="ToolId"   type="string"/>
      <element name="ToolModel" type="string" default="YieldStar S385"/>
      <element name="LotId"    type="string"/>
      <element name="Kind"     type="YS385:MeasurementKind"/>
      <element name="Wafer"    type="YS385:WaferMeasurementType" maxOccurs="unbounded"/>
    </sequence>
  </complexType>

</schema>
```

### 4.2 XML 예시 (`yieldstar_s385_overlay_lot7788.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<YS385:Log
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:YS385="YS385"
    xsi:schemaLocation="YS385 yieldstar_metrology_log.xsd">

  <ToolId>YS385-INSP-02</ToolId>
  <ToolModel>YieldStar S385</ToolModel>
  <LotId>ARF007788.03</LotId>
  <Kind>OVL</Kind>

  <Wafer>
    <WaferId>WAF-7788-W01</WaferId>
    <MeasureTime>2026-04-30T19:21:08+09:00</MeasureTime>
    <Wavelength>425.0</Wavelength>

    <OverlaySite>
      <WaferX_mm>-100.0</WaferX_mm><WaferY_mm>0.0</WaferY_mm>
      <OvlX_nm>1.1</OvlX_nm><OvlY_nm>-0.7</OvlY_nm><Residual_nm>0.3</Residual_nm>
    </OverlaySite>
    <OverlaySite>
      <WaferX_mm>0.0</WaferX_mm><WaferY_mm>0.0</WaferY_mm>
      <OvlX_nm>1.3</OvlX_nm><OvlY_nm>-0.9</OvlY_nm><Residual_nm>0.4</Residual_nm>
    </OverlaySite>
    <OverlaySite>
      <WaferX_mm>100.0</WaferX_mm><WaferY_mm>0.0</WaferY_mm>
      <OvlX_nm>1.5</OvlX_nm><OvlY_nm>-1.0</OvlY_nm><Residual_nm>0.5</Residual_nm>
    </OverlaySite>
  </Wafer>

  <Wafer>
    <WaferId>WAF-7788-W02</WaferId>
    <MeasureTime>2026-04-30T19:24:55+09:00</MeasureTime>
    <Wavelength>425.0</Wavelength>
    <OverlaySite>
      <WaferX_mm>0.0</WaferX_mm><WaferY_mm>0.0</WaferY_mm>
      <OvlX_nm>1.0</OvlX_nm><OvlY_nm>-1.2</OvlY_nm><Residual_nm>0.4</Residual_nm>
    </OverlaySite>
  </Wafer>

</YS385:Log>
```

핵심 활용: 노광기(예: §2 NXT2050i)의 overlay 보고와 **같은 LotId / WaferId로 조인** → 노광 ↔ 검증 클로즈드 루프.
`<extension>` 사용 → `XsdToStruct`가 base 필드와 추가 필드를 합쳐 단일 struct를 만든다.

---

## 5. e-beam Metrology — eP5 / eScan (CD-SEM Defect & CD)

ASML이 인수한 HMI 출신 e-beam 장비. SEM 이미지 기반 CD/결함 검출 결과를 사이트별로 출력.

### 5.1 XSD 발췌 (`ebeam_defect_log.xsd`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
        xmlns:EBEAM="EBEAM"
        targetNamespace="EBEAM">

  <element name="Log" type="EBEAM:LogType"/>

  <simpleType name="DefectClass">
    <restriction base="string">
      <pattern value="PARTICLE|BRIDGE|BREAK|MISSING|NUISANCE"/>
    </restriction>
  </simpleType>

  <complexType name="DefectType">
    <sequence>
      <element name="DefectId"   type="string"/>
      <element name="Class"      type="EBEAM:DefectClass"/>
      <element name="X_um"       type="double"/>
      <element name="Y_um"       type="double"/>
      <element name="Size_nm"    type="double"/>
      <element name="ImageRef"   type="string" minOccurs="0"/>
    </sequence>
  </complexType>

  <complexType name="CdMeasurementType">
    <sequence>
      <element name="SiteId"   type="string"/>
      <element name="X_um"     type="double"/>
      <element name="Y_um"     type="double"/>
      <element name="Cd_nm"    type="double"/>
    </sequence>
  </complexType>

  <complexType name="WaferType">
    <sequence>
      <element name="WaferId"   type="string"/>
      <element name="ScanTime"  type="dateTime"/>
      <element name="Beam_kV"   type="double" default="1.0"/>
      <element name="Defects">
        <complexType>
          <sequence>
            <element name="Defect" type="EBEAM:DefectType" minOccurs="0" maxOccurs="unbounded"/>
          </sequence>
        </complexType>
      </element>
      <element name="CdMeasurements" minOccurs="0">
        <complexType>
          <sequence>
            <element name="Cd" type="EBEAM:CdMeasurementType" maxOccurs="unbounded"/>
          </sequence>
        </complexType>
      </element>
    </sequence>
  </complexType>

  <complexType name="LogType">
    <sequence>
      <element name="ToolId"     type="string"/>
      <element name="ToolModel"  type="string" default="eP5"/>
      <element name="LotId"      type="string"/>
      <element name="Recipe"     type="string"/>
      <element name="Wafer"      type="EBEAM:WaferType" maxOccurs="unbounded"/>
    </sequence>
  </complexType>

</schema>
```

### 5.2 XML 예시 (`ebeam_ep5_lot7788.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<EBEAM:Log
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:EBEAM="EBEAM"
    xsi:schemaLocation="EBEAM ebeam_defect_log.xsd">

  <ToolId>eP5-INSP-09</ToolId>
  <ToolModel>eP5</ToolModel>
  <LotId>ARF007788.03</LotId>
  <Recipe>M3_post_overlay_inspection_v3</Recipe>

  <Wafer>
    <WaferId>WAF-7788-W01</WaferId>
    <ScanTime>2026-04-30T20:11:30+09:00</ScanTime>
    <Beam_kV>1.0</Beam_kV>

    <Defects>
      <Defect>
        <DefectId>D-0001</DefectId>
        <Class>BRIDGE</Class>
        <X_um>-128.4</X_um><Y_um>32.1</Y_um>
        <Size_nm>22.5</Size_nm>
        <ImageRef>imgs/W01/D-0001.png</ImageRef>
      </Defect>
      <Defect>
        <DefectId>D-0002</DefectId>
        <Class>PARTICLE</Class>
        <X_um>57.7</X_um><Y_um>-91.0</Y_um>
        <Size_nm>41.2</Size_nm>
        <ImageRef>imgs/W01/D-0002.png</ImageRef>
      </Defect>
    </Defects>

    <CdMeasurements>
      <Cd>
        <SiteId>S01</SiteId><X_um>0</X_um><Y_um>0</Y_um><Cd_nm>13.2</Cd_nm>
      </Cd>
      <Cd>
        <SiteId>S02</SiteId><X_um>50</X_um><Y_um>0</Y_um><Cd_nm>13.4</Cd_nm>
      </Cd>
    </CdMeasurements>
  </Wafer>

  <Wafer>
    <WaferId>WAF-7788-W02</WaferId>
    <ScanTime>2026-04-30T20:18:02+09:00</ScanTime>
    <Beam_kV>1.0</Beam_kV>
    <Defects/>
    <CdMeasurements>
      <Cd>
        <SiteId>S01</SiteId><X_um>0</X_um><Y_um>0</Y_um><Cd_nm>13.1</Cd_nm>
      </Cd>
    </CdMeasurements>
  </Wafer>

</EBEAM:Log>
```

핵심 활용: `Class`별 결함 빈도 집계, CD 분포에서 노광 dose/focus(§1, §2)와 회귀 분석 → root cause 추적.

---

## 6. 5종 비교 표

| # | 모델 | 기술 | 로그 성격 | 핵심 데이터 단위 | 사용한 XSD 기능 |
|---|---|---|---|---|---|
| 1 | NXE:3600D | EUV (13.5 nm) | 노광 + **stage calib(μm) + alignment(nm)** | Wafer→StageCalibration(X/Y/Z μm) → Alignment(Coarse/Fine, Mark×N, GridModel nm) → Field(dose/focus/pulse) | `pattern`, `min/maxInclusive`, `dateTime`, `default`, 다단계 `maxOccurs` |
| 2 | NXT:2050i | ArF Immersion (193 nm + 물) | overlay/leveling | Wafer→Field(OVL X/Y, leveling Z) | `choice` (TIS/SMASH), `union`, `pattern` |
| 3 | XT:860N | KrF (248 nm) | event / throughput | Lot 단위 이벤트 시퀀스 | `pattern`(severity, code), 익명 inline `complexType` |
| 4 | YieldStar S385 | 광학 메트롤로지 | overlay·CD 검증 | Wafer→Site (좌표+측정) | `extension`(SiteCoord 베이스), `choice maxOccurs="unbounded"` |
| 5 | eP5 | e-beam SEM | 결함·CD 검출 | Wafer→Defect/CdSite | 익명 inline `complexType`, `default` |

---

## 7. 5종을 묶어 분석할 때의 데이터 흐름 예시

```
[NXT2050i overlay log] ──┐
[NXE3600D exposure log]──┼─ join on LotId / WaferId
[YS385 metrology log]    ┘
                         │
                         ▼
              dose/focus ↔ overlay residual ↔ CD ↔ defect class
                         │
                         ▼
        Drain3 (텍스트 부분: XT:860N event Message) +
        XmlStructTools (구조화 부분: 위 4종) → 통합 분석 파이프라인
```

- 동일 `LotId`(예: `ARF007788.03`)와 `WaferId`(`WAF-7788-W01`)가 §2(노광), §4(검증), §5(검출)에 공유되도록 설계함 → **단일 wafer 라이프사이클** 추적이 그대로 가능.
- §3 XT:860N은 별도 lot이지만 자유 텍스트 `Message`가 핵심이라, **Drain3로 템플릿 추출** + XmlStructTools로 구조 부분 파싱이 자연스럽다.

---

## 8. XmlStructTools로 적재할 때의 절차 (요약)

```julia
using XsdToStruct, XmlStructLoader

# 1) 5종 XSD를 한 번에 모듈로 변환
xsd_locations = Dict(
    "EUV3600"   => "schemas/euv_exposure_log.xsd",
    "NXT2050i"  => "schemas/nxt_overlay_log.xsd",
    "XT860"     => "schemas/xt860_event_log.xsd",
    "YS385"     => "schemas/yieldstar_metrology_log.xsd",
    "EBEAM"     => "schemas/ebeam_defect_log.xsd",
)
generate_modules(xsd_locations, "generated/")

# 2) 개별 모듈 로드
include("generated/EUV3600/EUV3600.jl");  using .EUV3600
include("generated/NXT2050i/NXT2050i.jl"); using .NXT2050i
include("generated/YS385/YS385.jl");      using .YS385

# 3) XML 적재 (제약 위반 시 XSDValueRestrictionViolationError 자동 발생)
euv_log   = load("logs/euv_exposure_log_lot42.xml",     EUV3600)
nxt_log   = load("logs/nxt2050i_overlay_lot7788.xml",   NXT2050i)
ys_log    = load("logs/yieldstar_s385_overlay_lot7788.xml", YS385)

# 4) 분석 (DataFrames 등으로 변환은 별도)
for w in nxt_log.Wafer
    @info "wafer $(w.WaferId): n=$(length(w.Field))"
end
```

`validate=false`로 1차 적재한 뒤 후속 단계에서 별도 검증을 돌리면, 대용량 로그에서도 빠른 1패스 처리가 가능하다.
