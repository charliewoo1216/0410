# ASML XmlStructTools.jl 분석 보고서

> 분석 대상: `01-로그생성/01-asml-xml-git/`
> ASML 사내에서 개발되어 외부 공개된 Julia 패키지 묶음 **XmlStructTools.jl**(저자: Tom Lemmens)

---

## 1. 개요

`XmlStructTools.jl`은 **XSD(XML Schema Definition) 기반 데이터 바인딩**을 Julia 생태계에 제공하는 것을 목표로 하는 패키지 묶음이다. 즉, XSD 파일을 입력으로 받아 그에 대응하는 Julia `struct` 타입을 자동 생성하고, 그 타입으로 XML 파일을 로드/검증/저장할 수 있게 한다(Java의 JAXB, Python의 xsdata와 유사한 역할).

원 README의 자체 평가는 다음과 같다:
- **Work in progress** 상태이며, W3C XSD 권고안의 일부만 구현되어 있다.
- 알려진 버그가 있고, ASML 내부에서 수정 중이라 공식 패치는 사내 리뷰 절차로 인해 시간이 걸린다.
- JuliaCon Local Eindhoven 2023의 발표 *"XML Data and Julian Types"*가 입문 자료로 제시되어 있다.

저장소 디렉터리는 4개의 Julia 패키지로 분할되어 있다.

```
01-asml-xml-git/
├── README.md
├── docs/                        ← 통합 문서(Documenter.jl 빌드 스크립트)
├── AbstractXsdTypes.jl/         ← 공통 추상 타입과 제약(restriction) 검사
├── XsdToStruct.jl/              ← XSD → Julia 모듈 코드 생성
├── XmlStructLoader.jl/          ← XML → 생성된 struct 인스턴스 로딩
└── XmlStructWriter.jl/          ← struct 인스턴스 → XML 파일 직렬화
```

---

## 2. 패키지별 책임 분리

### 2.1 `XsdToStruct.jl` — 코드 제너레이터
- 진입점 함수: `xsd_to_struct_module(xsd_path[, output_dir])`, `generate_modules(Dict, out_dir)`
- 동작 흐름:
  1. `LightXML`로 XSD 파일을 파싱 (`read_xsd` → `create_xsd_tree`).
  2. 자체 트리 표현(`SchemaTreeNode`, `ComplexTreeNode`, `SimpleTreeNode`, `UnionTreeNode`, `ExtensionTreeNode`)으로 변환.
  3. `process_xsd_tree!`로 후처리(그룹 해소, 필드 순서 정렬 등).
  4. `write_module`이 두 개의 Julia 파일을 출력:
     - `<XsdName>.jl` — 외부에서 `include` 할 메인 모듈
     - `<XsdName>_struct.jl` — `_struct` 서브모듈, 실제 `struct` 정의·기본값·검증 함수를 보관
- 일괄 처리 모드(`generate_modules`)는 로컬 경로뿐 아니라 **HTTPS URL**도 받아 임시 디렉터리로 다운로드한 뒤 변환한다.
- 생성된 모듈 이름은 XSD의 `targetNamespace`를 그대로 사용하며, `__meta` 서브모듈에 `root_type` 등의 메타 정보를 둔다.
- 의존성: `AbstractXsdTypes.jl`, `Reexport.jl`(필요 시 `Dates.jl`, `TimeZones.jl`).

### 2.2 `AbstractXsdTypes.jl` — 추상 타입과 제약 검사
- 모든 생성 코드의 슈퍼타입을 제공한다:
  - `AbstractXSDFloat <: AbstractFloat`
  - `AbstractXSDSigned <: Signed`
  - `AbstractXSDUnsigned <: Unsigned`
  - `AbstractXSDString <: AbstractString`
  - `AbstractXSDComplex` (XML element 그룹)
  - `AbstractXSDUnion` (XSD `<union>`)
- 모든 구체 타입은 `value`, `__xml_attributes::Union{Nothing, Dict{String,String}}`, `__validated::Bool` 세 필드를 갖도록 강제된다.
- **제약(restriction) 검사**가 한 곳에 모여 있다:
  - 수치형: `bound_restriction_check`(min/max + exclusive 여부), `total_digits_check`, `fraction_digits_check`.
  - 문자열: `string_length_restriction_check`(min/max length), `string_pattern_restriction_check`(정규식 매칭).
  - 위반 시 `XSDValueRestrictionViolationError` / `XSDStringRestrictionViolationError`(공통 부모 `XSDRestrictionViolationError`).
- `defaults` 함수: 생성 모듈에서 오버라이드하여 XSD `default` 속성을 `NamedTuple`로 노출.
- `convert` 함수: 서로 다른 두 XSD가 호환 가능한 데이터를 정의할 때, 베스트-에포트 변환을 수행해 다중 디스패치를 살리는 용도.

### 2.3 `XmlStructLoader.jl` — XML → struct
- 외부 API: `load(xml_path, module_ref; validate=true)`, `import_module_from_xml`, `use_module_from_xml`.
- 파서는 `EzXML`을 기반으로 한다.
- 주의 사항(코드 주석에 명시): **루트 엘리먼트의 속성을 `LightXML`/`EzXML`이 누락**하므로, 정규식 `r"<([^\?][^<>]*[^\?])>"`로 첫 줄을 직접 스캔해 보강하는 워크어라운드가 들어 있다(`root_attributes_workaround`).
- 기본적으로 XSD의 모든 제약을 검사하며, `validate=false`로 끄면 파싱만 수행한다.
- 의존성: `EzXML`, `Parsers`, `Memoization`, `AbstractTrees`, `Dates`, `TimeZones`, `Reexport`, `URIs`, `ConcreteStructs`.

### 2.4 `XmlStructWriter.jl` — struct → XML
- 외부 API: `write_xml(xml_object, xml_path)`.
- 직렬화 시 `xml_object.__xml_attributes`에 다음 키가 반드시 있어야 한다:
  - `__root_name` — XML 루트 엘리먼트 이름.
  - 적어도 하나의 `xmlns:*` 항목 — 네임스페이스 URI.
- 내부적으로 `LightXML`로 XML 트리를 빌드한다(읽기는 `EzXML`, 쓰기는 `LightXML`을 사용 — 기능별 분담).
- 복합/벡터/단순 타입 각각에 대해 `add_child_element!`가 다중 디스패치로 분기.

---

## 3. XSD → Julia 타입 매핑

`XsdToStruct.jl/src/xsd_field_data/xsd_field_data_type_mapping.jl`의 사전:

| XSD 타입 | Julia 타입 |
|---|---|
| `string` | `String` |
| `double`, `decimal` | `Float64` |
| `boolean` | `Bool` |
| `integer`, `int` | `Int64` |
| `nonNegativeInteger`, `positiveInteger` | `UInt64` |
| `dateTime` | `Union{ZonedDateTime, DateTime}` |
| 사용자 정의 | XSD에 정의된 이름을 그대로 사용 |

부속 규칙:
- `maxOccurs > 1` 또는 `unbounded` → `Vector{...}`.
- `minOccurs == "0"` → `Union{T, Nothing}`(누락 가능 필드).
- `default` 속성 → `defaults(::Type{T})`에서 `NamedTuple`로 노출.
- `<choice>` → 익명 필드 이름(`__<parent>_choice_N`)에 `NamedTuple`로 펼쳐 매핑.
- 네임스페이스는 일단 **분리 후 마지막 토큰만** 사용(`split(type_string, ":")[end]`)하는 단순화가 들어 있어, 동일 로컬명 충돌 시 한계가 있다.

---

## 4. 지원되는 XSD 기능과 한계

### 지원
- `simpleType` / `complexType` 정의(중첩 정의 포함).
- `sequence`, `choice`, `group`, `element`, `attribute`.
- `extension`(complexType의 base 확장).
- `union`(여러 단순 타입의 합).
- 제약: `minInclusive` / `maxInclusive` / `minExclusive` / `maxExclusive`, `totalDigits`, `fractionDigits`, `minLength` / `maxLength`, `pattern`.
- `default` 값.
- `dateTime`(타임존 포함/미포함).
- 다중 XSD 일괄 변환, URL 다운로드.

### 미지원(README "Known limitations" + 코드 확인)
- **`<include>`, `<import>`, `<redefine>`** — 모듈 분할 스키마는 합쳐서 처리할 수 없음.
- **`targetNamespace`가 없는 XSD** — 생성 모듈 이름 자체가 네임스페이스에 의존.
- 일부 type restriction(미명시).
- `parse_simple_content`의 `restriction` 분기는 `@warn "not yet fully implemented"`로 표시되어 있음 — `simpleContent` 위의 `restriction` 사용 시 결과가 부정확할 수 있다.

---

## 5. 의존 라이브러리 요약

| 패키지 | 역할 |
|---|---|
| `LightXML` | XSD 읽기, XML 쓰기 |
| `EzXML` | XML 읽기 |
| `Parsers` | 빠른 값 파싱 |
| `Memoization` | 타입/모듈 조회 캐싱 |
| `AbstractTrees` | 생성 struct의 트리 출력 |
| `TimeZones` | `dateTime` 타임존 처리 |
| `Format` | 숫자 포매팅(소수 자릿수 검사) |
| `Reexport` | 생성 모듈에서 내부 심볼 노출 |
| `ConcreteStructs` | XSD union 타입 정의 |
| `Downloads` | URL 기반 XSD 다운로드 |

---

## 6. 사용 패턴 정리

```julia
# 1) XSD → Julia 모듈 생성
using XsdToStruct
xsd_to_struct_module("schema.xsd", "out/")
# → out/schema/schema.jl, out/schema/schema_struct.jl 생성

# 2) 모듈 로드 + XML 읽기
using XmlStructLoader
include("out/schema/schema.jl")
using .SchemaNamespace
data = load("input.xml", SchemaNamespace)             # validate=true(기본)
data = load("input.xml", SchemaNamespace; validate=false)  # 검증 생략

# 3) 데이터 수정 후 다시 쓰기 (Accessors.jl 권장)
using Accessors, XmlStructWriter
new_data = @set data.SomeField.SubField = 42
write_xml(new_data, "output.xml")
```

빌드 스크립트(`generate_modules`)에 `xsd_locations` 사전을 정의해 두면, 패키지 빌드 단계에서 항상 최신 XSD로부터 모듈을 재생성할 수 있다.

---

## 7. 구조적 특징 / 설계 관찰

- **단계별 IR(Intermediate Representation)**: XSD XML → 자체 `XsdTreeNode` 트리 → 후처리 → 텍스트 코드 생성. 텍스트 코드 생성은 `IOBuffer`가 아니라 두 개의 `IO`(`io_top`, `io_struct`)로 분리해 사용자 모듈과 내부 `_struct` 모듈을 동시에 작성한다.
- **추상 타입 + 다중 디스패치**: 검증·변환·writer 분기가 모두 `AbstractXSDFloat`/`AbstractXSDString` 등을 키로 한다. 사용자가 직접 새 추상 타입을 끼워 넣기 좋다.
- **속성과 데이터의 동거**: 모든 generated struct가 `__xml_attributes`, `__validated`라는 "사적" 필드를 갖는다. `public_propertynames`로 사용자에게 노출되는 필드 집합이 별도로 관리된다.
- **테스트 자료 위치**: 각 패키지 `test/test_data/specific_cases/`(예: `documentation_example.xsd`)를 보면 지원 범위를 가장 빠르게 파악할 수 있다.

---

## 8. ASML 로그 파싱(이 저장소의 본 목적)에서의 의의

- ASML 장비 측 XML/XSD 로그를 그대로 Julia 측 데이터 모델로 끌어와 **타입 안전한 후처리·집계**를 가능하게 한다.
- 다만 ASML 내부 XSD가 `import`/`include`로 분할되어 있다면 그대로는 변환되지 않을 수 있고, 이 경우 별도 합본 XSD를 만들거나 패치 후 사용해야 한다.
- `validate=false` 옵션이 있으므로, 대용량 로그 파일에 대한 빠른 1차 파싱 후 별도 검증 단계를 분리하는 파이프라인 설계가 가능하다.
- Drain3와 같은 텍스트 기반 템플릿 파서와 달리, 이 도구는 **구조화된 XML 로그 전용**이다. 두 가지를 병행해 전체 로그 종류(텍스트 + XML)를 커버하는 구도가 자연스럽다.

---

## 9. 검토 시 우선 살펴볼 파일

| 영역 | 파일 |
|---|---|
| 진입점 | `XsdToStruct.jl/src/XsdToStruct.jl` |
| 타입 매핑 사전 | `XsdToStruct.jl/src/xsd_field_data/xsd_field_data_type_mapping.jl` |
| XSD 트리 노드 | `XsdToStruct.jl/src/xsd_tree/xsd_tree_node_types.jl` |
| 코드 생성 메인 | `XsdToStruct.jl/src/xsd_module_builder/xsd_module_builder.jl` |
| 추상 타입 정의 | `AbstractXsdTypes.jl/src/type_definitions.jl` |
| 제약 검사 | `AbstractXsdTypes.jl/src/restrictions/{numeric,string}_restrictions.jl` |
| XML 로더 | `XmlStructLoader.jl/src/XmlStructLoader.jl`, `xml_parser/xml_parser.jl` |
| XML 라이터 | `XmlStructWriter.jl/src/XmlStructWriter.jl` |

---

## 10. 결론

`XmlStructTools.jl`은 ASML 사내 요구에서 출발한 **Julia용 XSD 데이터 바인딩 툴체인**으로, *생성기 / 추상 타입 / 로더 / 라이터*가 깔끔하게 4분할되어 있다. W3C XSD 전체를 덮지는 못하지만(특히 `import`/`include` 미지원), `simpleType`·`complexType`·`union`·주요 제약·`dateTime` 정도까지는 실무에 쓰일 수준이다. 본 프로젝트(로그 파싱) 맥락에서는 ASML 장비 XML 로그를 Julia struct로 끌어와 Drain3 등의 텍스트 파서와 상호 보완적으로 활용하는 것이 가장 자연스러운 사용 시나리오다.
