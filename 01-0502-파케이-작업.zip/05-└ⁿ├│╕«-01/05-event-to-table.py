"""05-event-to-table.py — 스키마 JSON + 평문 로그 → CSV + Parquet."""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd


HERE = Path(__file__).parent
DEFAULT_SCHEMA = HERE / "04-event-schema.json"
DEFAULT_LOG = HERE / "selected-log-normalized" / "Event_log.old"
DEFAULT_OUT_DIR = HERE / "04-out"


def parse_records(text: str):
    """빈 줄 기준으로 레코드 분리. 각 레코드는 [line_tokens, ...]."""
    records, block = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if block:
                records.append(block)
                block = []
        else:
            block.append(line.split())
    if block:
        records.append(block)
    return records


def load_schema(path: Path):
    spec = json.loads(path.read_text(encoding="utf-8"))
    columns = []  # [(line_idx, field_idx, name), ...] in (line, field) order
    for line in spec.get("lines", []):
        li = line["line_index"] - 1
        for f in line["fields"]:
            columns.append((li, f["index"], f["name"]))
    return spec, columns


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    ap.add_argument("--log", type=Path, default=DEFAULT_LOG)
    ap.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    ap.add_argument("--basename", default="event_log")
    args = ap.parse_args()

    if not args.schema.exists():
        sys.exit(f"스키마 JSON 없음: {args.schema}")
    if not args.log.exists():
        sys.exit(f"로그 파일 없음: {args.log}")

    spec, columns = load_schema(args.schema)
    empty = [(li + 1, fi) for li, fi, name in columns if not name]
    if empty:
        sys.exit(
            f"빈 이름이 {len(empty)}개 있습니다 ({empty}) — Streamlit 에디터에서 모두 입력하세요."
        )

    names = [name for _, _, name in columns]
    if len(names) != len(set(names)):
        sys.exit(f"컬럼 이름 중복: {names}")

    records = parse_records(args.log.read_text(encoding="utf-8"))

    expected_per_line = {}
    for li, fi, _ in columns:
        expected_per_line.setdefault(li, 0)
        expected_per_line[li] = max(expected_per_line[li], fi + 1)

    rows = []
    for ri, r in enumerate(records):
        if len(r) != len(expected_per_line):
            sys.exit(f"레코드 #{ri}: 줄 수 {len(r)} ≠ 스키마 {len(expected_per_line)}")
        row = {}
        for li, fi, name in columns:
            line_tokens = r[li]
            if fi >= len(line_tokens):
                sys.exit(
                    f"레코드 #{ri} line{li+1}: 필드 {fi} 없음 (실제 {len(line_tokens)}개)"
                )
            row[name] = line_tokens[fi]
        rows.append(row)

    df = pd.DataFrame(rows, columns=names)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.out_dir / f"{args.basename}.csv"
    pq_path = args.out_dir / f"{args.basename}.parquet"
    df.to_csv(csv_path, index=False, encoding="utf-8")
    df.to_parquet(pq_path, engine="pyarrow", index=False)

    print(f"records: {len(df)}")
    print(f"columns: {names}")
    print(f"CSV    : {csv_path}")
    print(f"Parquet: {pq_path}")


if __name__ == "__main__":
    main()
