"""
02-time-normalize.py — selected-log/ 의 모든 timestamp를 KST · microsecond 단위로 통일

입력:  selected-log/**            (XML, Event_log.old 등 모든 텍스트 로그)
출력:  selected-log-normalized/   (입력과 동일한 디렉터리 트리, 파일명 그대로)

통일 후 형식 (ISO 8601 / KST 암묵):
    YYYY-MM-DDTHH:MM:SS.ffffff
        - 날짜·시각 사이는 'T' 로 고정
        - 소수점 6자리 (microsecond) 로 0 패딩
        - 모든 시각은 KST 기준이라는 프로젝트 약속 (실제로그규칙 § 3-3, sql규칙 § 2-2)
          → '+09:00' suffix 는 중복이므로 출력에서 제거

변환 예시:
    Event_log.old   '2026-04-30 06:00:00.000'         → '2026-04-30T06:00:00.000000'
    XML <StartTime> '2026-04-30T06:00:00+09:00'       → '2026-04-30T06:00:00.000000'
    XML(.fff 포함)  '2026-04-30T06:00:00.391+09:00'   → '2026-04-30T06:00:00.391000'
    UTC 표기        '2026-04-29T21:00:00Z'            → '2026-04-30T06:00:00.000000'  (KST 환산)

가정:
    - 입력 파일은 모두 UTF-8 텍스트
    - 타임존이 명시되지 않은 timestamp는 KST 라고 가정
    - 타임존이 명시된 timestamp는 일단 KST로 환산한 뒤 suffix 제거
    - 파일명·XML 태그명·기타 -로 구분된 시간 문자열(`...T06-00-00+09-00.xml`)은 변환 대상이 아님
      (regex가 콜론 기반 'HH:MM:SS' 만 매치하므로 자동으로 제외됨)

사용:
    python 02-time-normalize.py
"""

import re
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT    = Path(__file__).parent
SRC_DIR = ROOT / "selected-log"
DST_DIR = ROOT / "selected-log-normalized"

KST = timezone(timedelta(hours=9))

# YYYY-MM-DD<T| >HH:MM:SS[.frac1~9][Z|+HH:MM|-HH:MM]
TS_RE = re.compile(
    r"(?P<date>\d{4}-\d{2}-\d{2})"
    r"(?P<sep>[T ])"
    r"(?P<time>\d{2}:\d{2}:\d{2})"
    r"(?:\.(?P<frac>\d{1,9}))?"
    r"(?P<tz>Z|[+-]\d{2}:\d{2})?"
)


def to_kst_iso(m: re.Match) -> str:
    date = m.group("date")
    time = m.group("time")
    frac = m.group("frac")
    tz   = m.group("tz")

    # 소수 자리수를 6자리(microsecond)로 좌패딩 — 9자리 nanosecond는 1us 단위로 truncate
    micro = int(frac.ljust(6, "0")[:6]) if frac else 0

    if tz is None:
        # 타임존 미명시 → KST 가정 → 변환 불필요
        return f"{date}T{time}.{micro:06d}"

    # 타임존 명시 → 파싱 후 KST 로 환산, suffix 는 제거
    iso_in = f"{date}T{time}.{micro:06d}{tz.replace('Z', '+00:00')}"
    dt_kst = datetime.fromisoformat(iso_in).astimezone(KST)
    return dt_kst.strftime("%Y-%m-%dT%H:%M:%S.%f")


def process_file(src: Path, dst: Path) -> int:
    text = src.read_text(encoding="utf-8")
    new_text, n = TS_RE.subn(to_kst_iso, text)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(new_text, encoding="utf-8")
    return n


def main():
    if not SRC_DIR.exists():
        raise FileNotFoundError(f"{SRC_DIR} not found")
    if DST_DIR.exists():
        shutil.rmtree(DST_DIR)

    total_files = 0
    total_hits  = 0
    for src in sorted(SRC_DIR.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(SRC_DIR)
        n = process_file(src, DST_DIR / rel)
        print(f"  {str(rel):<60s}  {n:>5d} timestamps")
        total_files += 1
        total_hits  += n

    print(f"\n총 {total_files} files, {total_hits} timestamps → {DST_DIR}")


if __name__ == "__main__":
    main()
