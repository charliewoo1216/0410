"""04-event-schema-editor.py — Streamlit 스키마 에디터.

엔지니어가 형태(line N의 field M)를 보고 이름을 부여 → JSON 저장.
실행: streamlit run 04-event-schema-editor.py
"""
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

import streamlit as st


HERE = Path(__file__).parent
DEFAULT_LOG = HERE / "selected-log-normalized" / "Event_log.old"
DEFAULT_JSON = HERE / "04-event-schema.json"
SAMPLE_TOP_N = 10


def parse_records(text: str):
    """빈 줄 기준으로 레코드 분리. 각 레코드는 [line_tokens, ...]."""
    records, block = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if block:
                records.append(block)
                block = []
        else:
            block.append(line.split())
    if block:
        records.append(block)
    return records


def build_field_counters(records):
    """records[r][line_idx][field_idx] 위치별 값 Counter 행렬."""
    if not records:
        return []
    max_lines = max(len(r) for r in records)
    counters = []
    for li in range(max_lines):
        line_counters = []
        max_fields = max((len(r[li]) for r in records if len(r) > li), default=0)
        for fi in range(max_fields):
            c = Counter()
            for r in records:
                if len(r) > li and len(r[li]) > fi:
                    c[r[li][fi]] += 1
            line_counters.append(c)
        counters.append(line_counters)
    return counters


def shape_consistent(records):
    """모든 레코드가 동일한 (line수, 각 line별 field수)인지."""
    if not records:
        return False
    first = [len(line) for line in records[0]]
    for r in records[1:]:
        if [len(line) for line in r] != first:
            return False
    return True


def load_existing(json_path: Path):
    if json_path.exists():
        try:
            return json.loads(json_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return None
    return None


def main():
    st.set_page_config(page_title="Event 로그 스키마 에디터", layout="wide")
    st.title("Event 로그 스키마 에디터")
    st.caption("형태(shape)는 자동, 이름(name)은 엔지니어가 부여합니다.")

    with st.sidebar:
        st.header("입출력 경로")
        log_path_str = st.text_input("로그 파일 경로", value=str(DEFAULT_LOG))
        json_path_str = st.text_input("JSON 저장 경로", value=str(DEFAULT_JSON))
        st.divider()
        load_existing_clicked = st.button("기존 JSON 불러오기")

    log_path = Path(log_path_str)
    json_path = Path(json_path_str)

    if not log_path.exists():
        st.error(f"로그 파일을 찾을 수 없음: {log_path}")
        return

    text = log_path.read_text(encoding="utf-8")
    records = parse_records(text)

    if not records:
        st.error("레코드가 없습니다.")
        return

    rec_line_counts = Counter(len(r) for r in records)
    counters = build_field_counters(records)
    consistent = shape_consistent(records)

    st.subheader("형태 요약 (자동 추출)")
    col1, col2, col3 = st.columns(3)
    col1.metric("총 레코드", len(records))
    col2.metric("레코드당 줄 수", f"{dict(rec_line_counts)}")
    col3.metric("일관성", "OK" if consistent else "불일치")

    if not consistent:
        st.warning("일부 레코드의 (줄 수, 필드 수)가 다릅니다. 그래도 진행은 가능하나 결과 검증 필요.")

    for li, line_counters in enumerate(counters):
        field_dist = Counter(sum(c.values()) for c in line_counters)  # placeholder
        st.write(f"**line {li+1}**: {len(line_counters)} fields")

    st.divider()

    # 기존 JSON 로드
    existing_names = {}
    existing = load_existing(json_path) if load_existing_clicked else None
    if existing:
        for line in existing.get("lines", []):
            li = line.get("line_index", 0) - 1
            for f in line.get("fields", []):
                existing_names[(li, f.get("index", 0))] = f.get("name", "")
        st.info(f"기존 스키마 불러옴: {json_path}")

    st.subheader("필드별 이름 부여")
    st.caption("각 위치의 고유값 분포를 보고 이름을 직접 입력하세요. 기본값 없음.")

    # 이름 입력 위젯
    names_state = {}  # (li, fi) -> name
    for li, line_counters in enumerate(counters):
        st.markdown(f"### line {li+1} ({len(line_counters)} fields)")
        cols = st.columns(min(len(line_counters), 3))
        for fi, counter in enumerate(line_counters):
            with cols[fi % len(cols)]:
                with st.container(border=True):
                    st.markdown(f"**line{li+1}.field{fi}**")
                    st.caption(f"고유값 {len(counter)}개")
                    top = counter.most_common(SAMPLE_TOP_N)
                    sample_text = "\n".join(f"  {v}  ×{c}" for v, c in top)
                    if len(counter) > SAMPLE_TOP_N:
                        sample_text += f"\n  ... (+{len(counter)-SAMPLE_TOP_N}개 더)"
                    st.code(sample_text or "(empty)", language=None)
                    default_name = existing_names.get((li, fi), "")
                    name = st.text_input(
                        "이름",
                        value=default_name,
                        key=f"name_{li}_{fi}",
                        label_visibility="collapsed",
                        placeholder="예: timestamp, process …",
                    )
                    names_state[(li, fi)] = name.strip()

    st.divider()

    if st.button("Save JSON", type="primary"):
        spec = {
            "source_file": log_path.name,
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "lines_per_record": len(counters),
            "separator": "blank_line",
            "lines": [
                {
                    "line_index": li + 1,
                    "fields": [
                        {"index": fi, "name": names_state.get((li, fi), "")}
                        for fi in range(len(line_counters))
                    ],
                }
                for li, line_counters in enumerate(counters)
            ],
        }
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(
            json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        empty = [k for k, v in names_state.items() if not v]
        if empty:
            st.warning(
                f"저장 완료, 단 {len(empty)}개 필드가 빈 이름입니다 (변환기 실행 시 에러)."
            )
        else:
            st.success(f"저장 완료: {json_path}")
        with st.expander("저장된 JSON 미리보기"):
            st.code(json_path.read_text(encoding="utf-8"), language="json")


if __name__ == "__main__":
    main()
