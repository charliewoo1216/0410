# 04 — XML 구조 추출 (값 제외, 모델별)

> 목적: 한 모델의 XML 한 개에서 **요소 계층(트리)** 만 뽑는다. value 는 모두 제거.
> 결과: 모델 한 개 당 트리 텍스트 1개. 이걸 보고 사람이 "이 모델 안에 뭐가 들어있나" 한눈에 파악.

---

## 1. 입출력

| | |
|---|---|
| 입력 | XML 파일 1개 (예: `selected-log-normalized/lot_01_eqp_01_euv_*.xml`) |
| 출력 | indented tree 텍스트 (stdout 또는 `out/structure_<model>.txt`) |

---

## 2. 알고리즘

1. `lxml.etree.parse` 로 트리 적재
2. 재귀 walk
3. 각 element 의 자식을 **이름별로 묶음** → 같은 이름이 N번 나오면 `(×N)` 표시 + 첫 번째 한 개의 구조만 재귀로 출력 (나머지 N-1개는 같다고 가정)
4. value(text content) 는 출력 안 함

---

## 3. 출력 예시 (EUV)

```
Log
├── Header
│   ├── ToolId
│   ├── ToolModel
│   ├── SoftwareVer
│   ├── StartTime
│   └── OperatorId
├── Lot
│   ├── LotId
│   ├── LotStartTime
│   ├── ReticleId
│   ├── Recipe
│   ├── Layer
│   └── WaferCount
├── Wafers
│   └── Wafer  (×25)
│       ├── WaferId
│       ├── StartTime
│       ├── StageCalibration
│       │   ├── ChuckId
│       │   ├── StartTime
│       │   ├── EndTime
│       │   ├── Axis  (×3)
│       │   │   ├── Axis
│       │   │   ├── NominalOrigin_um
│       │   │   ├── MeasuredOrigin_um
│       │   │   ├── Offset_um
│       │   │   ├── Tolerance_um
│       │   │   └── WithinTolerance
│       │   ├── NotchAngle_deg
│       │   └── Result
│       ├── Alignment  (×2)
│       │   ├── Stage
│       │   ├── Sensor
│       │   ├── StartTime
│       │   ├── EndTime
│       │   ├── Mark  (×16)
│       │   │   └── ...
│       │   └── GridModel
│       │       └── ...
│       ├── Field  (×12)
│       │   └── ...
│       └── EndTime
└── EndTime
```

---

## 4. 스크립트 (전체, ~30줄)

```python
"""04-xml-structure.py — XML 구조만 출력 (값 제외)."""
from collections import OrderedDict
from pathlib import Path
import sys
from lxml import etree


def localname(tag):
    return tag.split("}", 1)[1] if "}" in tag else tag


def group_children(elem):
    """자식을 이름별로 묶고 (이름, 첫번째 element, 카운트) 리스트 반환 (순서 보존)."""
    od = OrderedDict()
    for c in elem:
        name = localname(c.tag)
        if name in od:
            od[name][1] += 1
        else:
            od[name] = [c, 1]
    return [(n, rep, cnt) for n, (rep, cnt) in od.items()]


def print_tree(elem, prefix="", is_root=True):
    if is_root:
        print(localname(elem.tag))
    children = group_children(elem)
    for i, (name, rep, cnt) in enumerate(children):
        is_last = (i == len(children) - 1)
        connector = "└── " if is_last else "├── "
        suffix = f"  (×{cnt})" if cnt > 1 else ""
        print(prefix + connector + name + suffix)
        new_prefix = prefix + ("    " if is_last else "│   ")
        print_tree(rep, new_prefix, is_root=False)


def main():
    xml_path = Path(sys.argv[1])
    root = etree.parse(str(xml_path)).getroot()
    print_tree(root)


if __name__ == "__main__":
    main()
```

---

## 5. 사용법

```bash
# 한 모델 보기
python 04-xml-structure.py selected-log-normalized/lot_01_eqp_01_euv_2026-04-30T06-00-00+09-00.xml

# 모든 모델 한번에 (각자 파일로)
for x in selected-log-normalized/*.xml; do
    python 04-xml-structure.py "$x" > "out/structure_$(basename $x .xml).txt"
done
```

---

## 6. 그 다음 단계

이 트리를 사람이 보고 → 각 모델에서 "어떤 element 만 남기고 싶다" 를 결정 → 그걸 바탕으로 **모델별 추출기 (xpath 목록)** 를 손으로 작성. 즉 본 04 단계는 **추출기 작성을 위한 사전 조사 도구**.
