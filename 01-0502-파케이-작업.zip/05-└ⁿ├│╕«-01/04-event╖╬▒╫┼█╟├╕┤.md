# 04 — Event 로그 구조 추출 (사전정보 없이, 형태만)

> 목적: 평문 이벤트 로그(`Event_log.old`)에서 **레코드의 형태(shape)** 만 뽑는다.
> 컬럼 이름은 추측하지 않는다 — 이름 부여는 **엔지니어 몫**.
> 결과: "한 레코드가 몇 줄, 각 줄이 몇 필드, 몇 회 반복" + 샘플 레코드 몇 개.

> XML 과 달리 계층 트리가 없으므로 03-xml로그템플릿과는 알고리즘이 다르다.

---


## 6. 사용법

```powershell
# (A) 형태 추출 (사전정보 없이)
python 04-event-structure.py selected-log-normalized\Event_log.old > 04-out\04structure_event.txt

# (B) 이름 부여 — Streamlit 에디터로 인터랙티브하게
streamlit run 04-event-schema-editor.py
# → 04-event-schema.json 저장됨

# (C) 변환 — JSON + 로그 → CSV + Parquet
python 05-event-to-table.py
# → 04-out/event_log.csv, 04-out/event_log.parquet
```

---

## 1. 원칙

스키마 추출은 두 단계로 나눈다:

| 단계 | 누가 | 결과 |
|---|---|---|
| (A) 형태 (shape) | **스크립트** | 줄 수, 필드 수, 일관성 |
| (B) 의미 (label) | **엔지니어** | 각 필드의 이름 부여 |

본 04 단계는 **(A)만** 자동화한다. (B)는 사람이 샘플을 보고 이름을 정한다.
→ 도메인 지식, 명세서, 생성기 코드 등 별도 근거가 있어야 한다.

---

## 2. 입출력

| | |
|---|---|
| 입력 | 평문 로그 1개 (예: `selected-log-normalized/Event_log.old`) |
| 출력 | 형태(shape) 텍스트 + 샘플 레코드 (stdout 또는 `04-out/04structure_event.txt`) |

---

## 3. 알고리즘

1. 파일을 줄 단위로 읽음
2. **빈 줄을 레코드 경계**로 사용 → 비-빈 줄을 모아 한 레코드로 묶음
3. 레코드별로 `len(record)` (줄 수) 분포 집계
4. 각 줄 위치 i에 대해 `len(record[i].split())` (필드 수) 분포 집계
5. **이름 없이** 형태만 출력 + 샘플 레코드 N개를 같이 출력 (엔지니어가 보고 라벨링하도록)

---

## 4. 출력 예시

```
# Event_log.old
total lines: 2097
records (blank-separated): 699
lines per record: {2: 699}

record shape (no names — engineer to assign):
  line 1: field-count distribution = {6: 699}
  line 2: field-count distribution = {2: 699}
  separator: blank line

sample records (first 3):
  R1 line1: 2026-04-30T06:00:00.000000  |  LITHO_EUV  |  LOT_START  |  eqp_01  |  lot_01  |  wafer01.01
  R1 line2: start  |  success

  R2 line1: 2026-04-30T06:00:00.391000  |  LITHO_EUV  |  WAFER_LOAD  |  eqp_01  |  lot_01  |  wafer01.01
  R2 line2: start  |  success

  R3 line1: 2026-04-30T06:00:01.372000  |  LITHO_EUV  |  STAGE_CALIB_OK  |  eqp_01  |  lot_01  |  wafer01.01
  R3 line2: end  |  success
```

엔지니어는 이 출력을 보고 → line1 6필드, line2 2필드에 **이름을 직접 부여**한다.
(예: `timestamp / subsystem / event / eqp_id / lot_id / wafer_id` 등)

---

## 5. 스크립트 (전체, ~40줄)

`04-event-structure.py`

```python
"""04-event-structure.py — 평문 이벤트 로그 스키마 한 장 (사전정보 없이)."""
import sys
from collections import Counter
from pathlib import Path


def parse_records(text: str):
    """빈 줄 기준으로 레코드 분리. 각 레코드는 [line_tokens, ...]."""
    records, block = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if block:
                records.append(block)
                block = []
        else:
            block.append(line.split())
    if block:
        records.append(block)
    return records


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass

    if len(sys.argv) != 2:
        print("usage: python 04-event-structure.py <log_path>", file=sys.stderr)
        sys.exit(2)

    p = Path(sys.argv[1])
    text = p.read_text(encoding="utf-8")
    records = parse_records(text)

    rec_line_counts = Counter(len(r) for r in records)
    max_lines = max(rec_line_counts) if rec_line_counts else 0
    per_line_field_counts = [
        Counter(len(r[i]) for r in records if len(r) > i)
        for i in range(max_lines)
    ]

    print(f"# {p.name}")
    print(f"total lines: {len(text.splitlines())}")
    print(f"records (blank-separated): {len(records)}")
    print(f"lines per record: {dict(rec_line_counts)}")
    print()
    print("record shape (no names — engineer to assign):")
    for i, c in enumerate(per_line_field_counts, start=1):
        print(f"  line {i}: field-count distribution = {dict(c)}")
    print(f"  separator: blank line")
    print()
    print("sample records (first 3):")
    for ri, r in enumerate(records[:3], start=1):
        for li, toks in enumerate(r, start=1):
            print(f"  R{ri} line{li}: " + "  |  ".join(toks))
        print()


if __name__ == "__main__":
    main()
```

---

## 6. 사용법

```powershell
# (A) 형태 추출 (사전정보 없이)
python 04-event-structure.py selected-log-normalized\Event_log.old > 04-out\04structure_event.txt

# (B) 이름 부여 — Streamlit 에디터로 인터랙티브하게
streamlit run 04-event-schema-editor.py
# → 04-event-schema.json 저장됨

# (C) 변환 — JSON + 로그 → CSV + Parquet
python 05-event-to-table.py
# → 04-out/event_log.csv, 04-out/event_log.parquet
```

---

## 7. 03 (XML) 과의 차이

| 항목 | 03 XML 구조 | 04 Event 구조 |
|---|---|---|
| 입력 | 계층 XML | 평문 N줄-레코드 |
| 단위 | element 트리 | 레코드 (줄 묶음) |
| 표현 | 들여쓰기 트리 + `(×N)` | 줄·필드 분포 + 샘플 |
| 라이브러리 | `lxml` (이름이 태그에 있음) | 표준 라이브러리만 |
| 이름 자동? | **있음** (XML 태그 = 이름) | **없음** (엔지니어가 부여) |

→ XML 은 태그명이 곧 컬럼명이라 자동화되지만, 평문은 위치만 있고 이름이 없으므로 사람이 라벨링한다.

---

## 8. 그 다음 단계 (구현됨)

| 단계 | 도구 | 산출물 |
|---|---|---|
| (A) 형태 추출 | `04-event-structure.py` | `04-out/04structure_event.txt` |
| (B) 이름 부여 (엔지니어) | `04-event-schema-editor.py` (Streamlit) | `04-event-schema.json` |
| (C) 정규화 표 변환 | `05-event-to-table.py` | `04-out/event_log.csv` + `event_log.parquet` |

**원칙**: (A) 자동, (B) 수동(엔지니어), (C) 자동(JSON 입력).
변환기는 JSON에 빈 이름이 남아있으면 **에러로 종료** — 의미 부여 누락을 강제로 막는다.

JSON 예시:
```json
{
  "source_file": "Event_log.old",
  "lines_per_record": 2,
  "lines": [
    {"line_index": 1, "fields": [
      {"index": 0, "name": "timestamp"},
      {"index": 1, "name": "process"},
      {"index": 2, "name": "event"},
      {"index": 3, "name": "eqpid"},
      {"index": 4, "name": "lotid"},
      {"index": 5, "name": "waferid"}
    ]},
    {"line_index": 2, "fields": [
      {"index": 0, "name": "phase"},
      {"index": 1, "name": "result"}
    ]}
  ]
}
```
