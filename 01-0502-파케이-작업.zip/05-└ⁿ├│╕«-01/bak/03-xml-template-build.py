"""
03-xml-template-build.py — XML 로그 템플릿 카탈로그 생성

설계: 03-xml로그템플릿.md
입력: selected-log-normalized/*.xml      (XML 만 — Event_log.old 등은 제외)
출력: catalog/
        ├── xml_event_templates.csv     (이벤트 템플릿 사전)
        └── xml_slot_templates.csv      (측정 슬롯 사전)

사용:
    python 03-xml-template-build.py
"""

import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

try:
    from lxml import etree
except ImportError:
    print("lxml 이 필요하다: pip install lxml", file=sys.stderr)
    sys.exit(1)

ROOT    = Path(__file__).parent
SRC_DIR = ROOT / "selected-log-normalized"
OUT_DIR = ROOT / "catalog"

# ───── 시간 자식 (이벤트 marker) ─────
START_TAGS = {"StartTime", "ScanTime", "MeasureTime", "Time", "LotStartTime"}
END_TAGS   = {"EndTime"}
TIME_TAGS  = START_TAGS | END_TAGS

# event subtype 결정 자식 (우선순위)
SUBTYPE_TAGS = ("Stage", "Severity", "Kind")

RESULT_TAGS  = {"Result", "Severity"}
MESSAGE_TAGS = {"Message", "Description"}

# ───── unit suffix → 표준 표기 ─────
UNIT_SUFFIXES = [
    ("_mJ_cm2", "mJ_cm2"),
    ("_um",     "um"),
    ("_nm",     "nm"),
    ("_mm",     "mm"),
    ("_urad",   "urad"),
    ("_deg",    "deg"),
    ("_ppm",    "ppm"),
    ("_kV",     "kV"),
    ("_sec",    "s"),
]


# ───────────── 헬퍼 ─────────────

def localname(tag: str) -> str:
    """{namespace}Local → Local."""
    return tag.split("}", 1)[1] if "}" in tag else tag


def get_namespace(root) -> str:
    """root tag 의 namespace = 장비 코드 (프로젝트 컨벤션)."""
    if "}" in root.tag:
        return root.tag.split("}", 1)[0][1:]
    return "UNKNOWN"


def child_local_tags(elem) -> set:
    return {localname(c.tag) for c in elem}


def is_event(elem) -> bool:
    """element 가 시간 자식(들)을 가지면 이벤트 후보."""
    return bool(child_local_tags(elem) & TIME_TAGS)


def has_start_end(elem):
    ct = child_local_tags(elem)
    return bool(ct & START_TAGS), bool(ct & END_TAGS)


def find_subtype(elem):
    for tag in SUBTYPE_TAGS:
        for c in elem:
            if localname(c.tag) == tag and c.text and c.text.strip():
                return c.text.strip()
    return None


def has_result(elem) -> bool:
    return any(localname(c.tag) in RESULT_TAGS for c in elem)


def has_message(elem) -> bool:
    return any(localname(c.tag) in MESSAGE_TAGS for c in elem)


# ───────────── 이벤트 / 슬롯 수집 ─────────────

def collect_events(elem, parent_path=""):
    """이벤트 후보 element 를 재귀 수집."""
    name = localname(elem.tag)
    cur_path = f"{parent_path}/{name}" if parent_path else name

    out = []
    if is_event(elem):
        out.append({
            "elem":    elem,
            "name":    name,
            "subtype": find_subtype(elem),
            "path":    cur_path,
        })

    for c in elem:
        out.extend(collect_events(c, cur_path))
    return out


def collect_slots(event_elem):
    """이벤트의 leaf 슬롯 수집 — sub-event 영역과 시간 자식은 제외.

    discriminator(같은 이름의 leaf 자식, 예: Axis 안 <Axis>Z</Axis>)가 있으면
    xpath 에 predicate 형태로 반영 → Axis[Axis='Z']/Offset_um.
    """
    slots = []

    def walk(node, parts, depth):
        # sub-event 진입 금지
        if depth > 0 and is_event(node):
            return
        name = localname(node.tag)
        if name in TIME_TAGS:
            return

        children = list(node)
        if not children:
            slots.append({
                "xpath": "/".join(parts),
                "name":  name,
                "value": (node.text or "").strip(),
            })
            return

        # discriminator 탐색 (자기 자신과 같은 이름의 leaf 자식)
        disc_value = None
        for c in children:
            cn = localname(c.tag)
            if cn == name and len(list(c)) == 0 and c.text and c.text.strip():
                disc_value = c.text.strip()
                break

        # parent path 마지막 요소를 predicate 로 갱신
        eff_parts = parts.copy()
        if disc_value and eff_parts and eff_parts[-1] == name:
            eff_parts[-1] = f"{name}[{name}='{disc_value}']"

        for c in children:
            cn = localname(c.tag)
            # discriminator 자체는 별도 슬롯으로 기록 안 함 (xpath 에 표현됨)
            if cn == name and disc_value is not None and len(list(c)) == 0:
                continue
            walk(c, eff_parts + [cn], depth + 1)

    for c in event_elem:
        cn = localname(c.tag)
        if cn in TIME_TAGS:
            continue
        walk(c, [cn], 1)

    return slots


# ───────────── 추론 규칙 ─────────────

def infer_dtype(value: str) -> str:
    if not value:
        return "string"
    v = value.strip()
    if v in ("true", "false"):
        return "bool"
    if re.fullmatch(r"-?\d+", v):
        return "int64"
    if re.fullmatch(r"-?\d+\.\d+([eE][+-]?\d+)?", v):
        return "float64"
    if re.match(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", v):
        return "dateTime"
    return "string"


def infer_unit(local: str):
    for suffix, unit in UNIT_SUFFIXES:
        if local.endswith(suffix):
            return unit
    return None


def infer_role(local: str, dtype: str) -> str:
    n = local
    if n in {"Result", "Severity", "Used"} or n.endswith("WithinTolerance"):
        return "status"
    if "Time" in n:
        return "time"
    if "Tolerance" in n or n.endswith("Min") or n.endswith("Max"):
        return "threshold"
    if (n in {"FieldX", "FieldY"}
        or n.endswith("X_um") or n.endswith("Y_um")
        or n.endswith("X_mm") or n.endswith("Y_mm")):
        return "coordinate"
    if n in MESSAGE_TAGS:
        return "message"
    if (n.endswith("Id")
        or n in {"Recipe", "Layer", "LayerName", "Operator", "OperatorId",
                 "Code", "ChuckId", "Sensor", "Class", "Stage", "Kind",
                 "ToolId", "ToolModel", "SoftwareVer", "ReticleId"}):
        return "identifier"
    if dtype in ("float64", "int64"):
        return "measurement"
    return "string"


# ───────────── ID 생성 ─────────────

def safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")


def make_template_id(equipment: str, name: str, subtype) -> str:
    parts = [safe(equipment), safe(name)]
    if subtype:
        parts.append(safe(subtype))
    return "T_" + "_".join(parts)


def make_slot_id(template_id: str, xpath: str) -> str:
    return "S_" + template_id.removeprefix("T_") + "__" + safe(xpath)


# ───────────── 카탈로그 빌드 ─────────────

def build_catalog(xml_paths):
    event_acc = {}                  # tid → event template row dict
    slot_acc  = defaultdict(lambda: {"values": [], "name": "", "xpath": "",
                                      "occurrences": 0, "equipment": ""})

    for p in xml_paths:
        try:
            tree = etree.parse(str(p))
        except etree.XMLSyntaxError as e:
            print(f"  ! skip {p.name} (syntax error: {e})", file=sys.stderr)
            continue
        root = tree.getroot()
        equipment = get_namespace(root)

        for ev in collect_events(root):
            elem    = ev["elem"]
            name    = ev["name"]
            subtype = ev["subtype"]
            tid     = make_template_id(equipment, name, subtype)
            has_st, has_en = has_start_end(elem)

            if tid not in event_acc:
                event_acc[tid] = {
                    "template_id":    tid,
                    "equipment":      equipment,
                    "event_type":     name,
                    "event_subtype":  subtype or "",
                    "element_name":   name,
                    "event_path":     ev["path"],
                    "has_start_time": has_st,
                    "has_end_time":   has_en,
                    "has_result":     has_result(elem),
                    "has_message":    has_message(elem),
                    "has_wafer_id":   "Wafer" in ev["path"],
                    "occurrences":    0,
                    "description":    "",
                }
            row = event_acc[tid]
            row["occurrences"]    += 1
            row["has_start_time"]  = row["has_start_time"] or has_st
            row["has_end_time"]    = row["has_end_time"]   or has_en
            row["has_result"]      = row["has_result"]     or has_result(elem)
            row["has_message"]     = row["has_message"]    or has_message(elem)

            for s in collect_slots(elem):
                key = (tid, s["xpath"])
                acc = slot_acc[key]
                acc["name"]        = s["name"]
                acc["xpath"]       = s["xpath"]
                acc["equipment"]   = equipment
                acc["occurrences"] += 1
                if s["value"]:
                    acc["values"].append(s["value"])

    # event rows
    event_rows = []
    for tid in sorted(event_acc):
        r = event_acc[tid]
        event_rows.append({
            "template_id":    r["template_id"],
            "equipment":      r["equipment"],
            "event_type":     r["event_type"],
            "event_subtype":  r["event_subtype"],
            "element_name":   r["element_name"],
            "event_path":     r["event_path"],
            "has_start_time": int(r["has_start_time"]),
            "has_end_time":   int(r["has_end_time"]),
            "has_result":     int(r["has_result"]),
            "has_message":    int(r["has_message"]),
            "has_wafer_id":   int(r["has_wafer_id"]),
            "occurrences":    r["occurrences"],
            "description":    "",
        })

    # slot rows
    slot_rows = []
    for (tid, xpath) in sorted(slot_acc.keys()):
        info = slot_acc[(tid, xpath)]
        # dtype: 관측 값 다수결
        dtypes = [infer_dtype(v) for v in info["values"][:50]]
        dtype  = max(set(dtypes), key=dtypes.count) if dtypes else "string"
        unit   = infer_unit(info["name"]) or ""
        role   = infer_role(info["name"], dtype)

        # min/max 관측치 (수치형만)
        nums = []
        if dtype in ("float64", "int64"):
            for v in info["values"]:
                try:
                    nums.append(float(v))
                except (ValueError, TypeError):
                    pass

        slot_rows.append({
            "slot_id":     make_slot_id(tid, xpath),
            "template_id": tid,
            "equipment":   info["equipment"],
            "xpath":       xpath,
            "local_name":  info["name"],
            "dtype":       dtype,
            "unit":        unit,
            "role":        role,
            "min_value":   f"{min(nums)}" if nums else "",
            "max_value":   f"{max(nums)}" if nums else "",
            "occurrences": info["occurrences"],
            "description": "",
        })

    return event_rows, slot_rows


# ───────────── 출력 ─────────────

def write_csv(rows, path: Path, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main():
    if not SRC_DIR.exists():
        raise FileNotFoundError(f"입력 폴더 없음: {SRC_DIR}")

    xml_paths = sorted(SRC_DIR.glob("*.xml"))
    if not xml_paths:
        raise FileNotFoundError(f"{SRC_DIR} 안에 *.xml 파일 없음")

    print(f"입력 ({len(xml_paths)} XML):")
    for p in xml_paths:
        print(f"  - {p.name}")

    event_rows, slot_rows = build_catalog(xml_paths)

    EVENT_FIELDS = [
        "template_id", "equipment", "event_type", "event_subtype",
        "element_name", "event_path",
        "has_start_time", "has_end_time", "has_result", "has_message",
        "has_wafer_id", "occurrences", "description",
    ]
    SLOT_FIELDS = [
        "slot_id", "template_id", "equipment", "xpath", "local_name",
        "dtype", "unit", "role",
        "min_value", "max_value", "occurrences", "description",
    ]

    event_csv = OUT_DIR / "xml_event_templates.csv"
    slot_csv  = OUT_DIR / "xml_slot_templates.csv"
    write_csv(event_rows, event_csv, EVENT_FIELDS)
    write_csv(slot_rows,  slot_csv,  SLOT_FIELDS)

    print(f"\n출력:")
    print(f"  - {event_csv}  ({len(event_rows)} event templates)")
    print(f"  - {slot_csv}   ({len(slot_rows)} slot templates)")

    # 요약
    by_eqp = defaultdict(int)
    for r in event_rows:
        by_eqp[r["equipment"]] += 1
    print(f"\n장비별 이벤트 템플릿:")
    for eqp, n in sorted(by_eqp.items()):
        print(f"  {eqp:<12s} {n:>3d}")


if __name__ == "__main__":
    main()
