# 03 — XML 로그 처리 설계

> 처리 대상: `selected-log/*.xml` (실 운영에서는 1 파일 10~20MB, 합쳐서 GB+)
> 목적: 시간 경계가 있는 **동작 이벤트**와 wafer 단위 **집계 결과값**을 빠르게 추출, 분석용 테이블로 함축.

---

## 1. 목표

1. **동작 이벤트 추출** — `<StartTime>` / `<EndTime>` 쌍 (또는 단일 시점) 을 가진 모든 의미 있는 element.
2. **상단 명세 결합** — `<Header>` / `<Lot>` 의 lot, eqp, recipe, layer, reticle, operator, software ver. 을 모든 이벤트에 묶을 수 있는 형태로 보존.
3. **wafer 단위 집계** — `<Mark>`, `<Field>`, `<OverlaySite>`, `<Defect>`, `<Cd>` 같은 폭발 단위는 raw 로 두지 않고 통계량으로 함축.
4. **빠른 처리** — 20MB XML 1개 < 1초, 100개 < 1분, 메모리 < 50 MB 일정 유지.
5. **함축 출력** — 20MB raw XML → 합쳐서 ~100KB parquet (≈ 200× 압축).

---

## 2. 5종 ASML 장비 XML 구조 (분석 결과)

`02-asml-xml-분석/` 의 분석 자료 기준.

| 장비 | 자연 시간 단위 | start+end 쌍 | 단일 시점 | 측정값 단위 |
|---|---|---|---|---|
| **NXE:3600D / EXE:5200 (EUV / HNA-EUV)** | Wafer → StageCalibration(μm) → Alignment(COARSE/FINE, nm) → Field | ✓ 풍부 | — | dose mJ/cm², focus nm, residual nm, axis offset μm |
| **NXT:2050i / XT:1900i (ArF imm/dry)** | Wafer + Field overlay/leveling | △ wafer 레벨 | `<ScanTime>` | overlay nm, leveling Z |
| **XT:860N (KrF)** | Lot 전체 + Event stream | Lot 레벨 only | `<Event>/<Time>` 다수 | severity + 자유 텍스트 message |
| **YieldStar S385** | Wafer 측정 | — | `<MeasureTime>` | overlay nm, CD nm |
| **eP5 (e-beam)** | Wafer scan | — | `<ScanTime>` | defect class+size, CD nm |

**핵심 관찰**: start+end 쌍 이벤트는 scanner 계열 (EUV/HNA/ArF) 에 집중. metrology 계열은 단일 시점 + 좌표 + 측정값.
→ 이벤트 모델은 **`end_time` optional** 로 통일.

### 2-1. Cross-tool join 키
같은 `lot_id` + `wafer_id` 가 NXT(노광) → YS(검증) → eP5(검출) 에서 공유된다.
**wafer lifecycle 추적** 이 분석의 본 목적이므로 lot_id / wafer_id 는 모든 출력 테이블의 1급 컬럼.

---

## 3. 출력 구조 — Tiered Parquet 3 테이블

### 3-1. `xml_runs` — XML 1개 = 1 row (메타)

| 컬럼 | 타입 | 의미 |
|---|---|---|
| run_id | uint64 | 고유 ID (file path 해시 또는 인서트 순) |
| file_path | string | 입력 XML 절대경로 |
| equipment | string | `EUV3600` / `NXT2050i` / `XT860` / `YS385` / `EBEAM` / `EXE5200` / `XT1900i` |
| tool_id | string | `<ToolId>` |
| tool_model | string | `<ToolModel>` (예: `NXE:3600D`) |
| software_ver | string | `<SoftwareVer>` (없으면 NULL) |
| operator | string | `<OperatorId>` (없으면 NULL) |
| lot_id | string | `<LotId>` |
| recipe | string | `<Recipe>` |
| layer | string | `<Layer>` / `<LayerName>` |
| reticle | string | `<ReticleId>` |
| wafer_count | uint16 | `<WaferCount>` |
| lot_start_time | timestamp[us] | `<LotStartTime>` 또는 `<Header>/<StartTime>` |
| lot_end_time | timestamp[us] | `<EndTime>` (마지막 wafer end 로 합성 가능) |
| lot_duration_us | int64 | end - start |

### 3-2. `xml_events` — 시간 경계 또는 단일 시점 이벤트 (~100 row / 파일)

| 컬럼 | 타입 | 의미 |
|---|---|---|
| event_uid | uint64 | 고유 ID |
| run_id | uint64 | FK → xml_runs |
| equipment | string | (denorm, 쿼리 편의) |
| lot_id | string | (denorm) |
| wafer_id | string | nullable — lot 레벨 이벤트면 NULL |
| event_type | string | `Lot` / `Wafer` / `StageCalibration` / `Alignment` / `Exposure` / `WaferMeasurement` / `WaferScan` / `Event` |
| event_subtype | string | `COARSE` / `FINE` / `Z-axis` / severity (`INFO`/`WARN`/`ERROR`/`FATAL`) — nullable |
| event_path | string | XPath (예: `Wafers/Wafer[3]/Alignment[Stage='FINE']`) |
| start_time | timestamp[us] | 필수 |
| end_time | timestamp[us] | nullable (단일 시점 이벤트면 NULL) |
| duration_us | int64 | nullable (start+end 둘 다 있을 때만) |
| result | string | `OK` / `RECALIBRATED` / `FAIL` / `WARN` 등 nullable |
| message | string | KrF Event 의 자유 텍스트 (Drain3 후속 입력) — nullable |

### 3-3. `xml_wafer_summary` — wafer 단위 집계 (~25 row / 파일)

scanner 와 metrology 가 컬럼이 다르지만, 같은 wide 테이블에 sparse 로 (없는 컬럼 = NULL) 둔다.

공통:
| 컬럼 | 타입 | 의미 |
|---|---|---|
| run_id | uint64 | FK |
| equipment | string | (denorm) |
| lot_id, wafer_id | string | join 키 |
| wafer_start_time, wafer_end_time | timestamp[us] | wafer 레벨 |

scanner 전용 (EUV/HNA/ArF):
| 컬럼 | 타입 | 의미 |
|---|---|---|
| stage_calib_z_offset_um | float64 | `<StageCalibration>/<Axis[Z]>/<Offset_um>` |
| stage_calib_within_tol | bool | Z 축 기준 |
| stage_calib_result | string | `OK` / `RECALIBRATED` / `FAIL` |
| align_coarse_residual_3sigma_nm | float64 | `<Alignment[COARSE]>/<GridModel>/<Residual3Sigma_nm>` |
| align_fine_residual_3sigma_nm | float64 | FINE 단계 |
| align_marks_used_ratio | float32 | `<Mark>` 중 `Used=true` 비율 |
| align_marks_avg_signal_quality | float32 | 평균 SignalQuality |
| align_retry_count | uint8 | 정렬 재시도 횟수 |
| field_count | uint16 | wafer 의 field 개수 |
| dose_mean_mJ_cm2 | float64 | mean over fields |
| dose_std_mJ_cm2 | float64 | std |
| focus_mean_nm | float64 | |
| focus_std_nm | float64 | |
| pulse_total | uint64 | sum |

metrology 전용 (NXT overlay / YS / eP5):
| 컬럼 | 타입 | 의미 |
|---|---|---|
| ovl_x_mean_nm, ovl_y_mean_nm | float64 | OverlaySite 평균 |
| ovl_3sigma_nm | float64 | 3σ |
| residual_mean_nm | float64 | |
| cd_mean_nm, cd_std_nm | float64 | CD 측정 |
| defect_count | uint16 | wafer 의 defect 총 개수 |
| defect_class_top1 | string | 가장 많은 결함 클래스 |
| defect_class_top1_count | uint16 | 그 개수 |

(선택) **Tier B `xml_measurements`** — raw 측정값 전체 (Mark / Field / OverlaySite / Defect / Cd 별 1 row).
평소엔 만들지 않고, 깊은 분석 필요 시 별도 옵션 (`--full`) 으로 생성.

---

## 4. 처리 전략

### 4-1. 스트리밍 파싱 (`lxml.iterparse`)

```python
from lxml import etree

INTERESTING = (
    "Header", "Lot",
    "Wafer", "StageCalibration", "Alignment", "GridModel",
    "WaferMeasurement", "WaferScan",
    "Event",                                # KrF
)

ctx = etree.iterparse(
    xml_path,
    events=("end",),
    tag=INTERESTING,                         # whitelist — 다른 element 는 콜백 자체가 안 옴
    huge_tree=True,                          # 매우 큰 파일 안전 모드
)
for _, elem in ctx:
    handle(elem)
    elem.clear()                              # 자식 메모리 회수
    while elem.getprevious() is not None:    # 형제(처리 끝) 도 즉시 제거
        del elem.getparent()[0]
```

**원칙**:
- `<Mark>`, `<Field>`, `<OverlaySite>`, `<CdSite>`, `<Defect>` 같이 **수가 폭발하는 단위는 화이트리스트에 넣지 않는다**. lxml 이 내부적으로 파싱은 하지만 콜백이 안 발생 → 우리는 부모(`<Wafer>`) END 시점에 한꺼번에 집계.
- 부모 END 시점에는 자식이 이미 다 파싱되어 element 트리에 붙어있으므로 `elem.findall(...)` / `elem.findtext(...)` 로 즉시 통계 산출.
- 처리 끝나면 `elem.clear()` + 형제 prune → 메모리 일정.

### 4-2. 선택적 추출 — wafer END 에서 집계

```python
def summarize_wafer(wafer_elem, ns):
    # Mark 통계
    marks = wafer_elem.findall(".//Mark", ns)
    used_ratio = sum(1 for m in marks if m.findtext("Used") == "true") / len(marks)
    avg_sq    = mean(float(m.findtext("SignalQuality")) for m in marks)

    # Field 통계
    fields = wafer_elem.findall(".//Field", ns)
    doses  = [float(f.findtext("Dose"))  for f in fields if f.findtext("Dose")]
    focii  = [float(f.findtext("Focus")) for f in fields if f.findtext("Focus")]

    # GridModel (FINE)
    fine = wafer_elem.find(".//Alignment[Stage='FINE']/GridModel", ns)
    residual = float(fine.findtext("Residual3Sigma_nm")) if fine is not None else None

    # StageCalibration Z
    z_axis = wafer_elem.find(".//StageCalibration/Axis[Axis='Z']", ns)
    z_off  = float(z_axis.findtext("Offset_um")) if z_axis is not None else None

    return WaferSummary(...)
```

자식 단위 raw row 는 만들지 않는다. `<Mark>` 16개 × 25 wafer = 400 row 가 **1 wafer = 1 row × 25 wafer = 25 row** 로 줄어든다.

### 4-3. 출력 — Parquet append-streaming + 파티셔닝

```python
import pyarrow as pa
import pyarrow.parquet as pq

writer = pq.ParquetWriter(out_path, schema=WAFER_SUMMARY_SCHEMA, compression="zstd")
for batch in batches_of(rows, 1000):
    writer.write_table(pa.Table.from_pylist(batch, schema=WAFER_SUMMARY_SCHEMA))
writer.close()
```

파티션 레이아웃:
```
out/xml_runs/dt=2026-04-30/part-0.parquet
out/xml_events/dt=2026-04-30/eqp=eqp_01/part-0.parquet
out/xml_wafer_summary/dt=2026-04-30/eqp=eqp_01/part-0.parquet
```

DuckDB / pandas 둘 다 파티션 pruning 으로 빠른 쿼리 가능.

---

## 5. 의존성 (최소)

```
lxml      # iterparse, C 파서
pyarrow   # parquet append-streaming
# (선택)
duckdb    # SQL 쿼리
```

`xsdata` 는 도입하지 않음 — 실제 .xsd 파일이 손에 없고, 우리 추출 로직은 generic walker 로 충분.
`xml.etree.ElementTree` (stdlib) 는 GB 규모에선 lxml 대비 3~10배 느려 권장하지 않음.

---

## 6. 예상 성능 (20MB XML 1개)

| 방식 | 시간 | 메모리 |
|---|---|---|
| stdlib ET full parse | ~10 s | 200~500 MB |
| lxml full parse | ~3 s | 100~200 MB |
| **lxml.iterparse + tag whitelist + wafer 집계** | **~0.5 s** | **<50 MB** |

100개 파일(2GB 입력) → 1분 이내, 메모리 50MB 일정.
출력: 합쳐서 ~100KB parquet × 3 테이블 (≈ 200× 압축).

---

## 7. 모듈 구성 (예정)

```
05-전처리-01/
├── 03-xml-extract.py           ← 본 설계 구현 (메인 스크립트)
│   ├── stream_parse(path)      ← iterparse + 콜백
│   ├── build_run_row(...)      ← Header/Lot → xml_runs row
│   ├── build_event_row(...)    ← StageCalib/Alignment/Wafer/Event → xml_events row
│   ├── summarize_wafer(...)    ← Mark/Field/OvlSite/Defect 통계 → xml_wafer_summary row
│   └── write_parquet(...)      ← 3 테이블 append + 파티션
└── selected-log-normalized/    ← 02 단계 결과 (입력)

out/
├── xml_runs/         dt=YYYY-MM-DD/part-*.parquet
├── xml_events/       dt=YYYY-MM-DD/eqp=*/part-*.parquet
└── xml_wafer_summary/dt=YYYY-MM-DD/eqp=*/part-*.parquet
```

---

## 8. 처리 순서 (전체 파이프라인 위치)

1. `01-log-generator.py` — 합성 로그 생성
2. `02-time-normalize.py` — 시간 통일 (KST · μs)
3. **`03-xml-extract.py` — 본 설계** (XML → 3 parquet)
4. (후속) Event_log.old → 별도 처리 단계 (Drain3 가능 영역 포함)
5. (후속) cross-tool join 분석: lot_id + wafer_id 로 NXT/YS/eP5 lifecycle 추적

---

## 9. 예시 결과 (`selected-log/` 7 XML 입력 기준)

입력: in-range 7개 XML, 모두 `eqp_01` / `lot_01`. 시간 범위 `2026-04-30 06:00:00 ~ 06:59:59`.
아래는 본 설계대로 추출했을 때 나오는 **실제 row 모양** (값은 합성 데이터 기반).

### 9-1. `xml_runs` — 7 rows

| run_id | equipment | tool_model | lot_id | recipe | layer | reticle | wafer_count | lot_start_time | lot_end_time | duration_us |
|---:|---|---|---|---|---|---|---:|---|---|---:|
| 1 | EUV3600 | NXE:3600D | lot_01 | 5nm_BEOL_M2_v17 | METAL2 | RTC-EUV-9921A | 25 | 2026-04-30T06:00:00.000000 | 2026-04-30T06:01:48.000000 | 108_000_000 |
| 2 | NXT2050i | NXT:2050i | lot_01 | 7nm_M3_overlay_v8 | METAL3 | RTC-ARF-7714B | 25 | 2026-04-30T06:02:00.000000 | 2026-04-30T06:05:18.000000 | 198_000_000 |
| 3 | XT860 | XT:860N | lot_01 | i-line_align_v4 | (NULL) | (NULL) | 25 | 2026-04-30T06:06:00.000000 | 2026-04-30T06:09:42.000000 | 222_000_000 |
| 4 | EXE5200 | EXE:5200 | lot_01 | 2nm_FEOL_v2 | METAL1 | RTC-HNA-3301X | 25 | 2026-04-30T06:11:00.000000 | 2026-04-30T06:13:18.000000 | 138_000_000 |
| 5 | XT1900i | XT:1900i | lot_01 | nx_ArF_dry_recipe | METAL5 | RTC-ARF-9982C | 25 | 2026-04-30T06:18:00.000000 | 2026-04-30T06:22:18.000000 | 258_000_000 |
| 6 | YS385 | YieldStar S385 | lot_01 | post_overlay_M3_v3 | (NULL) | (NULL) | 25 | 2026-04-30T06:48:00.000000 | 2026-04-30T06:50:55.000000 | 175_000_000 |
| 7 | EBEAM | HMI eP5 | lot_01 | M3_post_overlay_v3 | (NULL) | (NULL) | 25 | 2026-04-30T06:53:00.000000 | 2026-04-30T06:57:30.000000 | 270_000_000 |

### 9-2. `xml_events` — 약 ~600 rows (7 XML 합산)

EUV(run_id=1) wafer01.01 의 발췌:

| event_uid | run_id | equipment | wafer_id | event_type | subtype | start_time | end_time | duration_us | result |
|---:|---:|---|---|---|---|---|---|---:|---|
| 1 | 1 | EUV3600 | (NULL) | Lot | (NULL) | 2026-04-30T06:00:00.000000 | 2026-04-30T06:01:48.000000 | 108_000_000 | OK |
| 2 | 1 | EUV3600 | wafer01.01 | Wafer | (NULL) | 2026-04-30T06:00:00.000000 | 2026-04-30T06:00:12.000000 | 12_000_000 | OK |
| 3 | 1 | EUV3600 | wafer01.01 | StageCalibration | (NULL) | 2026-04-30T06:00:00.000000 | 2026-04-30T06:00:01.000000 | 1_000_000 | OK |
| 4 | 1 | EUV3600 | wafer01.01 | Alignment | COARSE | 2026-04-30T06:00:01.000000 | 2026-04-30T06:00:02.000000 | 1_000_000 | OK |
| 5 | 1 | EUV3600 | wafer01.01 | Alignment | FINE | 2026-04-30T06:00:02.000000 | 2026-04-30T06:00:05.000000 | 3_000_000 | OK |

OVL(run_id=6) wafer01.01 — 단일 시점 이벤트:

| event_uid | run_id | equipment | wafer_id | event_type | subtype | start_time | end_time | duration_us | result |
|---:|---:|---|---|---|---|---|---|---:|---|
| 423 | 6 | YS385 | wafer01.01 | WaferMeasurement | OVL | 2026-04-30T06:48:08.000000 | (NULL) | (NULL) | (NULL) |

KrF Event 자유 텍스트 예시:

| event_uid | run_id | event_type | subtype | start_time | result | message |
|---:|---:|---|---|---|---|---|
| 178 | 3 | Event | WARN | 2026-04-30T06:08:13.000000 | WARN | "Reticle stage temperature out of nominal band, auto-recovered" |

### 9-3. `xml_wafer_summary` — 7 × 25 = 약 175 rows

EUV(run_id=1) wafer01.01:

| run_id | equipment | wafer_id | wafer_start_time | wafer_end_time | stage_calib_z_offset_um | stage_calib_within_tol | stage_calib_result | align_fine_residual_3sigma_nm | align_marks_used_ratio | dose_mean_mJ_cm2 | dose_std_mJ_cm2 | focus_mean_nm | field_count |
|---:|---|---|---|---|---:|---|---|---:|---:|---:|---:|---:|---:|
| 1 | EUV3600 | wafer01.01 | 2026-04-30T06:00:00.000000 | 2026-04-30T06:00:12.000000 | -0.676 | true | OK | 5.7 | 1.000 | 52.31 | 0.04 | -3.13 | 12 |

EUV wafer02.01 — Z 축 tolerance 초과 → recal:

| run_id | wafer_id | stage_calib_z_offset_um | stage_calib_within_tol | stage_calib_result | align_fine_residual_3sigma_nm | dose_mean_mJ_cm2 |
|---:|---|---:|---|---|---:|---:|
| 1 | wafer02.01 | 6.21 | **false** | **RECALIBRATED** | 4.8 | 52.29 |

OVL(run_id=6) wafer01.01 — metrology 컬럼 채워짐, scanner 컬럼은 NULL:

| run_id | equipment | wafer_id | wafer_start_time | ovl_x_mean_nm | ovl_y_mean_nm | ovl_3sigma_nm | residual_mean_nm |
|---:|---|---|---|---:|---:|---:|---:|
| 6 | YS385 | wafer01.01 | 2026-04-30T06:48:08.000000 | 1.27 | -0.87 | 1.41 | 0.40 |

eP5(run_id=7) wafer01.01:

| run_id | equipment | wafer_id | wafer_start_time | defect_count | defect_class_top1 | defect_class_top1_count | cd_mean_nm | cd_std_nm |
|---:|---|---|---|---:|---|---:|---:|---:|
| 7 | EBEAM | wafer01.01 | 2026-04-30T06:53:20.000000 | 0 | (NULL) | 0 | 13.20 | 0.10 |

eP5 wafer04.01 — defect 발견:

| run_id | wafer_id | defect_count | defect_class_top1 | defect_class_top1_count | cd_mean_nm |
|---:|---|---:|---|---:|---:|
| 7 | wafer04.01 | 3 | BRIDGE | 2 | 13.31 |

### 9-4. 합산 통계 (예상)

| 테이블 | row 수 | parquet 크기 (zstd) |
|---|---:|---:|
| `xml_runs` | 7 | < 2 KB |
| `xml_events` | ~600 | ~30 KB |
| `xml_wafer_summary` | ~175 | ~50 KB |
| **합계** | ~780 rows | **~80 KB** |

원본: 7 XML × 평균 80 KB = ~600 KB → 함축 후 ~80 KB (≈ 7× 압축).
실제 운영(20MB × 100 파일 = 2GB) 환경에서는 **약 200×** 압축 효과가 기대된다 (raw 측정값을 wafer 통계로 줄이므로).

### 9-5. 예시 쿼리 (DuckDB)

cross-tool wafer lifecycle 추적:
```sql
-- lot_01 의 wafer01.01 이 EUV 노광 → OVL 검증 → eP5 검출 까지 통과한 흐름
SELECT r.equipment, s.wafer_id, s.wafer_start_time,
       s.stage_calib_z_offset_um, s.align_fine_residual_3sigma_nm,
       s.ovl_3sigma_nm, s.defect_count
FROM 'out/xml_wafer_summary/**/*.parquet' s
JOIN 'out/xml_runs/**/*.parquet' r USING (run_id)
WHERE s.wafer_id = 'wafer01.01' AND r.lot_id = 'lot_01'
ORDER BY s.wafer_start_time;
```

stage calibration recal 발생 wafer:
```sql
SELECT run_id, wafer_id, stage_calib_z_offset_um, stage_calib_result
FROM 'out/xml_wafer_summary/**/*.parquet'
WHERE stage_calib_result = 'RECALIBRATED';
```

KrF WARN/ERROR 메시지 모음 (Drain3 입력 후보):
```sql
SELECT start_time, subtype, message
FROM 'out/xml_events/**/*.parquet'
WHERE event_type = 'Event' AND subtype IN ('WARN','ERROR','FATAL');
```

---

## 10. 결정된 사항 / 미결 사항

### 결정
- 파서: **lxml.iterparse + tag whitelist + clear**
- 출력: **Parquet 3 tier (runs / events / wafer_summary)**, dt+eqp 파티셔닝
- raw measurements 는 Tier B (옵션 플래그) — 1차 산출물에서 제외
- KrF `<Message>` 는 `xml_events.message` 컬럼에 보존 → 후속 Drain3 입력
- 시간 단위: μs 정밀도 timestamp (parquet `timestamp[us]`)
- 의존성: `lxml`, `pyarrow` (+선택 `duckdb`)

### 미결 (구현 시 보강)
- `xml_wafer_summary` 의 정확한 컬럼 집합 — 위 표는 1차 후보, 실제 추출 코드 작성 시 5종 XML 샘플별로 검증/조정
- raw measurement 압축 방식 (Tier B 활성화 시) — parquet zstd vs row group size
- 부분 실패 처리 (XML 손상/누락) — 현재는 raise, 운영시 quarantine 폴더로
