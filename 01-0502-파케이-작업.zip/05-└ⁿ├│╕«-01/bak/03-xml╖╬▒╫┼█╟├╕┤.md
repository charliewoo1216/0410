# 03 — XML 로그 템플릿 카탈로그 설계

> 처리 대상: `selected-log/*.xml` (5종 ASML 장비)
> 목적: 모든 후속 추출/분석의 **메타-스키마(템플릿 카탈로그)** 를 먼저 정의한다.
> 04(추출)는 이 카탈로그를 **참조**해서 동작하므로, 카탈로그가 진실원이다.

---

## 1. 왜 카탈로그를 먼저 만드나

- 5종 장비가 각자 다른 XSD를 따름 (EUV3600 / NXT2050i / XT860 / YS385 / EBEAM 등) → 추출 코드에 모든 분기를 hard-code 하면 새 장비 추가 시 코드 수정 필요.
- **카탈로그 = 데이터** 로 두면 추출 코드는 한 벌로 충분 (data-driven).
- 분석 단계에서 "이 XML 에 어떤 측정값이 있는가" 를 SQL 한 줄로 확인 가능.
- 템플릿 자체가 도메인 지식의 정형화된 표현 — 운영 인수인계, 변경 이력 추적에 유용.

---

## 2. 두 종류의 템플릿

### 2-1. 이벤트 템플릿 (event template)
시간 경계를 가진 (또는 단일 시점) **동작 단위**.
- 예: `EUV3600.StageCalibration`, `EUV3600.Alignment[FINE]`, `YS385.WaferMeasurement[OVL]`, `XT860.Event[WARN]`
- 속성: 장비, event_type, subtype, start/end 보유 여부, result/message 보유 여부

### 2-2. 측정 슬롯 템플릿 (slot template)
이벤트 템플릿이 포함하는 **leaf 측정값**.
- 예: `EUV3600.StageCalibration.Axis[Z].Offset_um` (dtype=float, unit=μm, role=measurement)
- 속성: 부모 이벤트 템플릿, XPath, 태그명, dtype, unit, role, min/max(있으면), description

→ 이벤트 템플릿 1개에 슬롯 템플릿 N개가 매달림 (1:N).

---

## 3. 카탈로그 스키마

### 3-1. `xml_event_templates` — 이벤트 템플릿 사전

| 컬럼 | 타입 | 의미 |
|---|---|---|
| template_id | string PK | 식별자 (예: `T_EUV_StageCalib`, `T_KRF_Event_WARN`) |
| equipment | string | `EUV3600` / `NXT2050i` / `XT860` / `YS385` / `EBEAM` / `EXE5200` / `XT1900i` |
| event_type | string | `Lot` / `Wafer` / `StageCalibration` / `Alignment` / `Exposure` / `WaferMeasurement` / `WaferScan` / `Event` |
| event_subtype | string | `COARSE`/`FINE`/`Z-axis`/severity 등 (nullable) |
| element_name | string | XML element 이름 (예: `StageCalibration`) |
| event_path | string | root 부터의 XPath 패턴 |
| has_start_time | bool | `<StartTime>` 자식 보유 |
| has_end_time | bool | `<EndTime>` 자식 보유 |
| has_result | bool | `<Result>` 또는 `<Severity>` 자식 보유 |
| has_message | bool | `<Message>` 자유 텍스트 보유 (KrF) |
| has_wafer_id | bool | wafer 컨텍스트와 연관 |
| typical_count_per_lot | int | lot 당 발생 횟수 (예상) |
| description | string | 사람이 읽는 설명 |

### 3-2. `xml_slot_templates` — 측정 슬롯 사전

| 컬럼 | 타입 | 의미 |
|---|---|---|
| slot_id | string PK | (예: `S_EUV_StageCalib_Z_Offset_um`) |
| template_id | string FK | → `xml_event_templates` |
| equipment | string | (denorm) |
| xpath | string | 부모 이벤트로부터의 상대 XPath (예: `Axis[Axis='Z']/Offset_um`) |
| local_name | string | leaf 태그명 (예: `Offset_um`) |
| dtype | string | `float64` / `int64` / `bool` / `string` / `dateTime` |
| unit | string | `um`/`nm`/`mJ_cm2`/`urad`/`deg`/`ppm`/... (nullable) |
| role | string | `measurement` / `identifier` / `status` / `coordinate` / `threshold` / `time` / `message` |
| min_value | double | XSD restriction 또는 관측치 (nullable) |
| max_value | double | (nullable) |
| nominal_value | double | XSD default 또는 평균 (nullable) |
| cardinality | string | `1` / `0..1` / `1..N` / `0..N` — 부모 element 당 발생 횟수 |
| description | string | 사람이 읽는 설명 |

---

## 4. 카탈로그 생성 알고리즘

### 4-1. 입력
- 권장: 5종 장비 각 1~2개의 **샘플 XML** (소수면 충분)
- 보너스: `.xsd` 파일이 손에 있으면 dtype/unit/min/max 를 정확히 가져옴
- 본 프로젝트 입력: `selected-log/*.xml` (현 7개) + (있다면) `02-asml-xml-분석/samples/*.xsd`

### 4-2. 절차
1. **XML walk (lxml)** — 각 sample XML 트리 순회
2. 각 element 에 대해:
   - `<StartTime>` 자식이 있거나, 본인이 `<StartTime>`/`<ScanTime>`/`<MeasureTime>`/`<Time>` 같은 단일 시각을 갖는 element 의 부모 → **이벤트 후보**
3. 이벤트 후보의 leaf descendant 모두 수집 → **슬롯 후보**
4. **dtype 추론** (§ 4-3)
5. **unit 추론** (§ 4-4)
6. **role 분류** (§ 4-5)
7. 동일 `(equipment, element_name, subtype)` 묶음 → 단일 이벤트 템플릿으로 머지
8. 동일 `(template_id, xpath)` 묶음 → 단일 슬롯 템플릿
9. min/max 는 관측치 + (있으면) XSD restriction 으로 보강
10. parquet/csv 로 출력

### 4-3. dtype 추론 규칙

leaf 값 문자열에 대해 패턴 매칭:

| 패턴 | dtype |
|---|---|
| `^(true|false)$` | bool |
| `^-?\d+$` | int64 |
| `^-?\d+\.\d+([eE][+-]?\d+)?$` | float64 |
| `^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}` (ISO 8601) | dateTime |
| 그 외 | string |

XSD `restriction base="..."` 가 있으면 그것 우선.

### 4-4. unit 추론 규칙

leaf 태그명 suffix → unit:

| suffix | unit |
|---|---|
| `_um` | μm |
| `_nm` | nm |
| `_mm` | mm |
| `_mJ_cm2` | mJ/cm² |
| `_urad` | μrad |
| `_deg` | deg |
| `_ppm` | ppm |
| `_kV` | kV |
| `_sec` | s |
| (suffix 없음) | NULL |

### 4-5. role 분류 규칙

| 휴리스틱 | role |
|---|---|
| 태그명에 `Id`/`Recipe`/`Operator` | identifier |
| 태그명에 `Time` | time |
| dtype=bool, 또는 태그명에 `Result`/`Severity`/`WithinTolerance`/`Used` | status |
| 태그명에 `Tolerance`/`Threshold`/`Min`/`Max` | threshold |
| 태그명에 `X_mm`/`Y_mm`/`X_um`/`FieldX`/`FieldY` | coordinate |
| 태그명에 `Message`/`Description` | message |
| 그 외 + dtype=숫자 + unit 있음 | measurement |
| 그 외 | (수동 분류) |

---

## 5. 예시 결과

### 5-1. `xml_event_templates` (발췌, 7 in-range XML 기준 ~15개 템플릿)

| template_id | equipment | event_type | subtype | element_name | start | end | result | message | desc |
|---|---|---|---|---|:-:|:-:|:-:|:-:|---|
| T_EUV_Lot | EUV3600 | Lot | (NULL) | Log | ✓ | ✓ | — | — | EUV lot 전체 |
| T_EUV_Wafer | EUV3600 | Wafer | (NULL) | Wafer | ✓ | ✓ | — | — | EUV wafer 1장 처리 |
| T_EUV_StageCalib | EUV3600 | StageCalibration | (NULL) | StageCalibration | ✓ | ✓ | ✓ | — | 척 원점 교정 (μm) |
| T_EUV_Align_COARSE | EUV3600 | Alignment | COARSE | Alignment | ✓ | ✓ | — | — | 거친 정렬 (nm) |
| T_EUV_Align_FINE | EUV3600 | Alignment | FINE | Alignment | ✓ | ✓ | — | — | 정밀 정렬 (nm) |
| T_NXT_Lot | NXT2050i | Lot | (NULL) | Log | ✓ | ✓ | — | — | ArF imm lot |
| T_NXT_Wafer | NXT2050i | Wafer | (NULL) | Wafer | ✓ (ScanTime) | — | — | — | ArF imm wafer 측정 (단일시점) |
| T_KRF_Lot | XT860 | Lot | (NULL) | Log | ✓ | ✓ | — | — | KrF lot |
| T_KRF_Event_INFO | XT860 | Event | INFO | Event | ✓ (Time) | — | ✓ | ✓ | KrF 이벤트 INFO |
| T_KRF_Event_WARN | XT860 | Event | WARN | Event | ✓ (Time) | — | ✓ | ✓ | KrF 이벤트 WARN |
| T_KRF_Event_ERROR | XT860 | Event | ERROR | Event | ✓ (Time) | — | ✓ | ✓ | KrF 이벤트 ERROR |
| T_YS_Lot | YS385 | Lot | (NULL) | Log | ✓ | ✓ | — | — | YS overlay lot |
| T_YS_WaferMeasure | YS385 | WaferMeasurement | OVL | Wafer | ✓ (MeasureTime) | — | — | — | YS wafer overlay 측정 |
| T_EBEAM_Lot | EBEAM | Lot | (NULL) | Log | ✓ | ✓ | — | — | eP5 lot |
| T_EBEAM_WaferScan | EBEAM | WaferScan | (NULL) | Wafer | ✓ (ScanTime) | — | — | — | eP5 wafer 결함 스캔 |
| T_HNA_StageCalib | EXE5200 | StageCalibration | (NULL) | StageCalibration | ✓ | ✓ | ✓ | — | HNA-EUV 척 교정 |
| T_HNA_Align_FINE | EXE5200 | Alignment | FINE | Alignment | ✓ | ✓ | — | — | HNA-EUV 정밀 정렬 |
| T_ARF_DRY_StageCalib | XT1900i | StageCalibration | (NULL) | StageCalibration | ✓ | ✓ | ✓ | — | ArF dry 척 교정 |

### 5-2. `xml_slot_templates` (발췌)

| slot_id | template_id | xpath | local_name | dtype | unit | role | min | max |
|---|---|---|---|---|---|---|---:|---:|
| S_EUV_StageCalib_ChuckId | T_EUV_StageCalib | ChuckId | ChuckId | string | — | identifier | — | — |
| S_EUV_StageCalib_Axis_Z_Offset_um | T_EUV_StageCalib | Axis[Axis='Z']/Offset_um | Offset_um | float64 | μm | measurement | -500 | 500 |
| S_EUV_StageCalib_Axis_Z_Tolerance_um | T_EUV_StageCalib | Axis[Axis='Z']/Tolerance_um | Tolerance_um | float64 | μm | threshold | 0 | — |
| S_EUV_StageCalib_Axis_Z_WithinTol | T_EUV_StageCalib | Axis[Axis='Z']/WithinTolerance | WithinTolerance | bool | — | status | — | — |
| S_EUV_StageCalib_NotchAngle_deg | T_EUV_StageCalib | NotchAngle_deg | NotchAngle_deg | float64 | deg | measurement | -1 | 1 |
| S_EUV_StageCalib_Result | T_EUV_StageCalib | Result | Result | string | — | status | — | — |
| S_EUV_Align_FINE_Sensor | T_EUV_Align_FINE | Sensor | Sensor | string | — | identifier | — | — |
| S_EUV_Align_FINE_Residual3Sigma_nm | T_EUV_Align_FINE | GridModel/Residual3Sigma_nm | Residual3Sigma_nm | float64 | nm | measurement | 0 | 100 |
| S_EUV_Align_FINE_TranslationX_nm | T_EUV_Align_FINE | GridModel/TranslationX_nm | TranslationX_nm | float64 | nm | measurement | -100 | 100 |
| S_EUV_Align_FINE_RotationX_urad | T_EUV_Align_FINE | GridModel/RotationX_urad | RotationX_urad | float64 | μrad | measurement | -10 | 10 |
| S_EUV_Wafer_Field_Dose_mJ_cm2 | T_EUV_Wafer | Field/Dose | Dose | float64 | mJ/cm² | measurement | 0 | 100 |
| S_EUV_Wafer_Field_Focus_nm | T_EUV_Wafer | Field/Focus | Focus | float64 | nm | measurement | -200 | 200 |
| S_EUV_Wafer_Field_PulseCnt | T_EUV_Wafer | Field/PulseCnt | PulseCnt | int64 | — | measurement | 0 | — |
| S_KRF_Event_Code | T_KRF_Event_* | Code | Code | string | — | identifier | — | — |
| S_KRF_Event_Severity | T_KRF_Event_* | Severity | Severity | string | — | status | — | — |
| S_KRF_Event_Message | T_KRF_Event_* | Message | Message | string | — | message | — | — |
| S_KRF_Event_WaferId | T_KRF_Event_* | WaferId | WaferId | string | — | identifier | — | — |
| S_YS_OvlSite_OvlX_nm | T_YS_WaferMeasure | OverlaySite/OvlX_nm | OvlX_nm | float64 | nm | measurement | -50 | 50 |
| S_YS_OvlSite_OvlY_nm | T_YS_WaferMeasure | OverlaySite/OvlY_nm | OvlY_nm | float64 | nm | measurement | -50 | 50 |
| S_YS_OvlSite_Residual_nm | T_YS_WaferMeasure | OverlaySite/Residual_nm | Residual_nm | float64 | nm | measurement | 0 | — |
| S_EBEAM_Defect_Class | T_EBEAM_WaferScan | Defects/Defect/Class | Class | string | — | identifier | — | — |
| S_EBEAM_Defect_Size_nm | T_EBEAM_WaferScan | Defects/Defect/Size_nm | Size_nm | float64 | nm | measurement | 0 | — |
| S_EBEAM_Defect_X_um | T_EBEAM_WaferScan | Defects/Defect/X_um | X_um | float64 | μm | coordinate | -150 | 150 |
| S_EBEAM_Cd_nm | T_EBEAM_WaferScan | CdMeasurements/Cd/Cd_nm | Cd_nm | float64 | nm | measurement | 0 | — |

### 5-3. 카탈로그 규모 (예상)

| | rows |
|---|---:|
| `xml_event_templates` | ~15~25 (장비 종류·subtype 조합) |
| `xml_slot_templates` | ~80~150 (모든 leaf 측정 종류) |

5종 장비 × 평균 ~3 이벤트 종류 ≈ ~15 templates.
이벤트 1개당 평균 ~6개 슬롯 ≈ ~90 slots.

---

## 6. 카탈로그 활용 (04 추출 단계와의 연결)

```
[03] 카탈로그 생성       [04] 추출 (data-driven)
─────────────────       ────────────────────────
xml_event_templates ─┐
xml_slot_templates  ─┼──►  for each XML, for each registered template:
                     │       extract event row + measurements
                     │       → xml_runs / xml_events / xml_wafer_summary
                     │
샘플 XML / XSD ──────┘
```

- 04 의 추출 코드는 카탈로그를 처음에 1회 로드 → 각 XML 을 카탈로그 템플릿에 매칭 → 이벤트/측정값 행 생성.
- 새 장비 / 새 슬롯이 들어오면 **카탈로그에 row 추가** 만 하면 04 추출 코드는 변경 없이 동작.
- wafer_summary 의 컬럼 집합도 카탈로그에서 자동 도출 가능 (`role=measurement` + 같은 wafer 안 묶음 → mean/std 자동 컬럼).

---

## 7. 모듈 구성 (예정)

```
05-전처리-01/
├── 03-xml-template-build.py         ← 본 설계 구현
│   ├── walk_xml(path) → element 트리
│   ├── infer_event_template(elem)
│   ├── infer_slot_template(leaf, parent_template)
│   ├── infer_dtype(value), infer_unit(name), infer_role(name, dtype)
│   ├── merge_templates(rows)        ← 동일 (eqp, type, subtype) 머지
│   └── write_catalog(events, slots, out_dir)
└── selected-log/                     ← 입력 (또는 selected-log-normalized/)

out/
├── xml_event_templates.parquet (또는 .csv)
└── xml_slot_templates.parquet  (또는 .csv)
```

CSV 출력도 함께 — 사람이 검토/수정 가능 (도메인 전문가가 description, role 손보기 위함).

---

## 8. 처리 순서 (전체 파이프라인 위치)

1. `01-log-generator.py` — 합성 로그 생성
2. `02-time-normalize.py` — 시간 통일 (KST · μs)
3. **`03-xml-template-build.py` — 본 설계** (XML → 카탈로그 2 테이블)
4. `04-xml-extract.py` — 카탈로그 기반 추출 (04 md 의 설계대로)
5. (후속) Event_log.old 처리, cross-tool 분석

03 은 **드물게 (새 장비/스키마 추가 시) 만 실행**. 04 는 새 XML 파일이 들어올 때마다 실행.

---

## 9. 운영 시나리오

### 9-1. 최초 셋업
- 5종 장비 샘플 XML 1~2개씩 수집 → `03-xml-template-build.py` 1회 실행 → 카탈로그 생성
- 도메인 전문가가 CSV 검토 → description 보강, role 보정 → 보강된 CSV 를 final 로 commit

### 9-2. 새 장비 추가
- 새 장비 샘플 XML 추가 → `03-xml-template-build.py` 재실행 (기존 카탈로그에 incremental upsert)
- 변경분만 검토 → commit

### 9-3. 슬롯 누락 발견
- 04 추출 단계에서 unknown leaf 가 발견되면 경고 → 03 재실행으로 카탈로그 갱신

---

## 10. 결정된 사항 / 미결 사항

### 결정
- 카탈로그는 **2 테이블** (`xml_event_templates`, `xml_slot_templates`)
- 출력 형식: parquet + csv (CSV 는 사람 검토용)
- 식별자 규칙: `T_<EQP>_<EventType>[_<Subtype>]`, `S_<EQP>_<EventType>_<LeafTag>`
- dtype/unit/role 추론은 **휴리스틱 + XSD restriction(있을 때)**
- 카탈로그 진실원: 처음엔 자동 추론, 이후 수동 보강 → 보강된 CSV 가 진실원

### 미결 (구현 시 보강)
- **카탈로그 변경 이력** 관리 방식 — git diff 만으로 충분? 별도 audit 테이블?
- **장비별 namespace prefix** 충돌 처리 — 같은 element 명을 다른 장비가 다른 의미로 쓸 때 (현재는 장비별로 namespace 분리됨, 안전)
- **단위 표기 표준화** — `μm` vs `um`, `mJ/cm²` vs `mJ_cm2` — CSV 용은 ASCII, parquet 메타에는 유니코드 양쪽 둘지?
- **자동 추론에서 놓치는 슬롯** 처리 (예: `<choice>` 안의 한쪽만 샘플에 등장) — XSD 가 있을 때 보강 가능
