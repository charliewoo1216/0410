"""04-event-structure.py — 평문 이벤트 로그 스키마 한 장 (사전정보 없이)."""
import sys
from collections import Counter
from pathlib import Path


def parse_records(text: str):
    """빈 줄 기준으로 레코드 분리. 각 레코드는 [line_tokens, ...]."""
    records, block = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if block:
                records.append(block)
                block = []
        else:
            block.append(line.split())
    if block:
        records.append(block)
    return records


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass

    if len(sys.argv) != 2:
        print("usage: python 04-event-structure.py <log_path>", file=sys.stderr)
        sys.exit(2)

    p = Path(sys.argv[1])
    text = p.read_text(encoding="utf-8")
    records = parse_records(text)

    # 레코드 당 줄 수 분포 (예: 대부분 2줄짜리)
    rec_line_counts = Counter(len(r) for r in records)
    max_lines = max(rec_line_counts) if rec_line_counts else 0

    # 각 줄 위치별 필드 수 분포
    per_line_field_counts = []
    for i in range(max_lines):
        c = Counter(len(r[i]) for r in records if len(r) > i)
        per_line_field_counts.append(c)

    print(f"# {p.name}")
    print(f"total lines: {len(text.splitlines())}")
    print(f"records (blank-separated): {len(records)}")
    print(f"lines per record: {dict(rec_line_counts)}")
    print()
    print("record shape (no names — engineer to assign):")
    for i, c in enumerate(per_line_field_counts, start=1):
        print(f"  line {i}: field-count distribution = {dict(c)}")
    print(f"  separator: blank line")
    print()
    print("sample records (first 3):")
    for ri, r in enumerate(records[:3], start=1):
        for li, toks in enumerate(r, start=1):
            cols = "  |  ".join(toks)
            print(f"  R{ri} line{li}: {cols}")
        print()


if __name__ == "__main__":
    main()
