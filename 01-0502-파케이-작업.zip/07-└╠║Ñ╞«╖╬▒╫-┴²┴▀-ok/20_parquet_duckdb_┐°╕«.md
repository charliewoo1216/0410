# `20_parquet_duckdb.py` 가 `13-logs.parquet` 를 만드는 원리

`20_parquet_duckdb.py` 가 `13-logs.parquet` 를 만들기까지의 4단계를 데이터 형태 변환 관점에서 추적한다.

## 흐름도

```
log-file/01-log.log              ← 텍스트 (3만 줄)
        │
        ▼  ① 블록 단위 파싱  (parse_log_file + _parse_block)
[
  {"ts":"2026-...", "equipment":"LITHO_EUV", "event":"LOT_START", ...},
  {"ts":"2026-...", "equipment":"LITHO_EUV", "event":"WAFER_LOAD", ...},
  ...                             ← 파이썬 dict 10,104개
]
        │
        ▼  ② DataFrame 생성  (pd.DataFrame.from_records)
   ts            equipment    event       ...
0  "2026-..."    LITHO_EUV    LOT_START   ...
1  "2026-..."    LITHO_EUV    WAFER_LOAD  ...
...                              ← 10,104 × 8 행렬 (모든 컬럼이 object 문자열)
        │
        ▼  ③ ts 만 datetime 으로 캐스팅  (pd.to_datetime)
   ts                          equipment    event       ...
0  2026-04-30 06:00:00.000000  LITHO_EUV    LOT_START   ...
                                ← ts: object → datetime64[us]
        │
        ▼  ④ Parquet 쓰기  (df.to_parquet)
13-logs.parquet  (95.8 KB, 컬럼 기반 바이너리, snappy 압축)
```

## 단계별 원리

### ① 블록 파싱 (텍스트 → dict)

원본은 한 이벤트가 **2줄 + 빈 줄** 구조:

```
2026-04-30T06:00:00.000000 LITHO_EUV LOT_START eqp_01 lot_01 wafer01.01   ← 헤더
start success                                                              ← 상태
                                                                            ← 빈 줄
```

- `parse_log_file()` 이 빈 줄을 만나면 누적된 두 줄을 `_parse_block()` 에 넘김
- `_parse_block()` 이 헤더 줄에 `HEADER_RE` 정규식을 적용해 6개 명명 그룹(`ts`, `equipment`, `event`, `eqp_id`, `lot_id`, `wafer_id`) 추출
- 상태 줄을 split 해 `action`, `result` 추출
- 두 결과를 합쳐 **8개 키짜리 dict 1개** 를 yield → 한 이벤트 = 한 dict

### ② DataFrame 만들기 (dict 리스트 → 표)

```python
records = [r for p in ... for r in parse_log_file(p)]   # 10,104개 dict
df = pd.DataFrame.from_records(records)
```

- `from_records()` 가 dict 리스트를 받아 키를 컬럼명으로, 값을 행으로 자동 정렬
- 이 시점엔 모든 컬럼이 **`object`(파이썬 문자열)** — 정규식이 잘라낸 문자열 그대로

### ③ 타입 정규화 (ts 만 캐스팅)

```python
df["ts"] = pd.to_datetime(df["ts"])
```

- `"2026-04-30T06:00:00.000000"` ISO 8601 문자열을 자동 인식
- 컬럼 타입: `object` → **`datetime64[us]`** (마이크로초 정밀도)
- 나머지 7컬럼은 `object` 그대로 둠 (어차피 Parquet 가 알아서 string 으로 저장)

### ④ Parquet 쓰기 — 핵심 변환

```python
df.to_parquet(PARQUET_PATH, compression="snappy", index=False)
```

내부적으로 일어나는 일:

#### (a) pyarrow 가 행 기반 DataFrame 을 컬럼 기반 Arrow Table 로 변환

```
[행 기반 DataFrame]              [컬럼 기반 Arrow Table]
ts          equipment   ...      ts        : [2026-..., 2026-..., 2026-..., ...]
2026-...    LITHO_EUV   ...  →   equipment : [LITHO_EUV, LITHO_EUV, LITHO_EUV, ...]
2026-...    LITHO_EUV   ...      event     : [LOT_START, WAFER_LOAD, WAFER_LOAD, ...]
                                  ...
```

같은 컬럼의 값들을 한 곳에 모아 저장 → 압축률·읽기 속도가 결정적으로 좋아짐.

#### (b) 컬럼별 인코딩 적용

- `equipment`, `event`, `action`, `result` 처럼 **반복 문자열** 은 dictionary encoding
  - `["LITHO_EUV", "LITHO_EUV", "LITHO_EUV", ...]` → 사전 `{0:"LITHO_EUV", 1:"INSP_OVL", ...}` + 정수 인덱스 `[0,0,0,...]`
  - 12바이트 문자열 10,000번 → 사전(7개) + int8 코드 10,000개로 축소
- `ts` 는 timestamp[us] 정수형으로 그대로 저장

#### (c) Snappy 압축

- 인코딩된 컬럼 데이터를 블록 단위로 Snappy 압축 (속도 우선 압축)
- 텍스트 30만 자(914 KB) → 95.8 KB (약 9.6배 축소)

#### (d) 메타데이터 헤더 작성

- 스키마(컬럼명/타입), row group 통계(min/max/null), 압축 방식 등을 파일 끝(footer)에 기록
- `index=False` → pandas RangeIndex 는 저장 안 함 (저장해도 정보 가치 없음)

## 결과 — `13-logs.parquet` 의 정체

- **헤더(footer)**: 스키마 + 통계
- **본문**: 8개 컬럼 각각이 dictionary encoding + Snappy 압축된 바이너리 블록 (1 row group)
- **크기**: 텍스트 914 KB → Parquet 95.8 KB (10.5%)
- DuckDB 의 `read_parquet('13-logs.parquet')` 가 이 footer 만 먼저 읽고 컬럼/필터 pushdown 을 결정하게 됨
