"""
T30. 인터랙티브 로그 분석 — Streamlit 앱

[실행]
  pip install streamlit duckdb pyarrow pandas
  streamlit run 30_streamlit_app.py

[좌측 메뉴 4단계]
  1) 로그 파일      : 01-log.log 디폴트, 드래그앤드롭으로 다른 파일 업로드
  2) 기본 구조      : Parquet 으로 저장하고 스키마/통계/샘플 표시
  3) 컬럼 확인/변경 : 8개 컬럼 이름을 자유롭게 리네이밍 (예: event → motion-event)
  4) DuckDB 쿼리    : 5종 예제 + 자유 SQL 입력. 컬럼 리네임 자동 반영.
"""
from pathlib import Path
import re
import pandas as pd
import streamlit as st
import duckdb

APP_DIR = Path(__file__).parent
DEFAULT_LOG = APP_DIR / "log-file" / "01-log.log"
PARQUET_PATH = APP_DIR / "streamlit_logs.parquet"

# 8개 원본 컬럼 (파싱 결과의 키 순서)
ORIGINAL_COLS = ["ts", "equipment", "event", "eqp_id", "lot_id", "wafer_id", "action", "result"]

# 헤더 정규식: ts equipment event eqp_id lot_id wafer_id
HEADER_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<equipment>\S+)\s+(?P<event>\S+)\s+"
    r"(?P<eqp_id>\S+)\s+(?P<lot_id>\S+)\s+(?P<wafer_id>\S+)\s*$"
)


# ─────────────────────────────────────────────────────────────────────────
# 파싱: 텍스트 → DataFrame
# ─────────────────────────────────────────────────────────────────────────
def _parse_block(block: list[str]):
    """[헤더, 상태] 두 줄을 dict 한 건으로. 형식이 어긋나면 None."""
    if len(block) < 2:
        return None
    m = HEADER_RE.match(block[0])
    if not m:
        return None
    status = block[1].split()
    if len(status) < 2:
        return None
    return {**m.groupdict(), "action": status[0], "result": status[1]}


def parse_text(text: str) -> pd.DataFrame:
    """전체 텍스트(빈 줄로 구분된 블록 모음)를 DataFrame 으로."""
    block, records = [], []
    for line in text.splitlines():
        line = line.rstrip()
        if line:
            block.append(line)
        elif block:
            r = _parse_block(block)
            if r:
                records.append(r)
            block = []
    if block:
        r = _parse_block(block)
        if r:
            records.append(r)

    df = pd.DataFrame.from_records(records, columns=ORIGINAL_COLS)
    df["ts"] = pd.to_datetime(df["ts"], errors="coerce")
    return df


# ─────────────────────────────────────────────────────────────────────────
# 세션 상태 헬퍼
# ─────────────────────────────────────────────────────────────────────────
def init_state():
    """앱 첫 실행 때 디폴트 로그 파싱."""
    if "df_original" not in st.session_state:
        if not DEFAULT_LOG.exists():
            st.session_state.df_original = pd.DataFrame(columns=ORIGINAL_COLS)
            st.session_state.source_name = "(디폴트 파일 없음)"
        else:
            text = DEFAULT_LOG.read_text(encoding="utf-8")
            st.session_state.df_original = parse_text(text)
            st.session_state.source_name = "01-log.log (디폴트)"
        st.session_state.column_map = {c: c for c in ORIGINAL_COLS}
        st.session_state.sql_text = ""


def renamed_df() -> pd.DataFrame:
    """원본 DataFrame 에 현재 컬럼 매핑을 적용한 사본."""
    return st.session_state.df_original.rename(columns=st.session_state.column_map)


def save_parquet() -> Path:
    """현재 (리네이밍 적용된) DataFrame 을 Parquet 으로 저장."""
    df = renamed_df()
    df.to_parquet(PARQUET_PATH, compression="snappy", index=False)
    return PARQUET_PATH


def safe_col(orig: str) -> str:
    """원본 키(orig)에 대응하는 현재 컬럼명 — SQL 안전(특수문자 시 큰따옴표)."""
    name = st.session_state.column_map.get(orig, orig)
    if re.search(r"[^A-Za-z0-9_]", name):
        return f'"{name}"'
    return name


# ─────────────────────────────────────────────────────────────────────────
# Streamlit 앱 본체
# ─────────────────────────────────────────────────────────────────────────
st.set_page_config(page_title="이벤트 로그 분석", layout="wide")
init_state()

# === 사이드바 ===
st.sidebar.title("📊 메뉴")
section = st.sidebar.radio(
    "단계",
    [
        "1. 로그 파일",
        "2. 기본 구조 (Parquet)",
        "3. 컬럼 확인/변경",
        "4. DuckDB 쿼리",
    ],
)
st.sidebar.markdown("---")
st.sidebar.markdown(f"**현재 입력**\n\n`{st.session_state.source_name}`")
st.sidebar.markdown(f"**이벤트 수**: {len(st.session_state.df_original):,}")
n_renamed = sum(1 for k, v in st.session_state.column_map.items() if k != v)
st.sidebar.markdown(f"**리네이밍**: {n_renamed}개 컬럼")


# ─────────────────────────────────────────────────────────────────────────
# 1) 로그 파일
# ─────────────────────────────────────────────────────────────────────────
if section.startswith("1"):
    st.header("1. 로그 파일 입력")
    st.markdown(
        f"디폴트는 `log-file/01-log.log`. 다른 파일을 업로드하면 즉시 파싱되어 "
        f"이후 모든 단계에 반영됩니다."
    )

    uploaded = st.file_uploader(
        "로그 파일 드래그앤드롭 또는 클릭",
        type=["log", "txt"],
        help="형식: 헤더 줄 + 상태 줄 + 빈 줄 의 반복",
    )
    if uploaded is not None:
        try:
            text = uploaded.read().decode("utf-8")
            df = parse_text(text)
            if len(df) == 0:
                st.error("파싱 결과가 비어있습니다. 형식을 확인해 주세요.")
            else:
                st.session_state.df_original = df
                st.session_state.source_name = uploaded.name
                st.session_state.column_map = {c: c for c in ORIGINAL_COLS}
                st.success(f"✅ {uploaded.name} 파싱 완료: {len(df):,}건")
        except Exception as e:
            st.error(f"파싱 실패: {e}")

    if st.button("🔄 디폴트(01-log.log)로 되돌리기"):
        if DEFAULT_LOG.exists():
            text = DEFAULT_LOG.read_text(encoding="utf-8")
            st.session_state.df_original = parse_text(text)
            st.session_state.source_name = "01-log.log (디폴트)"
            st.session_state.column_map = {c: c for c in ORIGINAL_COLS}
            st.success(f"디폴트 로드: {len(st.session_state.df_original):,}건")
        else:
            st.warning(f"디폴트 파일을 찾을 수 없음: {DEFAULT_LOG}")

    st.subheader("미리보기 (처음 5건)")
    st.dataframe(renamed_df().head(5), width="stretch")


# ─────────────────────────────────────────────────────────────────────────
# 2) 기본 구조 (Parquet)
# ─────────────────────────────────────────────────────────────────────────
elif section.startswith("2"):
    st.header("2. 로그 기본 구조 (Parquet 기준)")

    pq_path = save_parquet()
    df = renamed_df()
    size_kb = pq_path.stat().st_size / 1024

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("이벤트 수", f"{len(df):,}")
    c2.metric("컬럼 수", len(df.columns))
    c3.metric("Parquet 크기", f"{size_kb:.1f} KB")
    if "ts" in [st.session_state.column_map.get(c, c) for c in ORIGINAL_COLS]:
        ts_col = st.session_state.column_map.get("ts", "ts")
        if pd.api.types.is_datetime64_any_dtype(df[ts_col]):
            span = df[ts_col].max() - df[ts_col].min()
            c4.metric("시간 범위", f"{span}")

    st.subheader("스키마")
    schema_df = pd.DataFrame(
        {
            "컬럼명": df.columns,
            "dtype": df.dtypes.astype(str).values,
            "Null 수": df.isna().sum().values,
            "유니크 값": [df[c].nunique() for c in df.columns],
            "샘플": [
                str(df[c].dropna().iloc[0]) if len(df[c].dropna()) > 0 else ""
                for c in df.columns
            ],
        }
    )
    st.dataframe(schema_df, width="stretch")

    st.subheader("샘플 데이터 (처음 20행)")
    st.dataframe(df.head(20), width="stretch")

    st.caption(f"저장 경로: `{pq_path}`")


# ─────────────────────────────────────────────────────────────────────────
# 3) 컬럼 확인/변경
# ─────────────────────────────────────────────────────────────────────────
elif section.startswith("3"):
    st.header("3. 컬럼 명칭 확인 및 변경")
    st.markdown(
        "원본 컬럼 8개의 이름을 자유롭게 변경할 수 있습니다.\n"
        "- 영숫자/언더스코어 권장 — SQL 에서 따옴표 없이 쓰기 위함\n"
        "- 하이픈/공백도 가능하지만 쿼리 시 자동으로 큰따옴표가 붙습니다 "
        '(예: `motion-event` → `"motion-event"`)'
    )

    st.subheader("원본 → 새 이름")
    new_map: dict[str, str] = {}
    cols_layout = st.columns(2)
    for i, orig in enumerate(ORIGINAL_COLS):
        with cols_layout[i % 2]:
            current = st.session_state.column_map.get(orig, orig)
            new_name = st.text_input(
                f"`{orig}` →",
                value=current,
                key=f"col_input_{orig}",
            )
            new_map[orig] = (new_name or "").strip() or orig

    bt1, bt2 = st.columns(2)
    if bt1.button("✅ 변경 적용", width="stretch"):
        # 중복 검사
        if len(set(new_map.values())) != len(new_map):
            st.error("새 컬럼명에 중복이 있습니다.")
        else:
            st.session_state.column_map = new_map
            save_parquet()
            st.success("컬럼명 변경 적용 + Parquet 재저장 완료")
            st.rerun()

    if bt2.button("↩️ 원본으로 되돌리기", width="stretch"):
        st.session_state.column_map = {c: c for c in ORIGINAL_COLS}
        save_parquet()
        st.success("원본 컬럼명으로 복원")
        st.rerun()

    st.subheader("적용 결과 미리보기 (처음 5행)")
    st.dataframe(renamed_df().head(5), width="stretch")


# ─────────────────────────────────────────────────────────────────────────
# 4) DuckDB 쿼리
# ─────────────────────────────────────────────────────────────────────────
elif section.startswith("4"):
    st.header("4. DuckDB 쿼리")

    pq_path = save_parquet()
    p = pq_path.as_posix()

    # 현재 리네이밍 반영된 컬럼 참조
    c_ts, c_eq, c_ev = safe_col("ts"), safe_col("equipment"), safe_col("event")
    c_eqp, c_lot, c_waf = safe_col("eqp_id"), safe_col("lot_id"), safe_col("wafer_id")
    c_act, c_res = safe_col("action"), safe_col("result")

    PAIRING_SQL = f"""WITH ordered AS (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY {c_eq}, {c_eqp}, {c_lot}, {c_waf}, {c_ev}, {c_act}
            ORDER BY {c_ts}
        ) AS rn
    FROM read_parquet('{p}')
),
starts AS (SELECT * FROM ordered WHERE {c_act} = 'start'),
ends   AS (SELECT * FROM ordered WHERE {c_act} = 'end')
SELECT
    COALESCE(s.{c_ev}, e.{c_ev})   AS event,
    s.{c_ts}                        AS start_time,
    e.{c_ts}                        AS end_time,
    ROUND(epoch(e.{c_ts}) - epoch(s.{c_ts}), 3) AS duration_tm,
    COALESCE(s.{c_eqp}, e.{c_eqp}) AS eqp_id,
    COALESCE(s.{c_lot}, e.{c_lot}) AS lot_id,
    COALESCE(s.{c_waf}, e.{c_waf}) AS wafer_id
FROM starts s
FULL OUTER JOIN ends e
  ON s.{c_eq}  = e.{c_eq}
 AND s.{c_eqp} = e.{c_eqp}
 AND s.{c_lot} = e.{c_lot}
 AND s.{c_waf} = e.{c_waf}
 AND s.{c_ev}  = e.{c_ev}
 AND s.rn      = e.rn
ORDER BY COALESCE(s.{c_ts}, e.{c_ts})"""

    presets = {
        "① 기본 — start/end 페어링 (전체)": PAIRING_SQL,
        "② duration_tm 있는 행만 (NULL 제외)":
            f"SELECT * FROM (\n{PAIRING_SQL}\n) WHERE duration_tm IS NOT NULL",
        "③ 장비별 이벤트 카운트":
            f"SELECT {c_eq} AS equipment, COUNT(*) AS n\n"
            f"FROM read_parquet('{p}')\n"
            f"GROUP BY {c_eq} ORDER BY n DESC",
        "④ 실패/경고 이벤트만":
            f"SELECT {c_ts} AS ts, {c_eq} AS equipment, {c_ev} AS event,\n"
            f"       {c_waf} AS wafer_id, {c_res} AS result\n"
            f"FROM read_parquet('{p}')\n"
            f"WHERE {c_res} IN ('fail', 'warn')\n"
            f"ORDER BY {c_ts}",
        "⑤ event 별 평균/최대 소요시간":
            f"WITH paired AS (\n{PAIRING_SQL}\n)\n"
            f"SELECT event, COUNT(*) AS n,\n"
            f"       ROUND(AVG(duration_tm), 3) AS avg_sec,\n"
            f"       ROUND(MAX(duration_tm), 3) AS max_sec\n"
            f"FROM paired WHERE duration_tm IS NOT NULL\n"
            f"GROUP BY event ORDER BY avg_sec DESC",
    }

    st.subheader("쿼리 예제")
    cols_p = st.columns([3, 1])
    preset_choice = cols_p[0].selectbox("예제 선택", list(presets.keys()))
    if cols_p[1].button("📋 예제 불러오기", width="stretch"):
        st.session_state.sql_text = presets[preset_choice]
        st.rerun()

    # 처음 진입 시 디폴트로 ① 채워두기
    if not st.session_state.sql_text:
        st.session_state.sql_text = presets["① 기본 — start/end 페어링 (전체)"]

    sql = st.text_area(
        "SQL (자유롭게 수정/입력)",
        key="sql_text",
        height=320,
    )

    if st.button("▶️ 실행", type="primary"):
        try:
            with st.spinner("쿼리 실행 중..."):
                result = duckdb.sql(sql).df()
            st.success(f"✅ 결과: {len(result):,}행 × {len(result.columns)}열")
            st.dataframe(result, width="stretch")

            csv_bytes = result.to_csv(index=False).encode("utf-8")
            st.download_button(
                "💾 결과 CSV 다운로드",
                data=csv_bytes,
                file_name="query_result.csv",
                mime="text/csv",
            )
        except Exception as e:
            st.error(f"❌ 쿼리 오류:\n```\n{e}\n```")

    with st.expander("💡 현재 컬럼 매핑 (쿼리 작성 참고)"):
        mp = pd.DataFrame(
            {
                "원본": list(st.session_state.column_map.keys()),
                "현재 이름": list(st.session_state.column_map.values()),
                "SQL 표기": [safe_col(c) for c in st.session_state.column_map.keys()],
            }
        )
        st.dataframe(mp, width="stretch")
        st.caption(f"Parquet 경로: `{pq_path}`")
