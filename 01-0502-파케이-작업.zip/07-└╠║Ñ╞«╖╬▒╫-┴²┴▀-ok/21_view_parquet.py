"""
T21. 13-logs.parquet 뷰어
- 20_parquet_duckdb.py 가 만든 Parquet 파일을 열어 내용/스키마/통계를 확인.
- 파일이 정상적으로 저장됐는지, 어떤 컬럼·타입·행 수가 들어있는지 빠르게 보기.
"""
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import duckdb

PARQUET_PATH = Path(__file__).parent / "13-logs.parquet"

if not PARQUET_PATH.exists():
    raise SystemExit(f"[!] 파일 없음: {PARQUET_PATH}\n  먼저 20_parquet_duckdb.py 를 실행해 주세요.")

# ─────────────────────────────────────────────────────────────────────────
# 1) 파일 메타데이터 — pyarrow 로 헤더만 읽어 (전체 로드 없이) 정보 확인
# ─────────────────────────────────────────────────────────────────────────
pq_file = pq.ParquetFile(PARQUET_PATH)
size_kb = PARQUET_PATH.stat().st_size / 1024

print(f"[파일] {PARQUET_PATH.name}")
print(f"  경로       : {PARQUET_PATH}")
print(f"  크기       : {size_kb:.1f} KB")
print(f"  행 수      : {pq_file.metadata.num_rows:,}")
print(f"  row group  : {pq_file.metadata.num_row_groups}")
print(f"  압축       : {pq_file.metadata.row_group(0).column(0).compression}")

print(f"\n[스키마]")
for field in pq_file.schema_arrow:
    print(f"  {field.name:<12} {field.type}")

# ─────────────────────────────────────────────────────────────────────────
# 2) pandas 로 전체 로드 + 샘플/통계
# ─────────────────────────────────────────────────────────────────────────
df = pd.read_parquet(PARQUET_PATH)

print(f"\n[처음 10행]")
print(df.head(10).to_string(index=False))

print(f"\n[마지막 5행]")
print(df.tail(5).to_string(index=False))

print(f"\n[컬럼별 dtype]")
print(df.dtypes.to_string())

print(f"\n[기본 통계]")
print(f"  ts 범위    : {df['ts'].min()}  ~  {df['ts'].max()}")
print(f"  equipment  : {df['equipment'].nunique()}종 → {sorted(df['equipment'].unique())}")
print(f"  event 종류 : {df['event'].nunique()}종 → {sorted(df['event'].unique())}")
print(f"  action 분포:\n{df['action'].value_counts().to_string()}")
print(f"  result 분포:\n{df['result'].value_counts().to_string()}")

# ─────────────────────────────────────────────────────────────────────────
# 3) DuckDB 로 빠른 SQL 확인 — pandas 로드 없이 디스크에서 직접 쿼리
# ─────────────────────────────────────────────────────────────────────────
print(f"\n[DuckDB] 장비 × action 교차 카운트")
duckdb.sql(f"""
    SELECT equipment, action, COUNT(*) AS n
    FROM read_parquet('{PARQUET_PATH.as_posix()}')
    GROUP BY equipment, action
    ORDER BY equipment, action
""").show(max_rows=50)
