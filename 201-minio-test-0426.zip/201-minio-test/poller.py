"""주기적 폴링 클라이언트 — settings.json 기반 Cursor + Drain + 단일 트랜잭션 적재."""
import time
from datetime import datetime

import requests

import config
import db
import logger

log = logger.get("poller")

API = "http://localhost:5000/logs"

_cfg = config.load()
LIMIT = _cfg["poll_limit"]
IDLE_INTERVAL_MS = _cfg["poll_idle_interval_ms"]
IDLE_INTERVAL = IDLE_INTERVAL_MS / 1000.0
DRAIN_ENABLED = _cfg["poll_drain_enabled"]


def insert_batch(conn, rows, next_cursor):
    """데이터 적재 + cursor 갱신을 단일 트랜잭션으로 commit. 신규/중복 카운트 반환."""
    now = datetime.now().isoformat(timespec="seconds")
    payload = [(r["id"], r["msg"], r["raw"], now) for r in rows]
    before = conn.execute("SELECT COUNT(*) FROM logs").fetchone()[0]
    with conn:
        conn.executemany(
            "INSERT OR IGNORE INTO logs(id, msg, raw, fetched_at) VALUES (?, ?, ?, ?)",
            payload,
        )
        conn.execute(
            "INSERT INTO meta(key,value) VALUES('cursor', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (next_cursor,),
        )
    after = conn.execute("SELECT COUNT(*) FROM logs").fetchone()[0]
    inserted = after - before
    duplicated = len(rows) - inserted
    return inserted, duplicated


def main():
    conn = db.connect()
    db.init_schema(conn)
    cursor = db.get_cursor(conn)
    log.info(
        f"=== poller start  cursor={cursor!r}  limit={LIMIT}  "
        f"idle={IDLE_INTERVAL_MS}ms  drain={DRAIN_ENABLED} ==="
    )
    print(f"poller | start  cursor={cursor!r}")
    print(
        f"       | limit={LIMIT}  idle={IDLE_INTERVAL_MS}ms"
        f"  drain={'on' if DRAIN_ENABLED else 'off'}\n"
    )

    cycle = 0
    last_seen_id = 0
    while True:
        cycle += 1
        params = {"limit": LIMIT}
        if cursor:
            params["cursor"] = cursor

        try:
            t0 = time.perf_counter()
            res = requests.get(API, params=params, timeout=10).json()
            api_ms = (time.perf_counter() - t0) * 1000
        except requests.RequestException as e:
            log.error(f"#{cycle}  request error: {e}")
            print(f"  [#{cycle}] ERR {e}")
            time.sleep(IDLE_INTERVAL)
            continue

        data = res["data"]
        has_more = res["has_more"]

        if data:
            next_cursor = res["next_cursor"]
            ids = [r["id"] for r in data]
            inserted, duplicated = insert_batch(conn, data, next_cursor)
            cursor = next_cursor
            stat = db.stats(conn)
            mode = "DRAIN" if has_more else "OK   "

            # 🔴 누락 감지: 직전 last_seen_id 와 이번 첫 id 사이에 갭이 있는지
            warnings = []
            expected_first = last_seen_id + 1
            if last_seen_id > 0 and ids[0] != expected_first:
                warnings.append(
                    f"GAP_AT_RESPONSE(expected_first={expected_first},got={ids[0]})"
                )
            # 응답 내부의 id 연속성 검사
            for i in range(1, len(ids)):
                if ids[i] != ids[i - 1] + 1:
                    warnings.append(
                        f"GAP_IN_BATCH({ids[i-1]}->{ids[i]})"
                    )
                    break
            if duplicated > 0:
                warnings.append(f"DUP({duplicated})")
            if stat["gap"] != 0:
                warnings.append(f"SQLITE_GAP({stat['gap']})")

            msg = (
                f"#{cycle}  {mode}  ids={ids[0]}..{ids[-1]}  n={len(data)}  "
                f"ins={inserted}  dup={duplicated}  total={stat['total']}  "
                f"sqlite_gap={stat['gap']}  api={api_ms:.0f}ms"
            )
            if warnings:
                log.warning(msg + "  WARN=" + ",".join(warnings))
            else:
                log.info(msg)

            print(
                f"  [#{cycle}] {mode} ids={ids[0]}..{ids[-1]}  "
                f"n={len(data)}  ins={inserted}  total={stat['total']}  "
                f"gap={stat['gap']}  ({api_ms:.0f}ms)"
            )

            last_seen_id = ids[-1]

            if has_more and DRAIN_ENABLED:
                continue  # drain — sleep 생략
        else:
            log.debug(f"#{cycle}  NO_DATA  api={api_ms:.0f}ms  cursor unchanged")
            print(f"  [#{cycle}] NO NEW DATA  ({api_ms:.0f}ms)")

        time.sleep(IDLE_INTERVAL)


if __name__ == "__main__":
    main()
