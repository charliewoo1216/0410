import boto3
from botocore.exceptions import ClientError

ENDPOINT = "http://192.168.0.8:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "admin123"
BUCKET = "test01-log"

s3 = boto3.client(
    "s3",
    endpoint_url=ENDPOINT,
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1",
)

print("=== Existing buckets ===")
for b in s3.list_buckets().get("Buckets", []):
    print(f"  - {b['Name']}  (created: {b['CreationDate']})")

print(f"\n=== Creating bucket: {BUCKET} ===")
try:
    s3.create_bucket(Bucket=BUCKET)
    print(f"OK: '{BUCKET}' created")
except ClientError as e:
    code = e.response["Error"]["Code"]
    if code in ("BucketAlreadyOwnedByYou", "BucketAlreadyExists"):
        print(f"SKIP: '{BUCKET}' already exists ({code})")
    else:
        raise

print("\n=== Buckets after create ===")
for b in s3.list_buckets().get("Buckets", []):
    print(f"  - {b['Name']}")
