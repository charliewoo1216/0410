"""런타임 설정 영속화 — settings.json (ms 단위)."""
import json
from pathlib import Path

PATH = Path(__file__).parent / "settings.json"

DEFAULTS = {
    "gen_interval_ms": 5000,
    "gen_lines_per_cycle": 5,
    "poll_idle_interval_ms": 2000,
    "poll_limit": 100,
    "poll_drain_enabled": True,
}

# 빠른 설정 프리셋 — 로그 생성 주기에 최적화된 폴링 파라미터
# 원칙:
#   - idle ≈ 생성주기 / 2  (생성보다 2배 빠르게 폴링)
#   - limit ≥ 사이클당라인 × 10  (drain 1회로 캐치업)
#   - drain 항상 ON  (누락 방지)
PRESETS = {
    "case1": {
        "name": "Case 1",
        "desc": "5s 주기 · 느림 (1 line/s)",
        "gen_interval_ms": 5000,
        "gen_lines_per_cycle": 5,
        "poll_idle_interval_ms": 2000,
        "poll_limit": 50,
        "poll_drain_enabled": True,
    },
    "case2": {
        "name": "Case 2",
        "desc": "1s 주기 · 보통 (5 line/s)",
        "gen_interval_ms": 1000,
        "gen_lines_per_cycle": 5,
        "poll_idle_interval_ms": 500,
        "poll_limit": 50,
        "poll_drain_enabled": True,
    },
    "case3": {
        "name": "Case 3",
        "desc": "0.5s 주기 · 빠름 (10 line/s)",
        "gen_interval_ms": 500,
        "gen_lines_per_cycle": 5,
        "poll_idle_interval_ms": 250,
        "poll_limit": 100,
        "poll_drain_enabled": True,
    },
    "case4": {
        "name": "Case 4",
        "desc": "0.1s 주기 · 매우 빠름 (50 line/s)",
        "gen_interval_ms": 100,
        "gen_lines_per_cycle": 5,
        "poll_idle_interval_ms": 100,
        "poll_limit": 200,
        "poll_drain_enabled": True,
    },
}

_RUNTIME_KEYS = set(DEFAULTS.keys())


def apply_preset(key: str) -> dict:
    """프리셋의 런타임 파라미터만 settings.json 에 저장."""
    preset = PRESETS[key]
    payload = {k: v for k, v in preset.items() if k in _RUNTIME_KEYS}
    save(payload)
    return payload


def current_preset_key(cfg: dict) -> str | None:
    """현재 settings 가 어느 프리셋과 일치하는지 (없으면 None)."""
    for key, preset in PRESETS.items():
        if all(cfg.get(k) == preset[k] for k in _RUNTIME_KEYS):
            return key
    return None


def load() -> dict:
    if not PATH.exists():
        save(DEFAULTS)
        return dict(DEFAULTS)
    with PATH.open(encoding="utf-8") as f:
        data = json.load(f)
    return {**DEFAULTS, **data}


def save(data: dict) -> None:
    merged = {**DEFAULTS, **data}
    with PATH.open("w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    cfg = load()
    print(f"settings.json @ {PATH}")
    for k, v in cfg.items():
        print(f"  {k:<25} = {v}")
