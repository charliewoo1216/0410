"""
초기 시드 데이터 생성 + MinIO 업로드.

구성: 10개 파일 × 60건(1초 단위) = 600건, 연속 시간.
- logs_01.log : id=1..60   2026-04-25 10:00:00 ~ 10:00:59
- logs_02.log : id=61..120 2026-04-25 10:01:00 ~ 10:01:59
- ...
- logs_10.log : id=541..600 2026-04-25 10:09:00 ~ 10:09:59
"""
import random
from datetime import datetime, timedelta
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

ENDPOINT = "http://192.168.0.8:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "admin123"
BUCKET = "test01-log"

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

START = datetime(2026, 4, 25, 10, 0, 0)
LINES_PER_FILE = 60
NUM_FILES = 10
MSG_POOL = [
    "login", "view_item", "search", "add_to_cart", "remove_from_cart",
    "view_cart", "checkout", "payment", "logout", "click",
]

random.seed(42)

s3 = boto3.client(
    "s3",
    endpoint_url=ENDPOINT,
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1",
)


def clear_bucket():
    res = s3.list_objects_v2(Bucket=BUCKET)
    contents = res.get("Contents", [])
    if not contents:
        print("bucket already empty")
        return
    keys = [{"Key": o["Key"]} for o in contents]
    s3.delete_objects(Bucket=BUCKET, Delete={"Objects": keys})
    print(f"deleted {len(keys)} existing objects")


def gen_file(file_idx: int):
    file_no = file_idx + 1
    start_id = file_idx * LINES_PER_FILE + 1
    file_start = START + timedelta(seconds=file_idx * LINES_PER_FILE)
    path = DATA_DIR / f"logs_{file_no:02d}.log"
    with path.open("w", encoding="utf-8") as f:
        for i in range(LINES_PER_FILE):
            ts = file_start + timedelta(seconds=i)
            rec_id = start_id + i
            msg = random.choice(MSG_POOL)
            f.write(f"{ts:%Y-%m-%d %H:%M:%S} id={rec_id} msg={msg}\n")
    return path


def main():
    print(f"=== Clearing bucket '{BUCKET}' ===")
    clear_bucket()

    print(f"\n=== Generating {NUM_FILES} files ({LINES_PER_FILE} lines each) ===")
    paths = [gen_file(i) for i in range(NUM_FILES)]
    for p in paths:
        print(f"  generated: {p.name}  ({p.stat().st_size} bytes)")

    print(f"\n=== Uploading to '{BUCKET}' ===")
    for p in paths:
        s3.upload_file(str(p), BUCKET, p.name)
        print(f"  uploaded: {p.name}")

    print(f"\n=== Final objects ===")
    res = s3.list_objects_v2(Bucket=BUCKET)
    for obj in res.get("Contents", []):
        print(f"  - {obj['Key']:<15} {obj['Size']:>5} bytes")

    print(f"\nTotal: {NUM_FILES * LINES_PER_FILE} records (id 1..{NUM_FILES * LINES_PER_FILE})")


if __name__ == "__main__":
    main()
