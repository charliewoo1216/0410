"""프로세스 제어 헬퍼 — Windows python.exe 인스턴스를 command-line 매칭으로 관리."""
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent

SCRIPTS = {
    "api": "api_server.py",
    "gen": "generator.py",
    "poll": "poller.py",
}

_PS_LIST = (
    "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" "
    "| ForEach-Object { \"$($_.ProcessId)|$($_.CommandLine)\" }"
)


def _ps(cmd: str) -> str:
    out = subprocess.run(
        ["powershell", "-NoProfile", "-Command", cmd],
        capture_output=True, text=True, encoding="utf-8",
    )
    return out.stdout or ""


def list_running() -> dict:
    """단일 PowerShell 호출로 api/gen/poll 실행 여부 batch 조회."""
    raw = _ps(_PS_LIST)
    state = {k: {"running": False, "pids": []} for k in SCRIPTS}
    for line in raw.splitlines():
        line = line.strip().lower()
        if not line or "|" not in line:
            continue
        pid_str, cmdline = line.split("|", 1)
        if not pid_str.strip().isdigit():
            continue
        pid = int(pid_str)
        for key, script in SCRIPTS.items():
            if script.lower() in cmdline:
                state[key]["running"] = True
                state[key]["pids"].append(pid)
    return state


def is_running(key: str) -> bool:
    return list_running().get(key, {}).get("running", False)


def start(key: str) -> None:
    """별도 콘솔 창으로 스크립트 실행."""
    script = SCRIPTS[key]
    if key == "poll":
        # streamlit 환경에서는 sys.executable 이 streamlit 일 수 있음
        py = sys.executable
        if "streamlit" in py.lower():
            py = "python"
    else:
        py = "python"
    subprocess.Popen(
        [py, "-u", script],
        cwd=str(ROOT),
        creationflags=subprocess.CREATE_NEW_CONSOLE,
    )


def kill(key: str) -> int:
    """key 와 매칭되는 프로세스 모두 종료. 종료한 PID 수 반환."""
    state = list_running().get(key, {})
    pids = state.get("pids", [])
    for pid in pids:
        subprocess.run(
            ["taskkill", "/F", "/PID", str(pid)],
            capture_output=True,
        )
    return len(pids)


def kill_all() -> int:
    """api/gen/poll 모두 종료."""
    n = 0
    for key in SCRIPTS:
        n += kill(key)
    return n


def reset_data() -> None:
    """reset_data.py 실행 (블로킹)."""
    subprocess.run(
        ["python", "reset_data.py"],
        cwd=str(ROOT),
        capture_output=True,
    )


def seed() -> None:
    """seed_logs.py 실행 (블로킹)."""
    subprocess.run(
        ["python", "seed_logs.py"],
        cwd=str(ROOT),
        capture_output=True,
    )


if __name__ == "__main__":
    state = list_running()
    for key, val in state.items():
        flag = "[ON ]" if val["running"] else "[off]"
        print(f"  {key:<5} {flag}  pids={val['pids']}")
