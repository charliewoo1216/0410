@echo off
chcp 65001 >nul
cd /d %~dp0

echo ================================================
echo  RESET — wipe all previous data
echo  - Stop running processes
echo  - Clear MinIO bucket (test01-log)
echo  - Delete SQLite (data.db)
echo ================================================
echo.

echo [1/2] Stopping running processes...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -match 'generator|poller|api_server|dashboard|streamlit' } | ForEach-Object { Write-Host ('  killing PID ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force }"

echo.
echo [2/2] Clearing data...
python reset_data.py

echo.
echo ================================================
echo  Reset complete.
echo  Next step:
echo    python seed_logs.py    (re-seed 600 records)
echo    run_all.bat            (start pipeline)
echo ================================================
