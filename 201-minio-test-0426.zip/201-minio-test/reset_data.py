"""모든 데이터 초기화: MinIO 버킷 비우기 + SQLite 파일 삭제."""
from pathlib import Path

import boto3

ENDPOINT = "http://192.168.0.8:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "admin123"
BUCKET = "test01-log"

DB_PATH = Path(__file__).parent / "data.db"
DB_AUX = [DB_PATH.with_suffix(".db-wal"), DB_PATH.with_suffix(".db-shm")]


def clear_minio():
    s3 = boto3.client(
        "s3",
        endpoint_url=ENDPOINT,
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name="us-east-1",
    )
    contents = s3.list_objects_v2(Bucket=BUCKET).get("Contents", [])
    if not contents:
        print(f"  MinIO[{BUCKET}] : already empty")
        return
    keys = [{"Key": o["Key"]} for o in contents]
    s3.delete_objects(Bucket=BUCKET, Delete={"Objects": keys})
    print(f"  MinIO[{BUCKET}] : deleted {len(keys)} objects")


def clear_sqlite():
    targets = [DB_PATH, *DB_AUX]
    deleted = 0
    for p in targets:
        if p.exists():
            p.unlink()
            print(f"  SQLite       : deleted {p.name}")
            deleted += 1
    if not deleted:
        print(f"  SQLite       : already absent")


if __name__ == "__main__":
    print("=== Resetting all data ===")
    clear_minio()
    clear_sqlite()
    print("=== Done ===")
