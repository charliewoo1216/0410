import base64
import json
import re
import time

import boto3
from flask import Flask, jsonify, request

import logger

ENDPOINT = "http://192.168.0.8:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "admin123"
BUCKET = "test01-log"

s3 = boto3.client(
    "s3",
    endpoint_url=ENDPOINT,
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1",
)

app = Flask(__name__)
LINE_RE = re.compile(r"id=(\d+)\s+msg=(\w+)")
log = logger.get("api")


def list_objects():
    """KeyCount, IsTruncated 까지 함께 반환해서 1000개 한계 감지."""
    res = s3.list_objects_v2(Bucket=BUCKET)
    keys = [obj["Key"] for obj in res.get("Contents", [])]
    truncated = res.get("IsTruncated", False)
    return keys, truncated


def read_log_object(key):
    obj = s3.get_object(Bucket=BUCKET, Key=key)
    return obj["Body"].read().decode().splitlines()


def parse_line(line):
    m = LINE_RE.search(line)
    if not m:
        return None
    return {"id": int(m.group(1)), "msg": m.group(2), "raw": line}


def load_all_logs():
    logs_acc = []
    bad_lines = 0
    keys, truncated = list_objects()
    for key in keys:
        for line in read_log_object(key):
            if not line.strip():
                continue
            parsed = parse_line(line)
            if parsed:
                logs_acc.append(parsed)
            else:
                bad_lines += 1
    sorted_logs = sorted(logs_acc, key=lambda x: x["id"])
    return sorted_logs, len(keys), truncated, bad_lines


@app.route("/logs")
def logs_endpoint():
    t0 = time.perf_counter()
    cursor = request.args.get("cursor")
    limit = int(request.args.get("limit", 5))
    last_id = decode_cursor(cursor)

    all_logs, key_count, truncated, bad_lines = load_all_logs()
    filtered = [l for l in all_logs if l["id"] > last_id]
    result = filtered[:limit]
    next_cursor = encode_cursor(result[-1]["id"]) if result else None
    has_more = len(filtered) > limit
    elapsed_ms = (time.perf_counter() - t0) * 1000

    # 🔴 위험 신호 감지 ===========================================
    warnings = []
    if truncated:
        warnings.append("LIST_TRUNCATED(>1000 keys)")
    if all_logs:
        max_id = all_logs[-1]["id"]
        # 정렬된 로그가 1..max_id 까지 모두 있는지 검사
        ids = [l["id"] for l in all_logs]
        expected = max_id - all_logs[0]["id"] + 1
        if len(set(ids)) != expected:
            warnings.append(f"GAP_IN_MINIO(parsed={len(ids)},expected={expected})")
        if len(ids) != len(set(ids)):
            warnings.append(f"DUPLICATE_IDS(total={len(ids)},unique={len(set(ids))})")
    if bad_lines:
        warnings.append(f"BAD_LINES({bad_lines})")
    # ==============================================================

    log_msg = (
        f"GET /logs  cursor={cursor}  last_id={last_id}  limit={limit}  "
        f"|  keys={key_count}  parsed={len(all_logs)}  "
        f"filtered>{last_id}={len(filtered)}  returned={len(result)}  "
        f"next_id={result[-1]['id'] if result else '-'}  has_more={has_more}  "
        f"elapsed={elapsed_ms:.1f}ms"
    )
    if warnings:
        log.warning(log_msg + "  WARN=" + ",".join(warnings))
    else:
        log.info(log_msg)

    return jsonify(
        {
            "data": result,
            "next_cursor": next_cursor,
            "has_more": has_more,
        }
    )


def encode_cursor(last_id):
    return base64.b64encode(json.dumps({"last_id": last_id}).encode()).decode()


def decode_cursor(cursor):
    if not cursor:
        return 0
    return json.loads(base64.b64decode(cursor))["last_id"]


@app.route("/health")
def health():
    return {"status": "ok", "bucket": BUCKET, "endpoint": ENDPOINT}


if __name__ == "__main__":
    log.info(f"=== api start  bucket={BUCKET}  endpoint={ENDPOINT} ===")
    app.run(host="0.0.0.0", port=5000, debug=False)
