"""디버그 로거 — debug/{name}.log 에 ms 정밀도로 기록."""
import logging
from pathlib import Path

DEBUG_DIR = Path(__file__).parent / "debug"
DEBUG_DIR.mkdir(exist_ok=True)


def get(name: str, *, truncate: bool = False) -> logging.Logger:
    """이름별 logger 반환. 기본은 append. truncate=True 시 파일 초기화."""
    log = logging.getLogger(name)
    if log.handlers:
        return log
    log.setLevel(logging.DEBUG)
    mode = "w" if truncate else "a"
    fh = logging.FileHandler(
        DEBUG_DIR / f"{name}.log",
        mode=mode,
        encoding="utf-8",
    )
    fh.setFormatter(
        logging.Formatter(
            "%(asctime)s.%(msecs)03d %(levelname)-5s %(message)s",
            datefmt="%H:%M:%S",
        )
    )
    log.addHandler(fh)
    log.propagate = False
    return log


if __name__ == "__main__":
    log = get("smoke")
    log.info("hello")
    log.warning("warn")
    log.error("err")
    print(f"wrote: {DEBUG_DIR / 'smoke.log'}")
