"""실시간 대시보드 — SQLite read-only, 사이드바 제어판 + 3초 자동 새로고침."""
import time
from pathlib import Path

import pandas as pd
import streamlit as st

import api_server as api
import config
import db
import generator as gen
import logger
import poller as pol
import proc

REFRESH_SEC = 3

st.set_page_config(
    page_title="MinIO Polling Demo",
    page_icon="📊",
    layout="wide",
)

# ============================================================
#   사이드바 — 폴링 전략 설정 / 파이프라인 제어 / 상태
# ============================================================
cfg = config.load()
running = proc.list_running()

with st.sidebar:
    st.header("⚡ 빠른 설정 프리셋")
    active_key = config.current_preset_key(cfg)
    st.caption(
        f"현재 적용: **{config.PRESETS[active_key]['name']}**"
        if active_key else "현재 적용: (커스텀 — 프리셋과 일치하지 않음)"
    )
    for key, preset in config.PRESETS.items():
        is_active = (key == active_key)
        label = f"{'●' if is_active else '○'}  {preset['name']} — {preset['desc']}"
        if st.button(
            label,
            key=f"preset_{key}",
            width="stretch",
            type="primary" if is_active else "secondary",
        ):
            config.apply_preset(key)
            st.toast(f"{preset['name']} 적용 → [🔄 재시작] 으로 반영", icon="⚡")
            time.sleep(0.3)
            st.rerun()

    st.divider()

    st.header("⚙️ 폴링 전략 설정")
    st.caption("값은 `settings.json` 에 저장. 변경 후 [재시작] 클릭으로 적용.")

    st.subheader("Generator")
    gen_interval = st.number_input(
        "주기 (ms)",
        min_value=100, max_value=60000, step=100,
        value=cfg["gen_interval_ms"],
        help="새 로그를 MinIO 에 업로드하는 주기",
    )
    gen_lines = st.number_input(
        "사이클당 라인 수",
        min_value=1, max_value=100, step=1,
        value=cfg["gen_lines_per_cycle"],
    )

    st.subheader("Poller")
    poll_idle = st.number_input(
        "Idle 주기 (ms)",
        min_value=50, max_value=30000, step=50,
        value=cfg["poll_idle_interval_ms"],
        help="신규 데이터가 없을 때 대기 시간",
    )
    poll_limit = st.number_input(
        "페이지 크기 (limit)",
        min_value=1, max_value=2000, step=1,
        value=cfg["poll_limit"],
    )
    drain_enabled = st.checkbox(
        "Drain 모드",
        value=cfg["poll_drain_enabled"],
        help="has_more=true 면 sleep 생략하고 즉시 재호출",
    )

    if st.button("💾 설정 저장", width="stretch"):
        config.save({
            "gen_interval_ms": int(gen_interval),
            "gen_lines_per_cycle": int(gen_lines),
            "poll_idle_interval_ms": int(poll_idle),
            "poll_limit": int(poll_limit),
            "poll_drain_enabled": bool(drain_enabled),
        })
        st.success("저장됨. [재시작] 으로 반영하세요.")

    st.divider()

    st.header("▶️ 파이프라인 제어")

    cc1, cc2 = st.columns(2)
    if cc1.button("▶ 시작", width="stretch"):
        if not running["api"]["running"]:
            proc.start("api")
            time.sleep(2)
        if not running["gen"]["running"]:
            proc.start("gen")
        if not running["poll"]["running"]:
            proc.start("poll")
        st.success("시작 요청 완료")
        time.sleep(0.5)
        st.rerun()

    if cc2.button("🔄 재시작", width="stretch"):
        proc.kill_all()
        time.sleep(1.5)
        proc.start("api")
        time.sleep(2)
        proc.start("gen")
        proc.start("poll")
        st.success("재시작 완료 (새 설정 반영)")
        time.sleep(0.5)
        st.rerun()

    if st.button("⏹ 종료", width="stretch"):
        n = proc.kill_all()
        st.info(f"종료된 프로세스: {n}")
        time.sleep(0.5)
        st.rerun()

    st.divider()

    st.header("🗑️ 데이터")
    if st.button("초기화 (MinIO + SQLite 삭제)", width="stretch"):
        proc.kill_all()
        time.sleep(1)
        proc.reset_data()
        st.success("초기화 완료")
        time.sleep(0.5)
        st.rerun()
    if st.button("시드 600건 재생성", width="stretch"):
        proc.seed()
        st.success("시드 완료")
        time.sleep(0.5)
        st.rerun()

    if st.button("🧹 디버그 로그 비우기", width="stretch"):
        cleared = 0
        for p in logger.DEBUG_DIR.glob("*.log"):
            p.write_text("", encoding="utf-8")
            cleared += 1
        st.success(f"로그 {cleared}개 비움")
        time.sleep(0.3)
        st.rerun()

    st.divider()

    st.header("📡 상태")
    st.write(f"API   : {'🟢 ON' if running['api']['running'] else '⚫ off'}")
    st.write(f"GEN   : {'🟢 ON' if running['gen']['running'] else '⚫ off'}")
    st.write(f"POLL  : {'🟢 ON' if running['poll']['running'] else '⚫ off'}")


# ============================================================
#   본문 — 타이틀 + 설명 + 메트릭 + 차트 + 테이블
# ============================================================
st.title("📊 데이터 폴링 데모 with cursor key")
st.caption(
    f"SQLite: `{db.DB_PATH.name}`  |  refresh: {REFRESH_SEC}s  |  source bucket: `{api.BUCKET}`"
)

_active_preset_key = config.current_preset_key(cfg)
_active_preset_label = (
    f"{config.PRESETS[_active_preset_key]['name']} — "
    f"{config.PRESETS[_active_preset_key]['desc']}"
    if _active_preset_key else "Custom (프리셋 일치 없음)"
)
with st.expander(
    f"ℹ️  파이프라인 동작 설명  |  활성 프리셋: **{_active_preset_label}**",
    expanded=False,
):
    info_l, info_r = st.columns(2)
    with info_l:
        st.markdown(
            f"""
            **🟢 로그 생성 주기 (`generator.py`)**

            | 항목 | 현재 값 |
            | --- | --- |
            | 주기 | **{cfg['gen_interval_ms']} ms** ({cfg['gen_interval_ms']/1000:.3f}s) |
            | 사이클당 라인 | **{cfg['gen_lines_per_cycle']}건** (1초 단위 시간 연속) |
            | id 채번 | `MinIO max(id) + 1` 단조증가 |
            | MinIO key | `gen_<unix_ts>.log` (매번 신규) |
            | Bucket | `{api.BUCKET}` |
            | msg 후보 | {len(gen.MSG_POOL)}종 |

            **🔵 데이터 폴링 주기 (`poller.py`)**

            | 항목 | 현재 값 |
            | --- | --- |
            | 페이지 크기 | **{cfg['poll_limit']}** |
            | Idle 간격 | **{cfg['poll_idle_interval_ms']} ms** ({cfg['poll_idle_interval_ms']/1000:.3f}s) |
            | Drain 모드 | **{'ON (즉시 재호출)' if cfg['poll_drain_enabled'] else 'OFF'}** |
            | 적재 방식 | `INSERT OR IGNORE` + cursor 갱신 단일 TX |
            | API 엔드포인트 | `{pol.API}` |
            """
        )
    with info_r:
        st.markdown(
            f"""
            **🗝️  Cursor Key 역할**

            - **무엇**: `{{"last_id": N}}` 를 base64 로 감싼 **opaque** 토큰
            - **누가 발급**: API 서버 (`{api.ENDPOINT}`) 가 매 응답에 `next_cursor` 포함
            - **누가 보관**: Poller 가 SQLite `meta` 테이블에 영속화
            - **무엇을 보장**:
              1. **이어받기** — 재시작 시 마지막 위치 복원
              2. **누락 없음** — `id > last_id` 필터로 빠짐 차단
              3. **중복 없음** — 같은 cursor 로 재요청해도 동일 (멱등)
              4. **Split-brain 차단** — 데이터 적재 + cursor 갱신이 한 트랜잭션

            > Generator 가 **{cfg['gen_interval_ms']}ms** 마다 **{cfg['gen_lines_per_cycle']}건** 쌓아도, Poller 는 cursor 만 보고 **빠짐 0 / 중복 0** 으로 SQLite 적재.
            """
        )


def load_data():
    if not Path(db.DB_PATH).exists():
        return None, None, None
    conn = db.connect(read_only=True)
    stats = db.stats(conn)
    cursor = db.get_cursor(conn)
    df = pd.read_sql_query(
        "SELECT id, msg, raw, fetched_at FROM logs ORDER BY id",
        conn,
    )
    conn.close()
    return stats, cursor, df


stats, cursor, df = load_data()

if stats is None or stats["total"] == 0:
    st.warning("data.db 가 비어있습니다. 사이드바 [▶ 시작] 으로 파이프라인을 기동하세요.")
    time.sleep(REFRESH_SEC)
    st.rerun()

# === 상단 메트릭 ===
c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Records", f"{stats['total']:,}")
c2.metric("ID Range", f"{stats['min_id']} ~ {stats['max_id']}")
c3.metric("Gap (누락)", stats["gap"], delta=None, delta_color="inverse")
last_fetched = df["fetched_at"].max() if not df.empty else "-"
c4.metric("Last Fetched", last_fetched.split("T")[-1] if isinstance(last_fetched, str) else "-")

st.caption(f"cursor (opaque): `{cursor or '-'}`")

st.divider()

# === 차트 영역 ===
col_left, col_right = st.columns([2, 1])

with col_left:
    st.subheader("⏱️  적재 추이 (분 단위 카운트)")
    if not df.empty:
        df["fetched_min"] = df["fetched_at"].str.slice(0, 16)
        ts_count = df.groupby("fetched_min").size().reset_index(name="count")
        st.line_chart(ts_count.set_index("fetched_min"), height=280)

with col_right:
    st.subheader("🏷️  msg 분포")
    if not df.empty:
        msg_count = df["msg"].value_counts().reset_index()
        msg_count.columns = ["msg", "count"]
        st.bar_chart(msg_count.set_index("msg"), height=280)

st.divider()

# === 최근 레코드 테이블 ===
st.subheader("🕘  최근 20건")
recent = df.sort_values("id", ascending=False).head(20)[["id", "msg", "raw", "fetched_at"]]
st.dataframe(recent, width="stretch", hide_index=True)

# === 무결성 알림 ===
if stats["gap"] == 0:
    st.success(f"✅ 무결성 OK — id 1..{stats['max_id']} 전체 누락 없음")
else:
    st.error(f"❌ 누락 {stats['gap']}건 발견 — gap 검사 필요 (debug/ 로그 참조)")

# === 디버그 로그 뷰어 ===
st.divider()
with st.expander("🔍  디버그 로그 (debug/)", expanded=(stats["gap"] > 0)):
    st.caption(
        f"각 프로세스 시작 시 로그 파일 truncate. WARNING 이상은 컬러 표시. "
        f"폴더: `{logger.DEBUG_DIR}`"
    )
    log_files = sorted(logger.DEBUG_DIR.glob("*.log"))
    if not log_files:
        st.info("아직 로그가 없습니다. 파이프라인을 시작하세요.")
    else:
        tabs = st.tabs([f.stem for f in log_files])
        for tab, log_file in zip(tabs, log_files):
            with tab:
                try:
                    content = log_file.read_text(encoding="utf-8", errors="replace")
                    lines = content.splitlines()
                    tail_n = st.slider(
                        "표시 줄 수",
                        min_value=20, max_value=500, value=100, step=20,
                        key=f"slider_{log_file.stem}",
                    )
                    tail = "\n".join(lines[-tail_n:])
                    # WARN 줄 강조
                    warn_count = sum(1 for l in lines[-tail_n:] if "WARN" in l or "ERROR" in l)
                    st.caption(
                        f"📄 {log_file.name}  |  전체 {len(lines):,}줄  |  "
                        f"표시 {min(tail_n, len(lines))}줄  |  "
                        f"⚠️ 경고 {warn_count}건 (표시 범위 내)"
                    )
                    st.code(tail or "(empty)", language="log", line_numbers=False)
                except Exception as e:
                    st.error(f"읽기 실패: {e}")

# === 자동 새로고침 ===
time.sleep(REFRESH_SEC)
st.rerun()
