import boto3
from pathlib import Path

ENDPOINT = "http://192.168.0.8:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "admin123"
BUCKET = "test01-log"
DATA_DIR = Path(__file__).parent / "data"

s3 = boto3.client(
    "s3",
    endpoint_url=ENDPOINT,
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1",
)

for log_file in sorted(DATA_DIR.glob("*.log")):
    key = log_file.name
    s3.upload_file(str(log_file), BUCKET, key)
    print(f"uploaded: {key}  ({log_file.stat().st_size} bytes)")

print(f"\n=== Objects in '{BUCKET}' ===")
for obj in s3.list_objects_v2(Bucket=BUCKET).get("Contents", []):
    print(f"  - {obj['Key']}  ({obj['Size']} bytes, {obj['LastModified']})")
