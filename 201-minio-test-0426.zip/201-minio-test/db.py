"""SQLite 헬퍼 — logs / meta 테이블, cursor get/set."""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "data.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS logs (
    id          INTEGER PRIMARY KEY,
    msg         TEXT,
    raw         TEXT,
    fetched_at  TEXT
);

CREATE TABLE IF NOT EXISTS meta (
    key         TEXT PRIMARY KEY,
    value       TEXT
);

CREATE INDEX IF NOT EXISTS idx_logs_fetched_at ON logs(fetched_at);
"""


def connect(read_only: bool = False) -> sqlite3.Connection:
    if read_only:
        uri = f"file:{DB_PATH}?mode=ro"
        conn = sqlite3.connect(uri, uri=True)
    else:
        conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def get_cursor(conn: sqlite3.Connection) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key='cursor'").fetchone()
    return row["value"] if row else None


def stats(conn: sqlite3.Connection) -> dict:
    row = conn.execute(
        "SELECT COUNT(*) AS total, MIN(id) AS min_id, MAX(id) AS max_id FROM logs"
    ).fetchone()
    total = row["total"] or 0
    min_id, max_id = row["min_id"], row["max_id"]
    gap = (max_id - min_id + 1 - total) if total else 0
    return {"total": total, "min_id": min_id, "max_id": max_id, "gap": gap}


if __name__ == "__main__":
    with connect() as c:
        init_schema(c)
        print(f"db ready: {DB_PATH}")
        print(f"cursor : {get_cursor(c)}")
        print(f"stats  : {stats(c)}")
