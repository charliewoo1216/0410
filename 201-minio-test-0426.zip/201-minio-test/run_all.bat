@echo off
chcp 65001 >nul
cd /d %~dp0

echo ================================================
echo  MinIO Cursor Polling Demo - START ALL
echo ================================================

echo [1/4] API server (port 5000)
start "API"  cmd /k python api_server.py

echo       waiting 3s for API to come up...
timeout /t 3 /nobreak >nul

echo [2/4] Generator (5s / 5 records)
start "GEN"  cmd /k python generator.py

echo [3/4] Poller (drain + SQLite)
start "POLL" cmd /k python poller.py

echo [4/4] Dashboard (port 8501)
start "DASH" cmd /k streamlit run dashboard.py

echo.
echo ================================================
echo  All started. Open: http://localhost:8501
echo  To stop everything: run stop_all.bat
echo ================================================
