@echo off
chcp 65001 >nul

echo ================================================
echo  Stopping all demo processes
echo ================================================

powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -match 'generator|poller|api_server|dashboard|streamlit' } | ForEach-Object { Write-Host ('  killing PID ' + $_.ProcessId + ': ' + (($_.CommandLine -split ' ')[-1])); Stop-Process -Id $_.ProcessId -Force }"

echo.
echo Done.
