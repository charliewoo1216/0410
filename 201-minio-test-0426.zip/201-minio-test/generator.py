"""주기적 로그 생성기 — settings.json 의 ms 단위 주기 / 사이클당 라인 수로 동작."""
import random
import re
import time
from datetime import datetime, timedelta

import boto3

import config
import logger

log = logger.get("generator")

ENDPOINT = "http://192.168.0.8:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "admin123"
BUCKET = "test01-log"

_cfg = config.load()
INTERVAL_MS = _cfg["gen_interval_ms"]
INTERVAL = INTERVAL_MS / 1000.0
LINES_PER_CYCLE = _cfg["gen_lines_per_cycle"]
MSG_POOL = [
    "login", "view_item", "search", "add_to_cart", "remove_from_cart",
    "view_cart", "checkout", "payment", "logout", "click",
]
LINE_RE = re.compile(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+id=(\d+)\s+msg=\w+")

s3 = boto3.client(
    "s3",
    endpoint_url=ENDPOINT,
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1",
)


def scan_state() -> tuple[int, datetime]:
    """MinIO 전체를 스캔해 max(id), max(timestamp) 반환."""
    max_id = 0
    max_ts = datetime(2026, 4, 25, 9, 59, 59)
    for obj in s3.list_objects_v2(Bucket=BUCKET).get("Contents", []):
        body = s3.get_object(Bucket=BUCKET, Key=obj["Key"])["Body"].read().decode()
        for line in body.splitlines():
            m = LINE_RE.match(line)
            if not m:
                continue
            ts = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")
            rec_id = int(m.group(2))
            if rec_id > max_id:
                max_id = rec_id
            if ts > max_ts:
                max_ts = ts
    return max_id, max_ts


def make_payload(start_id: int, start_ts: datetime, n: int) -> str:
    lines = []
    for i in range(n):
        ts = start_ts + timedelta(seconds=i)
        rec_id = start_id + i
        msg = random.choice(MSG_POOL)
        lines.append(f"{ts:%Y-%m-%d %H:%M:%S} id={rec_id} msg={msg}")
    return "\n".join(lines) + "\n"


def main():
    log.info(
        f"=== generator start  every={INTERVAL_MS}ms  lines/cycle={LINES_PER_CYCLE}  bucket={BUCKET} ==="
    )
    print(f"generator | every {INTERVAL_MS}ms ({INTERVAL:.3f}s), {LINES_PER_CYCLE} lines/cycle")
    print(f"          | bucket={BUCKET}  endpoint={ENDPOINT}\n")

    t0 = time.perf_counter()
    max_id, max_ts = scan_state()
    log.info(f"scan_state: max_id={max_id}  max_ts={max_ts}  ({(time.perf_counter()-t0)*1000:.1f}ms)")
    print(f"start state: max_id={max_id}, max_ts={max_ts}")

    cycle = 0
    while True:
        cycle += 1
        next_id = max_id + 1
        next_ts = max_ts + timedelta(seconds=1)
        payload = make_payload(next_id, next_ts, LINES_PER_CYCLE)

        # 매 사이클 unique key (race-free)
        key = f"gen_{int(time.time()*1000)}_{cycle}.log"
        put_t0 = time.perf_counter()
        s3.put_object(Bucket=BUCKET, Key=key, Body=payload.encode())
        put_ms = (time.perf_counter() - put_t0) * 1000

        last_id = next_id + LINES_PER_CYCLE - 1
        last_ts = next_ts + timedelta(seconds=LINES_PER_CYCLE - 1)
        log.info(
            f"#{cycle}  PUT {key}  id={next_id}..{last_id}  "
            f"ts={next_ts:%H:%M:%S}..{last_ts:%H:%M:%S}  put={put_ms:.1f}ms"
        )
        print(
            f"  [#{cycle}] {key}  id={next_id}..{last_id}  "
            f"ts={next_ts:%H:%M:%S}..{last_ts:%H:%M:%S}"
        )

        max_id = last_id
        max_ts = last_ts
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
