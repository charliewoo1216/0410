"""Step 모듈 패키지 — 각 step_*.py 파일은 render() 함수를 제공한다."""
