"""
Step 5 — Volume Test.
parser_v1.py 를 subprocess 로 구동해 mcc-log-file/ 전체 로그를 처리.
SQLite 결과를 집계해 성능 메트릭 시각화.
"""
from __future__ import annotations

import sqlite3
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd
import streamlit as st

from utils import file_manager, log_sampler
from utils.debug_logger import log_event


MCC_DIR = "mcc-log-file"
EVENTS_DB = file_manager.OUTPUT_DIR / "events.db"
PARSER_PATH = file_manager.OUTPUT_DIR / "parser_v1.py"
SUBPROCESS_TIMEOUT = 300


def _render_header() -> None:
    st.markdown(
        """
        <div class="mcc-step-header">
          <div class="mcc-step-badge" style="background:var(--pink2);color:var(--pink);border:1px solid rgba(255,126,182,.25);">05</div>
          <div>
            <div class="mcc-step-title">Volume Test</div>
            <div class="mcc-step-desc">parser_v1.py 로 mcc-log-file/ 전체 로그를 처리. 실시간 진행률 + SQLite 집계 메트릭 시각화.</div>
          </div>
          <div class="mcc-step-tag" style="color:var(--pink);background:var(--pink2);border:1px solid rgba(255,126,182,.25);">Subprocess · SQLite</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _compute_metrics(total_lines: int, elapsed: float) -> dict:
    """events.db 로부터 Parse/Pairing/False Pair Rate 계산."""
    metrics = {
        "parse_rate": 0.0,
        "pairing_rate": 0.0,
        "false_pair_rate": 0.0,
        "events_per_sec": 0.0,
        "total_events": 0,
    }
    if not EVENTS_DB.exists():
        return metrics

    try:
        conn = sqlite3.connect(EVENTS_DB)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM motion_events")
        total_ev = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM motion_events WHERE motion_end_ts IS NOT NULL")
        paired = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM motion_events WHERE severity='TIMEOUT'")
        timeouts = cur.fetchone()[0]
        conn.close()
    except Exception:
        return metrics

    metrics["total_events"] = total_ev
    if total_ev > 0:
        metrics["pairing_rate"] = paired / total_ev
        metrics["false_pair_rate"] = timeouts / total_ev
    if total_lines > 0:
        # Parse Rate: 이벤트 수 / 전체 라인 — 대략적 지표 (정확한 실패 카운트는 파서에 달림)
        metrics["parse_rate"] = min(1.0, total_ev / max(1, total_lines / 10))
    if elapsed > 0:
        metrics["events_per_sec"] = total_ev / elapsed
    return metrics


def render() -> None:
    _render_header()

    if not PARSER_PATH.exists():
        st.markdown(
            f'<div class="mcc-info orange">⚠ <code>{PARSER_PATH}</code> 가 없습니다. Step 4 코드 생성을 먼저 완료하세요.</div>',
            unsafe_allow_html=True,
        )
        return

    # 전체 로그 파일 목록
    file_infos = log_sampler.scan_log_files(MCC_DIR)
    if not file_infos:
        st.markdown(
            '<div class="mcc-info orange">⚠ mcc-log-file/ 에 처리할 로그가 없습니다.</div>',
            unsafe_allow_html=True,
        )
        return

    df = pd.DataFrame([
        {"파일": i["rel"], "크기(MB)": i["size_mb"], "라인": i["total_lines"]}
        for i in file_infos
    ])
    with st.expander(f"📁 처리 대상 파일 ({len(file_infos)}개)", expanded=False):
        st.dataframe(df, width="stretch", hide_index=True)

    total_lines_all = sum(i["total_lines"] for i in file_infos if i.get("encoding"))

    c1, c2 = st.columns([1, 4])
    with c1:
        clicked = st.button("▶ 전체 테스트 시작", type="primary", width="stretch", key="btn_volume")
    with c2:
        if EVENTS_DB.exists():
            st.markdown(
                f'<div class="mcc-info" style="margin:0;">✓ <code>{EVENTS_DB}</code> 존재. 재실행 시 기존 DB에 누적됩니다.</div>',
                unsafe_allow_html=True,
            )

    if clicked:
        _run_volume_test(file_infos, total_lines_all)
        st.rerun()

    # 메트릭 표시
    if EVENTS_DB.exists():
        _render_results(total_lines_all)


def _run_volume_test(file_infos: list[dict], total_lines_all: int) -> None:
    """파일별 순차로 parser_v1.py subprocess 호출."""
    log_event("step5", "볼륨 테스트 시작", f"files={len(file_infos)}, lines={total_lines_all:,}")
    progress = st.progress(0.0, text="볼륨 테스트 시작...")
    status = st.empty()
    log_area = st.empty()

    n = len(file_infos)
    start_time = time.time()
    per_file_logs: list[str] = []

    for idx, info in enumerate(file_infos):
        path = info["path"]
        rel = info["rel"]
        progress.progress(idx / max(1, n), text=f"[{idx+1}/{n}] {rel}")
        status.markdown(
            f'<div class="mcc-info blue" style="margin:0;">🔄 처리 중: <code>{rel}</code> ({info["total_lines"]:,} 라인)</div>',
            unsafe_allow_html=True,
        )
        try:
            r = subprocess.run(
                [sys.executable, str(PARSER_PATH), "--input", path, "--db", str(EVENTS_DB)],
                capture_output=True,
                text=True,
                timeout=SUBPROCESS_TIMEOUT,
                encoding="utf-8",
                errors="replace",
            )
            rc = r.returncode
            tail = (r.stderr or "")[-200:] if rc != 0 else "OK"
            per_file_logs.append(f"[{rc}] {rel} — {tail}")
            log_event("step5", f"parser run [{rc}]", rel)
        except subprocess.TimeoutExpired:
            per_file_logs.append(f"[TIMEOUT] {rel}")
            log_event("step5", "parser TIMEOUT", rel)
        except Exception as e:
            per_file_logs.append(f"[ERROR] {rel} — {e}")
            log_event("step5", "parser ERROR", f"{rel}: {e}")

        log_area.code("\n".join(per_file_logs[-20:]), language="text")

    elapsed = time.time() - start_time
    progress.progress(1.0, text=f"✓ 완료 ({elapsed:.1f}s)")
    log_event("step5", "볼륨 테스트 완료", f"elapsed={elapsed:.1f}s")
    status.success(f"전체 {n}개 파일 처리 완료. 소요 {elapsed:.1f}초.")

    st.session_state["step5_done"] = EVENTS_DB.exists()
    st.session_state["_volume_elapsed"] = elapsed
    st.session_state["_volume_total_lines"] = total_lines_all


def _render_results(total_lines_all: int) -> None:
    elapsed = st.session_state.get("_volume_elapsed", 0.0)
    metrics = _compute_metrics(total_lines_all, elapsed)

    st.markdown("---")
    st.markdown(
        '<div style="font-family:\'IBM Plex Mono\',monospace;font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.09em;margin:6px 0 10px 0;">▸ 성능 메트릭</div>',
        unsafe_allow_html=True,
    )

    c1, c2, c3, c4 = st.columns(4)

    pr = metrics["parse_rate"]
    pr_delta = "✓ 목표 ≥ 0.95" if pr >= 0.95 else "✗ 미달"
    c1.metric("Parse Rate", f"{pr:.2%}", delta=pr_delta, delta_color=("normal" if pr >= 0.95 else "inverse"))

    pa = metrics["pairing_rate"]
    pa_delta = "✓ 목표 ≥ 0.90" if pa >= 0.90 else "✗ 미달"
    c2.metric("Pairing Rate", f"{pa:.2%}", delta=pa_delta, delta_color=("normal" if pa >= 0.90 else "inverse"))

    fp = metrics["false_pair_rate"]
    fp_delta = "✓ 목표 < 3%" if fp < 0.03 else "✗ 초과"
    c3.metric("False Pair", f"{fp:.2%}", delta=fp_delta, delta_color=("normal" if fp < 0.03 else "inverse"))

    ev_s = metrics["events_per_sec"]
    ev_delta = "✓ 목표 ≥ 1,000" if ev_s >= 1000 else "✗ 미달"
    c4.metric("처리 속도 (ev/s)", f"{ev_s:,.0f}", delta=ev_delta, delta_color=("normal" if ev_s >= 1000 else "inverse"))

    c5, c6 = st.columns(2)
    c5.metric("총 처리 라인", f"{total_lines_all:,}")
    c6.metric("추출 Motion Events", f"{metrics['total_events']:,}")

    # 재작업 경로 안내
    warnings = []
    if pr < 0.95:
        warnings.append(("red", "Parse Rate 미달 → Step 2 재분석 권장"))
    if pa < 0.90:
        warnings.append(("orange", "Pairing Rate 미달 → Step 3 페어링 규칙 보완 권장"))
    if fp >= 0.03:
        warnings.append(("yellow", "False Pair 초과 → Step 4 파서 재생성 권장"))

    if warnings:
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown(
            '<div style="font-family:\'IBM Plex Mono\',monospace;font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.09em;margin:4px 0 8px 0;">▸ 재작업 경로</div>',
            unsafe_allow_html=True,
        )
        for color, msg in warnings:
            st.markdown(f'<div class="mcc-info {color}">• {msg}</div>', unsafe_allow_html=True)

    # 이벤트 미리보기
    try:
        conn = sqlite3.connect(EVENTS_DB)
        df_preview = pd.read_sql_query(
            "SELECT id, equipment_id, wafer_id, motion_type, motion_start_ts, motion_end_ts, "
            "duration_sec, severity, note FROM motion_events ORDER BY id DESC LIMIT 100",
            conn,
        )
        df_counts = pd.read_sql_query(
            "SELECT motion_type, COUNT(*) as count FROM motion_events GROUP BY motion_type ORDER BY count DESC",
            conn,
        )
        conn.close()
    except Exception as e:
        st.error(f"SQLite 조회 실패: {e}")
        return

    if len(df_counts) > 0:
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown(
            '<div style="font-family:\'IBM Plex Mono\',monospace;font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.09em;margin:4px 0 8px 0;">▸ 모션 타입 분포</div>',
            unsafe_allow_html=True,
        )
        st.bar_chart(df_counts.set_index("motion_type"))

    if len(df_preview) > 0:
        st.markdown(
            '<div style="font-family:\'IBM Plex Mono\',monospace;font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.09em;margin:14px 0 8px 0;">▸ 최근 이벤트 100건</div>',
            unsafe_allow_html=True,
        )
        st.dataframe(df_preview, width="stretch", hide_index=True)
    else:
        st.info("events.db 에 저장된 모션 이벤트가 없습니다. 파서 코드나 페어링 규칙을 점검하세요.")
