"""
디버그 로거 — debug-log/ 폴더에 워크플로우 이벤트와 LLM 요청/응답을 기록한다.

- workflow.log : 타임스탬프 + step + 이벤트 (append-only, 전체 진행 요약)
- llm/<ts>_<purpose>.md : 1회 호출당 파일 1개 (system/user 메시지 + 응답 또는 에러)
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path


LOG_DIR = Path("debug-log")
LLM_DIR = LOG_DIR / "llm"
STEP4_DIR = LOG_DIR / "step4"
WORKFLOW_LOG = LOG_DIR / "workflow.log"


def _ensure_dirs() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    LLM_DIR.mkdir(parents=True, exist_ok=True)
    STEP4_DIR.mkdir(parents=True, exist_ok=True)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _ts_compact() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]


_SANITIZE_RE = re.compile(r"[^A-Za-z0-9가-힣._-]+")


def _sanitize(s: str, maxlen: int = 60) -> str:
    s = _SANITIZE_RE.sub("_", s).strip("_")
    return s[:maxlen] or "unnamed"


# ─────────────────────────────────────────────
# 워크플로우 이벤트 로그
# ─────────────────────────────────────────────
def log_event(step: str, event: str, detail: str = "") -> None:
    """한 줄 이벤트를 workflow.log 에 append."""
    _ensure_dirs()
    line = f"[{_ts()}] [{step:<8}] {event}"
    if detail:
        line += f" — {detail}"
    try:
        with WORKFLOW_LOG.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        # 로깅 실패는 무시 (앱 흐름을 막지 않음)
        pass


# ─────────────────────────────────────────────
# LLM 호출 로그
# ─────────────────────────────────────────────
def log_llm_call(
    step: str,
    purpose: str,
    messages: list[dict],
    params: dict,
    response: str = "",
    error: str = "",
    streaming: bool = False,
) -> Path | None:
    """
    LLM 호출 1건을 debug-log/llm/ 아래 md 파일로 저장.
    반환: 저장된 파일 경로 (실패 시 None)
    """
    _ensure_dirs()
    fname = f"{_ts_compact()}_{_sanitize(step)}_{_sanitize(purpose)}.md"
    path = LLM_DIR / fname
    try:
        lines: list[str] = []
        lines.append(f"# LLM Call — {step} / {purpose}")
        lines.append("")
        lines.append(f"- timestamp : `{_ts()}`")
        lines.append(f"- streaming : `{streaming}`")
        lines.append(f"- status    : `{'ERROR' if error else 'OK'}`")
        lines.append(f"- params    : `{json.dumps(params, ensure_ascii=False)}`")
        lines.append("")
        lines.append("## Messages")
        lines.append("")
        for m in messages:
            role = m.get("role", "?")
            content = m.get("content", "") or ""
            lines.append(f"### role: `{role}`")
            lines.append("")
            lines.append("```")
            lines.append(content)
            lines.append("```")
            lines.append("")
        if error:
            lines.append("## Error")
            lines.append("")
            lines.append("```")
            lines.append(error)
            lines.append("```")
        else:
            lines.append("## Response")
            lines.append("")
            lines.append("```")
            lines.append(response or "(empty)")
            lines.append("```")
        path.write_text("\n".join(lines), encoding="utf-8")
    except Exception as e:
        log_event(step, "LLM log 저장 실패", str(e))
        return None

    status = "ERR" if error else "OK"
    size = len(response) if response else 0
    log_event(
        step,
        f"LLM {purpose} [{status}]",
        f"→ {path.name} (resp={size} chars)",
    )
    return path


# ─────────────────────────────────────────────
# Step 4 전용 상세 진행 로그
# ─────────────────────────────────────────────
def start_step4_run() -> Path:
    """Step 4 ReAct 루프 1회 실행용 폴더를 생성하고 경로 반환."""
    _ensure_dirs()
    run_dir = STEP4_DIR / f"run_{_ts_compact()}"
    run_dir.mkdir(parents=True, exist_ok=True)
    # 헤더용 summary 초안
    (run_dir / "summary.md").write_text(
        f"# Step 4 ReAct Run — {_ts()}\n\n"
        f"- run_dir: `{run_dir}`\n"
        f"- status: _진행중_\n\n"
        f"## Iterations\n\n",
        encoding="utf-8",
    )
    log_event("step4", "run 폴더 생성", str(run_dir))
    return run_dir


def write_step4_iter(
    run_dir: Path,
    n: int,
    think: str,
    user_prompt: str,
    llm_response: str,
    extracted_code: str,
    observe: dict,
    extract_error: str | None = None,
    duration_sec: float | None = None,
) -> None:
    """
    한 iteration 의 모든 정보를 run_dir 에 저장.
    - iter_NN.md : prompt + response + observe 통합 뷰
    - iter_NN_code.py : 추출된 Python 코드 (있을 때만)
    """
    try:
        iter_md = run_dir / f"iter_{n:02d}.md"
        iter_py = run_dir / f"iter_{n:02d}_code.py"

        ok = observe.get("ok", False)
        status_badge = "OK" if ok else ("CODE_EXTRACT_ERR" if extract_error else "FAIL")

        lines: list[str] = []
        lines.append(f"# Iteration {n} — {status_badge}")
        lines.append("")
        lines.append(f"- timestamp : `{_ts()}`")
        if duration_sec is not None:
            lines.append(f"- duration  : `{duration_sec:.2f}s`")
        lines.append(f"- response_chars : `{len(llm_response or '')}`")
        lines.append(f"- code_chars     : `{len(extracted_code or '')}`")
        lines.append(f"- sandbox_ok     : `{ok}`")
        lines.append("")
        lines.append("## Think")
        lines.append("")
        lines.append(think or "(없음)")
        lines.append("")
        lines.append("## User Prompt")
        lines.append("")
        lines.append("```")
        lines.append(user_prompt or "")
        lines.append("```")
        lines.append("")
        lines.append("## LLM Response (raw)")
        lines.append("")
        lines.append("```")
        lines.append(llm_response or "(empty)")
        lines.append("```")
        lines.append("")
        if extract_error:
            lines.append("## Code Extraction Error")
            lines.append("")
            lines.append("```")
            lines.append(extract_error)
            lines.append("```")
            lines.append("")
        else:
            lines.append("## Extracted Code")
            lines.append("")
            lines.append(f"→ `{iter_py.name}`")
            lines.append("")
        lines.append("## Sandbox Observe")
        lines.append("")
        lines.append(f"- ok: `{ok}`")
        lines.append("")
        if observe.get("traceback"):
            lines.append("### Traceback")
            lines.append("```")
            lines.append(observe["traceback"])
            lines.append("```")
            lines.append("")
        if observe.get("stdout"):
            lines.append("### stdout")
            lines.append("```")
            lines.append(observe["stdout"])
            lines.append("```")
            lines.append("")
        if observe.get("stderr"):
            lines.append("### stderr")
            lines.append("```")
            lines.append(observe["stderr"])
            lines.append("```")
            lines.append("")

        iter_md.write_text("\n".join(lines), encoding="utf-8")

        # 추출된 코드가 있으면 별도 .py 로도 저장 (독립 실행/diff 가능)
        if extracted_code and not extract_error:
            iter_py.write_text(extracted_code, encoding="utf-8")

    except Exception as e:
        log_event("step4", "iter 로그 저장 실패", f"iter={n}: {e}")


def finalize_step4_run(run_dir: Path, iterations: list[dict], final_status: str) -> None:
    """루프 종료 시 summary.md 갱신 (iter 요약 표 + 최종 상태)."""
    try:
        lines: list[str] = []
        lines.append(f"# Step 4 ReAct Run — {_ts()}")
        lines.append("")
        lines.append(f"- run_dir: `{run_dir}`")
        lines.append(f"- status: **{final_status}**")
        lines.append(f"- total_iterations: `{len(iterations)}`")
        lines.append("")
        lines.append("## Iteration Summary")
        lines.append("")
        lines.append("| # | status | code_chars | tb_chars | title |")
        lines.append("|---|--------|-----------:|---------:|-------|")
        for it in iterations:
            n = it.get("n", "?")
            st_ = it.get("status", "")
            code_len = len((it.get("code") or ""))
            tb_len = len(((it.get("observe") or {}).get("traceback") or ""))
            title = (it.get("title") or "").replace("|", "\\|")
            lines.append(f"| {n} | {st_} | {code_len} | {tb_len} | {title} |")
        lines.append("")
        lines.append("## Files")
        lines.append("")
        for it in iterations:
            n = it.get("n", 0)
            lines.append(f"- iter {n:02d}: `iter_{n:02d}.md` / `iter_{n:02d}_code.py`")
        (run_dir / "summary.md").write_text("\n".join(lines), encoding="utf-8")
        log_event("step4", "run 종료 요약", f"{run_dir.name} — {final_status}")
    except Exception as e:
        log_event("step4", "summary 저장 실패", str(e))
