"""
output/ 폴더 파일 입출력 유틸.
md / py 파일 저장·로드, 단계별 완료 파일 확인.
"""
from __future__ import annotations

import json
from pathlib import Path


OUTPUT_DIR = Path("output")


# 각 step의 '완료 판단용' 필수 파일 목록
STEP_REQUIRED_FILES: dict[int, list[str]] = {
    # Step 1: 세션 기반이라 파일 필수 없음. 별도 플래그로 관리.
    1: [],
    2: ["이벤트분석_v2.md"],
    3: ["모션_페어링_분석_v2.md"],
    4: ["parser_v1.py"],
    5: ["events.db"],
}


def _ensure_dir() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def save_text(filename: str, content: str) -> Path:
    _ensure_dir()
    path = OUTPUT_DIR / filename
    path.write_text(content, encoding="utf-8")
    return path


def load_text(filename: str) -> str | None:
    path = OUTPUT_DIR / filename
    if not path.exists():
        return None
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return None


def save_md(filename: str, content: str) -> Path:
    return save_text(filename, content)


def load_md(filename: str) -> str | None:
    return load_text(filename)


def save_py(filename: str, content: str) -> Path:
    return save_text(filename, content)


def load_py(filename: str) -> str | None:
    return load_text(filename)


def save_json(filename: str, obj) -> Path:
    _ensure_dir()
    path = OUTPUT_DIR / filename
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_json(filename: str):
    raw = load_text(filename)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def check_step_done(step: int) -> bool:
    """step별 필수 파일이 모두 존재하면 True."""
    req = STEP_REQUIRED_FILES.get(step, [])
    if not req:
        return False  # Step 1은 세션 기반
    return all((OUTPUT_DIR / f).exists() for f in req)


def output_path(filename: str) -> Path:
    _ensure_dir()
    return OUTPUT_DIR / filename
