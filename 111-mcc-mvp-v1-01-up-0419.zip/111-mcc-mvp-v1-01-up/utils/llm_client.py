"""
LLM 클라이언트 — OpenAI 호환 엔드포인트용 래퍼.
- chat(): 논스트리밍 (전체 응답 str 반환)
- stream_chat(): 스트리밍 제너레이터 (토큰/청크 yield)
- Qwen3 계열 <think>...</think> 태그 자동 제거
- 최대 3회 재시도 (1초 간격)
"""
from __future__ import annotations

import json
import re
import time
import traceback
from typing import Generator, Iterable

from openai import OpenAI

from utils.debug_logger import log_llm_call


# Qwen3 reasoning 태그 제거용
_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)
_THINK_OPEN = re.compile(r"<think>.*", re.DOTALL)  # 닫힘 태그 누락 대비


def strip_think(text: str) -> str:
    """<think>...</think> 블록을 제거한다."""
    if not text:
        return text
    cleaned = _THINK_RE.sub("", text)
    # 닫힘 태그 누락 시 열림 이후 전부 제거
    cleaned = _THINK_OPEN.sub("", cleaned)
    return cleaned.strip()


def _parse_sse_text(raw: str) -> str:
    """
    SSE(Server-Sent Events) 포맷 문자열을 content 로 합친다.
    일부 OpenAI 호환 서버가 stream=False 요청에도 SSE 포맷으로 응답하는 케이스 대응.
    포맷 예: `data: {"choices":[{"delta":{"content":"..."}}]}\n\n`
    """
    pieces: list[str] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            obj = json.loads(payload)
        except Exception:
            continue
        choices = obj.get("choices") or []
        if not choices:
            continue
        c0 = choices[0]
        # streaming delta
        delta = c0.get("delta") or {}
        content = delta.get("content")
        if content is None:
            # non-streaming message
            msg = c0.get("message") or {}
            content = msg.get("content")
        if content is None:
            # legacy completion text
            content = c0.get("text")
        if content:
            pieces.append(content)
    return "".join(pieces)


def _looks_like_sse(text: str) -> bool:
    # 앞쪽 512바이트만 훑어 빠르게 판정
    head = text[:512]
    return "data:" in head and ("\"choices\"" in head or "choices" in head)


def _extract_content(resp) -> str:
    """
    OpenAI 호환 응답에서 content 추출. 서버 구현에 따라 resp가
    ChatCompletion 객체 / dict / str(SSE raw) 중 무엇이든 올 수 있어 방어적으로 파싱.
    """
    # 문자열 — SSE raw body 가능성 확인
    if isinstance(resp, str):
        if _looks_like_sse(resp):
            parsed = _parse_sse_text(resp)
            if parsed:
                return parsed
        return resp
    # dict 형태 (일부 서버가 raw JSON dict 반환)
    if isinstance(resp, dict):
        try:
            ch = resp.get("choices", [])
            if ch:
                msg = ch[0].get("message") or {}
                return msg.get("content") or ch[0].get("text") or ""
        except Exception:
            return ""
        return ""
    # 표준 OpenAI SDK 객체
    if hasattr(resp, "choices"):
        try:
            c0 = resp.choices[0]
            if hasattr(c0, "message") and c0.message is not None:
                return c0.message.content or ""
            if hasattr(c0, "text"):
                return c0.text or ""
        except Exception:
            return ""
    return str(resp)


def _extract_delta(chunk) -> str:
    """스트리밍 청크에서 델타 텍스트 추출 (방어적)."""
    if isinstance(chunk, str):
        return chunk
    if isinstance(chunk, dict):
        try:
            ch = chunk.get("choices", [])
            if ch:
                delta = ch[0].get("delta") or {}
                return delta.get("content") or ch[0].get("text") or ""
        except Exception:
            return ""
        return ""
    if hasattr(chunk, "choices"):
        try:
            c0 = chunk.choices[0]
            if hasattr(c0, "delta") and c0.delta is not None:
                return c0.delta.content or ""
            if hasattr(c0, "text"):
                return c0.text or ""
        except Exception:
            return ""
    return ""


class LLMClient:
    def __init__(self, base_url: str, model: str, api_key: str) -> None:
        self.base_url = base_url
        self.model = model
        self.api_key = api_key
        self._client = OpenAI(base_url=base_url, api_key=api_key)

    # ── 논스트리밍 ──────────────────────────────
    def chat(
        self,
        messages: list[dict],
        temperature: float = 0.3,
        max_tokens: int = 4096,
        step: str = "?",
        purpose: str = "chat",
    ) -> str:
        params = {
            "model": self.model,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "attempts": 0,
        }
        last_err: Exception | None = None
        for attempt in range(3):
            params["attempts"] = attempt + 1
            try:
                resp = self._client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=False,
                )
                content = _extract_content(resp)
                result = strip_think(content)
                log_llm_call(
                    step=step, purpose=purpose,
                    messages=messages, params=params,
                    response=result, streaming=False,
                )
                return result
            except Exception as e:
                last_err = e
                if attempt < 2:
                    time.sleep(1.0)
        err_text = "".join(traceback.format_exception_only(type(last_err), last_err))
        log_llm_call(
            step=step, purpose=purpose,
            messages=messages, params=params,
            error=err_text, streaming=False,
        )
        raise RuntimeError(f"LLM chat 실패 (3회 재시도): {last_err}")

    # ── 스트리밍 ────────────────────────────────
    def stream_chat(
        self,
        messages: list[dict],
        temperature: float = 0.3,
        max_tokens: int = 4096,
        step: str = "?",
        purpose: str = "stream",
    ) -> Generator[str, None, None]:
        """청크 단위 텍스트를 yield. <think> 블록은 제거한다. 완료 후 전체 응답을 로그."""
        params = {
            "model": self.model,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "attempts": 0,
        }
        collected: list[str] = []
        last_err: Exception | None = None
        for attempt in range(3):
            params["attempts"] = attempt + 1
            collected.clear()
            try:
                stream = self._client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=True,
                )
                in_think = False
                buffer = ""
                for chunk in stream:
                    delta = _extract_delta(chunk)
                    if not delta:
                        continue
                    buffer += delta
                    # <think> 블록 내부는 skip
                    while buffer:
                        if in_think:
                            end = buffer.find("</think>")
                            if end == -1:
                                buffer = ""
                                break
                            buffer = buffer[end + len("</think>"):]
                            in_think = False
                        else:
                            start = buffer.find("<think>")
                            if start == -1:
                                # 부분 태그 경계 유지 (<th, <thi, <thin...)
                                if "<" in buffer and len(buffer) < 10:
                                    break
                                collected.append(buffer)
                                yield buffer
                                buffer = ""
                                break
                            if start > 0:
                                collected.append(buffer[:start])
                                yield buffer[:start]
                            buffer = buffer[start + len("<think>"):]
                            in_think = True
                if buffer and not in_think:
                    collected.append(buffer)
                    yield buffer
                # 성공 — 로그 저장 후 정상 종료
                log_llm_call(
                    step=step, purpose=purpose,
                    messages=messages, params=params,
                    response="".join(collected), streaming=True,
                )
                return
            except Exception as e:
                last_err = e
                if attempt < 2:
                    time.sleep(1.0)
        err_text = "".join(traceback.format_exception_only(type(last_err), last_err))
        log_llm_call(
            step=step, purpose=purpose,
            messages=messages, params=params,
            response="".join(collected),
            error=err_text, streaming=True,
        )
        raise RuntimeError(f"LLM stream 실패 (3회 재시도): {last_err}")

    # ── 편의 메서드: 스트림을 문자열로 합치기 ──
    def stream_collect(
        self,
        messages: list[dict],
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> Iterable[str]:
        """st.write_stream 호환. 내부적으로 stream_chat을 그대로 반환."""
        return self.stream_chat(messages, temperature=temperature, max_tokens=max_tokens)


def build_client_from_session() -> LLMClient:
    """st.session_state['ai_config'] 로부터 LLMClient 생성."""
    import streamlit as st

    cfg = st.session_state.get("ai_config", {})
    return LLMClient(
        base_url=cfg.get("base_url", "http://192.168.0.8:8080/v1"),
        model=cfg.get("model", "qwen3.5:9b"),
        api_key=cfg.get("api_key", "sk_123!"),
    )
