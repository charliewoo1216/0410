# CLAUDE.md — Motion Parser MVP v1
> Claude Code가 이 프로젝트를 처음 열었을 때 읽는 문서.
> 전체 목적, 아키텍처, 구현 규칙, 파일 역할을 모두 담는다.

---

## 1. 프로젝트 목적

제조 장비의 원시 로그 파일에서 **모션(동작) 이벤트를 자동으로 추출**하는 파서를 생성하는
**Agentic AI 워크플로우**를 구현한다.

- 장비 종류가 다양하므로 로그 포맷을 사전에 가정하지 않는다.
- LLM이 샘플 로그를 보고 포맷·이벤트 코드·모션 구조를 **자율 추론**한다.
- 사용자가 대화로 도메인 지식을 보완하면 파서 코드(`parser_v1.py`)를 자동 생성한다.
- 생성된 파서로 전체 로그를 처리해 SQLite에 모션 이벤트를 저장한다.

---

## 2. 기술 스택

| 항목 | 내용 |
|------|------|
| UI | `streamlit` |
| LLM API | OpenAI-compatible (`openai` 라이브러리) |
| 모델 | `qwen3.5:9b` (기본값, UI에서 변경 가능) |
| Base URL | `http://192.168.0.8:8080/v1` (기본값, UI에서 변경 가능) |
| API Key | `sk_123!` (기본값, UI에서 변경 가능) |
| 컨텍스트 | 256k 토큰 → 로그에 180k 토큰 할당 (안전 마진) |
| 저장소 | `sqlite3` + 로컬 `.md` / `.py` 파일 |
| 로그 탐색 | `pathlib` 재귀 탐색 |
| 코드 실행 | `subprocess` + `exec()` |
| 상태 관리 | `st.session_state` |

---

## 3. 프로젝트 폴더 구조

```
project/
├── CLAUDE.md                  ← 이 파일
├── CHECKLIST.md               ← 구현 체크리스트
├── app.py                     ← Streamlit 메인 진입점
├── ai_config.py               ← LLM 설정 (base_url, model, api_key)
├── requirements.txt
│
├── utils/
│   ├── llm_client.py          ← LLM API 래퍼 (스트리밍/논스트리밍)
│   ├── log_sampler.py         ← 로그 파일 탐색 + 균등 샘플링
│   └── file_manager.py        ← output/ 파일 저장·로드
│
├── steps/
│   ├── step1_log_selection.py
│   ├── step2_ai_analysis.py
│   ├── step3_verification.py
│   ├── step4_code_generation.py
│   └── step5_volume_test.py
│
├── mcc-log-file/              ← 원시 로그 폴더 (읽기전용, 절대 수정 금지)
│   └── **/*.log / *.txt / *.csv
│
└── output/                    ← 생성 산출물 (자동 생성)
    ├── 원시로그템플릿.md
    ├── 이벤트분석_v1.md
    ├── 이벤트분석_v2.md
    ├── 모션_페어링_분석_v1.md
    ├── 모션_페어링_분석_v2.md
    ├── parser_v1.py
    └── events.db
```

---

## 4. Streamlit UI 구조

### 사이드바 (st.sidebar)
```
┌─────────────────────────────┐
│  ⚙ AI Config                │  ← 항상 표시, 언제든 수정 가능
│    Base URL / Model / Key   │
├─────────────────────────────┤
│  ① Log Selection     [시작] │  ← 항상 활성
│  ② AI Analysis       [잠금] │  ← step1_done=True 시 활성
│  ③ Verification      [잠금] │  ← step2_done=True 시 활성
│  ④ Code Generation   [잠금] │  ← step3_done=True 시 활성
│  ⑤ Volume Test       [잠금] │  ← step4_done=True 시 활성
└─────────────────────────────┘
```

### 단계 완료 조건 (session_state)
| 키 | 완료 조건 |
|----|-----------|
| `step1_done` | `output/sampled_logs.pkl` 존재 (또는 session_state에 샘플 로드 완료) |
| `step2_done` | `output/이벤트분석_v2.md` 파일 존재 |
| `step3_done` | `output/모션_페어링_분석_v2.md` 파일 존재 |
| `step4_done` | `output/parser_v1.py` 존재 + 샘플 실행 성공 플래그 |
| `step5_done` | `output/events.db` 존재 |

### 앱 시작 시 동작
- `output/` 폴더 없으면 자동 생성
- 각 output 파일 존재 여부로 `session_state` 초기화 → 중간 재시작 시 이전 진행 복원

---

## 5. 각 Step 상세 명세

---

### Step 1 — Log Selection

**역할**: 로그 파일 탐색 + 균등 샘플링. LLM 미사용.

**입력**: `mcc-log-file/` 하위 모든 파일

**처리**:
1. `pathlib.Path('mcc-log-file').rglob('*')` 로 `.log` / `.txt` / `.csv` 재귀 탐색
2. 각 파일 인코딩 자동 감지 (`utf-8` → `euc-kr` → `cp949` 순 시도)
3. 전체 라인 수 카운트
4. **균등 샘플링**: `stride = total_lines / target_lines`
   - `target_lines` 기본값: **120,000줄** (180k 토큰 안전 마진 기준)
   - 파일별 비례 배분: 파일 크기 비율로 target 배분
5. 샘플링 결과를 `session_state['sampled_lines']` 에 저장

**Streamlit UI**:
- 파일 목록 테이블 (파일명 / 크기 / 총 라인 수 / 샘플 라인 수)
- `target_lines` 슬라이더 (10,000 ~ 200,000)
- [샘플링 시작] 버튼 → `st.progress` 바 + 현재 처리 파일명
- 완료 후 샘플 미리보기 100줄 (`st.code`)
- 토큰 예상치 표시 (`sampled_lines * 평균글자 / 3.5`)
- 완료 시 → `step1_done = True`, 사이드바 Step 2 활성화

**출력**: `session_state['sampled_lines']` (list of str)

---

### Step 2 — AI Analysis

**역할**: LLM이 로그를 보고 포맷·이벤트 코드 의미를 자율 추론, 사용자 대화로 보완 → 2종 md 확정.

**핵심 원칙**: 로그 포맷 사전 가정 없음. 어떤 장비든 동일 프로세스 적용.

#### 2-1. 원시로그템플릿.md 생성
- **프롬프트**: 샘플 로그 전체 + 아래 지시
  ```
  이 로그의 장비 유형을 추론하고 다음을 분석하라:
  1. 타임스탬프 패턴 (포맷, 정밀도)
  2. 이벤트 코드 네이밍 규칙 (접두사 그룹, 번호 체계)
  3. 필드 구조 (KEY=VALUE, 탭 구분, CSV 등)
  4. 특이사항 (반복 패턴, 그룹 구조, 엔티티 식별자 등)
  마크다운으로 원시로그템플릿.md 를 작성하라.
  ```
- LLM 스트리밍 응답 → `st.write_stream` 으로 실시간 표시
- 완료 → `output/원시로그템플릿.md` 저장

#### 2-2. 이벤트분석_v1.md 생성
- **프롬프트**: 원시로그템플릿.md 내용 + 샘플 로그 + 아래 지시
  ```
  위 로그에서 모든 이벤트 코드를 나열하고,
  각 코드의 의미를 해석하라.
  모션(동작)과 관련된 이벤트를 후보로 분류하라:
  - 모션 시작 후보
  - 모션 종료 후보
  - 그룹 시퀀스 (헤더/바디/결과 구조)
  - 중간 상태 (반복 발생, 속성 수집용)
  - 선행조건 (모션 아님, 상태 변경)
  - 품질/결과 체크
  마크다운 테이블로 이벤트분석_v1.md 를 작성하라.
  ```
- 완료 → `output/이벤트분석_v1.md` 저장

#### 2-3. 사용자 대화 (채팅 UI)
- `st.chat_message` + `st.chat_input` 사용
- 대화 히스토리: `session_state['step2_chat_history']` (list of dict)
- 매 메시지마다 **전체 대화 히스토리 + 현재 이벤트분석_v1.md 내용**을 LLM 컨텍스트에 포함
- AI 응답 후 "이벤트분석_v1.md를 업데이트합니다" 가 포함되면 자동으로 파일 재저장
- **[✓ v2 확정 저장]** 버튼 클릭 시:
  - 현재 `이벤트분석_v1.md` 내용을 `이벤트분석_v2.md` 로 복사
  - `step2_done = True`
  - 사이드바 Step 3 활성화

**Streamlit UI 구성**:
```
[원시로그템플릿.md 생성] 버튼
→ st.expander("원시로그템플릿.md") : 생성 내용 표시

[이벤트분석 v1 생성] 버튼  (원시로그템플릿 완료 후 활성)
→ st.expander("이벤트분석_v1.md") : 생성 내용 표시

--- 대화창 ---
st.chat_message (AI / 사용자 번갈아)
st.chat_input ("수정 사항 입력...")
[✓ v2 확정 저장] 버튼
```

---

### Step 3 — Verification (Motion Pairing)

**역할**: 이벤트분석_v2.md의 후보 이벤트를 "모션"으로 구체화. 페어링 패턴 정의 및 사용자 확정.

**Step 2와의 차이**:
- Step 2: "이 이벤트가 무슨 의미인가" → 이벤트 코드 해석
- Step 3: "어떤 이벤트끼리 묶이는가" → 페어링 규칙, 시퀀스, 조건 명세

#### 페어링 패턴 4종 (LLM이 자동 분류, 사용자 확정)

| 패턴 | 설명 | 예시 |
|------|------|------|
| **Simple Pair** | Start/End 이벤트 1:1 쌍 | TR1001 → TR1099 |
| **Group Seq** | 헤더 → 바디(반복) → 결과 구조 | AL100 → AL101~AL1N9 → AL199 |
| **Conditional** | 필드값 기반 분기 또는 중첩 이벤트 | EX599.Result=NG → severity=NG |
| **Entity Key** | 엔티티 식별자(Wafer/Robot ID)로 분리 | Wafer=WFR006 기준으로 이벤트 묶기 |

#### 3-1. 모션_페어링_분석_v1.md 생성
- **프롬프트**: 이벤트분석_v2.md + 원시로그템플릿.md + 샘플 로그 + 아래 지시
  ```
  이벤트분석_v2.md의 모션 후보 이벤트들을 바탕으로:
  1. 각 모션 타입 이름 정의
  2. 페어링 패턴 분류 (Simple/Group/Conditional/EntityKey)
  3. Start 이벤트 코드, End 이벤트 코드, 중간 상태 이벤트
  4. 페어링 조건 (필드값, 엔티티 키)
  5. 중첩 모션 여부 (부모/자식 관계)
  6. 웨이퍼/장비 1사이클 전체 시퀀스
  7. SQLite 저장 필드 목록
  마크다운으로 모션_페어링_분석_v1.md 를 작성하라.
  ```

#### 3-2. 사용자 대화 (채팅 UI)
- Step 2와 동일한 채팅 구조
- 대화 히스토리: `session_state['step3_chat_history']`
- **[✓ v2 확정 저장]** 클릭 시:
  - `모션_페어링_분석_v2.md` 저장
  - `step3_done = True`

---

### Step 4 — Code Generation (ReAct Loop)

**역할**: 3개 md 파일을 참조해 ReAct 루프로 `parser_v1.py` 자동 생성 + 샘플 검증.

**참조 문서**: `원시로그템플릿.md` + `이벤트분석_v2.md` + `모션_페어링_분석_v2.md`

**파서 코드 요구사항**:
- 타임스탬프 기준 순차 처리
- 모션 페어링 패턴 4종 모두 처리 (Simple / Group / Conditional / EntityKey)
- 중첩 모션 지원 (parent_motion 필드)
- 페어링 타임아웃 처리
- SQLite `motion_events` 테이블 저장
- CLI 실행: `python parser_v1.py --input <로그파일> --db output/events.db`

**SQLite 스키마**:
```sql
CREATE TABLE motion_events (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id     TEXT,
  wafer_id         TEXT,
  motion_type      TEXT,
  motion_start_ts  DATETIME,
  motion_end_ts    DATETIME,
  duration_sec     REAL,
  severity         TEXT DEFAULT 'INFO',
  parent_motion_id INTEGER,
  attributes       TEXT,   -- JSON 문자열
  parser_version   TEXT DEFAULT 'v1',
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### ReAct 루프 구조 (최대 10회)

```
Iteration N:
  [Think]  md 파일 분석 → 코드 설계 / 이전 에러 원인 분석
  [Act]    Python 코드 생성
  [Observe] 샘플 로그로 exec() 실행
           → 성공(에러 0개): 루프 탈출 → parser_v1.py 저장
           → 실패: 에러 트레이스백을 다음 프롬프트에 포함 → 재시도
```

**탈출 조건**: 샘플 로그 전체를 에러 없이 처리 성공

**Streamlit UI**:
- 각 iteration을 `st.expander(f"Iteration {n} — {상태}")` 로 표시
- 상태: `🔄 실행중` / `✅ 성공` / `❌ 실패 → 재시도`
- expander 내부: [Think] / [Act 코드] / [Observe 결과] 탭
- 전체 진행: `st.progress(n / max_iter)`
- 완료 시: 생성 코드 `st.code(parser_v1_content, language='python')` 표시
- `step4_done = True`, Step 5 활성화

**프롬프트 구조 (최초)**:
```
당신은 Python 파싱 전문가입니다.
아래 3개 문서를 참고해 parser_v1.py를 작성하세요.

[원시로그템플릿.md]
{내용}

[이벤트분석_v2.md]
{내용}

[모션_페어링_분석_v2.md]
{내용}

요구사항:
- 타임스탬프 기준 순차 처리
- 페어링 패턴 4종 (Simple/Group/Conditional/EntityKey) 구현
- 중첩 모션 (parent_motion_id) 지원
- SQLite motion_events 테이블 저장
- CLI: python parser_v1.py --input <파일> --db <db경로>
- 완전한 실행 가능한 코드만 출력 (설명 없이)
```

**프롬프트 구조 (재시도)**:
```
이전 코드 실행 시 다음 에러가 발생했습니다:

[에러 트레이스백]
{traceback}

[실패한 로그 라인]
{failed_lines[:20]}

에러를 수정해서 parser_v1.py 전체 코드를 다시 작성하세요.
완전한 실행 가능한 코드만 출력 (설명 없이)
```

---

### Step 5 — Volume Test

**역할**: `parser_v1.py`로 `mcc-log-file/` 전체 로그를 처리. 성능 메트릭 시각화.

**처리**:
1. `mcc-log-file/` 하위 전체 로그 파일 목록 수집
2. 파일별 순차 처리: `subprocess.run(['python', 'output/parser_v1.py', '--input', 파일, '--db', 'output/events.db'])`
3. 결과 수집: 처리 라인 수, 파싱 성공/실패, 모션 이벤트 수

**성능 메트릭**:
| 메트릭 | 목표 | 계산 방법 |
|--------|------|-----------|
| Parse Rate | ≥ 0.95 | 성공 파싱 라인 / 전체 라인 |
| Pairing Rate | ≥ 0.90 | 완성된 모션 페어 / 시작 이벤트 수 |
| False Pair Rate | < 3% | 타임아웃 미완성 페어 / 전체 페어 |
| 처리 속도 | ≥ 1,000 ev/s | 이벤트 수 / 처리 시간 |

**Streamlit UI**:
- `st.progress` 바 (현재 파일 n/전체)
- 현재 처리 파일명 + 누적 통계 실시간 표시
- 완료 후 메트릭 카드 4종 (`st.metric`)
- SQLite 결과 테이블 미리보기 (`st.dataframe`)
- 모션 타입별 집계 바 차트 (`st.bar_chart`)
- 성능 미달 시 재작업 경로 안내:
  - Parse Rate 미달 → "Step 2 재분석 권장"
  - Pairing Rate 미달 → "Step 3 페어링 규칙 보완 권장"
  - False Pair 초과 → "Step 4 파서 재생성 권장"
- `step5_done = True`

---

## 6. 공통 유틸리티

### `utils/llm_client.py`
```python
class LLMClient:
    def __init__(self, base_url, model, api_key)
    def chat(self, messages, stream=False, temperature=0.3, max_tokens=4096) -> str
    def stream_chat(self, messages, ...) -> Generator[str]
    # Qwen3 특성: <think>...</think> 태그 자동 제거
    # 재시도: 최대 3회, 1초 간격
```

### `utils/log_sampler.py`
```python
def scan_log_files(base_dir: str) -> list[dict]
    # 반환: [{path, size_mb, total_lines, encoding}, ...]

def sample_logs(file_infos: list, target_lines: int) -> list[str]
    # 파일별 비례 배분 → stride 균등 샘플링
    # 반환: 샘플 라인 리스트

def estimate_tokens(lines: list[str]) -> int
    # 평균 글자 수 / 3.5 로 토큰 추정
```

### `utils/file_manager.py`
```python
OUTPUT_DIR = Path("output")

def save_md(filename: str, content: str) -> None
def load_md(filename: str) -> str | None
def save_py(filename: str, content: str) -> None
def load_py(filename: str) -> str | None
def check_step_done(step: int) -> bool
    # step별 필수 파일 존재 여부 확인
```

### `ai_config.py`
```python
DEFAULT_CONFIG = {
    "base_url": "http://192.168.0.8:8080/v1",
    "model": "qwen3.5:9b",
    "api_key": "sk_123!",
}

def render_config_sidebar() -> dict
    # st.sidebar에 텍스트 입력 3개 렌더링
    # session_state['ai_config'] 에 저장
    # 반환: 현재 설정 dict
```

---

## 7. 구현 규칙 (Claude Code 필독)

### 절대 규칙
1. **`mcc-log-file/` 폴더는 절대 수정하지 않는다.** 읽기 전용.
2. **모든 생성 파일은 `output/` 폴더에만 저장**한다.
3. **LLM 응답에서 코드 블록 추출 시** ` ```python ... ``` ` 펜스를 반드시 제거한 순수 코드만 사용.
4. **Step 진행은 단방향**이지만, 사이드바에서 이전 Step으로 이동해 재작업은 허용.
5. **session_state 키는 명세된 이름 그대로** 사용. 임의 변경 금지.

### 코드 품질 규칙
- 모든 파일 상단에 한글 docstring으로 목적 설명
- LLM API 호출은 반드시 try/except로 감싸고 에러 시 `st.error` 표시
- 긴 LLM 응답은 반드시 스트리밍으로 처리 (`stream=True`)
- `exec()` 실행 시 반드시 `try/except Exception as e` 로 트레이스백 캡처
- subprocess 실행 시 `timeout=300` 설정

### 스타일 규칙
- 모든 주석은 한글
- Streamlit UI 텍스트는 한글
- 변수명·함수명은 영어 (snake_case)
- 상수는 대문자 (UPPER_CASE)

### Streamlit 특이사항
- `st.rerun()` 사용 시 무한 루프 주의 → 플래그로 제어
- 채팅 UI는 `st.chat_message` + `st.chat_input` 조합 사용
- LLM 스트리밍은 `st.write_stream(generator)` 사용
- 대용량 루프(Volume Test)는 `st.empty()` placeholder 업데이트 방식 사용

---

## 8. 샘플 로그 참고 (반도체 노광장비 예시)

실제 `mcc-log-file/` 에 있는 로그와 다를 수 있음. Step 1-2에서 자동 파악.

```
2026-04-19 09:34:05.830   EVT#PA401   Wafer=WFR006  NotchAngle=267.4  CenterX=0.451
2026-04-19 09:34:06.528   EVT#AL100   Wafer=WFR006  Marks=11  ResidualX=2.0
2026-04-19 09:34:06.778   EVT#AL101   Wafer=WFR006  Mark=M01  X=0.1  Quality=Good
...
2026-04-19 09:34:08.843   EVT#AL199   Wafer=WFR006  ResidualFinal=1.2  Status=Pass
2026-04-19 09:34:09.562   EVT#EX500   Wafer=WFR006  Dose=20.1  Focus=0.053  Seq=1006
2026-04-19 09:34:10.012   EVT#ST3002  Wafer=WFR006  ScanMode=Continuous  Direction=Forward
2026-04-19 09:34:10.618   EVT#SC701   Wafer=WFR006  Field=1  PosX=12.55  ScanSpeed=102.77
...
2026-04-19 09:34:50.004   EVT#ST3003  Wafer=WFR006  ScanMode=Continuous  Status=Complete
2026-04-19 09:34:51.299   EVT#EX599   Wafer=WFR006  Result=NG  Seq=1006  Overlay=4.5
```

**이 로그의 웨이퍼 1사이클 시퀀스**:
```
WAFER_LOAD → PRE_ALIGN → ALIGNMENT → EXPOSE(⊃SCAN) → FOCUS_CHECK → WAFER_UNLOAD
```

**중첩 구조**: EXPOSE(EX500→EX599) 안에 SCAN(ST3002→ST3003)이 포함됨.

---

## 9. requirements.txt

```
streamlit>=1.32.0
openai>=1.20.0
chardet>=5.0.0
pathlib2>=2.3.7
```
