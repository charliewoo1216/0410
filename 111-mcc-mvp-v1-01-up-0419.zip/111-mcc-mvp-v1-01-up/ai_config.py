"""
AI 설정 사이드바 — LLM Base URL / Model / API Key 입력 UI.
session_state['ai_config'] 에 현재 설정을 보관한다.
"""
from __future__ import annotations

import streamlit as st


DEFAULT_CONFIG: dict[str, str] = {
    "base_url": "http://192.168.0.8:8080/v1",
    "model": "qwen3.5:9b",
    "api_key": "sk_123!",
}


def render_config_sidebar() -> dict:
    """사이드바 상단에 AI Config 섹션을 렌더링하고 현재 설정 dict을 반환한다."""
    if "ai_config" not in st.session_state:
        st.session_state["ai_config"] = DEFAULT_CONFIG.copy()

    cfg = st.session_state["ai_config"]

    with st.sidebar:
        st.markdown(
            """
            <div class="mcc-side-title">⚙ AI CONFIG</div>
            """,
            unsafe_allow_html=True,
        )
        cfg["base_url"] = st.text_input(
            "Base URL",
            value=cfg.get("base_url", DEFAULT_CONFIG["base_url"]),
            key="cfg_base_url",
        )
        cfg["model"] = st.text_input(
            "Model",
            value=cfg.get("model", DEFAULT_CONFIG["model"]),
            key="cfg_model",
        )
        cfg["api_key"] = st.text_input(
            "API Key",
            value=cfg.get("api_key", DEFAULT_CONFIG["api_key"]),
            type="password",
            key="cfg_api_key",
        )

    st.session_state["ai_config"] = cfg
    return cfg
