"""
Motion Parser MVP v1 — Streamlit 메인 진입점.
사이드바에서 5단계 워크플로우를 라우팅하고, 각 step의 render()를 호출한다.
다크 테마 CSS(설계참고.html 기반)를 전역 주입한다.
"""
from __future__ import annotations

import streamlit as st

import ai_config
from utils import file_manager
from utils.debug_logger import log_event
from steps import (
    step1_log_selection,
    step2_ai_analysis,
    step3_verification,
    step4_code_generation,
    step5_volume_test,
)


# ─────────────────────────────────────────────
# 페이지 설정
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="MPX · MVP v1 — Motion Parser",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ─────────────────────────────────────────────
# 글로벌 CSS (다크 테마 + 타이포그래피)
# ─────────────────────────────────────────────
GLOBAL_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;700&family=Noto+Sans+KR:wght@400;500;700;900&display=swap');

:root {
  --bg:       #0D1117;
  --bg2:      #161B22;
  --bg3:      #1C2128;
  --bg4:      #21262D;
  --border:   rgba(255,255,255,.07);
  --border2:  rgba(255,255,255,.14);
  --text:     #E6EDF3;
  --text2:    #8B949E;
  --text3:    #484F58;
  --green:    #3FB950;
  --green2:   rgba(63,185,80,.12);
  --green3:   rgba(63,185,80,.06);
  --blue:     #58A6FF;
  --blue2:    rgba(88,166,255,.12);
  --purple:   #A371F7;
  --purple2:  rgba(163,113,247,.12);
  --orange:   #F0883E;
  --orange2:  rgba(240,136,62,.12);
  --yellow:   #E3B341;
  --yellow2:  rgba(227,179,65,.12);
  --red:      #F85149;
  --red2:     rgba(248,81,73,.12);
  --pink:     #FF7EB6;
  --pink2:    rgba(255,126,182,.12);
}

/* 배경 */
.stApp {
  background: var(--bg);
  color: var(--text);
  font-family: 'Noto Sans KR', sans-serif;
}
.stApp::before {
  content:'';
  position:fixed; inset:0; z-index:0;
  background-image: radial-gradient(circle, rgba(255,255,255,.03) 1px, transparent 1px);
  background-size: 28px 28px;
  pointer-events:none;
}

/* 사이드바 */
[data-testid="stSidebar"] {
  background: var(--bg2);
  border-right: 1px solid var(--border);
}
[data-testid="stSidebar"] * {
  color: var(--text);
}
.mcc-side-title {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 11px; font-weight: 700;
  color: var(--green);
  letter-spacing: .12em;
  margin: 4px 0 10px 0;
  padding-bottom: 10px;
  border-bottom: 1px solid var(--border);
}
.mcc-side-section {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 10px; font-weight: 700;
  color: var(--text3);
  letter-spacing: .12em;
  text-transform: uppercase;
  margin: 18px 0 8px 0;
}

/* 사이드바 버튼 — Step */
[data-testid="stSidebar"] .stButton button {
  width: 100%;
  background: var(--bg3);
  color: var(--text2);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 10px 12px;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 12px;
  font-weight: 600;
  text-align: left;
  transition: all .15s;
}
[data-testid="stSidebar"] .stButton button:hover {
  border-color: var(--border2);
  background: var(--bg4);
  color: var(--text);
}
[data-testid="stSidebar"] .stButton button:disabled {
  opacity: .4;
  cursor: not-allowed;
}

/* 입력 요소 */
.stTextInput input, .stTextArea textarea, .stSelectbox div[role="combobox"] {
  background: var(--bg3) !important;
  color: var(--text) !important;
  border: 1px solid var(--border) !important;
  border-radius: 5px !important;
  font-family: 'IBM Plex Mono', monospace !important;
  font-size: 12px !important;
}
.stSlider [role="slider"] { background: var(--green) !important; }

/* 메트릭 */
[data-testid="stMetricValue"] {
  font-family: 'IBM Plex Mono', monospace !important;
  font-size: 28px !important;
  font-weight: 900 !important;
  color: var(--text) !important;
  letter-spacing: -.02em;
}
[data-testid="stMetricLabel"] {
  color: var(--text3) !important;
  font-family: 'IBM Plex Mono', monospace !important;
  font-size: 10px !important;
  letter-spacing: .07em;
  text-transform: uppercase;
}

/* 헤더 - 각 Step 섹션 */
.mcc-step-header {
  display: flex; align-items: center; gap: 14px;
  padding: 18px 0 20px 0;
  border-bottom: 1px solid var(--border);
  margin-bottom: 24px;
}
.mcc-step-badge {
  width: 44px; height: 44px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 14px; font-weight: 800;
  flex-shrink: 0;
}
.mcc-step-title {
  font-size: 22px; font-weight: 800;
  font-family: 'IBM Plex Mono', monospace;
  letter-spacing: -.02em;
  margin-bottom: 2px;
}
.mcc-step-desc {
  color: var(--text2); font-size: 12px; line-height: 1.6;
}
.mcc-step-tag {
  margin-left: auto;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 9px; font-weight: 700;
  padding: 4px 10px; border-radius: 4px;
  letter-spacing: .07em; text-transform: uppercase;
}

/* 카드 */
.mcc-card {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 14px 16px;
  margin-bottom: 12px;
  position: relative;
  overflow: hidden;
}
.mcc-card-accent {
  position: absolute; top: 0; left: 0; right: 0;
  height: 2px;
}
.mcc-card-title {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 11px; font-weight: 700;
  color: var(--text); margin-bottom: 6px;
  letter-spacing: .02em;
}
.mcc-card-body {
  font-size: 11.5px; color: var(--text2); line-height: 1.65;
}

/* info box */
.mcc-info {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-left: 3px solid var(--green);
  border-radius: 5px;
  padding: 12px 16px;
  font-size: 12px; color: var(--text2); line-height: 1.65;
  margin-bottom: 16px;
}
.mcc-info.blue   { border-left-color: var(--blue); }
.mcc-info.orange { border-left-color: var(--orange); }
.mcc-info.purple { border-left-color: var(--purple); }
.mcc-info.red    { border-left-color: var(--red); }

/* 태그 */
.mcc-tag {
  display:inline-block;
  font-family:'IBM Plex Mono',monospace;
  font-size: 9px; font-weight: 700;
  padding: 2px 7px; border-radius: 3px;
  margin-right: 4px;
  letter-spacing: .04em;
}
.mcc-tag.g { color:var(--green);  background:var(--green2);  border:1px solid rgba(63,185,80,.25); }
.mcc-tag.b { color:var(--blue);   background:var(--blue2);   border:1px solid rgba(88,166,255,.25); }
.mcc-tag.p { color:var(--purple); background:var(--purple2); border:1px solid rgba(163,113,247,.25); }
.mcc-tag.o { color:var(--orange); background:var(--orange2); border:1px solid rgba(240,136,62,.25); }
.mcc-tag.y { color:var(--yellow); background:var(--yellow2); border:1px solid rgba(227,179,65,.25); }
.mcc-tag.r { color:var(--red);    background:var(--red2);    border:1px solid rgba(248,81,73,.25); }
.mcc-tag.pk{ color:var(--pink);   background:var(--pink2);   border:1px solid rgba(255,126,182,.25); }

/* Expander 다크 */
.streamlit-expanderHeader, [data-testid="stExpander"] summary {
  background: var(--bg2) !important;
  border: 1px solid var(--border) !important;
  border-radius: 6px !important;
  color: var(--text) !important;
  font-family: 'IBM Plex Mono', monospace !important;
  font-size: 12px !important;
}
[data-testid="stExpander"] {
  border: 1px solid var(--border) !important;
  border-radius: 6px !important;
  background: var(--bg2) !important;
  margin-bottom: 10px;
}

/* Dataframe 다크 */
[data-testid="stDataFrame"] { background: var(--bg2); border: 1px solid var(--border); border-radius: 6px; }

/* 코드 블록 */
.stCode, pre, code {
  background: var(--bg3) !important;
  color: var(--text) !important;
  font-family: 'IBM Plex Mono', monospace !important;
  font-size: 11px !important;
  border-radius: 5px !important;
}

/* 채팅 메시지 */
[data-testid="stChatMessage"] {
  background: var(--bg2) !important;
  border: 1px solid var(--border) !important;
  border-radius: 8px !important;
  margin-bottom: 8px !important;
}
[data-testid="stChatInput"] textarea {
  background: var(--bg3) !important;
  color: var(--text) !important;
  border: 1px solid var(--border) !important;
}

/* progress */
.stProgress > div > div > div {
  background: var(--green) !important;
}

/* 일반 버튼 강조 (메인 영역) */
div[data-testid="stMainBlockContainer"] .stButton button[kind="primary"] {
  background: var(--green) !important;
  color: #000 !important;
  border: 1px solid var(--green) !important;
  font-weight: 700 !important;
  font-family: 'IBM Plex Mono', monospace !important;
}

/* 스크롤바 */
::-webkit-scrollbar { width: 10px; height: 10px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--bg4); border-radius: 5px; }
::-webkit-scrollbar-thumb:hover { background: var(--border2); }

/* 구분선 */
hr { border-color: var(--border) !important; }
</style>
"""

st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


# ─────────────────────────────────────────────
# output 폴더 보장
# ─────────────────────────────────────────────
file_manager.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# 앱 부팅 마커 (세션당 1회)
if not st.session_state.get("_boot_logged"):
    log_event("app", "세션 시작")
    st.session_state["_boot_logged"] = True


# ─────────────────────────────────────────────
# session_state 초기화
# ─────────────────────────────────────────────
def _init_state() -> None:
    defaults = {
        "current_step": 1,
        # step1: 세션 기반. sampled_lines 존재 여부로 판단
        "sampled_lines": [],
        "step1_done": False,
        # step 2~5: 파일 기반
        "step2_done": file_manager.check_step_done(2),
        "step3_done": file_manager.check_step_done(3),
        "step4_done": file_manager.check_step_done(4),
        "step5_done": file_manager.check_step_done(5),
        # 채팅 히스토리
        "step2_chat_history": [],
        "step3_chat_history": [],
        # Step 2 하위 상태
        "step2_template_done": (file_manager.load_md("원시로그템플릿.md") is not None),
        "step2_events_v1_done": (file_manager.load_md("이벤트분석_v1.md") is not None),
        # Step 3 하위 상태
        "step3_pairing_v1_done": (file_manager.load_md("모션_페어링_분석_v1.md") is not None),
        # Step 4 iterations
        "step4_iterations": [],
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


_init_state()


# ─────────────────────────────────────────────
# 사이드바 — AI Config + Step 라우터
# ─────────────────────────────────────────────
ai_config.render_config_sidebar()

STEP_META = [
    (1, "Log Selection",   "Sampler", "blue"),
    (2, "AI Analysis",     "LLM",     "purple"),
    (3, "Verification",    "HITL",    "orange"),
    (4, "Code Generation", "ReAct",   "green"),
    (5, "Volume Test",     "SQLite",  "pink"),
]


def _is_step_enabled(step_num: int) -> bool:
    if step_num == 1:
        return True
    prev_done_key = f"step{step_num - 1}_done"
    return bool(st.session_state.get(prev_done_key, False))


def _render_sidebar_steps() -> None:
    st.sidebar.markdown('<div class="mcc-side-section">▸ WORKFLOW</div>', unsafe_allow_html=True)
    for num, name, badge, _color in STEP_META:
        done = st.session_state.get(f"step{num}_done", False)
        enabled = _is_step_enabled(num)
        active = st.session_state["current_step"] == num

        prefix = "✅" if done else ("▸" if active else "  ")
        label = f"{prefix}  0{num}  {name}    ({badge})"

        if st.sidebar.button(
            label,
            key=f"nav_step_{num}",
            disabled=not enabled,
            width="stretch",
        ):
            st.session_state["current_step"] = num
            log_event("nav", "Step 전환", f"→ step{num} ({name})")
            st.rerun()


_render_sidebar_steps()

# 사이드바 하단 정보
st.sidebar.markdown('<div class="mcc-side-section">▸ INFO</div>', unsafe_allow_html=True)
st.sidebar.markdown(
    f"""<div style="font-family:'IBM Plex Mono',monospace;font-size:10px;color:var(--text3);line-height:1.8;">
    samples: <span style="color:var(--text2);">{len(st.session_state.get('sampled_lines', []))}</span><br>
    output: <span style="color:var(--text2);">{file_manager.OUTPUT_DIR}</span>
    </div>""",
    unsafe_allow_html=True,
)


# ─────────────────────────────────────────────
# 메인 라우터
# ─────────────────────────────────────────────
STEP_RENDERERS = {
    1: step1_log_selection.render,
    2: step2_ai_analysis.render,
    3: step3_verification.render,
    4: step4_code_generation.render,
    5: step5_volume_test.render,
}

current = st.session_state["current_step"]
renderer = STEP_RENDERERS.get(current, step1_log_selection.render)
renderer()
