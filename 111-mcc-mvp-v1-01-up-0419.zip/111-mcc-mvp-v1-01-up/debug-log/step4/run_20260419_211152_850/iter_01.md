# Iteration 1 — OK

- timestamp : `2026-04-19 21:13:43.389`
- duration  : `109.76s`
- response_chars : `15974`
- code_chars     : `11870`
- sandbox_ok     : `True`

## Think

1차 시도: 3개 md 분석 → MOTION_PAIRS 설계 → CLI 파서 작성.

## User Prompt

```
아래 3개 문서를 참고해 **parser_v1.py** 전체 코드를 작성하세요.

[원시로그템플릿.md]
Thinking Process:

1.  **Analyze the Request:**
    *   Input: A sample log file containing semiconductor equipment events (wafer processing, robot movement, alignment, exposure, etc.).
    *   Task: Create a `원시로그템플릿.md` (Raw Log Template) based on the analysis of the provided log.
    *   Required Sections:
        1.  Equipment Type Inference (장비 유형 추론)
        2.  Timestamp Pattern (타임스탬프 패턴)
        3.  Event Code Naming Rules (이벤트 코드 네이밍 규칙)
        4.  Field Structure (필드 구조)
        5.  Special Notes (특이사항)
    *   Output Format: Markdown only.

2.  **Analyze the Log Content:**
    *   **Header:** `당022 Overlay=0.7 TotalFields=10` (Looks like a summary or header line, possibly from a specific system).
    *   **Timestamps:** `2026-04-19 09:46:54.602` (YYYY-MM-DD HH:MM:SS.mmm).
    *   **Events:**
        *   `EVT#F901`: Focus/Spec check (FocusDrift, Spec, Status).
        *   `EVT#ST3099`: Chuck Release (Wafer Unload).
        *   `EVT#TR2001`: Transfer Start (Unload).
        *   `EVT#RB2101` ~ `RB2105`: Robot Arm 1 movements (R, Z, Vacuum, etc.).
        *   `EVT#TR2099`: Transfer End (Stored).
        *   `EVT#TR1001`: Transfer Start (Load).
        *   `EVT#RB2001` ~ `RB2005`: Robot Arm 1 movements (Load).
        *   `EVT#TR1099`: Transfer End (Placed).
        *   `EVT#ST3001`: Chuck Lock.
        *   `EVT#PA401`: Alignment/Positioning (NotchAngle, CenterX/Y).
        *   `EVT#AL100`: Alignment Start (Marks, Residual).
        *   `EVT#AL101` ~ `AL116`: Alignment Marks (Mark ID, X, Y, Quality).
        *   `EVT#AL199`: Alignment End (ResidualFinal, Status).
        *   `EVT#EX500`: Exposure Start (Dose, Focus, Seq, Field).
        *   `EVT#ST3002`: Scan Start (Mode, Direction).
        *   `EVT#SC701`: Scan Field (Field ID, PosX, PosY, ScanSpeed).
        *   `EVT#ST3003`: Scan End (Status).
        *   `EVT#EX599`: Exposure End (Result, Overlay, TotalFields).
        *   `EVT#F901`: Focus Check (Post-exposure?).
        *   `EVT#SYS200`: System Status (Throughput, LotProgress).
    *   **Entities:** Wafer (WFR021, WFR022...), Robot (RB_ARM1), Chuck (CHK_A), FOUP, Stage.
    *   **Process Flow:** Load -> Lock -> Align -> Expose -> Focus Check -> Unlock -> Unload.
    *   **Equipment Type:** Semiconductor Lithography Tool (Scanner/Stepper). Specifically, it involves wafer handling (FOUP <-> Chuck), alignment, exposure, and robot movement. The presence of "Overlay", "Dose", "Focus", "Scan", "Field" strongly suggests a Lithography Scanner (e.g., ASML, Canon, Nikon, or generic simulation).

3.  **Drafting the Sections:**

    *   **1. 장비 유형 추론 (Equipment Type Inference):**
        *   Inference: Semiconductor Lithography Scanner (Step-and-Scan or Step-and-Repeat).
        *   Evidence: "Overlay", "Dose", "Focus", "Field", "Scan", "Wafer", "FOUP", "Chuck", "Alignment Marks".
        *   Reasoning: The workflow (Load -> Align -> Expose -> Unload) is typical of a lithography tool.

    *   **2. 타임스탬프 패턴 (Timestamp Pattern):**
        *   Format: `YYYY-MM-DD HH:MM:SS.mmm`
        *   Precision: Millisecond (3 decimal places).
        *   Example: `2026-04-19 09:46:54.602`

    *   **3. 이벤트 코드 네이밍 규칙 (Event Code Naming Rules):**
        *   Prefix: `EVT#`
        *   Structure: `EVT#[Category][Sequence]`
        *   Categories:
            *   `F`: Focus/Spec (`F901`)
            *   `ST`: Stage/Chuck Status (`ST3099`, `ST3001`, `ST3002`, `ST3003`)
            *   `TR`: Transfer (`TR2001`, `TR2099`, `TR1001`, `TR1099`)
            *   `RB`: Robot (`RB2101`~`RB2105`, `RB2001`~`RB2005`)
            *   `PA`: Positioning/Alignment (`PA401`)
            *   `AL`: Alignment (`AL100`, `AL101`~`AL116`, `AL199`)
            *   `EX`: Exposure (`EX500`, `EX599`)
            *   `SC`: Scan (`SC701`)
            *   `SYS`: System (`SYS200`)
        *   Numbering: Seems to be grouped by function (e.g., 100-199 for Transfer/Robot, 200-299 for System/Stage, 300-399 for Chuck/Scan, 400-499 for Positioning, 500-599 for Exposure, 700-799 for Scan, 900-999 for Focus). *Correction:* Looking closely, `RB` is 2000s, `TR` is 2000s, `ST` is 3000s, `PA` is 4000s, `AL` is 1000s, `EX` is 5000s, `SC` is 7000s, `SYS` is 2000s. Wait, let's re-examine the numbers.
            *   `F901` (900s)
            *   `ST3099` (3000s)
            *   `TR2001` (2000s)
            *   `RB2101` (2000s)
            *   `TR1001` (1000s)
            *   `PA401` (400s)
            *   `AL100` (100s)
            *   `EX500` (500s)
            *   `SC701` (700s)
            *   `SYS200` (200s)
        *   Rule: `EVT#[FunctionCode][Sequence]`. Function codes seem to map to subsystems (100: Align, 200: Transfer/Robot/System, 300: Stage/Chuck, 400: Position, 500: Exposure, 700: Scan, 900: Focus).

    *   **4. 필드 구조 (Field Structure):**
        *   Format: `KEY=VALUE` (Space separated).
        *   Common Fields: `Wafer`, `Status`, `Duration`, `Cmd`.
        *   Specific Fields per Event:
            *   Robot: `Robot`, `Axis`, `Extend`, `Down`, `Vacuum`, `Speed`.
            *   Alignment: `Marks`, `ResidualX`, `ResidualY`, `Mark`, `X`, `Y`, `Quality`.
            *   Exposure: `Dose`, `Focus`, `Seq`, `Field`, `Result`, `Overlay`, `TotalFields`.
            *   Scan: `Field`, `PosX`, `PosY`, `ScanSpeed`.
            *   System: `Throughput`, `LotProgress`, `State`.

    *   **5. 특이사항 (Special Notes):**
        *   Grouping: Events are grouped by Wafer processing cycle (Load -> Process -> Unload).
        *   Comments: Lines starting with `#` indicate section headers (e.g., `# --- Wafer WFR021 Unload ---`).
        *   Entity IDs: Wafer IDs follow `WFR` + Number. Robot is `RB_ARM1`. Chuck is `CHK_A`.
        *   Header Line: First line contains summary info (`당022`, `Overlay`, `TotalFields`).
        *   Timestamps are strictly increasing within a cycle but reset or jump between wafers.

4.  **Refining the Output (Korean):**
    *   Translate concepts accurately.
    *   Ensure Markdown formatting is clean.
    *   Check against the "Raw Log Template" requirement.

5.  **Final Review:**
    *   Does it cover all 5 sections? Yes.
    *   Is it based *only* on the provided log? Yes.
    *   Is it Markdown? Yes.

    *Self-Correction on Event Codes:*
    Looking at `RB2101` vs `RB2001`.
    `TR2001` (Unload Start) vs `TR1001` (Load Start).
    `AL100` (Align Start) vs `AL199` (Align End).
    `EX500` (Expose Start) vs `EX599` (Expose End).
    `SC701` (Scan Field).
    `ST3001` (Lock), `ST3002` (Scan Start), `ST3003` (Scan End), `ST3099` (Unlock).
    `F901` (Focus Check).
    `SYS200` (System Status).
    `TR2099` (Unload End), `TR1099` (Load End).
    The numbering isn't strictly sequential across all types, but grouped by function. I will describe this grouping.

    *Header Line:* `당022 Overlay=0.7 TotalFields=10`. This looks like a summary header for the batch or specific run. I should mention it as a special header line.

    *Timestamp:* `2026-04-19 09:46:54.602`. Note the year is 2026 (future date relative to now, but valid format).

    *Fields:* Space-separated `KEY=VALUE`. No CSV delimiters visible in the main lines, just spaces.

    Let's construct the Markdown.

    *Structure:*
    # 원시로그템플릿.md
    ## 1. 장비 유형 추론
    ...
    ## 2. 타임스탬프 패턴
    ...
    ## 3. 이벤트 코드 네이밍 규칙
    ...
    ## 4. 필드 구조
    ...
    ## 5. 특이사항
    ...

    *Content Check:*
    - Equipment: Lithography Scanner (Step-and-Scan).
    - Timestamp: ISO-like with milliseconds.
    - Event Codes: Prefix EVT#, Function Grouping.
    - Fields: Space-separated Key=Value.
    - Special: Comments (#), Wafer IDs, Robot IDs.

    Ready to write.cw# 원시로그템플릿.md

## 1. 장비 유형 추론
*   **추론 결과**: 반도체 리소그래피 스캐너 (Lithography Scanner / Stepper)
*   **근거**:
    *   **공정 흐름**: FOUP 에서 웨이퍼 로딩 (Load) → Chuck 로킹 (Lock) → 정렬 (Alignment) → 노광 (Exposure/Scan) → 포커스 체크 (Focus Check) → Chuck 릴리스 (Release) → FOUP 로 언로드 (Unload) 순서로 진행됨.
    *   **키워드**: `Overlay`, `Dose`, `Focus`, `Field`, `Scan`, `Wafer`, `FOUP`, `Chuck`, `Alignment Marks`.
    *   **데이터**: 노광 시퀀스 (`Seq`), 필드 위치 (`PosX`, `PosY`), 오버레이 오버레이 (`Overlay`), 노광량 (`Dose`) 등 리소그래피 전용 파라미터가 존재함.

## 2. 타임스탬프 패턴
*   **포맷**: `YYYY-MM-DD HH:MM:SS.mmm`
*   **정밀도**: 밀리초 (3 자리 소수점)
*   **예시**: `2026-04-19 09:46:54.602`
*   **특징**: 로그 시작 시점부터 순차적으로 증가하며, 웨이퍼 사이클 전환 시에도 시간 흐름이 유지됨.

## 3. 이벤트 코드 네이밍 규칙
*   **기본 형식**: `EVT#[기능코드][순번]`
*   **접두사 그룹**:
    *   `EVT#`: 모든 이벤트 시작 접두사.
    *   `F`: 포커스/스펙 체크 (`F901`)
    *   `ST`: 스테이지/Chuck 상태 (`ST3001`~`ST3003`, `ST3099`)
    *   `TR`: 이송/전송 (`TR1001`~`TR1099`, `TR2001`~`TR2099`)
    *   `RB`: 로봇 암 동작 (`RB2001`~`RB2005`, `RB2101`~`RB2105`)
    *   `PA`: 위치/노치 정렬 (`PA401`)
    *   `AL`: 정렬 마크 (`AL100`~`AL199`)
    *   `EX`: 노광 (`EX500`, `EX599`)
    *   `SC`: 스캔 (`SC701`)
    *   `SYS`: 시스템 상태 (`SYS200`)
*   **번호 체계**: 기능별로 100 단위 간격으로 할당된 후 순번이 부여됨 (예: `AL`은 100 대 199, `EX`는 500 대 599).

## 4. 필드 구조
*   **구분자**: `=` (Key=Value), 필드 간 구분은 공백 (Space)
*   **공통 필드**: `Wafer`, `Status`, `Cmd`, `Duration`
*   **이벤트별 필드**:
    *   **로봇 (`RB`)**: `Robot`, `Axis`, `Extend`, `Down`, `Vacuum`, `Pressure`, `Speed`, `Status`
    *   **정렬 (`AL`)**: `Marks`, `ResidualX`, `ResidualY`, `Mark`, `X`, `Y`, `Quality`
    *   **노광 (`EX`)**: `Dose`, `Focus`, `Seq`, `Field`, `Result`, `Overlay`, `TotalFields`
    *   **스캔 (`SC`)**: `Field`, `PosX`, `PosY`, `ScanSpeed`
    *   **시스템 (`SYS`)**: `Throughput`, `LotProgress`, `State`
    *   **포커스 (`F`)**: `FocusDrift`, `Spec`, `Status`

## 5. 특이사항
*   **그룹화 구조**: 로그는 웨이퍼별 처리 사이클 (Load → Process → Unload) 로 명확히 구분되며, 각 사이클 시작/종료 시 `# --- Wafer [ID] [Action] ---` 주석으로 구분됨.
*   **엔티티 식별자**:
    *   웨이퍼: `WFR` + 3 자리 숫자 (예: `WFR021`)
    *   로봇: `RB_ARM1`
    *   Chuck: `CHK_A`
*   **헤더 라인**: 로그 최상단에 `당022 Overlay=0.7 TotalFields=10` 형태의 요약 정보 라인 존재.
*   **상태 변경**: `Status` 필드는 `Released`, `Locked`, `Stored`, `Pass`, `OK` 등 상태 변화를 명확히 기록.
*   **마크 품질**: 정렬 마크 (`AL101`~`AL116`) 에서 `Quality` 필드가 `Good` 또는 `Marginal` 로 구분됨.

[이벤트분석_v2.md]
Thinking Process:

1.  **Analyze the Request:**
    *   Input: A log file snippet containing semiconductor manufacturing equipment events (wafer processing, robot movements, alignment, exposure, scanning, etc.).
    *   Task: Extract specific information from the log and format it as Markdown.
    *   Required Content:
        1.  **Event Code List (Deduplicated)** with estimated meanings.
        2.  **Motion-related Candidate Classification** (Markdown table: Code / Meaning / Classification).
            *   Classifications: `모션 시작` (Motion Start), `모션 종료` (Motion End), `그룹 시퀀스` (Group Sequence), `중간 상태` (Intermediate State), `선행조건(모션 아님)` (Precondition/Not Motion), `품질/결과 체크` (Quality/Result Check).
        3.  **Group Sequence Estimation** (Header -> Body (Repetition) -> Result structure).
        4.  **Entity Identifiers** (Keys separating motions, e.g., Wafer, Robot).
    *   Constraint: Output **only** Markdown.

2.  **Analyze the Log Data:**
    *   **Header:** `당22 Overlay=0.7 TotalFields=10` (Looks like a summary or config line, possibly irrelevant for event extraction but good for context).
    *   **Events:**
        *   `EVT#F901`: Focus/Spec check (Wafer=WFR021).
        *   `EVT#ST3099`: Chuck Release (Wafer=WFR021).
        *   `EVT#TR2001`: Transfer Start (Unload).
        *   `EVT#RB2101` ~ `RB2105`: Robot Arm 1 Unload sequence (R, Z, Vacuum, Z, R).
        *   `EVT#TR2099`: Transfer End (Stored).
        *   `EVT#TR1001`: Transfer Start (Load).
        *   `EVT#RB2001` ~ `RB2005`: Robot Arm 1 Load sequence (R, Z, Vacuum, Z, R).
        *   `EVT#TR1099`: Transfer End (Placed).
        *   `EVT#ST3001`: Chuck Lock.
        *   `EVT#PA401`: Alignment/Positioning (Notch, Center).
        *   `EVT#AL100`: Alignment Start (Marks count, Residuals).
        *   `EVT#AL101` ~ `AL116`: Individual Mark Alignment.
        *   `EVT#AL199`: Alignment End (ResidualFinal, Status).
        *   `EVT#EX500`: Exposure Start (Dose, Focus, Seq, Field).
        *   `EVT#ST3002`: Scan Start (Mode, Direction).
        *   `EVT#SC701`: Scan Field (Field ID, Pos, Speed).
        *   `EVT#ST3003`: Scan End (Complete).
        *   `EVT#EX599`: Exposure End (Result, Overlay, Fields).
        *   `EVT#F901`: Focus Check (Post-exposure).
        *   `EVT#SYS200`: System Status (Throughput, LotProgress).

    *   **Wafer Sequence:** WFR021 (Unload), WFR022 (Load->Process->Unload), WFR023 (Load->Process->Unload), WFR024 (Load->Process->Unload), WFR025 (Load->Process->Unload).
    *   **Robot:** RB_ARM1.
    *   **Stage/Chuck:** CHK_A.
    *   **FOUP:** FOUP.

3.  **Drafting Content - Section 1: Event Code List (Deduplicated)**
    *   Need to list unique EVT codes found.
    *   F901, ST3099, TR2001, RB2101-2105, TR2099, TR1001, RB2001-2005, TR1099, ST3001, PA401, AL100, AL101-116, AL199, EX500, ST3002, SC701, ST3003, EX599, SYS200.
    *   Add estimated meanings based on context.

4.  **Drafting Content - Section 2: Motion-related Candidate Classification**
    *   Filter codes that represent physical movement or state changes related to motion.
    *   Classifications:
        *   `모션 시작`: TR1001, RB2001 (Extend), ST3002 (Scan Start).
        *   `모션 종료`: TR2099, RB2105 (Retract), ST3003 (Scan Complete), EX599 (Exposure End).
        *   `그룹 시퀀스`: RB2001-2005 (Load Sequence), RB2101-2105 (Unload Sequence), SC701 (Scan Fields).
        *   `중간 상태`: RB2002/2004 (Z Down/Up), RB2102/2104 (Z Down/Up), AL101-116 (Mark checks during alignment).
        *   `선행조건(모션 아님)`: ST3001 (Lock), PA401 (Positioning), AL100 (Start Check), F901 (Focus Check), SYS200 (System Status).
        *   `품질/결과 체크`: AL100, AL199, EX599, F901.
    *   *Self-Correction on Classification:* The prompt asks for specific classification values. I need to map each unique code to one of these values.
    *   *Refinement:*
        *   `TR1001`: Transfer Start -> `모션 시작`
        *   `RB2001`: Robot Extend -> `모션 시작`
        *   `RB2002/2004`: Z Axis Move -> `중간 상태` (Part of motion sequence)
        *   `RB2003`: Vacuum On -> `중간 상태` (Pre-condition for hold)
        *   `RB2005`: Robot Retract -> `모션 종료`
        *   `TR2099`: Transfer End -> `모션 종료`
        *   `ST3001`: Lock -> `선행조건(모션 아님)`
        *   `PA401`: Positioning -> `선행조건(모션 아님)`
        *   `AL100`: Alignment Start -> `중간 상태` or `선행조건`? Let's say `중간 상태` (Process Start).
        *   `AL101-116`: Mark Check -> `품질/결과 체크`
        *   `AL199`: Alignment End -> `모션 종료` (Process End)
        *   `EX500`: Exposure Start -> `모션 시작`
        *   `ST3002`: Scan Start -> `모션 시작`
        *   `SC701`: Scan Field -> `중간 상태` (Continuous motion)
        *   `ST3003`: Scan Complete -> `모션 종료`
        *   `EX599`: Exposure End -> `모션 종료`
        *   `F901`: Focus Check -> `품질/결과 체크`
        *   `SYS200`: System Status -> `선행조건(모션 아님)`
        *   `ST3099`: Chuck Release -> `모션 종료` (Process End)
        *   `TR2001`: Unload Start -> `모션 시작`
        *   `RB2101-2105`: Unload Robot -> `모션 시작/중간/종료` (Group sequence)
        *   `TR2099`: Stored -> `모션 종료`

    *   *Decision:* I will consolidate similar codes (e.g., RB2001-2005) into the table or list them individually. The prompt asks for "Event Code List" first, then "Motion-related Candidate Classification". I should list unique codes in section 1, and then filter/classify them in section 2.
    *   *Wait, Section 1 says "Event Code List (Deduplicated) — Estimated Meaning". Section 2 says "Motion-related Candidate Classification".*
    *   I will list all unique codes in Section 1.
    *   In Section 2, I will create a table for the *Motion-related* ones specifically, using the required classification values.

5.  **Drafting Content - Section 3: Group Sequence Estimation**
    *   Identify the repeating pattern: Load (TR1001 -> RB20xx -> TR1099) -> Process (ST3001 -> PA401 -> AL -> EX -> SC -> ST3003 -> EX599 -> F901 -> ST3099) -> Unload (ST3099 -> TR2001 -> RB21xx -> TR2099).
    *   Structure: Header (Config) -> Loop (Wafer Process) -> Footer (System Status).
    *   Entities: Wafer (WFR021-025), Robot (RB_ARM1), Chuck (CHK_A), FOUP.

6.  **Drafting Content - Section 4: Entity Identifiers**
    *   Wafer ID (WFR021...)
    *   Robot ID (RB_ARM1)
    *   Chuck ID (CHK_A)
    *   FOUP Slot ID (21-25)
    *   Event ID (EVT#...)

7.  **Review and Formatting:**
    *   Ensure Markdown only.
    *   Ensure Korean language for headers and content (as per prompt instruction "마크다운만 출력하세요" and prompt is in Korean).
    *   Check classification values strictly: `모션 시작`, `모션 종료`, `그룹 시퀀스`, `중간 상태`, `선행조건(모션 아님)`, `품질/결과 체크`.
    *   Check Event Code List: Deduplicated.
    *   Check Group Sequence: Explain the structure.

    *   *Refining Section 1 (Event Code List):*
        *   List all unique codes found in the text.
        *   Add brief meaning.
    *   *Refining Section 2 (Motion Table):*
        *   Filter codes that imply movement or state change relevant to the process flow.
        *   Assign the specific classification labels.
    *   *Refining Section 3 (Group Sequence):*
        *   Describe the Wafer Processing Loop.
    *   *Refining Section 4 (Entities):*
        *   List the keys.

    *   *Wait, one detail:* The prompt asks for "Event Code List (Deduplicated)" in Section 1. Then "Motion-related Candidate Classification" in Section 2.
    *   I need to make sure I don't duplicate the list in Section 2, but Section 2 is specifically for *Motion-related* candidates.
    *   Actually, usually, Section 1 is the master list, Section 2 is the filtered/analyzed list.
    *   Let's check the classification values again: `모션 시작`, `모션 종료`, `그룹 시퀀스`, `중간 상태`, `선행조건(모션 아님)`, `품질/결과 체크`.
    *   I will map the codes to these.

    *   *Codes:*
        *   F901 (Focus Check) -> 품질/결과 체크
        *   ST3099 (Chuck Release) -> 모션 종료 (Process End)
        *   TR2001 (Unload Start) -> 모션 시작
        *   TR2099 (Unload End) -> 모션 종료
        *   RB2101-2105 (Unload Robot) -> 그룹 시퀀스 (or 모션 시작/중간/종료 depending on specific line). I'll classify the sequence as `그룹 시퀀스` for the block, or specific lines as `모션 시작/중간/종료`. The prompt asks for "Motion-related Candidate Classification". I will classify specific codes.
        *   TR1001 (Load Start) -> 모션 시작
        *   RB2001-2005 (Load Robot) -> 그룹 시퀀스
        *   TR1099 (Load End) -> 모션 종료
        *   ST3001 (Lock) -> 선행조건(모션 아님)
        *   PA401 (Position) -> 선행조건(모션 아님)
        *   AL100 (Align Start) -> 중간 상태
        *   AL101-116 (Marks) -> 품질/결과 체크
        *   AL199 (Align End) -> 모션 종료
        *   EX500 (Exposure Start) -> 모션 시작
        *   ST3002 (Scan Start) -> 모션 시작
        *   SC701 (Scan Field) -> 중간 상태
        *   ST3003 (Scan Complete) -> 모션 종료
        *   EX599 (Exposure End) -> 모션 종료
        *   SYS200 (System) -> 선행조건(모션 아님)

    *   *Wait, `그룹 시퀀스` (Group Sequence):* This usually refers to a sequence of events like the robot arm sequence (RB2001-2005). I will mark the start/end of these sequences as `모션 시작/종료` and the sequence block itself as `그룹 시퀀스` if possible, or just mark the specific motion codes. Given the instruction "Motion-related Candidate Classification", I will classify the specific event codes.
    *   Let's group the Robot moves as `그룹 시퀀스` for the start/end of the sequence, and individual moves as `중간 상태`? Or mark the whole block?
    *   Better approach:
        *   TR1001/TR2001: `모션 시작`
        *   RB2001/RB2101: `모션 시작`
        *   RB2002/RB2102: `중간 상태`
        *   RB2003/RB2103: `중간 상태`
        *   RB2004/RB2104: `중간 상태`
        *   RB2005/RB2105: `모션 종료`
        *   TR1099/TR2099: `모션 종료`
        *   ST3001/ST3099: `선행조건(모션 아님)` (State change, not physical motion per se, but process state).
        *   AL100/AL199: `중간 상태` / `모션 종료`
        *   AL101-116: `품질/결과 체크`
        *   EX500/EX599: `모션 시작` / `모션 종료`
        *   ST3002/ST3003: `모션 시작` / `모션 종료`
        *   SC701: `중간 상태`
        *   PA401: `선행조건(모션 아님)`
        *   SYS200: `선행조건(모션 아님)`

    *   Okay, ready to write.

    *   *Constraint Check:* "마크다운만 출력하세요" (Output only Markdown). No introductory text.

    *   *Structure:*
        1.  **이벤트 코드 전체 목록**
        2.  **모션 관련 후보 분류** (Table)
        3.  **그룹 시퀀스 추정**
        4.  **엔티티 식별자**

    *   *Language:* Korean.

    *   *Refining Event List:*
        *   F901, ST3099, TR2001, RB2101, RB2102, RB2103, RB2104, RB2105, TR2099, TR1001, RB2001, RB2002, RB2003, RB2004, RB2005, TR1099, ST3001, PA401, AL100, AL101, AL102, AL103, AL104, AL105, AL106, AL107, AL108, AL109, AL110, AL111, AL112, AL113, AL114, AL115, AL116, AL199, EX500, ST3002, SC701, ST3003, EX599, SYS200.
        *   I will list them in a table or list format. A list is better for "List".
        *   Wait, the prompt says "Event Code List (Deduplicated)". I will use a table for clarity or a bulleted list. Let's use a table for consistency with the second requirement, or just a clean list. I'll use a list for the first section and a table for the second section to distinguish them. Actually, a table is cleaner for "List". But the second section requires a table. I'll use a list for section 1 and a table for section 2.
        *   Wait, looking at the instruction "반드시 포함할 내용: 1. 이벤트 코드 전체 목록... 2. 모션 관련 후보 분류 — 마크다운 테이블".
        *   Okay, Section 1 can be a list or table. Section 2 must be a table.
        *   I will make Section 1 a table for consistency, or just a list. Let's do a list for Section 1 to save space, and a table for Section 2 as requested.
        *   Actually, to be safe and clean, I will use a table for Section 1 as well, or just a clean list. Let's use a clean list for Section 1.
        *   Wait, I need to make sure I don't miss any codes.
        *   Codes: F901, ST3099, TR2001, RB2101, RB2102, RB2103, RB2104, RB2105, TR2099, TR1001, RB2001, RB2002, RB2003, RB2004, RB2005, TR1099, ST3001, PA401, AL100, AL101, AL102, AL103, AL104, AL105, AL106, AL107, AL108, AL109, AL110, AL111, AL112, AL113, AL114, AL115, AL116, AL199, EX500, ST3002, SC701, ST3003, EX599, SYS200.
        *   Total unique codes: ~40.
        *   I will group AL101-116 as AL101~AL116 in the list to save space? No, deduplicated list means unique codes. I will list them as ranges if they are sequential, but strictly unique codes. I'll list them as `AL101~AL116` for brevity in the list, but clarify in meaning. Or just list `AL101`... `AL116`. I'll list `AL101~AL116` to keep it clean.
        *   Actually, for "Deduplicated", `AL101` and `AL102` are distinct codes. I will list `AL101~AL116` as a range in the code column to avoid clutter, or just list `AL101` and note the range. Let's list `AL101~AL116` as one entry to represent the group.
        *   Better: List `AL101` and `AL102`... No, that's too long. I will list `AL101~AL116` as a single entry in the code column.
        *   Wait, the prompt asks for "Event Code List". I will list unique codes. `AL101` is a code. `AL102` is a code. I will list `AL101~AL116` to represent the set.
        *   Okay, let's finalize the plan.

    *   *Section 3 (Group Sequence):*
        *   Header: `당22 Overlay=0.7 TotalFields=10`
        *   Loop: `Wafer Load` -> `Alignment` -> `Exposure/Scan` -> `Focus Check` -> `Unload`.
        *   Footer: `SYS200`.
        *   Entities: Wafer, Robot, Chuck, FOUP.

    *   *Section 4 (Entities):*
        *   Wafer ID, Robot ID, Chuck ID, FOUP Slot.

    *   *Final check on Markdown:* No extra text. Just the content.

    *   *Wait, one more check:* "반드시 포함할 내용: 1. 이벤트 코드 전체 목록 (중복 제거) — 각 코드의 추정 의미".
    *   "2. 모션 관련 후보 분류 — 마크다운 테이블 (코드 / 의미 / 분류)".
    *   "3. 그룹 시퀀스 추정".
    *   "4. 엔티티 식별자".
    *   Okay, I will structure the output exactly like this.

    *   *Refining Classification:*
        *   `TR1001`: `모션 시작` (Transfer Start)
        *   `RB2001`: `모션 시작` (Robot Extend)
        *   `RB2002`: `중간 상태` (Z Down)
        *   `RB2003`: `중간 상태` (Vacuum On)
        *   `RB2004`: `중간 상태` (Z Up)
        *   `RB2005`: `모션 종료` (Robot Retract)
        *   `TR1099`: `모션 종료` (Transfer End)
        *   `ST3001`: `선행조건(모션 아님)` (Lock)
        *   `PA401`: `선행조건(모션 아님)` (Position)
        *   `AL100`: `중간 상태` (Align Start)
        *   `AL101~AL116`: `품질/결과 체크` (Mark Check)
        *   `AL199`: `모션 종료` (Align End)
        *   `EX500`: `모션 시작` (Exposure Start)
        *   `ST3002`: `모션 시작` (Scan Start)
        *   `SC701`: `중간 상태` (Scan Field)
        *   `ST3003`: `모션 종료` (Scan Complete)
        *   `EX599`: `모션 종료` (Exposure End)
        *   `F901`: `품질/결과 체크` (Focus Check)
        *   `ST3099`: `모션 종료` (Chuck Release)
        *   `TR2001`: `모션 시작` (Unload Start)
        *   `RB2101`: `모션 시작` (Robot Extend)
        *   `RB2102`: `중간 상태` (Z Down)
        *   `RB2103`: `중간 상태` (Vacuum Off)
        *   `RB2104`: `중간 상태` (Z Up)
        *   `RB2105`: `모션 종료` (Robot Retract)
        *   `TR2099`: `모션 종료` (Unload End)
        *   `SYS200`: `선행조건(모션 아님)` (System Status)
        *   `F901` (First one): `품질/결과 체크`
        *   `F901` (Last one): `품질/결과 체크`
        *   Wait, `F901` appears twice (Start and End of process). I will list it once in Section 1, and classify it in Section 2.
        *   `ST3099` appears twice.
        *   `TR2001` appears twice.
        *   `TR2099` appears twice.
        *   `TR1001` appears multiple times.
        *   `RB2001` appears multiple times.
        *   `RB2101` appears multiple times.
        *   `AL100` appears multiple times.
        *   `AL199` appears multiple times.
        *   `EX500` appears multiple times.
        *   `EX599` appears multiple times.
        *   `ST3001` appears multiple times.
        *   `ST3002` appears multiple times.
        *   `ST3003` appears multiple times.
        *   `PA401` appears multiple times.
        *   `SYS200` appears once.
        *   `SC701` appears multiple times.

    *   Okay, I will consolidate the unique codes in Section 1.
    *   In Section 2, I will list the unique codes and their classification.
    *   Wait, Section 1 is "Event Code List (Deduplicated)". Section 2 is "Motion-related Candidate Classification".
    *   I will ensure Section 2 only contains codes relevant to motion classification (which is basically all of them except maybe SYS200, but I'll include it as `선행조건`).
    *   Actually, Section 2 is a subset of Section 1 filtered for "Motion-related". But the prompt says "Motion-related Candidate Classification". I will include all codes in Section 2 but classify them. Or should I filter? "모션 관련 후보 분류" implies filtering for motion-related candidates. I will include all codes that have a motion/state implication. SYS200 is system status, not motion. I'll include it as `선행조건`.
    *   Okay, let's write.

    *   *Formatting:*
        *   # 1. 이벤트 코드 전체 목록
        *   # 2. 모션 관련 후보 분류
        *   # 3. 그룹 시퀀스 추정
        *   # 4. 엔티티 식별자
        *   Use tables for lists where appropriate.
        *   Ensure no markdown outside the content.

    *   *Wait, one detail:* "Overlay=0.7 TotalFields=10" is in the header.
    *   I will ignore it for the event list as it's config.
    *   I will focus on EVT#... codes.

    *   *Final check on constraints:* "마크다운만 출력하세요".
    *   I will not add any conversational text.

    *   *Wait, Section 1:* "이벤트 코드 전체 목록 (중복 제거)".
    *   I will use a table for this too for consistency, or a list. A table is better for "Meaning".
    *   Okay, I'll use a table for Section 1 as well.
    *   Wait, Section 2 requires a table. I can use the same table structure for Section 1 to save space, but the prompt distinguishes them. I'll use a list for Section 1 and a table for Section 2 to differentiate.
    *   Actually, a table is cleaner for "Code / Meaning". I'll use a table for Section 1.
    *   Okay, let's go.

    *   *Wait, Section 3:* "그룹 시퀀스 추정". I will describe the flow.
    *   *Section 4:* "엔티티 식별자". I will list them.

    *   *Wait, check classification values again:* `모션 시작`, `모션 종료`, `그룹 시퀀스`, `중간 상태`, `선행조건(모션 아님)`, `품질/결과 체크`.
    *   I must use these exact strings.

    *   *Wait, `RB2001` vs `RB2101`:* They are different codes (different sequence numbers). I will list them as `RB2001` and `RB2101` in Section 1.
    *   In Section 2, I will classify them.
    *   Okay.

    *   *Wait, `AL101~AL116`:* I will list `AL101~AL116` in Section 1 to avoid 16 lines.
    *   In Section 2, I will list `AL101~AL116`.

    *   *Wait, `RB2001~RB2005`:* I will list `RB2001~RB2005` in Section 1.
    *   In Section 2, I will list `RB2001~RB2005`.

    *   *Wait, `SC701`:* It's a single code used for multiple fields. I will list `SC701`.

    *   *Wait, `TR1001` vs `TR2001`:* Different codes.
    *   Okay.

    *   *Wait, `F901`:* Appears twice. Deduplicated means one entry.
    *   Okay.

    *   *Wait, `SYS200`:* Only one.

    *   *Wait, `PA401`:* Only one.

    *   *Wait, `ST3001`, `ST3002`, `ST3003`, `ST3099`:* Different codes.

    *   *Wait, `AL100`, `AL199`:* Different codes.

    *   *Wait, `EX500`, `EX599`:* Different codes.

    *   *Wait, `TR1099`, `TR2099`:* Different codes.

    *   *Wait, `TR1001`, `TR2001`:* Different codes.

    *   Okay, ready.

    *   *Wait, one more thing:* The prompt says "Overlay=0.7 TotalFields=10" at the top. This is likely a header line. I will not include it in the Event Code List as it's not an EVT#.
    *   Okay.

    *   *Wait, Section 3:* "그룹 시퀀스 추정 — 헤더 → 바디(반복) → 결과 구조가 있다면 설명".
    *   I will explain the structure.

    *   *Wait, Section 4:* "엔티티 식별자 — 모션을 분리하는 키 (예: Wafer, Robot)".
    *   I will list Wafer, Robot, Chuck, FOUP.

    *   *Wait, Markdown only:* No bolding outside of headers/tables/lists? No, Markdown allows bolding. I will use standard Markdown.

    *   *Wait, check classification values again:* `모션 시작`, `모션 종료`, `그룹 시퀀스`, `중간 상태`, `선행조건(모션 아님)`, `품질/결과 체크`.
    *   I must use these exact strings.

    *   *Wait, `RB2001`:* `모션 시작`.
    *   `RB2002`: `중간 상태`.
    *   `RB2003`: `중간 상태`.
    *   `RB2004`: `중간 상태`.
    *   `RB2005`: `모션 종료`.
    *   `RB2101`: `모션 시작`.
    *   `RB2102`: `중간 상태`.
    *   `RB2103`: `중간 상태`.
    *   `RB2104`: `중간 상태`.
    *   `RB2105`: `모션 종료`.
    *   `TR1001`: `모션 시작`.
    *   `TR2001`: `모션 시작`.
    *   `TR1099`: `모션 종료`.
    *   `TR2099`: `모션 종료`.
    *   `ST3001`: `선행조건(모션 아님)`.
    *   `ST3099`: `모션 종료`.
    *   `PA401`: `선행조건(모션 아님)`.
    *   `AL100`: `중간 상태`.
    *   `AL199`: `모션 종료`.
    *   `AL101~AL116`: `품질/결과 체크`.
    *   `EX500`: `모션 시작`.
    *   `EX599`: `모션 종료`.
    *   `ST3002`: `모션 시작`.
    *   `ST3003`: `모션 종료`.
    *   `SC701`: `중간 상태`.
    *   `F901`: `품질/결과 체크`.
    *   `SYS200`: `선행조건(모션 아님)`.

    *   Okay, I will generate the response now.# 1. 이벤트 코드 전체 목록 (중복 제거)

| 코드 | 추정 의미 |
| :--- | :--- |
| EVT#F901 | 포커스 드리프트 및 규격 확인 (InSpec) |
| EVT#ST3099 | 체크 (Chuck) 릴리스 (Wafer Unload) |
| EVT#TR2001 | 언로드 시작 (FOUP 로 이동) |
| EVT#RB2101~RB2105 | 로봇 언로드 시퀀스 (축 이동, 진공 해제) |
| EVT#TR2099 | 언로드 완료 (FOUP 에 저장) |
| EVT#TR1001 | 로드 시작 (FOUP 에서 체크로 이동) |
| EVT#RB2001~RB2005 | 로봇 로드 시퀀스

[모션_페어링_분석_v2.md]
Thinking Process:

1.  **Analyze the Request:**
    *   Input: A log file snippet containing semiconductor manufacturing equipment events (wafer load, unload, alignment, exposure, scan, etc.).
    *   Task: Extract and structure specific information based on the provided log.
    *   Required Output Format: Markdown only.
    *   Required Content:
        1.  **Motion Type List**: Markdown table (Name / Pattern / Start / End / Intermediate State / EntityKey). Patterns: `Simple`, `Group`, `Conditional`, `EntityKey`, `Single`.
        2.  **Pairing Conditions**: Entity keys (Wafer/Seq/Robot), field value branching.
        3.  **Nested Motions**: Parent/Child relationships (e.g., EXPOSE inside SCAN).
        4.  **Intermediate State Handling**: Rules for collecting repeated events (AL101~AL1N9) as attributes.
        5.  **Wafer/Equipment 1 Cycle Sequence**: Sequential listing of the entire cycle.
        6.  **SQLite Storage Fields**: List of fields (motion_type, wafer_id, severity, etc.).
    *   Constraint: Output *only* Markdown.

2.  **Analyze the Log Data:**
    *   **Events:**
        *   `EVT#F901`: Focus check (Start/End of focus check).
        *   `EVT#ST3099`: Chuck Release (Unload).
        *   `EVT#TR2001`: Transfer Start (Unload).
        *   `EVT#RB2101~RB2105`: Robot Arm movements (Unload).
        *   `EVT#TR2099`: Transfer End (Unload/Store).
        *   `EVT#TR1001`: Transfer Start (Load).
        *   `EVT#RB2001~RB2005`: Robot Arm movements (Load).
        *   `EVT#TR1099`: Transfer End (Load/Place).
        *   `EVT#ST3001`: Chuck Lock.
        *   `EVT#PA401`: Alignment (Notch, Center).
        *   `EVT#AL100`: Alignment Start (Marks count, Residuals).
        *   `EVT#AL101~AL116`: Alignment Marks (Repeated events).
        *   `EVT#AL199`: Alignment End (Final Residual, Status).
        *   `EVT#EX500`: Exposure Start (Dose, Focus, Seq, Field).
        *   `EVT#ST3002`: Scan Start.
        *   `EVT#SC701`: Scan Fields (Repeated events).
        *   `EVT#ST3003`: Scan End.
        *   `EVT#EX599`: Exposure End (Result, Seq, Overlay, TotalFields).
        *   `EVT#F901`: Focus Check (End).
        *   `EVT#SYS200`: System Status (Throughput, LotProgress).
    *   **Wafer Sequence:** WFR021 (Unload) -> WFR022 (Load/Process/Unload) -> WFR023 (Load/Process/Unload) -> WFR024 (Load/Process/Unload) -> WFR025 (Load/Process/Unload).
    *   **Note:** The log starts with WFR021 Unload (already processed) and ends with WFR025 Unload. The main processing cycle shown is WFR022 to WFR025. WFR021 is just the tail end of a previous cycle. I should focus on the complete cycles shown (WFR022, WFR023, WFR024, WFR025) or generalize the structure based on the repeating pattern. The prompt asks for "Wafer/Equipment 1 Cycle Sequence". I will describe the standard cycle based on the repeating pattern (Load -> Align -> Expose -> Scan -> Unload).

3.  **Drafting the Content:**

    *   **1. Motion Type List:**
        *   Need to categorize events into types.
        *   *Load Motion*: TR1001 -> RB2001~RB2005 -> TR1099 -> ST3001.
        *   *Align Motion*: PA401 -> AL100 -> AL101~AL116 -> AL199.
        *   *Expose Motion*: EX500 -> ST3002 -> SC701 (xN) -> ST3003 -> EX599.
        *   *Unload Motion*: F901 -> ST3099 -> TR2001 -> RB2101~RB2105 -> TR2099.
        *   *System Motion*: SYS200.
        *   Patterns: `Simple` (Single event), `Group` (Sequence of events), `Conditional` (Based on status), `EntityKey` (Wafer ID), `Single` (One-off).
        *   Let's map specific events to these patterns.
        *   *Load*: Group (Transfer + Robot + Place).
        *   *Align*: Group (PA + AL100 + AL101~AL199).
        *   *Expose*: Group (EX500 + ST3002 + SC701 + ST3003 + EX599).
        *   *Unload*: Group (F901 + ST3099 + TR2001 + RB2101~RB2105 + TR2099).
        *   *Focus Check*: Simple (F901).

    *   **2. Pairing Conditions:**
        *   Entity Keys: `Wafer` (WFR022, WFR023...), `Seq` (1023, 1024...), `Robot` (RB_ARM1).
        *   Field Value Branching: `Status` (Pass/Fail), `Quality` (Good/Marginal), `Result` (OK).

    *   **3. Nested Motions:**
        *   Parent: `EXPOSE` (EX500/EX599).
        *   Child: `SCAN` (ST3002/ST3003 + SC701 events).
        *   Also `ALIGN` contains `AL101~AL116`.

    *   **4. Intermediate State Handling:**
        *   Repeated events like `AL101` to `AL116` (Alignment Marks) or `SC701` (Scan Fields).
        *   Rule: Collect `X`, `Y`, `Quality` into an array/attribute list. Aggregate `ResidualX`, `ResidualY` for final status.

    *   **5. Wafer/Equipment 1 Cycle Sequence:**
        *   Load (TR1001 -> TR1099)
        *   Lock (ST3001)
        *   Align (PA401 -> AL100 -> AL101~AL199)
        *   Expose (EX500 -> ST3002 -> SC701 -> ST3003 -> EX599)
        *   Focus Check (F901)
        *   Unlock (ST3099)
        *   Unload (TR2001 -> TR2099)
        *   Robot Move (RB2001/2101 etc.)

    *   **6. SQLite Storage Fields:**
        *   `motion_type`, `wafer_id`, `seq_id`, `start_time`, `end_time`, `status`, `severity`, `robot_id`, `field_count`, `overlay_error`, `focus_drift`, `alignment_residual`, `quality_summary`.

4.  **Refining the Output (Markdown Only):**
    *   Ensure no extra text outside Markdown.
    *   Check table formatting.
    *   Ensure all 6 required sections are present.
    *   Use the specific patterns requested (`Simple`, `Group`, `Conditional`, `EntityKey`, `Single`).

    *   *Self-Correction on Motion Types:*
        *   The prompt asks for a table with columns: Name / Pattern / Start / End / Intermediate State / EntityKey.
        *   I need to define what "Start" and "End" mean in this context (Event IDs or Time). Let's use Event IDs for clarity.
        *   Patterns:
            *   `Simple`: Single event (e.g., `EVT#F901` status check).
            *   `Group`: Sequence of events (e.g., Load sequence).
            *   `Conditional`: Depends on status (e.g., `Status=Pass`).
            *   `EntityKey`: Tied to specific Wafer/Seq.
            *   `Single`: One-off event.
        *   I will map the major phases to these patterns.

    *   *Self-Correction on Pairing Conditions:*
        *   Explain how Wafer ID links Load/Unload.
        *   Explain how Seq ID links Exposure events.

    *   *Self-Correction on Nested Motions:*
        *   EXPOSE (Parent) -> SCAN (Child).
        *   ALIGN (Parent) -> MARKS (Child).

    *   *Self-Correction on Intermediate State:*
        *   Explain `AL101`~`AL116` -> `Attributes[Mark]`.
        *   Explain `SC701` -> `Attributes[Field]`.

    *   *Self-Correction on Cycle Sequence:*
        *   List the logical steps.

    *   *Self-Correction on SQLite Fields:*
        *   List the schema.

5.  **Final Review against Constraints:**
    *   Markdown only? Yes.
    *   All 6 sections included? Yes.
    *   Language: Korean (based on prompt).

    *   *Wait, one detail:* The prompt says "반드시 포함할 내용" (Must include content). I need to make sure I don't miss any.
    *   "마크다운만 출력하세요" (Output only Markdown). No introductory text like "Here is the markdown".

    *   *Structure:*
        *   # Motion Type List
        *   Table
        *   ## Pairing Conditions
        *   ## Nested Motions
        *   ## Intermediate State Handling
        *   ## Wafer/Equipment 1 Cycle Sequence
        *   ## SQLite Storage Fields

    *   *Content Check:*
        *   Log shows WFR021 Unload (partial), then WFR022~WFR025 Load/Process/Unload.
        *   I will generalize the cycle based on WFR022-WFR025 as they are complete cycles.
        *   Event IDs: `EVT#...`
        *   Entity Keys: `Wafer`, `Seq`, `Robot`.

    *   *Drafting the Table:*
        *   Name: Load Motion
        *   Pattern: Group
        *   Start: EVT#TR1001
        *   End: EVT#TR2099
        *   Intermediate: RB2001~RB2005
        *   EntityKey: Wafer, Robot
        *   ... and so on for Align, Expose, Unload.

    *   *Drafting SQLite Fields:*
        *   `motion_type`, `wafer_id`, `seq_id`, `start_time`, `end_time`, `status`, `severity`, `robot_id`, `field_count`, `overlay_error`, `focus_drift`, `alignment_residual`, `quality_summary`.

    *   *Refining Korean Translation:*
        *   Motion Type -> 동작 유형
        *   Pattern -> 패턴
        *   Start -> 시작 이벤트
        *   End -> 종료 이벤트
        *   Intermediate State -> 중간 상태
        *   EntityKey -> 엔티티 키
        *   Pairing Conditions -> 페어링 조건
        *   Nested Motions -> 중첩 모션
        *   Intermediate State Handling -> 중간 상태 처리
        *   Cycle Sequence -> 사이클 시퀀스
        *   SQLite Storage Fields -> SQLite 저장 필드

    *   *Final Polish:* Ensure clean Markdown syntax.

6.  **Constructing the Output:** (Mental check of the generated text)
    *   Start with `# Motion Type List`.
    *   Insert Table.
    *   Insert `## Pairing Conditions`.
    *   Insert `## Nested Motions`.
    *   Insert `## Intermediate State Handling`.
    *   Insert `## Wafer/Equipment 1 Cycle Sequence`.
    *   Insert `## SQLite Storage Fields`.
    *   Ensure no extra text.

    *   *Wait, check the "Pattern" column values:* The prompt specifies `Simple`, `Group`, `Conditional`, `EntityKey`, `Single`. I should use these exact strings in the table.
    *   *Check "Intermediate State":* Describe the attributes collected.
    *   *Check "Nested Motions":* Explicitly mention EXPOSE/SCAN.

    *   *Ready to write.*# Motion Type List

| Name | Pattern | Start | End | Intermediate State | EntityKey |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Load Motion** | Group | EVT#TR1001 | EVT#TR1099 | RB2001~RB2005 (Robot Move) | Wafer, Robot |
| **Align Motion** | Group | EVT#PA401 | EVT#AL199 | AL100~AL116 (Mark Events) | Wafer, Seq |
| **Expose Motion** | Group | EVT#EX500 | EVT#EX599 | ST3002, SC701, ST3003 | Wafer, Seq, Field |
| **Focus Check** | Single | EVT#F901 | EVT#F901 | FocusDrift, Spec, Status | Wafer |
| **Unload Motion** | Group | EVT#ST3099 | EVT#TR2099 | RB2101~RB2105 (Robot Move) | Wafer, Robot |
| **System Status** | Conditional | EVT#SYS200 | EVT#SYS200 | Throughput, LotProgress | Lot, State |
| **Transfer Start** | Simple | EVT#TR1001 | EVT#TR1001 | Cmd, Src, Dest | Wafer, Slot |
| **Transfer End** | Simple | EVT#TR1099 | EVT#TR1099 | Status, Duration | Wafer, Slot |
| **Chuck Lock** | Simple | EVT#ST3001 | EVT#ST3001 | Status | Wafer, Chuck |
| **Chuck Release** | Simple | EVT#ST3099 | EVT#ST3099 | Status | Wafer, Chuck |
| **Scan Start** | Simple | EVT#ST3002 | EVT#ST3002 | ScanMode, Direction | Wafer |
| **Scan End** | Simple | EVT#ST3003 | EVT#ST3003 | Status | Wafer |
| **Robot Extend** | Single | EVT#RB2xxx | EVT#RB2xxx | Axis, Speed, Vacuum | Robot, Axis |

## Pairing Conditions

*   **Wafer ID**: `Wafer` (e.g., WFR022) links all events from Load (`TR1001`) to Unload (`TR2099`).
*   **Sequence ID**: `Seq` (e.g., 1023) links Exposure events (`EX500`, `EX599`) and Scan fields.
*   **Robot ID**: `Robot` (e.g., RB_ARM1) links all Robot Arm events (`RB2xxx`).
*   **Field Value Branching**:
    *   `Quality`: `Good` vs `Marginal` (e.g., AL108, AL111).
    *   `Status`: `Pass` vs `Fail` (e.g., AL199, EX599).
    *   `Result`: `OK` vs `NG` (e.g., EX599).
*   **Slot ID**: `Slot` (e.g., 22, 23) links FOUP storage events (`TR2099`).

## Nested Motions

*   **Parent: EXPOSE** (`EVT#EX500` ~ `EVT#EX599`)
    *   **Child: SCAN** (`EVT#ST3002` ~ `EVT#ST3003`)
        *   **Grandchild: FIELD** (`EVT#SC701` repeated per field)
*   **Parent: ALIGN** (`EVT#PA401` ~ `EVT#AL199`)
    *   **Child: MARK** (`EVT#AL101` ~ `EVT#AL116`)
*   **Parent: LOAD/UNLOAD** (`EVT#TR1001`/`TR2001` ~ `TR1099`/`TR2099`)
    *   **Child: ROBOT_MOVE** (`EVT#RB2xxx`)

## Intermediate State Handling

*   **Repeated Events (Attributes)**:
    *   **Alignment Marks**: `EVT#AL101` ~ `EVT#AL116` are collected into an attribute list `AlignmentMarks[]` containing `{Mark, X, Y, Quality}`.
    *   **Scan Fields**: `EVT#SC701` is collected into `ScanFields[]` containing `{Field, PosX, PosY, ScanSpeed}`.
    *   **Robot Moves**: `EVT#RB2xxx` sequence is aggregated into `RobotPath[]` containing `{Axis, Value, Speed, Vacuum}`.
*   **Aggregation Logic**:
    *   `ResidualX`, `ResidualY` from `AL100` and `AL199` are averaged or compared for `Status=Pass`.
    *   `TotalFields` from `EX599` is the count of `SC701` events.
    *   `Overlay` from `EX599` is the final metric for the `EXPOSE` motion.

## Wafer/Equipment 1 Cycle Sequence

1.  **Load**: `EVT#TR1001` (TransferStart) -> `EVT#RB2001~RB2005` (Robot Move) -> `EVT#TR1099` (TransferEnd/Place).
2.  **Lock**: `EVT#ST3001` (Chuck Lock).
3.  **Align**: `EVT#PA401` (Notch/Center) -> `EVT#AL100` (Start) -> `EVT#AL101~AL116` (Marks) -> `EVT#AL199` (End/Pass).
4.  **Expose**: `EVT#EX500` (Start) -> `EVT#ST3002` (ScanStart) -> `EVT#SC701` (Fields) -> `EVT#ST3003` (ScanEnd) -> `EVT#EX599` (End).
5.  **Focus Check**: `EVT#F901` (FocusDrift/Status).
6.  **Unlock**: `EVT#ST3099` (Chuck Release).
7.  **Unload**: `EVT#TR2001` (TransferStart) -> `EVT#RB2101~RB2105` (Robot Move) -> `EVT#TR2099` (TransferEnd/Store).
8.  **System Update**: `EVT#SYS200` (Throughput/LotProgress).

## SQLite Storage Fields

| Field Name | Type | Description |
| :--- | :--- | :--- |
| `motion_type` | TEXT | `Load`, `Align`, `Expose`, `Unload`, `Focus` |
| `wafer_id` | TEXT | Unique Wafer ID (e.g., WFR022) |
| `seq_id` | INTEGER | Exposure Sequence Number |
| `start_time` | DATETIME | Timestamp of Start Event |
| `end_time` | DATETIME | Timestamp of End Event |
| `status` | TEXT | `Pass`, `Fail`, `InSpec`, `OK` |
| `severity` | INTEGER | Error Level (0=Normal, 1=Warning, 2=Error) |
| `robot_id` | TEXT | `RB_ARM1` |
| `field_count` | INTEGER | Total Scan Fields (e.g., 14) |
| `overlay_error` | REAL | Overlay value (e.g., 1.0) |
| `focus_drift` | REAL | Focus Drift value (e.g., 0.028) |
| `alignment_residual` | REAL | Final Residual (e.g., 2.8) |
| `quality_summary` | TEXT | `Good`, `Marginal`, `Pass` |
| `slot_id` | INTEGER | FOUP Slot Number |
| `duration` | INTEGER | Total Duration in ms |

[실제 로그 샘플 — 이 포맷을 정확히 처리해야 함]
```
2026-04-19 09:30:00.263		EVT#SYS100		Tool=TWINSCAN_NXT1980Di  State=IDLE→READY
2026-04-19 09:30:00.520		EVT#SYS101		Recipe=EUV_DRAM_1A_RP7  Loaded=Yes  WaferCount=25
2026-04-19 09:30:01.032		EVT#TR1001		Src=FOUP  Dest=CHK_A  Cmd=TransferStart  Wafer=WFR001  Slot=1
2026-04-19 09:30:01.672		EVT#RB2001		Robot=RB_ARM1  Axis=R  Extend=160.2  Speed=109.5
2026-04-19 09:30:02.134		EVT#RB2002		Robot=RB_ARM1  Axis=Z  Down=52.2  Speed=109.5
2026-04-19 09:30:02.591		EVT#RB2003		Robot=RB_ARM1  Vacuum=ON  Pressure=61.9  Status=Hold
2026-04-19 09:30:03.126		EVT#RB2004		Robot=RB_ARM1  Axis=Z  Up=46.4  Speed=109.5
2026-04-19 09:30:03.814		EVT#RB2005		Robot=RB_ARM1  Axis=R  Retract=209.0  Speed=109.5
2026-04-19 09:30:05.622		EVT#TR1099		Wafer=WFR001  Stage=CHK_A  Status=Placed  Duration=4590
2026-04-19 09:30:06.035		EVT#ST3001		Wafer=WFR001  Chuck=CHK_A  Status=Locked
```

요구사항:
- **CLI 인자는 정확히 `--input <로그파일> --db <sqlite경로>` 두 개만** 받는다.
  - argparse 사용. 다른 인자(`--output`, `--format` 등) **금지** — 채점/호출은 두 인자만 사용.
  - 파일 인코딩 자동 감지 (utf-8 → cp949 → latin-1 순).
- **라인 포맷 유의** (위 샘플 참고):
  - 구조: `타임스탬프\t\t이벤트코드\t\tKEY=VALUE  KEY=VALUE  ...`
  - `parts[0]` = **타임스탬프** (예: `2026-04-19 09:30:00.263`), `parts[1]` = **이벤트코드** (예: `EVT#SYS100` 또는 `SC701`)
  - 탭이 **연속(\t\t)** 으로 나올 수 있음 → `split('\t')` 결과에서 **빈 필드 제거** 필수.
  - **이벤트 코드의 `EVT#` 접두사는 선택적** — 있을 수도 없을 수도 있다.
    - 정규화: `code = raw_code[4:] if raw_code.startswith('EVT#') else raw_code`
    - 비교는 정규화된 코드(`AL100`, `EX500`, `SC701` 등) 기준.
    - 예: `EVT#AL100` → `AL100`, `SC701` → `SC701` 둘 다 최종 `SC701.startswith('SC')` 형태로 매칭되어야 함.
  - **빈 줄** 이 데이터 사이사이에 섞여 있을 수 있음 → `line.strip()` 비어 있으면 건너뛴다.
  - 주석 라인(`#` 으로 시작)은 **있을 수도 없을 수도** 있음 — 방어적으로 건너뛰면 됨.
- **타임스탬프 기준 순차 처리**. 라인 파싱 → 이벤트 객체 생성.
- **페어링 패턴 4종**을 모두 구현:
  - Simple: start 이벤트 → end 이벤트 매칭 (엔티티 키 일치)
  - Group: 헤더 → 바디(반복) → 결과 구조. 중간은 attributes에 수집
  - Conditional: 필드값으로 severity 분기 (예: Result=NG → severity=NG)
  - EntityKey: Wafer/Robot 등 키로 모션 분리
- **중첩 모션**: parent_motion_id 컬럼에 부모 row id 저장.
- **페어링 타임아웃**: 30초 초과 미완성 페어는 flush (end_ts=null, severity='TIMEOUT').
- **SQLite 저장**: 아래 스키마를 **컬럼명·순서 그대로** 사용. 컬럼을 줄이거나 이름을 바꾸지 말 것.
```
CREATE TABLE IF NOT EXISTS motion_events (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id     TEXT,
  wafer_id         TEXT,
  motion_type      TEXT,
  motion_start_ts  DATETIME,
  motion_end_ts    DATETIME,
  duration_sec     REAL,
  severity         TEXT DEFAULT 'INFO',
  note             TEXT,     -- 모션 타입 한글 설명 (output/motion_notes.json 에서 로드)
  parent_motion_id INTEGER,
  attributes       TEXT,
  parser_version   TEXT DEFAULT 'v1',
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
);
```
- attributes 필드는 **JSON 문자열**로 저장 (json.dumps).
- **note 컬럼**: 스크립트 시작 시 `Path(__file__).parent / "motion_notes.json"` 을 읽어
  `{motion_type: 한글설명}` 매핑을 메모리에 로드. INSERT 시 `note = notes.get(motion_type)` 주입.
  파일이 없거나 JSON 오류면 빈 dict 로 fallback (note=NULL 로 동작).
- **라인 파싱 실패는 건너뛰기** (조용히 무시).
- `if __name__ == "__main__":` 블록에서 argparse 실행.

**반드시 ```python 펜스로 감싼 완전한 실행 가능 코드만** 출력하세요. 설명 금지.
```

## LLM Response (raw)

```
The user wants a Python CLI script (`parser_v1.py`) that parses semiconductor equipment logs and stores them in SQLite.
The script must adhere to strict constraints:
1.  **CLI Arguments**: Only `--input <logfile>` and `--db <sqlite_path>`. No other arguments allowed.
2.  **Encoding**: Auto-detect (utf-8 -> cp949 -> latin-1).
3.  **Log Parsing**:
    *   Format: `Timestamp\t\tEventCode\tKEY=VALUE...`
    *   Handle multiple tabs (`\t\t`).
    *   Handle optional `EVT#` prefix (normalize to code without prefix).
    *   Skip empty lines and comments (`#`).
    *   Timestamp is `parts[0]`, Event Code is `parts[1]` (after stripping empty fields).
4.  **Motion Pairing Patterns**:
    *   Simple: Start/End matching.
    *   Group: Header -> Body -> Result.
    *   Conditional: Field value branching (severity).
    *   EntityKey: Wafer/Robot separation.
5.  **Nested Motions**: Store `parent_motion_id`.
6.  **Timeout**: 30 seconds for incomplete pairs -> flush with `severity='TIMEOUT'`.
7.  **SQLite Schema**: Must match the provided schema exactly (column names, order).
8.  **Attributes**: JSON string.
9.  **Notes**: Load from `motion_notes.json` relative to script location. Fallback if missing.
10. **Error Handling**: Skip parsing failures silently.
11. **Output**: Only the Python code inside a markdown block. No explanations.

I need to write the complete code.

**Plan:**
1.  Import necessary modules (`argparse`, `re`, `datetime`, `sqlite3`, `json`, `os`, `sys`).
2.  Define the SQLite schema creation function.
3.  Define the `MotionEvent` class or structure to hold parsed data.
4.  Implement the log parsing logic (encoding detection, line splitting, field extraction).
5.  Implement the motion classification logic (identifying Start/End/Intermediate events based on code patterns).
6.  Implement the pairing logic (tracking active motions, checking timeouts).
7.  Implement the SQLite insertion logic.
8.  Implement the `motion_notes.json` loading logic.
9.  Implement the main entry point with `argparse`.

**Motion Classification Logic (based on the provided log sample and previous analysis):**
*   `TR1001` (Transfer Start) -> Start of Load Motion.
*   `RB2001`...`RB2005` -> Intermediate (Robot Move).
*   `TR1099` (Transfer End) -> End of Load Motion.
*   `ST3001` (Lock) -> Start of Align Motion (or intermediate state).
*   `PA401` -> Intermediate (Positioning).
*   `AL100` -> Start of Align Motion.
*   `AL101`...`AL116` -> Intermediate (Marks).
*   `AL199` -> End of Align Motion.
*   `EX500` -> Start of Expose Motion.
*   `ST3002` -> Start of Scan Motion (Nested).
*   `SC701` -> Intermediate (Scan Field).
*   `ST3003` -> End of Scan Motion.
*   `EX599` -> End of Expose Motion.
*   `F901` -> Focus Check (Simple/Conditional).
*   `ST3099` -> Start of Unload Motion (Release).
*   `TR2001` -> Start of Unload Transfer.
*   `RB2101`...`RB2105` -> Intermediate (Robot Move).
*   `TR2099` -> End of Unload Motion.
*   `SYS200` -> System Status (Simple/Conditional).

I will implement a function to classify the event code into a `motion_type` and determine if it's a start, end, or intermediate event.

**Timeout Logic:**
*   Maintain a dictionary of active motions: `{motion_id: {start_ts, type, wafer_id, ...}}`.
*   Check `datetime.now() - start_ts > 30 seconds`.
*   If timeout, insert with `severity='TIMEOUT'`, `end_ts=null`, `note='Timeout'`.
*   Clear from active dict.

**Encoding Detection:**
*   Try `utf-8`.
*   If error, try `cp949`.
*   If error, try `latin-1`.
*   If all fail, raise error or skip.

**Notes File:**
*   Path: `Path(__file__).parent / "motion_notes.json"`.
*   Content example: `{"Load Motion": "웨이퍼 로딩", "Align Motion": "정렬", ...}`.
*   If file doesn't exist, use empty dict.

**SQLite:**
*   Use `sqlite3.connect`.
*   Execute `CREATE TABLE` if not exists.
*   Use parameterized queries.

**Code Structure:**
*   Imports.
*   `load_notes()` function.
*   `parse_line(line)` function.
*   `classify_event(code, fields)` function.
*   `process_log(input_path, db_path)` function.
*   `main()` function.

Let's write the code.```python
import argparse
import datetime
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

# --- Constants & Config ---
TIMEOUT_SECONDS = 30
NOTES_FILE_PATH = Path(__file__).parent / "motion_notes.json"

# --- Motion Classification Rules ---
# Maps normalized event codes to motion types and roles (start, end, intermediate)
MOTION_RULES = {
    # Load Motion
    "TR1001": {"type": "Load Motion", "role": "start"},
    "RB2001": {"type": "Load Motion", "role": "intermediate"},
    "RB2002": {"type": "Load Motion", "role": "intermediate"},
    "RB2003": {"type": "Load Motion", "role": "intermediate"},
    "RB2004": {"type": "Load Motion", "role": "intermediate"},
    "RB2005": {"type": "Load Motion", "role": "end"},
    "TR1099": {"type": "Load Motion", "role": "end"},
    # Align Motion
    "ST3001": {"type": "Align Motion", "role": "start"},
    "PA401": {"type": "Align Motion", "role": "intermediate"},
    "AL100": {"type": "Align Motion", "role": "start"},
    "AL101": {"type": "Align Motion", "role": "intermediate"},
    "AL102": {"type": "Align Motion", "role": "intermediate"},
    "AL103": {"type": "Align Motion", "role": "intermediate"},
    "AL104": {"type": "Align Motion", "role": "intermediate"},
    "AL105": {"type": "Align Motion", "role": "intermediate"},
    "AL106": {"type": "Align Motion", "role": "intermediate"},
    "AL107": {"type": "Align Motion", "role": "intermediate"},
    "AL108": {"type": "Align Motion", "role": "intermediate"},
    "AL109": {"type": "Align Motion", "role": "intermediate"},
    "AL110": {"type": "Align Motion", "role": "intermediate"},
    "AL111": {"type": "Align Motion", "role": "intermediate"},
    "AL112": {"type": "Align Motion", "role": "intermediate"},
    "AL113": {"type": "Align Motion", "role": "intermediate"},
    "AL114": {"type": "Align Motion", "role": "intermediate"},
    "AL115": {"type": "Align Motion", "role": "intermediate"},
    "AL116": {"type": "Align Motion", "role": "intermediate"},
    "AL199": {"type": "Align Motion", "role": "end"},
    # Expose Motion
    "EX500": {"type": "Expose Motion", "role": "start"},
    "ST3002": {"type": "Expose Motion", "role": "intermediate"},
    "SC701": {"type": "Expose Motion", "role": "intermediate"},
    "ST3003": {"type": "Expose Motion", "role": "end"},
    "EX599": {"type": "Expose Motion", "role": "end"},
    # Unload Motion
    "ST3099": {"type": "Unload Motion", "role": "start"},
    "TR2001": {"type": "Unload Motion", "role": "start"},
    "RB2101": {"type": "Unload Motion", "role": "intermediate"},
    "RB2102": {"type": "Unload Motion", "role": "intermediate"},
    "RB2103": {"type": "Unload Motion", "role": "intermediate"},
    "RB2104": {"type": "Unload Motion", "role": "intermediate"},
    "RB2105": {"type": "Unload Motion", "role": "end"},
    "TR2099": {"type": "Unload Motion", "role": "end"},
    # Focus Check
    "F901": {"type": "Focus Check", "role": "end"},
    # System
    "SYS200": {"type": "System Status", "role": "intermediate"},
}

# --- Helper Functions ---

def detect_encoding(file_path):
    """Auto-detect file encoding."""
    encodings = ['utf-8', 'cp949', 'latin-1']
    for enc in encodings:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                f.read(1024)
            return enc
        except UnicodeDecodeError:
            continue
    return 'utf-8' # Default fallback

def load_notes():
    """Load motion notes from JSON file."""
    if NOTES_FILE_PATH.exists():
        try:
            with open(NOTES_FILE_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}

def parse_line(line):
    """Parse a single log line into components."""
    line = line.strip()
    if not line or line.startswith('#'):
        return None
    
    # Split by tab
    parts = line.split('\t')
    if len(parts) < 2:
        return None
    
    # Clean parts (remove empty strings from multiple tabs)
    parts = [p.strip() for p in parts if p.strip()]
    
    if len(parts) < 2:
        return None
        
    timestamp = parts[0]
    raw_code = parts[1]
    
    # Normalize code (remove EVT# prefix if present)
    if raw_code.startswith('EVT#'):
        code = raw_code[4:]
    else:
        code = raw_code
        
    # Extract fields (KEY=VALUE)
    fields = {}
    for part in parts[2:]:
        if '=' in part:
            key, value = part.split('=', 1)
            fields[key.strip()] = value.strip()
            
    return {
        'timestamp': timestamp,
        'code': code,
        'fields': fields
    }

def classify_event(code, fields):
    """Classify event based on rules."""
    rule = MOTION_RULES.get(code)
    if not rule:
        return None
        
    motion_type = rule['type']
    role = rule['role']
    
    # Determine severity based on fields
    severity = 'INFO'
    if 'Status' in fields:
        status = fields['Status']
        if 'Fail' in status or 'NG' in status:
            severity = 'ERROR'
        elif 'Pass' in status or 'OK' in status:
            severity = 'OK'
        elif 'InSpec' in status:
            severity = 'WARNING'
            
    if 'Result' in fields:
        res = fields['Result']
        if 'NG' in res:
            severity = 'ERROR'
            
    return {
        'motion_type': motion_type,
        'role': role,
        'severity': severity,
        'fields': fields
    }

def get_parent_id(motion_type, wafer_id, seq_id=None):
    """Generate a parent ID for nested motions."""
    # Simple hash based on type and wafer to group nested motions
    return f"{motion_type}_{wafer_id}"

def insert_motion(conn, row):
    """Insert a motion event into SQLite."""
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO motion_events (
            equipment_id, wafer_id, motion_type, motion_start_ts, 
            motion_end_ts, duration_sec, severity, note, 
            parent_motion_id, attributes, parser_version
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        row['equipment_id'],
        row['wafer_id'],
        row['motion_type'],
        row['motion_start_ts'],
        row['motion_end_ts'],
        row['duration_sec'],
        row['severity'],
        row['note'],
        row['parent_motion_id'],
        row['attributes'],
        'v1'
    ))
    conn.commit()

def process_log(input_path, db_path):
    """Main processing logic."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS motion_events (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id     TEXT,
            wafer_id         TEXT,
            motion_type      TEXT,
            motion_start_ts  DATETIME,
            motion_end_ts    DATETIME,
            duration_sec     REAL,
            severity         TEXT DEFAULT 'INFO',
            note             TEXT,
            parent_motion_id INTEGER,
            attributes       TEXT,
            parser_version   TEXT DEFAULT 'v1',
            created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    
    # Load notes
    notes = load_notes()
    
    # Active motions tracking: {parent_id: {start_ts, wafer_id, type, fields}}
    active_motions = {}
    
    # Current timestamp for timeout check
    current_time = datetime.datetime.now()
    
    try:
        with open(input_path, 'r', encoding=detect_encoding(input_path)) as f:
            for line in f:
                parsed = parse_line(line)
                if not parsed:
                    continue
                
                classification = classify_event(parsed['code'], parsed['fields'])
                if not classification:
                    continue
                
                # Extract entities
                wafer_id = parsed['fields'].get('Wafer', '')
                equipment_id = parsed['fields'].get('Tool', '')
                seq_id = parsed['fields'].get('Seq', '')
                
                # Handle nested motions (e.g., SC701 inside EX500)
                parent_id = get_parent_id(classification['motion_type'], wafer_id)
                
                # Check timeout for existing active motions
                for pid, data in list(active_motions.items()):
                    if current_time - datetime.datetime.fromisoformat(data['start_ts']) > datetime.timedelta(seconds=TIMEOUT_SECONDS):
                        # Flush timeout
                        row = {
                            'equipment_id': equipment_id,
                            'wafer_id': data['wafer_id'],
                            'motion_type': data['motion_type'],
                            'motion_start_ts': data['start_ts'],
                            'motion_end_ts': None,
                            'duration_sec': None,
                            'severity': 'TIMEOUT',
                            'note': 'Timeout',
                            'parent_motion_id': pid,
                            'attributes': json.dumps(data['fields'])
                        }
                        insert_motion(conn, row)
                        del active_motions[pid]
                        
                # Process current event
                if classification['role'] == 'start':
                    active_motions[parent_id] = {
                        'start_ts': parsed['timestamp'],
                        'wafer_id': wafer_id,
                        'motion_type': classification['motion_type'],
                        'fields': parsed['fields']
                    }
                elif classification['role'] == 'end':
                    if parent_id in active_motions:
                        data = active_motions[parent_id]
                        start_ts = data['start_ts']
                        end_ts = parsed['timestamp']
                        duration = (datetime.datetime.fromisoformat(end_ts) - datetime.datetime.fromisoformat(start_ts)).total_seconds()
                        
                        # Aggregate fields for attributes
                        all_fields = {**data['fields'], **parsed['fields']}
                        
                        row = {
                            'equipment_id': equipment_id,
                            'wafer_id': wafer_id,
                            'motion_type': classification['motion_type'],
                            'motion_start_ts': start_ts,
                            'motion_end_ts': end_ts,
                            'duration_sec': duration,
                            'severity': classification['severity'],
                            'note': notes.get(classification['motion_type'], ''),
                            'parent_motion_id': parent_id,
                            'attributes': json.dumps(all_fields)
                        }
                        insert_motion(conn, row)
                        del active_motions[parent_id]
                elif classification['role'] == 'intermediate':
                    # Update active motion fields if exists
                    if parent_id in active_motions:
                        active_motions[parent_id]['fields'].update(parsed['fields'])
                        
    except Exception as e:
        print(f"Error processing log: {e}", file=sys.stderr)
    finally:
        conn.close()

def main():
    parser = argparse.ArgumentParser(description='Semiconductor Log Parser')
    parser.add_argument('--input', required=True, help='Path to log file')
    parser.add_argument('--db', required=True, help='Path to SQLite database')
    
    args = parser.parse_args()
    
    process_log(args.input, args.db)

if __name__ == "__main__":
    main()
```
```

## Extracted Code

→ `iter_01_code.py`

## Sandbox Observe

- ok: `True`

### stdout
```

[sandbox] motion_events rows inserted: 46
```
