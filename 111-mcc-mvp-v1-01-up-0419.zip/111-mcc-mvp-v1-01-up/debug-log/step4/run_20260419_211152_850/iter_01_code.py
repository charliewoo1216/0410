import argparse
import datetime
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

# --- Constants & Config ---
TIMEOUT_SECONDS = 30
NOTES_FILE_PATH = Path(__file__).parent / "motion_notes.json"

# --- Motion Classification Rules ---
# Maps normalized event codes to motion types and roles (start, end, intermediate)
MOTION_RULES = {
    # Load Motion
    "TR1001": {"type": "Load Motion", "role": "start"},
    "RB2001": {"type": "Load Motion", "role": "intermediate"},
    "RB2002": {"type": "Load Motion", "role": "intermediate"},
    "RB2003": {"type": "Load Motion", "role": "intermediate"},
    "RB2004": {"type": "Load Motion", "role": "intermediate"},
    "RB2005": {"type": "Load Motion", "role": "end"},
    "TR1099": {"type": "Load Motion", "role": "end"},
    # Align Motion
    "ST3001": {"type": "Align Motion", "role": "start"},
    "PA401": {"type": "Align Motion", "role": "intermediate"},
    "AL100": {"type": "Align Motion", "role": "start"},
    "AL101": {"type": "Align Motion", "role": "intermediate"},
    "AL102": {"type": "Align Motion", "role": "intermediate"},
    "AL103": {"type": "Align Motion", "role": "intermediate"},
    "AL104": {"type": "Align Motion", "role": "intermediate"},
    "AL105": {"type": "Align Motion", "role": "intermediate"},
    "AL106": {"type": "Align Motion", "role": "intermediate"},
    "AL107": {"type": "Align Motion", "role": "intermediate"},
    "AL108": {"type": "Align Motion", "role": "intermediate"},
    "AL109": {"type": "Align Motion", "role": "intermediate"},
    "AL110": {"type": "Align Motion", "role": "intermediate"},
    "AL111": {"type": "Align Motion", "role": "intermediate"},
    "AL112": {"type": "Align Motion", "role": "intermediate"},
    "AL113": {"type": "Align Motion", "role": "intermediate"},
    "AL114": {"type": "Align Motion", "role": "intermediate"},
    "AL115": {"type": "Align Motion", "role": "intermediate"},
    "AL116": {"type": "Align Motion", "role": "intermediate"},
    "AL199": {"type": "Align Motion", "role": "end"},
    # Expose Motion
    "EX500": {"type": "Expose Motion", "role": "start"},
    "ST3002": {"type": "Expose Motion", "role": "intermediate"},
    "SC701": {"type": "Expose Motion", "role": "intermediate"},
    "ST3003": {"type": "Expose Motion", "role": "end"},
    "EX599": {"type": "Expose Motion", "role": "end"},
    # Unload Motion
    "ST3099": {"type": "Unload Motion", "role": "start"},
    "TR2001": {"type": "Unload Motion", "role": "start"},
    "RB2101": {"type": "Unload Motion", "role": "intermediate"},
    "RB2102": {"type": "Unload Motion", "role": "intermediate"},
    "RB2103": {"type": "Unload Motion", "role": "intermediate"},
    "RB2104": {"type": "Unload Motion", "role": "intermediate"},
    "RB2105": {"type": "Unload Motion", "role": "end"},
    "TR2099": {"type": "Unload Motion", "role": "end"},
    # Focus Check
    "F901": {"type": "Focus Check", "role": "end"},
    # System
    "SYS200": {"type": "System Status", "role": "intermediate"},
}

# --- Helper Functions ---

def detect_encoding(file_path):
    """Auto-detect file encoding."""
    encodings = ['utf-8', 'cp949', 'latin-1']
    for enc in encodings:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                f.read(1024)
            return enc
        except UnicodeDecodeError:
            continue
    return 'utf-8' # Default fallback

def load_notes():
    """Load motion notes from JSON file."""
    if NOTES_FILE_PATH.exists():
        try:
            with open(NOTES_FILE_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}

def parse_line(line):
    """Parse a single log line into components."""
    line = line.strip()
    if not line or line.startswith('#'):
        return None
    
    # Split by tab
    parts = line.split('\t')
    if len(parts) < 2:
        return None
    
    # Clean parts (remove empty strings from multiple tabs)
    parts = [p.strip() for p in parts if p.strip()]
    
    if len(parts) < 2:
        return None
        
    timestamp = parts[0]
    raw_code = parts[1]
    
    # Normalize code (remove EVT# prefix if present)
    if raw_code.startswith('EVT#'):
        code = raw_code[4:]
    else:
        code = raw_code
        
    # Extract fields (KEY=VALUE)
    fields = {}
    for part in parts[2:]:
        if '=' in part:
            key, value = part.split('=', 1)
            fields[key.strip()] = value.strip()
            
    return {
        'timestamp': timestamp,
        'code': code,
        'fields': fields
    }

def classify_event(code, fields):
    """Classify event based on rules."""
    rule = MOTION_RULES.get(code)
    if not rule:
        return None
        
    motion_type = rule['type']
    role = rule['role']
    
    # Determine severity based on fields
    severity = 'INFO'
    if 'Status' in fields:
        status = fields['Status']
        if 'Fail' in status or 'NG' in status:
            severity = 'ERROR'
        elif 'Pass' in status or 'OK' in status:
            severity = 'OK'
        elif 'InSpec' in status:
            severity = 'WARNING'
            
    if 'Result' in fields:
        res = fields['Result']
        if 'NG' in res:
            severity = 'ERROR'
            
    return {
        'motion_type': motion_type,
        'role': role,
        'severity': severity,
        'fields': fields
    }

def get_parent_id(motion_type, wafer_id, seq_id=None):
    """Generate a parent ID for nested motions."""
    # Simple hash based on type and wafer to group nested motions
    return f"{motion_type}_{wafer_id}"

def insert_motion(conn, row):
    """Insert a motion event into SQLite."""
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO motion_events (
            equipment_id, wafer_id, motion_type, motion_start_ts, 
            motion_end_ts, duration_sec, severity, note, 
            parent_motion_id, attributes, parser_version
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        row['equipment_id'],
        row['wafer_id'],
        row['motion_type'],
        row['motion_start_ts'],
        row['motion_end_ts'],
        row['duration_sec'],
        row['severity'],
        row['note'],
        row['parent_motion_id'],
        row['attributes'],
        'v1'
    ))
    conn.commit()

def process_log(input_path, db_path):
    """Main processing logic."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS motion_events (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id     TEXT,
            wafer_id         TEXT,
            motion_type      TEXT,
            motion_start_ts  DATETIME,
            motion_end_ts    DATETIME,
            duration_sec     REAL,
            severity         TEXT DEFAULT 'INFO',
            note             TEXT,
            parent_motion_id INTEGER,
            attributes       TEXT,
            parser_version   TEXT DEFAULT 'v1',
            created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    
    # Load notes
    notes = load_notes()
    
    # Active motions tracking: {parent_id: {start_ts, wafer_id, type, fields}}
    active_motions = {}
    
    # Current timestamp for timeout check
    current_time = datetime.datetime.now()
    
    try:
        with open(input_path, 'r', encoding=detect_encoding(input_path)) as f:
            for line in f:
                parsed = parse_line(line)
                if not parsed:
                    continue
                
                classification = classify_event(parsed['code'], parsed['fields'])
                if not classification:
                    continue
                
                # Extract entities
                wafer_id = parsed['fields'].get('Wafer', '')
                equipment_id = parsed['fields'].get('Tool', '')
                seq_id = parsed['fields'].get('Seq', '')
                
                # Handle nested motions (e.g., SC701 inside EX500)
                parent_id = get_parent_id(classification['motion_type'], wafer_id)
                
                # Check timeout for existing active motions
                for pid, data in list(active_motions.items()):
                    if current_time - datetime.datetime.fromisoformat(data['start_ts']) > datetime.timedelta(seconds=TIMEOUT_SECONDS):
                        # Flush timeout
                        row = {
                            'equipment_id': equipment_id,
                            'wafer_id': data['wafer_id'],
                            'motion_type': data['motion_type'],
                            'motion_start_ts': data['start_ts'],
                            'motion_end_ts': None,
                            'duration_sec': None,
                            'severity': 'TIMEOUT',
                            'note': 'Timeout',
                            'parent_motion_id': pid,
                            'attributes': json.dumps(data['fields'])
                        }
                        insert_motion(conn, row)
                        del active_motions[pid]
                        
                # Process current event
                if classification['role'] == 'start':
                    active_motions[parent_id] = {
                        'start_ts': parsed['timestamp'],
                        'wafer_id': wafer_id,
                        'motion_type': classification['motion_type'],
                        'fields': parsed['fields']
                    }
                elif classification['role'] == 'end':
                    if parent_id in active_motions:
                        data = active_motions[parent_id]
                        start_ts = data['start_ts']
                        end_ts = parsed['timestamp']
                        duration = (datetime.datetime.fromisoformat(end_ts) - datetime.datetime.fromisoformat(start_ts)).total_seconds()
                        
                        # Aggregate fields for attributes
                        all_fields = {**data['fields'], **parsed['fields']}
                        
                        row = {
                            'equipment_id': equipment_id,
                            'wafer_id': wafer_id,
                            'motion_type': classification['motion_type'],
                            'motion_start_ts': start_ts,
                            'motion_end_ts': end_ts,
                            'duration_sec': duration,
                            'severity': classification['severity'],
                            'note': notes.get(classification['motion_type'], ''),
                            'parent_motion_id': parent_id,
                            'attributes': json.dumps(all_fields)
                        }
                        insert_motion(conn, row)
                        del active_motions[parent_id]
                elif classification['role'] == 'intermediate':
                    # Update active motion fields if exists
                    if parent_id in active_motions:
                        active_motions[parent_id]['fields'].update(parsed['fields'])
                        
    except Exception as e:
        print(f"Error processing log: {e}", file=sys.stderr)
    finally:
        conn.close()

def main():
    parser = argparse.ArgumentParser(description='Semiconductor Log Parser')
    parser.add_argument('--input', required=True, help='Path to log file')
    parser.add_argument('--db', required=True, help='Path to SQLite database')
    
    args = parser.parse_args()
    
    process_log(args.input, args.db)

if __name__ == "__main__":
    main()