# CHECKLIST.md — Motion Parser MVP v1 구현 체크리스트
> Claude Code가 구현을 진행하면서 완료된 항목을 체크한다.
> 항목 완료 시 `[ ]` → `[x]` 로 변경.

---

## Phase 0 — 프로젝트 초기화

- [x] `output/` 폴더 생성
- [x] `requirements.txt` 작성
- [x] `pip install -r requirements.txt` 확인
- [x] `mcc-log-file/` 폴더 존재 확인 (없으면 빈 폴더 생성 + README 안내)
- [x] Python 버전 확인 (3.10 이상 권장)  — 3.11.9

---

## Phase 1 — 공통 유틸리티

### ai_config.py
- [x] `DEFAULT_CONFIG` 딕셔너리 정의 (base_url / model / api_key)
- [x] `render_config_sidebar()` 함수 구현
  - [x] `st.sidebar.text_input` 3개 (Base URL / Model / API Key)
  - [x] `session_state['ai_config']` 저장
  - [x] 반환값: 현재 설정 dict

### utils/llm_client.py
- [x] `LLMClient` 클래스 구현
  - [x] `__init__(base_url, model, api_key)` — openai.OpenAI 클라이언트 초기화
  - [x] `chat(messages, stream=False, temperature, max_tokens)` — 논스트리밍
  - [x] `stream_chat(messages, ...)` — 스트리밍 제너레이터
  - [x] Qwen3 `<think>...</think>` 태그 자동 제거 처리
  - [x] API 실패 시 최대 3회 재시도 (1초 간격)
  - [x] 모든 호출 try/except 처리

### utils/log_sampler.py
- [x] `scan_log_files(base_dir)` 구현
  - [x] `.log` / `.txt` / `.csv` 재귀 탐색
  - [x] 인코딩 자동 감지 (utf-8 → euc-kr → cp949 순)
  - [x] 반환: `[{path, size_mb, total_lines, encoding}, ...]`
- [x] `sample_logs(file_infos, target_lines)` 구현
  - [x] 파일별 비례 배분 계산
  - [x] stride 균등 샘플링
  - [x] 반환: 샘플 라인 리스트 (str)
- [x] `estimate_tokens(lines)` 구현
  - [x] `sum(len(l) for l in lines) / 3.5` 로 토큰 추정

### utils/file_manager.py
- [x] `OUTPUT_DIR = Path("output")` 상수 정의
- [x] `save_md(filename, content)` 구현
- [x] `load_md(filename)` 구현 — 파일 없으면 None 반환
- [x] `save_py(filename, content)` 구현
- [x] `load_py(filename)` 구현
- [x] `check_step_done(step)` 구현
  - [x] step별 필수 파일 매핑 테이블
  - [x] 파일 존재 여부 bool 반환

---

## Phase 2 — app.py (메인)

- [x] 페이지 설정 (`st.set_page_config` — layout="wide")
- [x] 앱 시작 시 `output/` 폴더 자동 생성
- [x] 앱 시작 시 `session_state` 초기화
  - [x] `check_step_done(n)` 으로 기존 파일 기반 복원
- [x] `ai_config.render_config_sidebar()` 호출
- [x] 사이드바 Step 버튼 5개 렌더링
  - [x] 각 버튼: 이전 step_done 조건으로 `disabled` 제어
  - [x] 완료된 Step은 ✅ 아이콘 표시
  - [x] 현재 선택 Step은 강조 표시
- [x] `session_state['current_step']` 에 따라 메인 영역 렌더링
  - [x] `step1_log_selection.render()`
  - [x] `step2_ai_analysis.render()`
  - [x] `step3_verification.render()`
  - [x] `step4_code_generation.render()`
  - [x] `step5_volume_test.render()`

---

## Phase 3 — Step 1: Log Selection

### steps/step1_log_selection.py
- [x] `render()` 함수 구현
- [x] 로그 파일 목록 스캔 (`log_sampler.scan_log_files`)
- [x] 파일 목록 테이블 표시
  - [x] 컬럼: 파일명 / 크기(MB) / 총 라인 수 / 인코딩
- [x] `target_lines` 슬라이더 (10,000 ~ 200,000, 기본 120,000)
- [x] [샘플링 시작] 버튼
  - [x] `st.progress` 바 + 현재 처리 파일명 실시간 업데이트
  - [x] 완료 후 `session_state['sampled_lines']` 저장
- [x] 샘플 미리보기 100줄 (`st.code`)
- [x] 토큰 예상치 표시
- [x] 완료 시 `step1_done = True` + 성공 메시지

---

## Phase 4 — Step 2: AI Analysis

### steps/step2_ai_analysis.py
- [x] `render()` 함수 구현
- [x] 2-1. 원시로그템플릿.md 생성
  - [x] [원시로그템플릿 생성] 버튼
  - [x] LLM 스트리밍 호출 (`st.write_stream`)
  - [x] 완료 → `output/원시로그템플릿.md` 저장
  - [x] `st.expander` 로 결과 표시
- [x] 2-2. 이벤트분석_v1.md 생성
  - [x] 원시로그템플릿 완료 후 버튼 활성화
  - [x] LLM 스트리밍 호출
  - [x] 완료 → `output/이벤트분석_v1.md` 저장
  - [x] `st.expander` 로 결과 표시
- [x] 2-3. 채팅 UI
  - [x] `session_state['step2_chat_history']` 초기화 (AI 첫 메시지 포함)
  - [x] 대화 히스토리 렌더링 (`st.chat_message`)
  - [x] `st.chat_input` 입력 처리
  - [x] 사용자 메시지 → 전체 히스토리 + 현재 md 내용 포함해 LLM 호출
  - [x] AI 응답 스트리밍 표시
  - [x] [✓ v2 확정 저장] 버튼
    - [x] 현재 이벤트분석_v1.md → 이벤트분석_v2.md 복사
    - [x] `step2_done = True`
    - [x] 성공 메시지 + Step 3 활성화 안내

---

## Phase 5 — Step 3: Verification

### steps/step3_verification.py
- [x] `render()` 함수 구현
- [x] 참조 파일 표시 (이벤트분석_v2.md / 원시로그템플릿.md 내용 expander)
- [x] 3-1. 모션_페어링_분석_v1.md 생성
  - [x] [페어링 분석 생성] 버튼
  - [x] 프롬프트: 3개 입력(원시로그템플릿.md + 이벤트분석_v2.md + 샘플 로그 일부)
  - [x] LLM 스트리밍 호출
  - [x] 완료 → `output/모션_페어링_분석_v1.md` 저장
  - [x] `st.expander` 로 결과 표시
- [x] 3-2. 채팅 UI
  - [x] `session_state['step3_chat_history']` 초기화
  - [x] Step 2와 동일한 채팅 구조
  - [x] [✓ v2 확정 저장] 버튼
    - [x] 모션_페어링_분석_v2.md 저장
    - [x] `step3_done = True`

---

## Phase 6 — Step 4: Code Generation

### steps/step4_code_generation.py
- [x] `render()` 함수 구현
- [x] 참조 문서 3종 로드 확인 표시
- [x] [코드 생성 시작] 버튼
- [x] ReAct 루프 구현 (최대 10회)
  - [x] 각 iteration `st.expander(f"Iteration {n}")` 생성
    - [x] [Think] 탭: LLM 분석 내용
    - [x] [Act] 탭: 생성된 코드
    - [x] [Observe] 탭: 실행 결과 (성공/에러)
  - [x] `st.progress(n / max_iter)` 전체 진행률
  - [x] 코드 추출: LLM 응답에서 ` ```python ... ``` ` 제거
  - [x] `exec()` 실행 → 성공 판별
    - [x] 성공: 루프 탈출
    - [x] 실패: 트레이스백 + 실패 라인 → 다음 프롬프트에 포함
  - [x] max_iter 초과 시: 마지막 코드 저장 + 경고 표시
- [x] 성공 시
  - [x] `output/parser_v1.py` 저장
  - [x] 생성 코드 전체 `st.code` 표시
  - [x] `step4_done = True`

---

## Phase 7 — Step 5: Volume Test

### steps/step5_volume_test.py
- [x] `render()` 함수 구현
- [x] parser_v1.py 존재 확인
- [x] 전체 로그 파일 목록 표시 (파일명 / 크기)
- [x] [전체 테스트 시작] 버튼
- [x] 파일별 순차 처리
  - [x] `subprocess.run(['python', 'output/parser_v1.py', '--input', 파일, '--db', 'output/events.db'], timeout=300)`
  - [x] `st.empty()` placeholder 로 진행 상황 실시간 업데이트
  - [x] `st.progress(처리파일수 / 전체파일수)`
  - [x] 파일별 결과 누적 (성공 라인 / 실패 라인 / 이벤트 수)
- [x] 전체 완료 후 메트릭 표시
  - [x] `st.metric` 4개: Parse Rate / Pairing Rate / False Pair Rate / 처리 속도
  - [x] 목표 미달 항목 빨간색 경고
- [x] SQLite 결과 테이블 미리보기
  - [x] `st.dataframe(events_df.head(100))`
- [x] 모션 타입별 집계 바 차트 (`st.bar_chart`)
- [x] 성능 미달 시 재작업 경로 안내 카드
- [x] `step5_done = True`

---

## Phase 8 — 통합 테스트

- [x] `streamlit run app.py` 정상 실행 확인  — 헤드리스 부팅 OK (HTTP 200)
- [ ] Step 1: 로그 파일 없는 경우 안내 메시지 표시
- [ ] Step 1 → Step 2 전환 시 사이드바 버튼 활성화 확인
- [ ] Step 2 채팅: 대화 히스토리 누적 확인
- [ ] Step 2 → Step 3 전환 (v2 확정 저장) 확인
- [ ] Step 3 채팅: 중첩 모션 시나리오 대화 처리 확인
- [ ] Step 4 ReAct: 최소 1회 성공 케이스 확인
- [ ] Step 4 ReAct: 실패 → 재시도 루프 확인
- [ ] Step 5: subprocess 실행 + SQLite 저장 확인
- [ ] 앱 재시작 시 이전 진행 상태 복원 확인
- [ ] AI Config 변경 시 즉시 적용 확인

---

## Phase 9 — 엣지케이스 처리

- [ ] `mcc-log-file/` 폴더가 비어있는 경우 → Step 1에서 안내 메시지
- [ ] 인코딩 감지 실패 파일 → 건너뛰기 + 경고 로그
- [ ] LLM API 연결 실패 → `st.error` + 재시도 버튼
- [ ] Step 4 max_iter 10회 모두 실패 → 마지막 코드 저장 + 수동 수정 안내
- [ ] parser_v1.py 실행 중 타임아웃(300초) → 에러 표시
- [ ] output/ 파일 손상/누락 → 해당 step 재실행 유도
- [ ] 샘플링 결과가 0줄인 경우 → 경고 + 슬라이더 조정 안내

---

## 완료 기준

모든 Phase 체크 완료 후 아래를 최종 확인:

- [ ] `streamlit run app.py` — 에러 없이 실행
- [ ] Step 1~5 순차 진행 — 에러 없이 완료
- [ ] `output/events.db` — 모션 이벤트 1건 이상 저장
- [ ] `output/parser_v1.py` — 독립 실행 가능
- [ ] 앱 재시작 후 — 이전 진행 상태 유지
