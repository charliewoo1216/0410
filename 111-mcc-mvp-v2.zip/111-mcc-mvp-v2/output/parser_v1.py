"""
parser_v1.py — ASML JB64 스캐너 이벤트 로그 모션 파서 (v1)

대상 로그 포맷 (mcc-log-file/asml-eventlog.log):
    MM/DD/YYYY HH:MM:SS.ffff Machine:JB64 (Rel:6.3.0.b, LOMW[13206], LOMWxKC_load_cassette.c) \
    SYSTEM EVENT: LO-8011 DEFAULT Cassette load started. Loading cassette into port 3, 25 wafers detected.

설계 문서: 원시로그템플릿.md / 이벤트분석_v2.md / 모션_페어링_분석_v2.md

핵심 규칙:
- 이벤트 코드는 LO-XXXX (16진). 공정 모션은 started→finished 쌍이며 finished = started + 1.
- **row-per-event**: 매칭된 모든 로그 라인을 motion_events 1행으로 적재(②파싱 단계).
- **PROCESS_TIME_MS**: 동일 동작(same operation) 기준으로 start–end 페어를 찾고,
  (end 시각 − start 시각)을 ms로 환산해 END row에 기록한다.
  동일 동작 매칭 키 = (시작 코드, LOMW tid) — 한 스레드가 한 동작의 start→end를 수행.
- SIGNAL: 시작코드→START / 종료코드(=start+1)→END / 그 외(90xx 모니터·70xx 경고)→MID.
- IS_MOTION_RELATED: 80xx 페어 코드=Y, 그 외=N. ③LLM·④엔지니어 자유서술 컬럼은 NULL(후속 단계).
- 실행마다 PARSE_JOBS에 1행(job_id=uuid) 기록, motion_events.JOB_ID가 이를 참조.

CLI: python parser_v1.py --input <로그파일> --db output/events.db
"""

import argparse
import re
import sqlite3
import sys
import traceback
import uuid
from datetime import datetime
from pathlib import Path

# --- 상수 ---
PARSER_VERSION = "v1"

# 라인 파서 정규식: 타임스탬프 / 장비 / 소스모듈 / 코드 / 심각도 / 메시지
LINE_RE = re.compile(
    r"^(?P<ts>\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}\.\d+)\s+"
    r"Machine:(?P<machine>\S+)\s+"
    r"\(Rel:[^,]+,\s*LOMW\[(?P<tid>\d+)\],\s*(?P<src>[^)]+)\)\s+"
    r"SYSTEM EVENT:\s+(?P<code>LO-[0-9A-Fa-f]+)\s+"
    r"(?P<sev>\w+)\s+(?P<msg>.*)$"
)

TS_FMT = "%m/%d/%Y %H:%M:%S.%f"

# --- 모션 시작 코드 → (모션 이름, 패턴) ---
# 종료 코드는 시작 코드 + 1 규칙으로 자동 계산한다.
# 패턴: simple / group(필드 노광 루프) / conditional(품질 분기 포함)
START_MOTIONS = {
    0x8011: ("Cassette Load", "simple"),
    0x8013: ("Cassette Unload", "simple"),
    0x8015: ("Cassette Map", "simple"),
    0x8017: ("Wafer ID Read", "simple"),
    0x8019: ("Wafer Load", "simple"),
    0x801B: ("Wafer Unload", "simple"),
    0x801D: ("Wafer Transfer", "simple"),
    0x801F: ("Wafer Chuck", "simple"),
    0x8021: ("Prealign", "simple"),
    0x8023: ("Mark Search", "simple"),
    0x8025: ("Chuck Exchange", "simple"),
    0x8027: ("Chuck Cleaning", "simple"),
    0x8029: ("Measure", "simple"),
    0x802B: ("Color Alignment", "simple"),
    0x802D: ("Fine Alignment", "simple"),
    0x802F: ("Backside Alignment", "simple"),
    0x8031: ("Leveling", "simple"),
    0x8033: ("Tilt Adjustment", "simple"),
    0x8035: ("Height Map", "simple"),
    0x8037: ("Wafer Mapping", "simple"),
    0x8039: ("Pellicle Check", "simple"),
    0x803B: ("Mark Detection", "simple"),
    0x803D: ("Sensor Calibration", "simple"),
    0x803F: ("Wafer ID Verify", "simple"),
    0x8041: ("Reticle Pod Load", "simple"),
    0x8043: ("Reticle Load", "simple"),
    0x8045: ("Reticle Align", "simple"),
    0x8047: ("Reticle ID Read", "simple"),
    0x8049: ("Reticle Unload", "simple"),
    0x804B: ("Reticle Inspect", "conditional"),
    0x804D: ("Reticle Clamp", "simple"),
    0x804F: ("Reticle Pod Unload", "simple"),
    0x8051: ("Exposure", "group"),
    0x8053: ("Pre-exposure Scan", "group"),
    0x8055: ("Post-exposure Dwell", "group"),
    0x8057: ("Field Stitch", "conditional"),
    0x8059: ("Dose Calibration", "simple"),
    0x805B: ("Illumination On", "simple"),
    0x805D: ("Illumination Off", "simple"),
    0x805F: ("Pupil Setting", "simple"),
    0x8061: ("Stage Move", "group"),
    0x8063: ("Stage Settle", "group"),
    0x8065: ("Stage Stabilization", "simple"),
    0x8067: ("Z-axis Move", "simple"),
    0x8069: ("Acceleration Ramp", "simple"),
    0x806B: ("Deceleration Ramp", "simple"),
    0x806D: ("Focus Calibration", "simple"),
    0x806F: ("Focus Offset", "group"),
    0x8071: ("Beam Shape Adjust", "simple"),
    0x8073: ("Vacuum Check", "simple"),
}

# 시작 코드 정수 집합 / 종료 코드 → 시작 코드 역매핑
START_CODES = set(START_MOTIONS.keys())
END_TO_START = {code + 1: code for code in START_MOTIONS}


def code_str(code_int):
    """정수 코드 → 'LO-XXXX' 표기 (대문자 16진 4자리)."""
    return f"LO-{code_int:04X}"


def parse_line(line):
    """로그 한 줄을 구조화한다. 빈 줄·미매칭은 None 반환."""
    line = line.rstrip("\n")
    if not line.strip():
        return None
    m = LINE_RE.match(line.strip())
    if not m:
        return None
    return {
        "ts": m.group("ts"),
        "machine": m.group("machine"),
        "tid": m.group("tid"),
        "src": m.group("src"),
        "code_hex": m.group("code")[3:].upper(),   # 'LO-8051' → '8051'
        "severity_raw": m.group("sev"),
        "msg": m.group("msg"),
    }


def parse_ts(ts):
    try:
        return datetime.strptime(ts, TS_FMT)
    except ValueError:
        return None


DDL_MOTION_EVENTS = """
CREATE TABLE IF NOT EXISTS motion_events (
    ID                       INTEGER PRIMARY KEY AUTOINCREMENT,
    JOB_ID                   TEXT,    -- ② PARSE_JOBS.JOB_ID 참조
    DATETIME                 TEXT,    -- ② regex 추출 타임스탬프
    EVENT_CODE               TEXT,    -- ② 원시 이벤트 코드 (LO-XXXX)
    ORIGIN_MESSAGE           TEXT,    -- ② 원본 로그 라인
    EVENT_NAME               TEXT,    -- ③ 이벤트/모션 명칭
    SIGNAL                   TEXT,    -- ③ 신호 방향 START/END/MID
    START_CODE               TEXT,    -- ③ 모션 시작 코드
    END_CODE                 TEXT,    -- ③ 모션 종료 코드
    LLM_INTERPRETATION       TEXT,    -- ③ LLM 해석 전문 (후속 단계)
    IS_MOTION_RELATED        TEXT,    -- ③④ 모션 관련 여부 Y/N
    ENGINEER_INTERPRETATION  TEXT,    -- ④ 엔지니어 해석 (후속 단계)
    REMARK                   TEXT,    -- ③④ 비고
    PROCESS_TIME_MS          REAL,    -- Step4 동일동작 start-end 소요(ms)
    CODE_GEN_OK              TEXT,    -- Step4 코드생성 검증 완료 Y/N
    CREATED_AT               TEXT,    -- ② 레코드 생성
    UPDATED_AT               TEXT     -- 전체 최종 수정
)
"""

DDL_PARSE_JOBS = """
CREATE TABLE IF NOT EXISTS PARSE_JOBS (
    JOB_ID          TEXT PRIMARY KEY,
    INPUT_FILE      TEXT,
    STARTED_AT      TEXT,
    FINISHED_AT     TEXT,
    STATUS          TEXT,
    TOTAL_LINES     INTEGER,
    TOTAL_EVENTS    INTEGER,
    PAIRED_MOTIONS  INTEGER,
    PARSER_VERSION  TEXT
)
"""

INSERT_EVENT = """
INSERT INTO motion_events (
    JOB_ID, DATETIME, EVENT_CODE, ORIGIN_MESSAGE, EVENT_NAME, SIGNAL,
    START_CODE, END_CODE, LLM_INTERPRETATION, IS_MOTION_RELATED,
    ENGINEER_INTERPRETATION, REMARK, PROCESS_TIME_MS, CODE_GEN_OK,
    CREATED_AT, UPDATED_AT
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
"""


def process_log(input_path, db_path):
    """로그를 순차 처리해 row-per-event로 motion_events에 적재한다.
    동일 동작(시작 코드, tid) 기준으로 start-end 페어를 찾아 END row에 PROCESS_TIME_MS를 기록."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(DDL_MOTION_EVENTS)
    cur.execute(DDL_PARSE_JOBS)
    conn.commit()

    job_id = str(uuid.uuid4())
    started_at = datetime.now().isoformat(sep=" ", timespec="seconds")
    cur.execute(
        "INSERT INTO PARSE_JOBS (JOB_ID, INPUT_FILE, STARTED_AT, STATUS, PARSER_VERSION) "
        "VALUES (?,?,?,?,?)",
        (job_id, str(input_path), started_at, "RUNNING", PARSER_VERSION),
    )
    conn.commit()

    # 동일 동작 진행 중 페어: (시작 코드, tid) -> 시작 datetime
    open_pairs = {}
    total_lines = 0
    total_events = 0
    paired = 0

    def insert_event(rec, raw_line, event_name, signal, start_code, end_code,
                     is_motion, process_ms):
        now = datetime.now().isoformat(sep=" ", timespec="seconds")
        dt = parse_ts(rec["ts"])
        cur.execute(INSERT_EVENT, (
            job_id,
            dt.isoformat(sep=" ") if dt else rec["ts"],
            f"LO-{rec['code_hex']}",
            raw_line,
            event_name,
            signal,
            start_code,
            end_code,
            None,                       # LLM_INTERPRETATION (후속)
            "Y" if is_motion else "N",
            None,                       # ENGINEER_INTERPRETATION (후속)
            None,                       # REMARK
            process_ms,
            "Y",                        # CODE_GEN_OK (파서 정상 적재)
            now, now,
        ))

    with open(input_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            raw = line.rstrip("\n")
            rec = parse_line(line)
            if rec is None:
                if raw.strip():
                    total_lines += 1
                continue
            total_lines += 1
            try:
                code = int(rec["code_hex"], 16)
            except ValueError:
                continue

            if code in START_CODES:
                # 동일 동작 시작: 페어 스택에 시작 시각 보관
                motion_name = START_MOTIONS[code][0]
                open_pairs[(code, rec["tid"])] = parse_ts(rec["ts"])
                insert_event(rec, raw, motion_name, "START",
                             code_str(code), code_str(code + 1), True, None)
            elif code in END_TO_START:
                # 동일 동작 종료: 매칭 start를 찾아 PROCESS_TIME_MS 계산
                start_code = END_TO_START[code]
                motion_name = START_MOTIONS[start_code][0]
                start_dt = open_pairs.pop((start_code, rec["tid"]), None)
                end_dt = parse_ts(rec["ts"])
                process_ms = None
                if start_dt and end_dt:
                    process_ms = round((end_dt - start_dt).total_seconds() * 1000.0, 3)
                    paired += 1
                insert_event(rec, raw, motion_name, "END",
                             code_str(start_code), code_str(code), True, process_ms)
            else:
                # 90xx 모니터링 / 70xx 경고 등 비모션 이벤트
                insert_event(rec, raw, None, "MID", None, None, False, None)
            total_events += 1

    conn.commit()

    finished_at = datetime.now().isoformat(sep=" ", timespec="seconds")
    cur.execute(
        "UPDATE PARSE_JOBS SET FINISHED_AT=?, STATUS=?, TOTAL_LINES=?, "
        "TOTAL_EVENTS=?, PAIRED_MOTIONS=? WHERE JOB_ID=?",
        (finished_at, "DONE", total_lines, total_events, paired, job_id),
    )
    conn.commit()
    conn.close()
    return job_id, total_events, paired


def main():
    ap = argparse.ArgumentParser(description="ASML JB64 모션 로그 파서 v1")
    ap.add_argument("--input", required=True, help="로그 파일 경로")
    ap.add_argument("--db", required=True, help="SQLite DB 경로")
    args = ap.parse_args()

    if not Path(args.input).exists():
        print(f"입력 파일 없음: {args.input}", file=sys.stderr)
        sys.exit(1)

    try:
        job_id, total_events, paired = process_log(args.input, args.db)
        print(f"[OK] 이벤트 적재: {total_events}건 (완성 페어 {paired}건), "
              f"job_id={job_id} → {args.db}")
    except Exception:
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
