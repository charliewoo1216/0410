"""
Step 2 — AI Analysis.
2-1) 원시로그템플릿.md 생성
2-2) 이벤트분석_v1.md 생성
2-3) 채팅 UI로 수정 → v2 확정
"""
from __future__ import annotations

import re

import streamlit as st

from utils import file_manager
from utils.debug_logger import log_event
from utils.llm_client import build_client_from_session


# ─────────────────────────────────────────────
# 프롬프트
# ─────────────────────────────────────────────
SYSTEM_ANALYST = (
    "당신은 제조 장비 로그 분석 전문가입니다. 어떤 장비의 어떤 포맷인지 "
    "**사전 가정 없이** 로그를 관찰해 스스로 추론합니다. "
    "응답은 요청된 형식의 마크다운 문서만 출력하고, 불필요한 서문/후기는 쓰지 않습니다."
)

PROMPT_TEMPLATE = """다음은 제조 장비의 원시 로그 샘플입니다.

[샘플 로그 시작]
{log_sample}
[샘플 로그 끝]

이 로그를 분석해 **원시로그템플릿.md** 를 작성하세요. 아래 섹션을 모두 포함해야 합니다.

1. **장비 유형 추론** — 어떤 장비로 보이는지, 근거는 무엇인지
2. **타임스탬프 패턴** — 포맷, 정밀도, 예시
3. **이벤트 코드 네이밍 규칙** — 접두사 그룹, 번호 체계, 예시
4. **필드 구조** — KEY=VALUE / 탭 구분 / CSV 등, 공통 필드 나열
5. **특이사항** — 반복 패턴, 그룹 구조, 엔티티 식별자(Wafer/Robot 등)

마크다운만 출력하세요."""

PROMPT_EVENTS_V1 = """다음 [원시로그템플릿.md] 와 [샘플 로그] 를 참고해, **이벤트분석_v1.md** 를 작성하세요.

[원시로그템플릿.md]
{template}

[샘플 로그 시작]
{log_sample}
[샘플 로그 끝]

반드시 포함할 내용:
1. **이벤트 코드 전체 목록** (중복 제거) — 각 코드의 추정 의미
2. **모션 관련 후보 분류** — 마크다운 테이블 (코드 / 의미 / 분류)
   - 분류 값: `모션 시작`, `모션 종료`, `그룹 시퀀스`, `중간 상태`, `선행조건(모션 아님)`, `품질/결과 체크`
3. **그룹 시퀀스 추정** — 헤더 → 바디(반복) → 결과 구조가 있다면 설명
4. **엔티티 식별자** — 모션을 분리하는 키 (예: Wafer, Robot)

마크다운만 출력하세요."""

CHAT_SYSTEM = """당신은 제조 장비 로그 분석가입니다. 엔지니어와 대화하면서 이벤트분석_v1.md 내용을 보완합니다.

규칙:
- 엔지니어의 도메인 지식을 반영해 분석을 개선하세요.
- **문서 전체를 재작성해야 할 때**는 반드시 ```markdown 펜스로 감싼 완전한 md 내용을 응답 말미에 포함하고,
  응답 본문에는 "이벤트분석_v1.md를 업데이트합니다" 문구를 포함하세요.
- 단순 질문/답변일 때는 md 재작성 없이 대화만 하세요.

[현재 원시로그템플릿.md]
{template}

[현재 이벤트분석_v1.md]
{current_md}
"""


# ─────────────────────────────────────────────
# 공통 유틸
# ─────────────────────────────────────────────
_MD_BLOCK_RE = re.compile(r"```(?:markdown|md)?\s*\n(.*?)```", re.DOTALL)


def _extract_md(response: str) -> str | None:
    m = _MD_BLOCK_RE.search(response)
    if m:
        return m.group(1).strip()
    return None


def _join_sample(lines: list[str], max_lines: int | None = None) -> str:
    if max_lines:
        lines = lines[:max_lines]
    return "\n".join(lines)


def _render_header() -> None:
    st.header("02 · AI Analysis")
    st.caption("LLM이 샘플 로그를 관찰해 포맷·이벤트 코드 의미를 자율 추론. 2종 md 파일 생성 후 엔지니어 대화로 보완 → v2 확정. · LLM · Streaming")
    st.divider()


# ─────────────────────────────────────────────
# 메인 render
# ─────────────────────────────────────────────
def render() -> None:
    _render_header()

    sampled = st.session_state.get("sampled_lines", [])
    if not sampled:
        st.warning("⚠ 샘플 로그가 없습니다. Step 1에서 샘플링을 먼저 실행하세요.")
        return

    log_sample_text = _join_sample(sampled)

    # ── 2-1. 원시로그템플릿.md ─────────────
    _section_template(log_sample_text)

    # 2-1 완료되어야 2-2 진행
    template_md = file_manager.load_md("원시로그템플릿.md")
    if not template_md:
        return

    st.markdown("---")

    # ── 2-2. 이벤트분석_v1.md ─────────────
    _section_events_v1(template_md, log_sample_text)

    events_v1_md = file_manager.load_md("이벤트분석_v1.md")
    if not events_v1_md:
        return

    st.markdown("---")

    # ── 2-3. 채팅 UI + v2 확정 ────────────
    _section_chat_and_confirm(template_md)


# ─────────────────────────────────────────────
# 2-1
# ─────────────────────────────────────────────
def _section_template(log_sample_text: str) -> None:
    st.subheader("▸ 2-1. 원시로그템플릿.md")

    existing = file_manager.load_md("원시로그템플릿.md")

    c1, c2 = st.columns([1, 4])
    with c1:
        clicked = st.button(
            "🔄 재생성" if existing else "▶ 템플릿 생성",
            type="primary",
            width="stretch",
            key="btn_template",
        )
    with c2:
        if existing:
            st.success("✓ `output/원시로그템플릿.md` 저장됨.")

    if clicked:
        log_event("step2", "원시로그템플릿 생성 시작")
        client = build_client_from_session()
        messages = [
            {"role": "system", "content": SYSTEM_ANALYST},
            {"role": "user", "content": PROMPT_TEMPLATE.format(log_sample=log_sample_text)},
        ]
        st.markdown("#### 생성 중 (스트리밍)")
        try:
            full = st.write_stream(client.stream_chat(
                messages, temperature=0.2, max_tokens=8000,
                step="step2", purpose="원시로그템플릿",
            ))
            if isinstance(full, list):
                full = "".join(full)
            file_manager.save_md("원시로그템플릿.md", full)
            st.session_state["step2_template_done"] = True
            log_event("step2", "원시로그템플릿.md 저장", f"{len(full)} chars")
            st.success("원시로그템플릿.md 저장 완료.")
            st.rerun()
        except Exception as e:
            log_event("step2", "원시로그템플릿 생성 실패", str(e))
            st.error(f"LLM 호출 실패: {e}")

    existing = file_manager.load_md("원시로그템플릿.md")
    if existing:
        with st.expander("📄 원시로그템플릿.md 보기", expanded=False):
            st.markdown(existing)


# ─────────────────────────────────────────────
# 2-2
# ─────────────────────────────────────────────
def _section_events_v1(template_md: str, log_sample_text: str) -> None:
    st.subheader("▸ 2-2. 이벤트분석_v1.md")

    existing = file_manager.load_md("이벤트분석_v1.md")

    c1, c2 = st.columns([1, 4])
    with c1:
        clicked = st.button(
            "🔄 재생성" if existing else "▶ v1 생성",
            type="primary",
            width="stretch",
            key="btn_events_v1",
        )
    with c2:
        if existing:
            st.success("✓ `output/이벤트분석_v1.md` 저장됨.")

    if clicked:
        log_event("step2", "이벤트분석_v1 생성 시작")
        client = build_client_from_session()
        messages = [
            {"role": "system", "content": SYSTEM_ANALYST},
            {"role": "user", "content": PROMPT_EVENTS_V1.format(
                template=template_md, log_sample=log_sample_text
            )},
        ]
        st.markdown("#### 생성 중 (스트리밍)")
        try:
            full = st.write_stream(client.stream_chat(
                messages, temperature=0.2, max_tokens=8000,
                step="step2", purpose="이벤트분석_v1",
            ))
            if isinstance(full, list):
                full = "".join(full)
            file_manager.save_md("이벤트분석_v1.md", full)
            st.session_state["step2_events_v1_done"] = True
            log_event("step2", "이벤트분석_v1.md 저장", f"{len(full)} chars")
            st.success("이벤트분석_v1.md 저장 완료.")
            st.rerun()
        except Exception as e:
            log_event("step2", "이벤트분석_v1 생성 실패", str(e))
            st.error(f"LLM 호출 실패: {e}")

    existing = file_manager.load_md("이벤트분석_v1.md")
    if existing:
        with st.expander("📄 이벤트분석_v1.md 보기", expanded=False):
            st.markdown(existing)


# ─────────────────────────────────────────────
# 2-3
# ─────────────────────────────────────────────
def _section_chat_and_confirm(template_md: str) -> None:
    st.subheader("▸ 2-3. 엔지니어 검증 대화 → v2 확정")

    history: list[dict] = st.session_state.get("step2_chat_history", [])

    # AI 최초 인삿말 (히스토리 비어 있으면)
    if not history:
        history.append({
            "role": "assistant",
            "content": "이벤트분석_v1.md 초안이 준비됐습니다. 분류가 잘못된 이벤트나 추가해야 할 도메인 규칙이 있으면 알려주세요. 수정이 필요하면 md 전체를 업데이트해드립니다.",
        })
        st.session_state["step2_chat_history"] = history

    # 히스토리 렌더링
    for msg in history:
        role = msg["role"]
        avatar = "🤖" if role == "assistant" else "👤"
        with st.chat_message(role, avatar=avatar):
            st.markdown(msg["content"])

    # 사용자 입력
    user_input = st.chat_input("수정 사항 입력... (예: PA401은 단독 모션, AL100~199는 하나의 시퀀스)")
    if user_input:
        history.append({"role": "user", "content": user_input})
        with st.chat_message("user", avatar="👤"):
            st.markdown(user_input)

        current_md = file_manager.load_md("이벤트분석_v1.md") or ""
        system_msg = CHAT_SYSTEM.format(template=template_md, current_md=current_md)

        messages = [{"role": "system", "content": system_msg}]
        for m in history:
            messages.append({"role": m["role"], "content": m["content"]})

        log_event("step2", "채팅 턴", user_input[:80])
        client = build_client_from_session()
        with st.chat_message("assistant", avatar="🤖"):
            try:
                full = st.write_stream(client.stream_chat(
                    messages, temperature=0.3, max_tokens=6000,
                    step="step2", purpose="chat",
                ))
                if isinstance(full, list):
                    full = "".join(full)
            except Exception as e:
                full = f"⚠ LLM 호출 실패: {e}"
                log_event("step2", "채팅 실패", str(e))
                st.error(full)

        history.append({"role": "assistant", "content": full})
        st.session_state["step2_chat_history"] = history

        # md 업데이트 키워드 감지
        if "이벤트분석_v1.md를 업데이트" in full or "v1.md를 업데이트" in full:
            new_md = _extract_md(full)
            if new_md:
                file_manager.save_md("이벤트분석_v1.md", new_md)
                st.toast("✓ 이벤트분석_v1.md 자동 업데이트 완료")

        st.rerun()

    # v2 확정 저장 버튼
    st.write("")
    c1, c2 = st.columns([1, 4])
    with c1:
        confirm = st.button(
            "✓ v2 확정 저장",
            type="primary",
            width="stretch",
            key="btn_confirm_v2_step2",
        )
    with c2:
        if st.session_state.get("step2_done"):
            st.success("✓ `이벤트분석_v2.md` 저장됨. Step 3 활성화됨.")

    if confirm:
        v1 = file_manager.load_md("이벤트분석_v1.md")
        if not v1:
            st.error("이벤트분석_v1.md 가 없습니다.")
            return
        file_manager.save_md("이벤트분석_v2.md", v1)
        st.session_state["step2_done"] = True
        log_event("step2", "v2 확정 저장", f"이벤트분석_v2.md ({len(v1)} chars)")
        st.success("✓ 이벤트분석_v2.md 저장 완료. Step 3 으로 이동하세요.")
        st.rerun()
