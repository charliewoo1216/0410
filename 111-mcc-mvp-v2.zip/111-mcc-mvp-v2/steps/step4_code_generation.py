"""
Step 4 — Code Generation (ReAct Loop).
3개 md 파일을 근거로 parser_v1.py 를 LLM 이 생성하고, 샘플 로그 일부로 exec() 실행 검증.
실패 시 트레이스백을 프롬프트에 포함해 재시도 (최대 10회).
"""
from __future__ import annotations

import ast as _ast
import io
import re
import sys
import time as _time
import traceback
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

import streamlit as st

from utils import file_manager
from utils.debug_logger import (
    log_event,
    start_step4_run,
    write_step4_iter,
    finalize_step4_run,
)
from utils.llm_client import build_client_from_session


MAX_ITER = 10
SAMPLE_RUN_LINES = 500  # 샌드박스 실행에 쓸 라인 수
SAMPLE_RUN_FILE = file_manager.OUTPUT_DIR / "_sample_run.log"
SAMPLE_RUN_DB = file_manager.OUTPUT_DIR / "_events_sample.db"


SQLITE_SCHEMA = """CREATE TABLE IF NOT EXISTS motion_events (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id     TEXT,
  wafer_id         TEXT,
  motion_type      TEXT,
  motion_start_ts  DATETIME,
  motion_end_ts    DATETIME,
  duration_sec     REAL,
  severity         TEXT DEFAULT 'INFO',
  note             TEXT,     -- 모션 타입 한글 설명 (output/motion_notes.json 에서 로드)
  parent_motion_id INTEGER,
  attributes       TEXT,
  parser_version   TEXT DEFAULT 'v1',
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
);"""


SYSTEM_CODER = (
    "당신은 시니어 파이썬 엔지니어입니다. 제조 장비 로그에서 모션 이벤트를 추출하는 "
    "CLI 파서 스크립트를 작성합니다.\n\n"
    "**응답 형식 — 반드시 준수**\n"
    "- 응답 전체는 정확히 **하나의 ```python 펜스 블록** 으로만 구성된다.\n"
    "- 펜스 밖에 어떤 텍스트도 금지: `Thinking Process:`, `# Analysis:`, "
    "별표 bullet(`*   **...**`), 설명 문장, 인사말, `Let's begin.` 같은 것 전부 금지.\n"
    "- 코드 블록 안에는 **실행 가능한 완전한 파이썬 코드** 만. 마크다운 문법(`*`, `**`, `#` 헤더 등) 포함 금지.\n"
    "- 펜스의 언어 태그는 `python` 으로."
)


PROMPT_INITIAL = """아래 3개 문서를 참고해 **parser_v1.py** 전체 코드를 작성하세요.

[원시로그템플릿.md]
{template}

[이벤트분석_v2.md]
{events_v2}

[모션_페어링_분석_v2.md]
{pairing_v2}

[실제 로그 샘플 — 이 포맷을 정확히 처리해야 함]
```
{log_samples}
```

요구사항:
- **CLI 인자는 정확히 `--input <로그파일> --db <sqlite경로>` 두 개만** 받는다.
  - argparse 사용. 다른 인자(`--output`, `--format` 등) **금지** — 채점/호출은 두 인자만 사용.
  - 파일 인코딩 자동 감지 (utf-8 → cp949 → latin-1 순).
- **라인 포맷 유의** (위 샘플 참고):
  - 구조: `타임스탬프\\t\\t이벤트코드\\t\\tKEY=VALUE  KEY=VALUE  ...`
  - `parts[0]` = **타임스탬프** (예: `2026-04-19 09:30:00.263`), `parts[1]` = **이벤트코드** (예: `EVT#SYS100` 또는 `SC701`)
  - 탭이 **연속(\\t\\t)** 으로 나올 수 있음 → `split('\\t')` 결과에서 **빈 필드 제거** 필수.
  - **이벤트 코드의 `EVT#` 접두사는 선택적** — 있을 수도 없을 수도 있다.
    - 정규화: `code = raw_code[4:] if raw_code.startswith('EVT#') else raw_code`
    - 비교는 정규화된 코드(`AL100`, `EX500`, `SC701` 등) 기준.
    - 예: `EVT#AL100` → `AL100`, `SC701` → `SC701` 둘 다 최종 `SC701.startswith('SC')` 형태로 매칭되어야 함.
  - **빈 줄** 이 데이터 사이사이에 섞여 있을 수 있음 → `line.strip()` 비어 있으면 건너뛴다.
  - 주석 라인(`#` 으로 시작)은 **있을 수도 없을 수도** 있음 — 방어적으로 건너뛰면 됨.
- **타임스탬프 기준 순차 처리**. 라인 파싱 → 이벤트 객체 생성.
- **페어링 패턴 4종**을 모두 구현:
  - Simple: start 이벤트 → end 이벤트 매칭 (엔티티 키 일치)
  - Group: 헤더 → 바디(반복) → 결과 구조. 중간은 attributes에 수집
  - Conditional: 필드값으로 severity 분기 (예: Result=NG → severity=NG)
  - EntityKey: Wafer/Robot 등 키로 모션 분리
- **중첩 모션**: parent_motion_id 컬럼에 부모 row id 저장.
- **페어링 타임아웃**: 30초 초과 미완성 페어는 flush (end_ts=null, severity='TIMEOUT').
- **SQLite 저장**: 아래 스키마를 **컬럼명·순서 그대로** 사용. 컬럼을 줄이거나 이름을 바꾸지 말 것.
```
{schema}
```
- attributes 필드는 **JSON 문자열**로 저장 (json.dumps).
- **note 컬럼**: 스크립트 시작 시 `Path(__file__).parent / "motion_notes.json"` 을 읽어
  `{{motion_type: 한글설명}}` 매핑을 메모리에 로드. INSERT 시 `note = notes.get(motion_type)` 주입.
  파일이 없거나 JSON 오류면 빈 dict 로 fallback (note=NULL 로 동작).
- **라인 파싱 실패는 건너뛰기** (조용히 무시).
- `if __name__ == "__main__":` 블록에서 argparse 실행.

**반드시 ```python 펜스로 감싼 완전한 실행 가능 코드만** 출력하세요. 설명 금지."""


PROMPT_RETRY = """이전에 생성한 parser_v1.py 실행 시 아래 에러가 발생했습니다.

[에러 트레이스백]
```
{traceback}
```

[stdout]
```
{stdout}
```

[stderr]
```
{stderr}
```

위 에러를 수정한 parser_v1.py **전체 코드**를 다시 작성하세요.

**반드시 지켜야 할 스펙** (재고지):
- CLI 인자는 **정확히 `--input <로그파일> --db <sqlite경로>`** 만 받는다. 다른 인자 금지.
- 지정된 `--db` 경로에 SQLite 를 생성하고, `motion_events` 테이블을 만들고, **실제 이벤트를 1건 이상 저장**해야 한다.
- **스키마는 아래 그대로 사용** — 컬럼 축소/이름 변경 금지 (필수 컬럼: `motion_type`, `motion_start_ts`).
```
{schema}
```
- 라인 파싱: `parts[0]`=타임스탬프, `parts[1]`=이벤트코드. 연속 탭 빈 필드 제거 필수.
- **`EVT#` 접두사는 선택적** — 있으면 벗기고, 없으면 그대로 사용. `code = raw[4:] if raw.startswith('EVT#') else raw` 로 정규화 후 비교.
- **빈 줄** 은 건너뛴다. 주석 라인(`#` 으로 시작)도 방어적으로 건너뛴다.
- **단순 INSERT 로 끝내지 말 것**: motion 페어링 (Start/End 매칭)을 구현해 `motion_start_ts` / `motion_end_ts` / `duration_sec` 을 채워야 한다.

[실제 로그 샘플]
```
{log_samples}
```

**코드 블록은 단 1개만** — ```python 펜스로 감싼 완전한 실행 가능 코드만 출력하세요. 설명/예시/부분 스니펫 금지."""


_CODE_BLOCK_RE = re.compile(r"```(?:python|py)?\s*\n?(.*?)```", re.DOTALL)


class CodeExtractionError(Exception):
    """LLM 응답에서 실행 가능한 Python 코드 블록을 찾지 못했을 때."""


def _is_valid_python(src: str) -> bool:
    try:
        _ast.parse(src)
        return True
    except Exception:
        return False


def _extract_code(response: str) -> str:
    """
    LLM 응답에서 실행 가능한 Python 코드를 추출.
    - 모든 ```...``` 블록을 수집.
    - AST parse 가능한 블록만 유효 후보로 채택.
    - 유효한 후보 중 **가장 긴 것** 선택.
    - 유효 후보가 없으면 CodeExtractionError 발생 → sandbox에서 잡아서 다음 iter 에 피드백.
      (이전 동작: 펜스 없으면 응답 전체를 코드로 가정 → 'Thinking Process:' 같은 reasoning 이
       코드로 취급되어 SyntaxError 무한 반복하던 버그.)
    """
    blocks = _CODE_BLOCK_RE.findall(response)
    candidates = [b.strip() for b in blocks if b.strip()]
    if not candidates:
        # 펜스가 하나도 없거나 매칭 실패 → 응답 전체가 직접 코드인지만 확인
        whole = response.strip()
        if whole and _is_valid_python(whole):
            return whole
        raise CodeExtractionError(
            "응답에 ```python ... ``` 코드 블록이 없거나 유효한 Python 코드가 아닙니다. "
            "응답 첫 부분: " + (response[:200].replace("\n", " ") or "(empty)")
        )
    valid = [c for c in candidates if _is_valid_python(c)]
    if not valid:
        raise CodeExtractionError(
            f"펜스 블록 {len(candidates)}개 추출됐으나 **전부 Python 구문 에러**.\n"
            f"블록 샘플: " + (candidates[0][:200].replace("\n", " "))
        )
    return max(valid, key=len)


def _prepare_sample_file() -> Path:
    sampled = st.session_state.get("sampled_lines", [])
    sample_lines = sampled[:SAMPLE_RUN_LINES]
    SAMPLE_RUN_FILE.write_text("\n".join(sample_lines), encoding="utf-8")
    # 이전 샌드박스 DB 제거 (멱등 실행)
    if SAMPLE_RUN_DB.exists():
        try:
            SAMPLE_RUN_DB.unlink()
        except Exception:
            pass
    return SAMPLE_RUN_FILE


def _run_sandbox(code: str, sample_file: Path) -> dict:
    """
    생성 코드를 exec 로 실행. sys.argv 를 CLI 형태로 세팅.
    성공 기준 = (1) 예외 없이 종료 + (2) motion_events 에 1건 이상 저장.
    반환: {'ok': bool, 'stdout': str, 'stderr': str, 'traceback': str}
    """
    old_argv = sys.argv
    sys.argv = [
        "parser_v1.py",
        "--input", str(sample_file),
        "--db", str(SAMPLE_RUN_DB),
    ]
    stdout_buf, stderr_buf = io.StringIO(), io.StringIO()
    result = {"ok": False, "stdout": "", "stderr": "", "traceback": ""}
    exec_ok = False
    try:
        globs: dict = {"__name__": "__main__", "__file__": "parser_v1.py"}
        with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
            exec(compile(code, "parser_v1.py", "exec"), globs)
        exec_ok = True
    except SystemExit as e:
        if (e.code or 0) == 0:
            exec_ok = True
        else:
            result["traceback"] = f"SystemExit(code={e.code})\n" + traceback.format_exc()
    except Exception:
        result["traceback"] = traceback.format_exc()
    finally:
        sys.argv = old_argv
        result["stdout"] = stdout_buf.getvalue()[-4000:]
        result["stderr"] = stderr_buf.getvalue()[-4000:]

    # 검증: motion_events 테이블에 실제로 1건 이상 저장됐는가
    if exec_ok:
        import sqlite3 as _sq
        if not SAMPLE_RUN_DB.exists():
            result["traceback"] = (
                "샌드박스 실행은 예외 없이 종료됐으나, 요구된 DB 파일이 생성되지 않았습니다.\n"
                f"기대 경로: {SAMPLE_RUN_DB}\n"
                "CLI 인자를 반드시 --input/--db 로 받고, 지정된 --db 경로에 SQLite 를 생성해야 합니다."
            )
        else:
            try:
                _c = _sq.connect(str(SAMPLE_RUN_DB))
                _cur = _c.cursor()
                _cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='motion_events'")
                has_table = _cur.fetchone() is not None
                row_count = 0
                cols: list[str] = []
                if has_table:
                    _cur.execute("PRAGMA table_info(motion_events)")
                    cols = [r[1] for r in _cur.fetchall()]
                    _cur.execute("SELECT COUNT(*) FROM motion_events")
                    row_count = _cur.fetchone()[0]
                _c.close()

                required_cols = {"motion_type", "motion_start_ts"}
                missing = [c for c in required_cols if c not in cols]

                if not has_table:
                    result["traceback"] = (
                        "샌드박스 실행 성공, 그러나 'motion_events' 테이블이 없습니다.\n"
                        "요구된 스키마대로 CREATE TABLE motion_events (...) 를 수행하십시오."
                    )
                elif missing:
                    result["traceback"] = (
                        f"motion_events 테이블은 존재하나 **필수 컬럼이 누락** 되었습니다: {missing}\n"
                        f"현재 컬럼: {cols}\n"
                        "스키마를 임의로 축소/변경하지 말고, 주어진 13-컬럼 스키마를 그대로 사용하세요."
                    )
                elif row_count == 0:
                    result["traceback"] = (
                        "샌드박스 실행 성공, motion_events 테이블은 있으나 **저장된 이벤트가 0건** 입니다.\n"
                        "파싱 로직이 실제 로그 라인을 매칭하지 못하고 있습니다.\n"
                        "체크리스트:\n"
                        "  1) `parts[0]`=타임스탬프, `parts[1]`=이벤트코드 인지 확인 (자리를 바꾸지 마십시오).\n"
                        "  2) `split('\\t')` 후 빈 문자열 필드를 반드시 제거.\n"
                        "  3) `EVT#` 접두사는 선택적 — 있으면 벗기고, 없으면 그대로 사용 (양쪽 케이스 모두 처리).\n"
                        "  4) 빈 줄 건너뛰기 (`line.strip()` 이 비어있으면 skip).\n"
                        "  5) 샘플의 실제 이벤트 코드(AL100/EX500/SC701/TR1001/PA401 등)가 Start 매핑에 포함되는지 확인."
                    )
                else:
                    result["ok"] = True
                    result["stdout"] += f"\n[sandbox] motion_events rows inserted: {row_count}"
            except Exception:
                result["traceback"] = "DB 검증 실패:\n" + traceback.format_exc()
    return result


def _render_header() -> None:
    st.header("04 · Code Generation")
    st.caption("3개 .md 문서를 참조해 ReAct 루프로 parser_v1.py 자동 생성. 샘플 로그 실행 검증 → 실패 시 에러 포함 재생성. 최대 10회.")
    st.divider()


def _render_iterations(iterations: list[dict]) -> None:
    if not iterations:
        return
    for it in iterations:
        n = it["n"]
        status = it["status"]
        icon = {"done": "✅", "fail": "❌", "running": "🔄", "timeout": "⚠"}.get(status, "•")
        title = f"Iteration {n} — {icon} {it['title']}"
        with st.expander(title, expanded=(status == "running" or (status == "fail" and n == len(iterations)))):
            tab_think, tab_act, tab_observe = st.tabs(["Think", "Act", "Observe"])
            with tab_think:
                st.markdown(it.get("think", "_분석 준비 중_"))
            with tab_act:
                code = it.get("code", "")
                if code:
                    st.code(code, language="python")
                else:
                    st.markdown("_코드 생성 중..._")
            with tab_observe:
                obs = it.get("observe", {})
                if obs.get("ok"):
                    st.success("✓ 샌드박스 실행 성공")
                elif obs.get("traceback"):
                    st.error("❌ 실행 실패")
                    st.code(obs.get("traceback", ""), language="text")
                if obs.get("stdout"):
                    st.markdown("**stdout**")
                    st.code(obs["stdout"], language="text")
                if obs.get("stderr"):
                    st.markdown("**stderr**")
                    st.code(obs["stderr"], language="text")


def render() -> None:
    _render_header()

    template = file_manager.load_md("원시로그템플릿.md")
    events_v2 = file_manager.load_md("이벤트분석_v2.md")
    pairing_v2 = file_manager.load_md("모션_페어링_분석_v2.md")

    if not (template and events_v2 and pairing_v2):
        st.warning("⚠ Step 2/3 결과 md 가 없습니다. Step 2 → Step 3 를 먼저 완료하세요.")
        return

    # 참조 문서 뱃지
    st.info(
        "**참조 문서 3종** "
        "`원시로그템플릿.md` `이벤트분석_v2.md` `모션_페어링_분석_v2.md` "
        "→ 모두 LLM 컨텍스트에 주입 후 코드 생성."
    )

    # SQLite 스키마
    with st.expander("SQLite 스키마 — motion_events", expanded=False):
        st.code(SQLITE_SCHEMA, language="sql")

    existing_parser = file_manager.load_py("parser_v1.py")

    c1, c2 = st.columns([1, 4])
    with c1:
        clicked = st.button(
            "🔄 재생성" if existing_parser else "▶ 코드 생성 시작",
            type="primary",
            width="stretch",
            key="btn_gen_code",
        )
    with c2:
        if existing_parser:
            st.success("✓ `output/parser_v1.py` 저장됨. Step 5 활성화됨.")

    # 기존 iterations 표시
    _render_iterations(st.session_state.get("step4_iterations", []))

    if clicked:
        _run_react_loop(template, events_v2, pairing_v2)
        st.rerun()

    # 저장된 parser 전체 코드 표시
    if existing_parser:
        with st.expander("📄 parser_v1.py 보기", expanded=False):
            st.code(existing_parser, language="python")


def _run_react_loop(template: str, events_v2: str, pairing_v2: str) -> None:
    """ReAct 루프 본체. st.session_state 에 iterations 누적."""
    log_event("step4", "ReAct 루프 시작", f"max_iter={MAX_ITER}")
    run_dir = start_step4_run()  # debug-log/step4/run_<ts>/ 생성
    client = build_client_from_session()
    sample_file = _prepare_sample_file()

    # 프롬프트에 보여줄 실제 로그 샘플 몇 줄 (주석/빈줄 제외, 최대 10줄)
    sampled = st.session_state.get("sampled_lines", [])
    meaningful = [ln for ln in sampled if ln.strip() and not ln.lstrip().startswith("#")]
    log_samples = "\n".join(meaningful[:10]) or "(no sample available)"

    iterations: list[dict] = []
    st.session_state["step4_iterations"] = iterations

    progress = st.progress(0.0, text="ReAct 루프 시작...")

    last_error: dict | None = None
    last_code: str = ""

    for n in range(1, MAX_ITER + 1):
        progress.progress(n / MAX_ITER, text=f"Iteration {n}/{MAX_ITER}")

        # 프롬프트 선택
        if n == 1:
            user_prompt = PROMPT_INITIAL.format(
                template=template,
                events_v2=events_v2,
                pairing_v2=pairing_v2,
                schema=SQLITE_SCHEMA,
                log_samples=log_samples,
            )
            think = "1차 시도: 3개 md 분석 → MOTION_PAIRS 설계 → CLI 파서 작성."
        else:
            user_prompt = PROMPT_RETRY.format(
                traceback=(last_error or {}).get("traceback", ""),
                stdout=(last_error or {}).get("stdout", ""),
                stderr=(last_error or {}).get("stderr", ""),
                schema=SQLITE_SCHEMA,
                log_samples=log_samples,
            )
            think = f"재시도 {n}회: 이전 에러 트레이스백 분석 → 수정."

        it: dict = {
            "n": n,
            "title": "코드 생성 중",
            "status": "running",
            "think": think,
            "code": "",
            "observe": {},
        }
        iterations.append(it)

        # LLM 호출
        messages = [
            {"role": "system", "content": SYSTEM_CODER},
            {"role": "user", "content": user_prompt},
        ]
        _iter_start = _time.time()
        try:
            response = client.chat(
                messages, temperature=0.2, max_tokens=8000,
                step="step4", purpose=f"react_iter{n}",
            )
        except Exception as e:
            it["status"] = "fail"
            it["title"] = "LLM 호출 실패"
            it["observe"] = {"ok": False, "traceback": str(e), "stdout": "", "stderr": ""}
            log_event("step4", f"iter{n} LLM 실패", str(e))
            write_step4_iter(
                run_dir, n, think, user_prompt,
                llm_response="", extracted_code="",
                observe=it["observe"],
                extract_error=f"LLM 호출 실패: {e}",
                duration_sec=_time.time() - _iter_start,
            )
            break

        # 코드 추출 — 응답에 유효한 Python 코드 블록이 없으면 CodeExtractionError
        try:
            code = _extract_code(response)
        except CodeExtractionError as ex:
            obs = {
                "ok": False,
                "stdout": "",
                "stderr": "",
                "traceback": (
                    f"코드 추출 실패: {ex}\n\n"
                    "→ 응답은 **오직 한 개의 ```python ... ``` 펜스 블록** 안에 완전한 파이썬 코드만. "
                    "`Thinking Process:`, 별표 bullet(`*   **...**`), 설명 문장 등 **펜스 밖 텍스트는 일체 금지** 입니다."
                ),
            }
            last_code = ""
            it["code"] = response[:800]  # 디버그용 응답 일부 보관
            it["observe"] = obs
            log_event(
                "step4", f"iter{n} observe",
                f"ok=False code_extract_error tb_len={len(obs['traceback'])}",
            )
            it["status"] = "fail"
            it["title"] = "코드 추출 실패 → 재시도"
            last_error = obs
            write_step4_iter(
                run_dir, n, think, user_prompt,
                llm_response=response, extracted_code="",
                observe=obs, extract_error=str(ex),
                duration_sec=_time.time() - _iter_start,
            )
            continue

        last_code = code
        it["code"] = code

        # 샌드박스 실행
        obs = _run_sandbox(code, sample_file)
        it["observe"] = obs

        log_event(
            "step4",
            f"iter{n} observe",
            f"ok={obs['ok']} code_len={len(code)} tb_len={len(obs.get('traceback','')) if obs.get('traceback') else 0}",
        )

        if obs["ok"]:
            it["status"] = "done"
            it["title"] = "샘플 실행 성공 → parser_v1.py 저장"
            file_manager.save_py("parser_v1.py", code)
            st.session_state["step4_done"] = True
            progress.progress(1.0, text=f"✓ 완료 (iteration {n})")
            log_event("step4", "parser_v1.py 저장", f"iter={n}, {len(code)} chars")
            write_step4_iter(
                run_dir, n, think, user_prompt,
                llm_response=response, extracted_code=code,
                observe=obs, duration_sec=_time.time() - _iter_start,
            )
            break
        else:
            it["status"] = "fail"
            it["title"] = "샘플 실행 실패 → 재시도"
            last_error = obs
            write_step4_iter(
                run_dir, n, think, user_prompt,
                llm_response=response, extracted_code=code,
                observe=obs, duration_sec=_time.time() - _iter_start,
            )

    else:
        # MAX_ITER 도달
        if last_code:
            file_manager.save_py("parser_v1.py", last_code)
            log_event("step4", "MAX_ITER 도달", f"마지막 코드 저장 ({len(last_code)} chars)")
            st.warning(f"⚠ 최대 반복({MAX_ITER}) 도달. 마지막 코드를 parser_v1.py 에 저장했습니다. 수동 검토 필요.")

    st.session_state["step4_iterations"] = iterations

    # 최종 요약 저장
    if st.session_state.get("step4_done"):
        final_status = f"SUCCESS (iter {iterations[-1]['n']})"
    else:
        final_status = f"FAILED after {len(iterations)} iterations"
    finalize_step4_run(run_dir, iterations, final_status)
